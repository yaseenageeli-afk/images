local lastReports={};local previous;local airborne=0;local staminaSamples=0;local invincibleSamples=0
local shotState={weapon=0,ammo=0,clip=0,lastShot=0,lastReload=0,sameAmmo=0}
local blocked={};for _,weapon in ipairs(Config.Weapons.blocked) do blocked[GetHashKey(weapon)]=true end
local profiles={};for name,p in pairs(Config.Weapons.profiles) do profiles[GetHashKey(name)]=p end
function BF.Report(id,detail)
 local rule=Config.Checks[id];local now=GetGameTimer()
 if not rule or not rule.enabled or now<BF.allGrace or now<(BF.grace[id] or 0) then return end
 if now-(lastReports[id] or -100000)<Config.Client.reportCooldownSeconds*1000 then return end
 lastReports[id]=now;TriggerServerEvent('bofaisal:report',id,tostring(detail):sub(1,400))
end
local function resetSample(ped,now)
 previous={pos=GetEntityCoords(ped),at=now,health=GetEntityHealth(ped),armor=GetPedArmour(ped),ped=ped}
end
CreateThread(function()
 while true do
  Wait(Config.Client.intervalMs)
  local ped=PlayerPedId();local player=PlayerId();local now=GetGameTimer()
  if not NetworkIsPlayerActive(player) or IsEntityDead(ped) or IsPlayerSwitchInProgress() or IsScreenFadedOut() or IsCutsceneActive() then
   previous=nil;airborne=0;staminaSamples=0;invincibleSamples=0
  else
   local pos=GetEntityCoords(ped);local speed=GetEntitySpeed(ped)
   local vehicle=IsPedInAnyVehicle(ped,false);local swimming=IsPedSwimming(ped) or IsPedSwimmingUnderWater(ped)
   local jumping=IsPedJumping(ped);local falling=IsPedFalling(ped);local parachute=GetPedParachuteState(ped)
   local tools=BF.tools.freecam or BF.tools.spectate
   if previous and previous.ped==ped and now>=BF.allGrace then
    local moved=#(pos-previous.pos);local elapsed=math.max((now-previous.at)/1000,0.1)
    if not vehicle and not falling and moved>Config.Movement.teleportDistance and moved/elapsed>Config.Movement.maxFootSpeed*3 then BF.Report('teleport',('%.1f m / %.1f s'):format(moved,elapsed)) end
    if not vehicle and not swimming and not falling and not jumping and speed>Config.Movement.maxFootSpeed then BF.Report('speed',('%.1f m/s'):format(speed)) end
    if swimming and speed>Config.Movement.maxSwimSpeed then BF.Report('fast_swim',speed) end
    if jumping and GetEntityHeightAboveGround(ped)>Config.Movement.maxJumpHeight then BF.Report('super_jump',GetEntityHeightAboveGround(ped)) end
    if not vehicle and not swimming and not falling and not jumping and parachute<0 and IsEntityInAir(ped) and GetEntityHeightAboveGround(ped)>3 then
     airborne=airborne+elapsed;if airborne>Config.Movement.noclipAirSeconds and not tools then BF.Report('noclip','sustained unsupported airborne movement') end
    else airborne=0 end
    local health=GetEntityHealth(ped);local armor=GetPedArmour(ped)
    if health>Config.Movement.maxHealth or health-previous.health>40 then BF.Report('heal',health..' / '..previous.health) end
    if armor>Config.Movement.maxArmor or armor-previous.armor>40 then BF.Report('armor',armor..' / '..previous.armor) end
    if IsPedSprinting(ped) and GetPlayerSprintStaminaRemaining(player)>99 then staminaSamples=staminaSamples+1 else staminaSamples=0 end
    if staminaSamples>=10 then BF.Report('infinite_stamina','full stamina over repeated sprint samples') end
   end
   if GetPlayerInvincible(player) or (type(GetEntityCanBeDamaged)=='function' and not GetEntityCanBeDamaged(ped)) then
    invincibleSamples=invincibleSamples+1
    if invincibleSamples>=Config.Movement.godmodeSamples then BF.Report('godmode','invincibility flag') end
   else invincibleSamples=0 end
   if not tools and not IsPauseMenuActive() then
    if NetworkIsInSpectatorMode() then BF.Report('spectate','spectator flag') end
    if #(GetGameplayCamCoord()-pos)>80 and not IsCinematicCamRendering() and not vehicle then BF.Report('freecam','camera distance') end
   end
   if not IsEntityVisible(ped) or GetEntityAlpha(ped)<100 then BF.Report('invisibility','visibility/alpha flag') end
   if GetUsingseethrough() then BF.Report('thermal','thermal vision active') end
   if GetUsingnightvision() then BF.Report('nightvision','night vision active') end
   local weapon=GetSelectedPedWeapon(ped)
   if blocked[weapon] then BF.Report('blocked_weapon',weapon) end
   resetSample(ped,now)
  end
 end
end)
CreateThread(function()
 while true do
  Wait(Config.Client.vehicleIntervalMs)
  local ped=PlayerPedId();local vehicle=GetVehiclePedIsIn(ped,false)
  if vehicle~=0 and GetPedInVehicleSeat(vehicle,-1)==ped then
   if GetEntitySpeed(vehicle)>Config.Movement.maxVehicleSpeed then BF.Report('vehicle_speed',GetEntitySpeed(vehicle)) end
   if type(GetVehicleCheatPowerIncrease)=='function' and GetVehicleCheatPowerIncrease(vehicle)>Config.Movement.maxPowerMultiplier then
    BF.Report('vehicle_power',GetVehicleCheatPowerIncrease(vehicle))
   end
  end
 end
end)
-- Sample only selected configured firearms. Legitimate inventory/reload changes need grace.
CreateThread(function()
 while true do
  local ped=PlayerPedId();local weapon=GetSelectedPedWeapon(ped);local profile=profiles[weapon]
  if not profile or IsEntityDead(ped) then Wait(1000);shotState.weapon=0
  else
   Wait(50)
   local now=GetGameTimer();local ammo=GetAmmoInPedWeapon(ped,weapon)
   local hasClip,clip=GetAmmoInClip(ped,weapon)
   if shotState.weapon~=weapon then shotState={weapon=weapon,ammo=ammo,clip=clip or 0,lastShot=0,lastReload=0,sameAmmo=0} end
   if IsPedReloading(ped) and shotState.lastReload==0 then shotState.lastReload=now end
   if hasClip and clip>shotState.clip then
    if shotState.lastReload>0 and now-shotState.lastReload<profile.minReloadMs then BF.Report('fast_reload',now-shotState.lastReload) end
    shotState.lastReload=0
   end
   if IsPedShooting(ped) and not BF.tools.deleteTool then
    if shotState.lastShot>0 and now-shotState.lastShot<profile.minShotMs then BF.Report('weapon_rate',now-shotState.lastShot) end
    if ammo==shotState.ammo and clip==shotState.clip then shotState.sameAmmo=shotState.sameAmmo+1 else shotState.sameAmmo=0 end
    if shotState.sameAmmo>=8 then BF.Report('infinite_ammo','ammo unchanged across shooting samples') end
    shotState.lastShot=now
   end
   if hasClip and clip>profile.maxClip then BF.Report('infinite_ammo','clip over configured maximum') end
   shotState.ammo=ammo;shotState.clip=clip or 0
  end
 end
end)
CreateThread(function()
 Wait(Config.Client.startupGraceSeconds*1000)
 while true do
  local commands=GetRegisteredCommands();local set={}
  for _,cmd in ipairs(commands) do set[cmd.name:lower()]=true end
  for _,name in ipairs(Config.Events.suspiciousCommands) do if set[name:lower()] then BF.Report('menu_command',name) end end
  Wait(30000)
 end
end)
AddEventHandler('onClientResourceStop',function(resource)
 if resource==GetCurrentResourceName() then TriggerServerEvent('bofaisal:report','resource_stop','protection stopped (may be planned restart)') end
end)
