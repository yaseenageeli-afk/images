"""Browser integration tests for NUI with explicit mocked server data.
Install: pip install playwright && playwright install chromium
Run: python tests/test_ui.py
Generated docs/preview-*.png use synthetic fixtures, not a live FXServer.
"""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
import threading
import json
import base64
import shutil
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
PERMISSIONS=['menu','players','ban','unban','kick','mute','chat','chatBypass','entities','weapons','screenshot','monitor','teleport','freecam','esp','punishments','logs','bypass']
FIXTURE={
 'brand':'BoFaisal AntiCheat','language':'ar','counts':{'players':3,'vehicles':18,'peds':24,'objects':86,'bans':2},
 'permissions':{k:True for k in PERMISSIONS},'chatLocked':False,'tools':{},'chatMaxLength':250,'entityRadiusMax':500,
 'capabilities':{'screenshots':True,'clientPunishments':False,'onesync':True,'vrp':True},
 'monitor':{'maxTargets':12,'maxConcurrent':4,'intervalMs':2500},
 'players':[{'id':i,'name':name,'discord':str(1000000+i),'ping':35+i*4,'risk':risk,'muted':False} for i,name,risk in [(1,'BoFaisal',4),(2,'ناصر',36),(3,'<script>window.pwned=true</script>',75)]],
 'bans':[{'id':'BF-000001','name':'Test player','reason':'Test evidence','created':1791330000,'expires':1791934800,'evidence':True},
         {'id':'BF-000002','name':'Test player 2','reason':'Permanent test ban','created':1791340000,'expires':0,'evidence':False}],
 'checks':[{'id':key,'kind':kind,'action':action,'enabled':enabled,'strikes':3,'banDays':7} for key,kind,action,enabled in [('noclip','client','alert',True),('weapon_damage','server','alert',True),('explosion','server','alert',True),('entity_spawn','server','alert',True),('lua_injection','server','alert',False),('heartbeat','server','alert',True)]],
 'events':[{'at':1791330000+i*600,'category':cat,'actor':1,'target':2,'code':code,'detail':'Synthetic UI test record','name':'ناصر'} for i,cat,code in [(1,'admin','teleport'),(2,'detection','noclip'),(3,'ban','ban')]],
 'chart':[{'at':1791244800+i*3600,'players':n,'detections':d} for i,(n,d) in enumerate([(0,0),(0,0),(0,0),(0,0),(0,0),(1,0),(1,0),(2,1),(2,0),(3,0),(3,1),(2,0),(2,1),(3,2),(3,1),(2,0),(2,0),(3,1),(3,1),(3,0),(2,0),(2,1),(2,0),(3,0)])]
}
class QuietHandler(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(ROOT/'web')))
threading.Thread(target=server.serve_forever,daemon=True).start()
requests=[];errors=[];passed=[]

def check(condition,name):
 assert condition,name
 passed.append(name)
 print('PASS',name)

with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=shutil.which("chromium"))
 page=browser.new_page(viewport={'width':1400,'height':900},device_scale_factor=1)
 page.on('pageerror',lambda err:errors.append(str(err)))
 def backend(route):
  body=route.request.post_data_json or {}
  requests.append(body)
  if body.get('action')=='snapshot':response={'ok':True,'data':FIXTURE}
  else:response={'ok':True,'data':'ok'}
  route.fulfill(status=200,content_type='application/json',headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST, OPTIONS'},body=json.dumps(response))
 page.route('https://bofaisal-anticheat/**',backend)
 page.goto(f'http://127.0.0.1:{server.server_port}/index.html')
 check(page.locator('#app').is_hidden(),'NUI stays hidden until server snapshot')
 page.evaluate('(data)=>window.postMessage({type:"open",data},"*")',FIXTURE)
 page.wait_for_selector('#app',state='visible')
 check(page.locator('html').get_attribute('dir')=='rtl','Arabic RTL enabled')
 check(page.locator('.stat-value').count()==6,'Six dashboard statistics rendered')
 ROOT.joinpath('docs').mkdir(exist_ok=True)
 page.locator('#app').screenshot(path=str(ROOT/'docs/preview-ar.png'))
 for name in ['entities','weapons','players','monitor','tools','chat','bans','policies','events','settings','dashboard']:
  page.locator(f'#nav [data-page="{name}"]').click()
  check(page.locator('#page-name').inner_text()!='',f'{name} page renders')
  check(page.locator('#content').evaluate('(el)=>el.scrollWidth<=el.clientWidth+2'),f'{name} page fits container')
 page.locator('#nav [data-page="players"]').click()
 check(page.evaluate('window.pwned===undefined'),'Player names do not execute HTML')
 page.locator('#search').fill('ناصر')
 check(page.locator('tbody tr').count()==1,'Player search filters Arabic names')
 page.locator('[data-action="banForm"]').click()
 page.locator('[name="reason"]').fill('Browser regression reason')
 page.locator('[name="days"]').fill('14')
 page.locator('#action-form [type="submit"]').click()
 page.wait_for_function('() => !document.querySelector("#dialog").open')
 check(any(x.get('action')=='ban' and x['payload']=={'target':2,'reason':'Browser regression reason','days':14} for x in requests),'Ban form sends validated target, reason and duration')
 page.locator('#nav [data-page="tools"]').click()
 page.locator('[data-tool="esp"]').check()
 check(any(x.get('action')=='tool' and x['payload']=={'tool':'esp','enabled':True} for x in requests),'ESP toggle invokes server action')
 page.locator('#nav [data-page="policies"]').click()
 page.locator('[data-policy="noclip"][data-policy-action="none"]').click()
 check(any(x.get('action')=='policy' and x['payload']['id']=='noclip' and x['payload']['action']=='none' for x in requests),'Policy change is persisted through server RPC')
 page.locator('#nav [data-page="entities"]').click()
 page.locator('[data-action="cleanupForm"]').first.click()
 page.locator('#action-form [type="submit"]').click()
 page.wait_for_function('() => !document.querySelector("#dialog").open')
 check(any(x.get('action')=='cleanup' and x['payload']['ignoreOccupied'] is True for x in requests),'Cleanup confirmation preserves occupied vehicles')
 page.locator('#nav [data-page="monitor"]').click()
 page.locator('[data-monitor-target="2"]').check()
 page.locator('#monitor-toggle').click()
 page.wait_for_timeout(2700)
 check(any(x.get('action')=='monitorFrame' and x['payload']['target']==2 for x in requests),'Monitoring schedules authorized frame requests')
 jpeg='data:image/jpeg;base64,'+base64.b64encode(page.screenshot(type='jpeg')).decode()
 page.evaluate('(data)=>window.postMessage({type:"frame",data},"*")',{'target':2,'ok':True,'data':jpeg})
 page.wait_for_selector('.monitor-tile img')
 page.locator('.monitor-tile').click()
 check(page.locator('.capture-full').is_visible(),'Monitoring tile opens larger capture')
 page.locator('#dialog-cancel').click()
 page.locator('#nav [data-page="dashboard"]').click()
 page.locator('#language').click()
 check(page.locator('html').get_attribute('dir')=='ltr','English LTR enabled')
 check(page.locator('#page-name').inner_text()=='Overview','English menu translated')
 page.locator('#app').screenshot(path=str(ROOT/'docs/preview-en.png'))
 page.set_viewport_size({'width':1000,'height':700})
 check(page.locator('#app').evaluate('(el)=>el.getBoundingClientRect().right<=window.innerWidth'),'Panel fits smaller viewport')
 limited={**FIXTURE,'permissions':{k:k=='menu' for k in PERMISSIONS}}
 page.evaluate('(data)=>window.postMessage({type:"open",data},"*")',limited)
 check(page.locator('#nav [data-page="players"]').count()==0,'Unauthorized players navigation hidden')
 check(page.locator('#nav [data-page="bans"]').count()==0,'Unauthorized bans navigation hidden')
 page.locator('#close').click()
 check(page.locator('#app').is_hidden(),'Close releases NUI visibility')
 check(not errors,'No browser runtime errors: '+str(errors))
 page.evaluate('()=>{const en=Object.keys(LOCALES.en),ar=Object.keys(LOCALES.ar);if(en.some(k=>!ar.includes(k))||ar.some(k=>!en.includes(k)))throw Error("Locale mismatch")}')
 check(True,'Arabic and English dictionaries have equal coverage')
 browser.close()
server.shutdown()
print(f'\n{len(passed)} browser checks passed; previews contain explicitly mocked test data.')
