AC = { players={}, rates={}, strikes={}, grace={}, permits={}, weaponGrants={}, sessions={},
 tools={}, pendingShots={}, shotActive=0, shotByAdmin={}, chatLocked=false, dirty=false }
AC.Resource=GetCurrentResourceName()
function AC.T(key) return (Config.Locales[Config.Language] or Config.Locales.en)[key] or key end
function AC.SafeString(value,max) return tostring(value or ''):gsub('[%z\1-\31\127]',''):sub(1,max or 240) end
function AC.Int(value,min,max)
 local n=tonumber(value)
 if not n or n~=n or n%1~=0 or n<min or n>max then return nil end
 return n
end
function AC.Identifiers(src)
 local out={}
 for _,id in ipairs(GetPlayerIdentifiers(src)) do
  local kind=id:match('^([^:]+):')
  if kind and kind~='ip' then out[kind]=id end
 end
 return out
end
function AC.Keys(ids)
 local keys={}
 for _,kind in ipairs(Config.Connection.identifiers) do if ids[kind] then keys[#keys+1]=ids[kind] end end
 return keys
end
function AC.LoadStore()
 local raw=LoadResourceFile(AC.Resource,Config.Database.path)
 if not raw or raw=='' then AC.DB={version=1,sequence=0,bans={},events={},mutes={},metrics={}}; return end
 local ok,db=pcall(json.decode,raw)
 if not ok or type(db)~='table' or db.version~=1 or type(db.bans)~='table'
  or type(db.events)~='table' or type(db.mutes)~='table' or type(db.metrics)~='table' then
  error('BoFaisal: invalid database; restore data/store.json from backup. Refusing to discard bans.')
 end
 db.sequence=tonumber(db.sequence) or 0; AC.DB=db
end
function AC.Flush()
 if not AC.dirty then return true end
 local encoded=json.encode(AC.DB)
 -- Save the previous persisted state before replacing it; never silently discard bans.
 local old=LoadResourceFile(AC.Resource,Config.Database.path)
 if old then SaveResourceFile(AC.Resource,Config.Database.path..'.bak',old,#old) end
 local ok=SaveResourceFile(AC.Resource,Config.Database.path,encoded,#encoded)
 if ok then AC.dirty=false else print('[BoFaisal] ERROR: cannot persist database; check data directory permissions') end
 return ok
end
function AC.Event(category,actor,target,code,detail)
 local event={at=os.time(),category=category,actor=tonumber(actor) or 0,target=tonumber(target) or 0,
 code=AC.SafeString(code,80),detail=AC.SafeString(detail,500),name=AC.SafeString(GetPlayerName(target) or '',80)}
 AC.DB.events[#AC.DB.events+1]=event
 if #AC.DB.events>Config.Database.maxEvents then table.remove(AC.DB.events,1) end
 local hour=tostring(math.floor(event.at/3600)*3600)
 local m=AC.DB.metrics[hour] or {detections=0,peakPlayers=0}
 if category=='detection' then m.detections=m.detections+1 end
 m.peakPlayers=math.max(m.peakPlayers,#GetPlayers());AC.DB.metrics[hour]=m
 AC.dirty=true
 if AC.Log then AC.Log(category,event) end
 return event
end
function AC.ActiveBan(ids)
 local now=os.time()
 for _,ban in pairs(AC.DB.bans) do
  if not ban.revokedAt and (ban.expires==0 or ban.expires>now) then
   for _,id in ipairs(AC.Keys(ids)) do
    for _,stored in ipairs(ban.identifiers or {}) do if stored==id then return ban end end
   end
  end
 end
end
function AC.MuteExpiry(src)
 local now=os.time()
 for _,id in ipairs(AC.Keys(AC.Identifiers(src))) do
  local mute=AC.DB.mutes[id]
  if mute and (mute.expires==0 or mute.expires>now) then return mute.expires end
 end
 return nil
end
function AC.Prune()
 local cutoff=os.time()-Config.Database.retentionDays*86400
 for hour in pairs(AC.DB.metrics) do if tonumber(hour)<cutoff then AC.DB.metrics[hour]=nil end end
 local retained={}
 for _,event in ipairs(AC.DB.events) do if event.at>=cutoff then retained[#retained+1]=event end end
 AC.DB.events=retained
 for id,mute in pairs(AC.DB.mutes) do if mute.expires~=0 and mute.expires<os.time() then AC.DB.mutes[id]=nil end end
 AC.dirty=true
end
AC.LoadStore()
CreateThread(function()
 while true do Wait(Config.Database.flushSeconds*1000);AC.Prune();AC.Flush() end
end)
AddEventHandler('onResourceStop',function(resource) if resource==AC.Resource then AC.Flush() end end)
