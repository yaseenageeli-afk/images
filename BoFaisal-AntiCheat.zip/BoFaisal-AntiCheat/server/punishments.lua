function AC.Notify(src,message,kind)
 TriggerClientEvent('bofaisal:notify',src,{message=AC.SafeString(message,500),kind=kind or 'info',settings=Config.Notifications})
end
function AC.Has(src,cap)
 if src==0 then return true end
 if not Config.Permissions[cap] then return false end
 if IsPlayerAceAllowed(src,Config.Permissions[cap]) then return true end
 return AC.VRPPermission and AC.VRPPermission(src,Config.Permissions[cap]) or false
end
function AC.Alert(message)
 for _,id in ipairs(GetPlayers()) do local src=tonumber(id);if AC.Has(src,'logs') then AC.Notify(src,message,'danger') end end
end
function AC.BanText(ban)
 return AC.T('banned')..'\n'..AC.T('reason')..': '..ban.reason..'\n'..AC.T('banId')..': '..ban.id..
 '\n'..AC.T('date')..': '..os.date('!%Y-%m-%d %H:%M UTC',ban.created)..'\n'..AC.T('expires')..': '..
 (ban.expires==0 and AC.T('permanent') or os.date('!%Y-%m-%d %H:%M UTC',ban.expires))..'\n'..Config.AppealURL
end
function AC.Capture(actor,target,quality,callback,internal)
 if not Config.Screenshots.enabled or GetResourceState(Config.Screenshots.resource)~='started' then
  callback(false,'screenshot-basic unavailable');return
 end
 if not internal and (not AC.Has(actor,'screenshot') and not AC.Has(actor,'monitor')) then callback(false,'permission');return end
 if not GetPlayerName(target) then callback(false,'offline');return end
 if AC.shotActive>=Config.Screenshots.maxConcurrent or (AC.shotByAdmin[actor] or 0)>=Config.Screenshots.maxConcurrent then
  callback(false,'busy');return
 end
 AC.shotActive=AC.shotActive+1;AC.shotByAdmin[actor]=(AC.shotByAdmin[actor] or 0)+1
 local done=false;local targetIdentity=GetPlayerIdentifierByType(target,'license')
 local function finish(ok,data)
  if done then return end;done=true
  AC.shotActive=math.max(0,AC.shotActive-1);AC.shotByAdmin[actor]=math.max(0,(AC.shotByAdmin[actor] or 1)-1)
  if GetPlayerIdentifierByType(target,'license')~=targetIdentity then callback(false,'player changed');return end
  if not internal and actor~=0 and not GetPlayerName(actor) then return end
  callback(ok,data)
 end
 SetTimeout(Config.Screenshots.timeoutMs,function() finish(false,'timeout') end)
 local ok=pcall(function()
  exports[Config.Screenshots.resource]:requestClientScreenshot(target,{encoding='jpg',quality=Config.Screenshots.qualities[quality] or 0.45},function(err,data)
   if err or type(data)~='string' or #data>Config.Screenshots.maxBytes or not data:match('^data:image/jpeg;base64,') then finish(false,'capture failed');return end
   finish(true,data)
  end)
 end)
 if not ok then finish(false,'screenshot adapter failed') end
end
function AC.RecordBan(actor,target,reason,days,overrideName)
 local ids=AC.Identifiers(target);local keys=AC.Keys(ids)
 if #keys==0 then return nil,'Missing persistent identifiers' end
 AC.DB.sequence=AC.DB.sequence+1
 local ban={id=('BF-%06d'):format(AC.DB.sequence),created=os.time(),reason=AC.SafeString(reason,Config.AdminTools.reasonMaxLength),
 expires=days==0 and 0 or os.time()+days*86400,identifiers=keys,
 name=AC.SafeString(overrideName or GetPlayerName(target),80),actor=actor,discord=(ids.discord or ''):gsub('discord:','')}
 AC.DB.bans[ban.id]=ban;AC.dirty=true
 if not AC.Flush() then AC.DB.bans[ban.id]=nil;return nil,'Ban could not be saved' end
 return ban
end
function AC.Ban(actor,target,reason,days,callback)
 if not GetPlayerName(target) then return false,AC.T('offline') end
 local ban,error=AC.RecordBan(actor,target,reason,days)
 if not ban then return false,error end
 local identity=GetPlayerIdentifierByType(target,'license');local done=false
 local function finish(data)
  if done then return end;done=true
  if data then
   local filename='data/'..ban.id..'.evidence'
   if SaveResourceFile(AC.Resource,filename,data,#data) then ban.evidence=filename;AC.dirty=true;AC.Flush() end
  end
  AC.Event('ban',actor,target,'ban',ban.id..': '..ban.reason);AC.Flush()
  if GetPlayerIdentifierByType(target,'license')==identity and GetPlayerName(target) then
   local appeal=Config.AppealURL
   if not appeal:match('^https://discord%.gg/') and not appeal:match('^https://discord%.com/invite/') then appeal='' end
   TriggerClientEvent('bofaisal:banScreen',target,{id=ban.id,reason=ban.reason,created=ban.created,expires=ban.expires,appeal=appeal})
   SetTimeout(400,function()
    if GetPlayerIdentifierByType(target,'license')==identity then DropPlayer(target,AC.BanText(ban)) end
   end)
  end
  if callback then callback(true,ban.id) end
 end
 if Config.Screenshots.evidence then AC.Capture(actor,target,'medium',function(ok,data) finish(ok and data or nil) end,true)
 else finish() end
 return true,ban.id
end
function AC.Unban(actor,id)
 local ban=AC.DB.bans[id]
 if not ban or ban.revokedAt then return false,'Unknown or revoked ban' end
 ban.revokedAt=os.time();ban.revokedBy=actor;AC.dirty=true
 if not AC.Flush() then ban.revokedAt=nil;ban.revokedBy=nil;return false,'Database write failed' end
 AC.Event('admin',actor,0,'unban',id);return true,id
end
function AC.SetMute(actor,target,minutes)
 local keys=AC.Keys(AC.Identifiers(target));if #keys==0 then return false,'Missing identifiers' end
 local previous={}
 for _,id in ipairs(keys) do
  previous[id]=AC.DB.mutes[id]
  if minutes==nil then AC.DB.mutes[id]=nil
  else AC.DB.mutes[id]={expires=minutes==0 and 0 or os.time()+minutes*60,actor=actor} end
 end
 AC.dirty=true
 if not AC.Flush() then for _,id in ipairs(keys) do AC.DB.mutes[id]=previous[id] end;return false,'Mute could not be saved' end
 AC.Event('admin',actor,target,minutes==nil and 'unmute' or 'mute',tostring(minutes or ''))
 return true,'ok'
end
function AC.Detect(src,id,detail,origin)
 local rule=Config.Checks[id]
 if not rule or not rule.enabled or not GetPlayerName(src) or AC.Has(src,'bypass') then return end
 if origin=='client' and rule.kind~='client' and rule.kind~='mixed' then return end
 local grace=AC.grace[src]
 if grace and grace.expires>os.time() and (grace.all or grace.checks[id]) then return end
 local now=os.time();local key=src..':'..id
 local strike=AC.strikes[key] or {count=0,start=now,last=-100000,lastAlert=-100000}
 if now-strike.last<math.min(rule.cooldownSeconds or 30,5) then return end
 if now-strike.start>(rule.windowSeconds or 90) then strike.count=0;strike.start=now end
 strike.count=strike.count+1;strike.last=now;AC.strikes[key]=strike
 local state=AC.players[src];if state then state.risk=math.min(100,(state.risk or 0)+3) end
 AC.Event('detection',0,src,id,AC.SafeString(detail,400)..' ['..origin..']')
 if strike.count<(rule.strikes or 3) or now-strike.lastAlert<(rule.cooldownSeconds or 30) then return end
 strike.lastAlert=now
 local action=rule.action
 if origin=='client' and not Config.AllowClientPunishments and (action=='ban' or action=='kick') then action='alert' end
 if action=='alert' then AC.Alert(AC.T('alert')..': '..src..' / '..id)
 elseif action=='kick' then DropPlayer(src,AC.T('kick')..': '..id)
 elseif action=='ban' then AC.Ban(0,src,id,rule.banDays or 7) end
end
