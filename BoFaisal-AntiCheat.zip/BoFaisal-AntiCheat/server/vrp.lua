-- Original vRP Proxy/Tunnel adapter. This file is server-only.
-- ACE is always accepted; optional vRP permission strings use the same config names.
local vRP
local function reply(player,ok,message) AC.Notify(player,tostring(message or 'ok'),ok and 'success' or 'danger') end
local function dispatch(player,action,payload) reply(player,AC.Dispatch(player,action,payload)) end
local function prompt(player,text,default,callback)
 vRP.prompt({player,text,default or '',function(_,value) callback(AC.SafeString(value,240)) end})
end
local function selectPlayer(player,callback)
 prompt(player,'Player ID','',function(value)
  local target=AC.Int(value,1,65535)
  if not target or not GetPlayerName(target) then AC.Notify(player,AC.T('offline'));return end
  callback(target)
 end)
end
CreateThread(function()
 if not Config.VRP.enabled then return end
 local resource=Config.VRP.resource
 while GetResourceState(resource)=='starting' do Wait(500) end
 if GetResourceState(resource)~='started' then print('[BoFaisal] vRP not running; ACE commands/menu remain available.');return end
 local raw=LoadResourceFile(resource,'lib/utils.lua')
 if not raw then print('[BoFaisal] vRP lib/utils.lua missing');return end
 -- Load ONLY the installed, trusted framework's module loader.
 local loader,err=load(raw,'@'..resource..'/lib/utils.lua')
 if not loader then print('[BoFaisal] vRP loader incompatible');return end
 local ok=pcall(loader);if not ok or type(module)~='function' then print('[BoFaisal] vRP loader failed');return end
 local Proxy=module(resource,'lib/Proxy');vRP=Proxy.getInterface('vRP')
 AC.VRPPermission=function(src,permission)
  local ok,user=pcall(function() return vRP.getUserId({src}) end)
  if not ok or not user then return false end
  local success,allowed=pcall(function() return vRP.hasPermission({user,Config.VRP.permissionPrefix..permission}) end)
  return success and allowed==true
 end
 local function openPhone(player)
  local menu={name=Config.VRP.menuName,css={top='75px',header_color='rgba(30,140,240,0.85)'}}
  local function entry(label,cap,fn) if AC.Has(player,cap) then menu[label]={fn,''} end end
  entry('Open F10 panel / لوحة الحماية','menu',function() TriggerClientEvent('bofaisal:openMenu',player) end)
  entry('Online players / المتصلون','players',function()
   local list={name='Players / اللاعبين'}
   for _,id in ipairs(GetPlayers()) do local target=tonumber(id)
    list['['..id..'] '..GetPlayerName(target)]={function() AC.Notify(player,'ID: '..target..' / '..GetPlayerName(target)) end,''}
   end
   vRP.openMenu({player,list})
  end)
  entry('Lock / unlock chat • الشات','chat',function() dispatch(player,'chatLock',{locked=not AC.chatLocked}) end)
  entry('Clear chat / حذف الشات','chat',function() dispatch(player,'chatClear',{}) end)
  entry('Mute player / ميوت','mute',function() selectPlayer(player,function(target)
   prompt(player,'Minutes (0 = indefinite) / الدقائق','10',function(minutes) dispatch(player,'mute',{target=target,minutes=minutes}) end)
  end) end)
  entry('Unmute / فك الميوت','mute',function() selectPlayer(player,function(target) dispatch(player,'unmute',{target=target}) end) end)
  for _,kind in ipairs({'vehicle','ped','object'}) do local selectedKind=kind
   entry('Delete nearby '..kind..' / حذف القريب','entities',function() dispatch(player,'cleanup',{kind=selectedKind,scope='near',radius=100,ignoreOccupied=true}) end)
  end
  entry('Delete tool / سلاح الحذف','entities',function()
   local on=AC.tools[player] and AC.tools[player].deleteTool or false
   dispatch(player,'tool',{tool='deleteTool',enabled=not on})
  end)
  entry('Ban / حظر','ban',function() selectPlayer(player,function(target)
   prompt(player,'Days (0 = permanent) / الأيام','7',function(days)
    prompt(player,'Reason / السبب','',function(reason) dispatch(player,'ban',{target=target,days=days,reason=reason}) end)
   end)
  end) end)
  entry('Unban / فك الحظر','unban',function()
   local list={name='Bans / الباندات'}
   for id,ban in pairs(AC.DB.bans) do local banId=id
    if not ban.revokedAt and (ban.expires==0 or ban.expires>os.time()) then
     list[id..' '..ban.name]={function() dispatch(player,'unban',{id=banId}) end,ban.reason}
    end
   end
   vRP.openMenu({player,list})
  end)
  vRP.openMenu({player,menu})
 end
 for _,menuName in ipairs(Config.VRP.phoneMenus) do
  vRP.registerMenuBuilder({menuName,function(add,data)
   local player=data.player;if not player then return end
   local allowed=false
   for _,cap in ipairs({'menu','players','chat','mute','entities','ban','unban'}) do if AC.Has(player,cap) then allowed=true end end
   if allowed then add({[Config.VRP.menuName]={function() openPhone(player) end,'Server-authorized administration'}}) end
  end})
 end
 print('[BoFaisal] Original vRP phone adapter registered')
end)
