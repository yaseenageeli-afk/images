function AC.Rate(src,key,limit,window)
 local now=GetGameTimer();AC.rates[src]=AC.rates[src] or {}
 local r=AC.rates[src][key]
 if not r or now-r.start>=window*1000 then r={start=now,count=0};AC.rates[src][key]=r end
 r.count=r.count+1;return r.count<=limit
end
function AC.HashSet(list)
 local out={};for _,name in ipairs(list or {}) do out[type(name)=='number' and name or GetHashKey(name)]=true end;return out
end
AC.Blocked={vehicle=AC.HashSet(Config.Entities.blockedVehicles),ped=AC.HashSet(Config.Entities.blockedPeds),object=AC.HashSet(Config.Entities.blockedObjects)}
AC.BlockedWeapons=AC.HashSet(Config.Weapons.blocked)
local function unsigned(hash) return math.floor(tonumber(hash) or 0)%4294967296 end
local profiles={};for name,p in pairs(Config.Weapons.profiles) do profiles[unsigned(GetHashKey(name))]=p end
local blockedDamageWeapons={};for _,name in ipairs(Config.Weapons.blocked) do blockedDamageWeapons[unsigned(GetHashKey(name))]=true end
local function permitted(src,kind,model)
 local p=AC.permits[src]
 if not p or p.expires<os.time() then return false end
 if p.kind~=kind and p.kind~='all' then return false end
 if p.models and not p.models[model] then return false end
 if p.remaining<1 then return false end
 p.remaining=p.remaining-1;return true
end
local function trustedExport()
 local caller=GetInvokingResource();return caller and caller~=AC.Resource
end
exports('GrantGrace',function(src,seconds,checks)
 if not trustedExport() then return false end
 src=AC.Int(src,1,65535);seconds=AC.Int(seconds,1,300)
 if not src or not seconds or not GetPlayerName(src) then return false end
 local set={};for _,id in ipairs(type(checks)=='table' and checks or {}) do if Config.Checks[id] then set[id]=true end end
 AC.grace[src]={expires=os.time()+seconds,all=checks==nil,checks=set}
 TriggerClientEvent('bofaisal:grace',src,seconds,checks);return true
end)
exports('PermitSpawn',function(src,kind,models,count,seconds)
 if not trustedExport() then return false end
 src=AC.Int(src,1,65535);count=AC.Int(count or 1,1,Config.Entities.maxPermitCount)
 seconds=AC.Int(seconds or Config.Entities.permissionsTTL,1,60)
 if not src or not count or not seconds or (kind~='vehicle' and kind~='ped' and kind~='object' and kind~='all') then return false end
 AC.permits[src]={kind=kind,models=type(models)=='table' and AC.HashSet(models) or nil,remaining=count,expires=os.time()+seconds};return true
end)
exports('PermitWeapon',function(src,weapon,seconds)
 if not trustedExport() then return false end
 src=AC.Int(src,1,65535);seconds=AC.Int(seconds or Config.Weapons.grantsTTLSeconds,1,3600)
 if not src or not seconds or type(weapon)~='string' then return false end
 AC.weaponGrants[src]=AC.weaponGrants[src] or {};AC.weaponGrants[src][GetHashKey(weapon)]=os.time()+seconds;return true
end)
exports('RegisterProtectedEvent',function(name,handler)
 if not trustedExport() or type(name)~='string' or type(handler)~='function' then return false end
 local policy=Config.Events.protected[name];if not policy then return false end
 AC.protectedRegistered=AC.protectedRegistered or {};if AC.protectedRegistered[name] then return false end
 AC.protectedRegistered[name]=true
 RegisterNetEvent(name);AddEventHandler(name,function(...)
  local src=tonumber(source);if not src or src<=0 then return end
  if not AC.Rate(src,'protected:'..name,policy.burst,policy.windowSeconds) then
   AC.Detect(src,'event_spam',name,'server');return
  end
  if policy.permission and not IsPlayerAceAllowed(src,policy.permission) then AC.Detect(src,'protected_event',name,'server');return end
  -- The integrating resource validates ownership, schema, amounts and session state.
  local ok,err=pcall(handler,src,...)
  if not ok then print('[BoFaisal] protected handler failed: '..name) end
 end);return true
end)
RegisterNetEvent('bofaisal:report',function(id,detail)
 local src=source
 if type(id)~='string' or type(detail)~='string' or #detail>400 then return end
 if not AC.Rate(src,'report',Config.Events.reportBurst,Config.Events.reportWindowSeconds) then AC.Detect(src,'event_spam','reports','server');return end
 if AC.players[src] and os.time()-AC.players[src].joined<Config.Client.startupGraceSeconds then return end
 AC.Detect(src,id,detail,'client')
end)
RegisterNetEvent('bofaisal:heartbeat',function()
 local src=source;if not AC.Rate(src,'heartbeat',3,10) then return end
 if AC.players[src] then AC.players[src].heartbeat=os.time() end
end)
AddEventHandler('entityCreating',function(entity)
 local owner=NetworkGetEntityOwner(entity)
 if not owner or owner<=0 or not GetPlayerName(owner) then return end
 local typ=GetEntityType(entity);local kind=({[1]='ped',[2]='vehicle',[3]='object'})[typ]
 if not kind then return end
 local model=GetEntityModel(entity)
 if AC.Has(owner,'bypass') or permitted(owner,kind,model) then return end
 local code='blocked_'..kind
 if AC.Blocked[kind][model] and Config.Checks[code].enabled then CancelEvent();AC.Detect(owner,code,tostring(model),'server');return end
 if Config.Checks.entity_spawn.enabled and not AC.Rate(owner,'spawn:'..kind,Config.Entities.limits[kind],Config.Entities.spawnWindowSeconds) then
  CancelEvent();AC.Detect(owner,'entity_spawn',kind,'server')
 end
end)
AddEventHandler('explosionEvent',function(sender,event)
 if type(event)~='table' or AC.Has(sender,'bypass') then return end
 local blocked=false;for _,id in ipairs(Config.Explosions.blockedTypes) do if event.explosionType==id then blocked=true end end
 local excessive=not AC.Rate(sender,'explosion',Config.Explosions.maxCount,Config.Explosions.windowSeconds)
 if Config.Checks.explosion.enabled and (blocked or excessive or (tonumber(event.damageScale) or 0)>Config.Explosions.maxDamageScale) then
  if Config.Explosions.cancelBlocked then CancelEvent() end
  AC.Detect(sender,'explosion',tostring(event.explosionType),'server')
 end
end)
AddEventHandler('fireEvent',function(sender,event)
 if not Config.Checks.fire.enabled or AC.Has(sender,'bypass') then return end
 local count=type(event)=='table' and (type(event.fires)=='table' and #event.fires or math.max(1,#event)) or 1
 local allowed=true
 for _=1,math.min(count,100) do if not AC.Rate(sender,'fire',Config.Explosions.maxFires,Config.Explosions.windowSeconds) then allowed=false;break end end
 if not allowed then CancelEvent();AC.Detect(sender,'fire',tostring(count),'server') end
end)
AddEventHandler('ptFxEvent',function(sender,event)
 if not Config.Checks.particles.enabled or AC.Has(sender,'bypass') or type(event)~='table' then return end
 local attached=false;local entity=NetworkGetEntityFromNetworkId(tonumber(event.entityNetId) or 0)
 if entity~=0 then
  for _,id in ipairs(GetPlayers()) do if tonumber(id)~=sender and GetPlayerPed(tonumber(id))==entity then attached=true;break end end
 end
 local rate=AC.Rate(sender,'ptfx',Config.Explosions.maxParticles,Config.Explosions.windowSeconds)
 local whitelisted=false
 for _,effect in ipairs(Config.Explosions.allowedParticleEffects) do
  if event.effectHash==(type(effect)=='number' and effect or GetHashKey(effect)) then whitelisted=true end
 end
 if not whitelisted and (not rate or (attached and Config.Explosions.blockParticlesOnOtherPlayers)) then
  CancelEvent();AC.Detect(sender,'particles','particle abuse','server')
 end
end)
AddEventHandler('weaponDamageEvent',function(sender,event)
 if type(event)~='table' or AC.Has(sender,'bypass') then return end
 local weapon=unsigned(event.weaponType);local profile=profiles[weapon]
 if blockedDamageWeapons[weapon] and Config.Checks.blocked_weapon.enabled then CancelEvent();AC.Detect(sender,'blocked_weapon',tostring(weapon),'server');return end
 if Config.Checks.weapon_spawn.enabled and Config.Weapons.enforceGrantedWeapons then
  local expiry=AC.weaponGrants[sender] and (AC.weaponGrants[sender][weapon] or AC.weaponGrants[sender][weapon-4294967296])
  if not expiry or expiry<os.time() then CancelEvent();AC.Detect(sender,'weapon_spawn',tostring(weapon),'server') end
 end
 if not profile then return end
 if Config.Checks.weapon_damage.enabled and event.overrideDefaultDamage and (tonumber(event.weaponDamage) or 0)>profile.maxDamage then
  CancelEvent();AC.Detect(sender,'weapon_damage',tostring(event.weaponDamage),'server')
 end
 local target=NetworkGetEntityFromNetworkId(tonumber(event.hitGlobalId) or 0);local ped=GetPlayerPed(sender)
 if Config.Checks.impossible_hit.enabled and target~=0 and ped~=0 then
  local distance=#(GetEntityCoords(ped)-GetEntityCoords(target))
  if distance>profile.maxRange then CancelEvent();AC.Detect(sender,'impossible_hit',('%.1f m'):format(distance),'server') end
 end
 -- hitGlobalIds is a multi-target array, not a trustworthy pellet count.
 -- weapon_pellets needs authoritative custom-weapon shot metadata; never infer it from this array.
end)
for _,kind in ipairs({'giveWeaponEvent','removeWeaponEvent','removeAllWeaponsEvent'}) do
 AddEventHandler(kind,function(sender,event)
  if AC.Has(sender,'bypass') or AC.Has(sender,'weapons') or type(event)~='table' then return end
  local entity=NetworkGetEntityFromNetworkId(tonumber(event.pedId) or 0)
  local other=false
  for _,id in ipairs(GetPlayers()) do if tonumber(id)~=sender and GetPlayerPed(tonumber(id))==entity then other=true;break end end
  local code=kind=='giveWeaponEvent' and 'weapon_give' or 'weapon_remove'
  if Config.Checks[code].enabled and (other or not AC.Rate(sender,'weapon-transfer',Config.Weapons.giveRemoveLimit,Config.Weapons.giveRemoveWindowSeconds)) then
   CancelEvent();AC.Detect(sender,code,kind,'server')
  end
 end)
end
for _,name in ipairs(Config.Events.honeypots) do
 RegisterNetEvent(name,function() AC.Detect(source,'executor','decoy:'..name,'server') end)
end
CreateThread(function()
 while true do
  Wait(15000)
  for src,state in pairs(AC.players) do
   if os.time()-state.joined>Config.Client.startupGraceSeconds and os.time()-state.heartbeat>Config.Client.heartbeatTimeoutSeconds then
    AC.Detect(src,'heartbeat','client unresponsive (may be network loss)','server')
   end
  end
 end
end)

-- Integrations may report only server-observed detections through a local export.
-- There is deliberately no network event for this trusted reporting channel.
exports('ReportDetection',function(src,id,detail)
 if not trustedExport() then return false end
 src=AC.Int(src,1,65535)
 local rule=type(id)=='string' and Config.Checks[id]
 if not src or not GetPlayerName(src) or not rule or (rule.kind~='server' and rule.kind~='mixed') then return false end
 AC.Detect(src,id,AC.SafeString(detail,400),'server');return true
end)
