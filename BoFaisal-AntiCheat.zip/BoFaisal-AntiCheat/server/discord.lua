local queue,avatars={},{}
local function webhook(category)
 local channel=category=='ban' and 'bans' or category=='detection' and 'detections' or 'admin'
 return GetConvar(Config.Discord.webhookConvars[channel],'')
end
function AC.Log(category,event)
 if not Config.Discord.enabled then return end
 local url=webhook(category)
 if not url:match('^https://discord%.com/api/webhooks/') and not url:match('^https://discordapp%.com/api/webhooks/') then return end
 if #queue>=Config.Discord.maxQueue then return end
 queue[#queue+1]={url=url,payload={username=Config.Brand,allowed_mentions={parse={}},embeds={{
 title=AC.SafeString(event.code,80),description=AC.SafeString(event.detail,500),
 color=category=='ban' and 15158332 or category=='detection' and 16753920 or 3447003,
 fields={{name='Actor / Target',value=tostring(event.actor)..' / '..tostring(event.target),inline=true},
 {name='Player',value=event.name~='' and event.name or '—',inline=true}},
 timestamp=os.date('!%Y-%m-%dT%H:%M:%SZ',event.at)}}}}
end
CreateThread(function()
 while true do
  Wait(Config.Discord.intervalMs)
  local item=table.remove(queue,1)
  if item then PerformHttpRequest(item.url,function(status,body,headers)
   if status==429 and (item.retries or 0)<2 then
    item.retries=(item.retries or 0)+1
    if #queue<Config.Discord.maxQueue then queue[#queue+1]=item end
   elseif status~=200 and status~=204 then print('[BoFaisal] Discord delivery failed ('..tostring(status)..')') end
  end,'POST',json.encode(item.payload),{['Content-Type']='application/json'}) end
 end
end)
function AC.Avatar(src)
 if not Config.Discord.bot.enabled then return nil end
 local id=(AC.Identifiers(src).discord or ''):match('discord:(%d+)')
 if not id then return nil end
 local entry=avatars[id]
 if entry then return entry.url end
 avatars[id]={}
 local token=GetConvar(Config.Discord.bot.tokenConvar,'')
 if token=='' then return nil end
 PerformHttpRequest('https://discord.com/api/v10/users/'..id,function(status,body)
  if status~=200 then return end
  local ok,user=pcall(json.decode,body)
  if ok and type(user)=='table' and type(user.avatar)=='string' and user.avatar:match('^[%w_]+$') then
   avatars[id]={url='https://cdn.discordapp.com/avatars/'..id..'/'..user.avatar..'.png?size=64'}
  end
 end,'GET','',{Authorization='Bot '..token})
 return nil
end
