Config = {}
Config.Language = 'ar'
Config.Brand = 'BoFaisal AntiCheat'
Config.AppealURL = 'https://discord.gg/CHANGE_ME'
Config.Command = 'acmenu'
Config.Key = 'F10'
Config.OneSyncRequired = true
Config.Database = { path = 'data/store.json', flushSeconds = 15, maxEvents = 5000, retentionDays = 31 }
Config.Permissions = {
 menu='bofaisal.menu', players='bofaisal.players', ban='bofaisal.ban', unban='bofaisal.unban',
 kick='bofaisal.kick', mute='bofaisal.mute', chat='bofaisal.chat', chatBypass='bofaisal.chat.bypass',
 entities='bofaisal.entities', weapons='bofaisal.weapons', screenshot='bofaisal.screenshot',
 monitor='bofaisal.monitor', teleport='bofaisal.teleport', freecam='bofaisal.freecam', esp='bofaisal.esp',
 punishments='bofaisal.punishments', logs='bofaisal.logs', bypass='bofaisal.bypass'
}
Config.Chat = { maxLength=250, burst=5, windowSeconds=10, maxMuteMinutes=10080,
 forbiddenWords={'كلمة_ممنوعة','forbidden_example'}, blockedNames={'admin impersonator','اسم_ممنوع'},
 maxNameCharacters=48, minNameCharacters=2 }
Config.Connection = {
 duplicateIdentifiers=true, identifiers={'license','license2','steam','fivem'},
 -- Optional VPN provider. Response must contain a Boolean vpn=true/false.
 -- Uses HTTPS only. The key stays in a server convar, never config shared with clients.
 vpn={enabled=false, url='https://YOUR_PROVIDER.example/check?ip=%s', keyConvar='bofaisal_vpn_key',
 header='Authorization', prefix='Bearer ', timeoutMs=5000, failClosed=false}
}
Config.Discord = { enabled=false, webhookConvars={detections='bofaisal_webhook_detections',
 bans='bofaisal_webhook_bans', admin='bofaisal_webhook_admin'},
 bot={enabled=false,tokenConvar='bofaisal_discord_bot_token'}, maxQueue=100, intervalMs=1500 }
Config.Notifications = { chat=true, toast=true, sound=true }
Config.Client = { intervalMs=2000, startupGraceSeconds=45, reportCooldownSeconds=20,
 heartbeatSeconds=15, heartbeatTimeoutSeconds=90, vehicleIntervalMs=3000 }
Config.Screenshots = { resource='screenshot-basic', enabled=true, timeoutMs=4000,
 maxBytes=1200000, transferBytesPerSecond=200000, evidence=true, qualities={low=0.25,medium=0.45,high=0.7},
 monitorIntervalMs=2500, maxConcurrent=4, maxTargets=12 }
Config.Entities = { radiusMax=500, batchSize=40, batchDelayMs=50, spawnWindowSeconds=10,
 limits={vehicle=10,ped=20,object=35}, permissionsTTL=15, maxPermitCount=100,
 -- Populate these lists with the models prohibited on YOUR server.
 blockedVehicles={'RHINO','LAZER','HYDRA'}, blockedPeds={'s_m_y_swat_01'},
 blockedObjects={'prop_ld_bomb','prop_gas_tank_01'},
 ignoreOccupiedVehicles=true }
Config.Weapons = {
 blocked={'WEAPON_RAILGUN','WEAPON_RPG','WEAPON_MINIGUN'},
 -- Only listed weapons are measured. Adjust to your custom weapon metadata.
 profiles={
 WEAPON_PISTOL={maxDamage=60,maxRange=180,minShotMs=80,maxClip=12,maxPellets=1,minReloadMs=500},
 WEAPON_COMBATPISTOL={maxDamage=65,maxRange=180,minShotMs=80,maxClip=12,maxPellets=1,minReloadMs=500},
 WEAPON_CARBINERIFLE={maxDamage=70,maxRange=450,minShotMs=35,maxClip=30,maxPellets=1,minReloadMs=500},
 WEAPON_PUMPSHOTGUN={maxDamage=250,maxRange=150,minShotMs=200,maxClip=8,maxPellets=12,minReloadMs=250}
 }, giveRemoveWindowSeconds=10, giveRemoveLimit=5,
 -- requires integration of PermitWeapon export by legitimate inventory resources
 enforceGrantedWeapons=false, grantsTTLSeconds=120,
 deleteToolWeapon='WEAPON_PISTOL'
}
Config.Movement = { maxFootSpeed=14, maxSwimSpeed=12, maxJumpHeight=7,
 teleportDistance=160, noclipAirSeconds=10, maxHealth=200, maxArmor=100,
 maxVehicleSpeed=160, maxPowerMultiplier=100, godmodeSamples=3 }
Config.Explosions = { windowSeconds=10, maxCount=6, maxDamageScale=2,
 blockedTypes={0,1,2,4,5,25,32,33,35,36,37,38}, cancelBlocked=true,
 maxFires=8, maxParticles=15, blockParticlesOnOtherPlayers=true,
 allowedParticleEffects={} }
Config.Events = {
 reportBurst=12, reportWindowSeconds=10, actionBurst=15, actionWindowSeconds=5,
 -- These are *decoy* events only. NEVER add events used by legitimate resources.
 honeypots={'bofaisal:decoy:grantMoney','bofaisal:decoy:runCode'},
 -- Only list known malicious client commands; strings are heuristics, not proof.
 suspiciousCommands={'lynxmenu','hammafia','brutan','redengine'},
 -- Register a protected server handler using exports[resource]:RegisterProtectedEvent.
 -- Do not put secrets/tokens in shared config. The server must validate every payload.
 protected={
 ['example:protectedPurchase']={burst=4,windowSeconds=10,permission=false}
 }
}
Config.Commands = { ban='acban', unban='acunban', kick='ackick', mute='acmute',
 unmute='acunmute', chatLock='acchatlock', chatClear='acchatclear', wipe='acwipe',
 strip='acstrip', screenshot='acshot' }
Config.VRP = { enabled=true, resource='vrp', permissionPrefix='', menuName='BoFaisal AntiCheat',
 phoneMenus={'phone'} }
Config.AdminTools = { freecamSpeed=8, freecamFastMultiplier=4, espDistance=200,
 espMaxPlayers=32, deleteDistance=100, maxBanDays=3650, reasonMaxLength=240 }
Config.Checks = {}
local function check(id,kind,action,extra)
 local c={enabled=true,kind=kind,action=action or 'alert',banDays=7,strikes=3,
 windowSeconds=90,cooldownSeconds=30}
 for k,v in pairs(extra or {}) do c[k]=v end
 Config.Checks[id]=c
end
-- Client detections are untrusted hints. Automatic client-only bans are OFF.
Config.AllowClientPunishments=false
check('noclip','client'); check('teleport','client'); check('spectate','client')
check('freecam','client'); check('super_jump','client'); check('speed','client')
check('infinite_stamina','client'); check('fast_swim','client'); check('godmode','client')
check('heal','client'); check('armor','client'); check('invisibility','client')
check('thermal','client'); check('nightvision','client')
check('weapon_damage','server'); check('weapon_recoil','client','alert',{enabled=false})
check('weapon_spread','client','alert',{enabled=false})
check('fast_reload','client'); check('weapon_rate','client'); check('weapon_pellets','server','alert',{enabled=false})
check('infinite_ammo','client'); check('blocked_weapon','mixed'); check('weapon_spawn','server','alert',{enabled=false})
check('impossible_hit','server'); check('weapon_give','server'); check('weapon_remove','server')
check('entity_spawn','server'); check('blocked_vehicle','server'); check('blocked_ped','server')
check('blocked_object','server'); check('vehicle_model','client','alert',{enabled=false})
check('vehicle_power','client'); check('vehicle_speed','client'); check('explosion','server')
check('fire','server'); check('particles','server'); check('executor','server')
check('lua_injection','server','alert',{enabled=false})
check('menu_command','client'); check('protected_event','server'); check('event_spam','server')
check('devtools','client','alert',{enabled=false})
check('resource_stop','client'); check('heartbeat','server')
check('fake_chat','server'); check('broadcast_abuse','server','alert',{enabled=false})
check('freeze_player','server','alert',{enabled=false})
check('vpn','connection','kick',{enabled=false,strikes=1}); check('duplicate_account','connection','kick',{strikes=1})
check('blocked_name','connection','kick',{strikes=1})
-- No generic reliable detection exists for disabled checks above. Integrate relevant
-- resources/weapon metadata; do not enable a placebo detector or auto-ban on a hint.
Config.Locales = {
 ar={banned='أنت محظور من السيرفر',reason='السبب',banId='رقم الحظر',date='التاريخ',
 expires='ينتهي',permanent='دائم',appeal='تقديم اعتراض',denied='ليست لديك صلاحية',
 muted='أنت مكتوم',chatLocked='الشات مقفل',filtered='الرسالة تحتوي كلمة ممنوعة',
 tooLong='الرسالة طويلة',duplicate='حسابك متصل بالفعل',nameRejected='اسم الدخول غير مسموح',
 vpnRejected='الاتصال عبر VPN غير مسموح',vpnUnavailable='تعذر التحقق من الاتصال، حاول لاحقًا',
 alert='تنبيه الحماية',kick='تم طردك',rateLimit='انتظر قبل تكرار العملية',offline='اللاعب غير متصل'},
 en={banned='You are banned from this server',reason='Reason',banId='Ban ID',date='Date',
 expires='Expires',permanent='Permanent',appeal='Appeal this ban',denied='Permission denied',
 muted='You are muted',chatLocked='Chat is locked',filtered='Message contains a blocked word',
 tooLong='Message is too long',duplicate='Your account is already connected',nameRejected='Invalid player name',
 vpnRejected='VPN connections are not allowed',vpnUnavailable='Connection check unavailable; try again',
 alert='Protection alert',kick='You were kicked',rateLimit='Please slow down',offline='Player is offline'}
}
