fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'BoFaisal'
description 'Server-authorized bilingual protection and administration'
version '1.0.0'
shared_script 'config.lua'
server_scripts {
 'server/database.lua', 'server/discord.lua', 'server/punishments.lua',
 'server/detections.lua', 'server/main.lua', 'server/commands.lua', 'server/vrp.lua'
}
client_scripts { 'client/main.lua', 'client/checks.lua', 'client/menu.lua' }
ui_page 'web/index.html'
files { 'web/index.html', 'web/style.css', 'web/app.js', 'web/locales.js' }
