-- توحيد رقم السيرفر؛ لا تُستخدم أرقام vRP بدل source في natives.
function AC.Source(value,console) return AC.Int(value,console and 0 or 1,65535) end
function AC.Name(value)
 local src=AC.Source(value);if not src then return nil end
 local ok,name=pcall(GetPlayerName,tostring(src))
 return ok and type(name)=='string' and name or nil
end
function AC.OneSync()
 local mode=GetConvar('onesync','off'):lower()
 return mode~='off' and mode~='false' and mode~='0' and mode~=''
end
function AC.Ped(src)
 if not AC.OneSync() or type(GetPlayerPed)~='function' then return 0 end
 src=AC.Source(src);if not src then return 0 end
 local ok,ped=pcall(GetPlayerPed,tostring(src))
 return ok and type(ped)=='number' and ped or 0
end
function AC.Session(src)
 src=AC.Source(src);if not src or not AC.Name(src) then return nil end
 AC.sessionCounter=(AC.sessionCounter or 0)+1
 if not AC.sessions[src] then AC.sessions[src]=AC.sessionCounter end
 return AC.sessions[src]
end
function AC.Identifiers(src)
 local out={};src=AC.Source(src);if not src then return out end
 if type(GetPlayerIdentifiers)=='function' then
  local ok,ids=pcall(GetPlayerIdentifiers,tostring(src))
  if ok and type(ids)=='table' then
   for _,id in pairs(ids) do if type(id)=='string' then local kind=id:match('^([^:]+):');if kind and kind~='ip' then out[kind]=id end end end
  end
 end
 if type(GetNumPlayerIdentifiers)=='function' then
  local ok,count=pcall(GetNumPlayerIdentifiers,tostring(src))
  if ok and type(count)=='number' then for i=0,count-1 do
   local good,id=pcall(GetPlayerIdentifier,tostring(src),i)
   if good and type(id)=='string' then local kind=id:match('^([^:]+):');if kind and kind~='ip' then out[kind]=id end end
  end end
 end
 if Config.Identity.allowVrpFallback and AC.UserId then
  local id=AC.UserId(src)
  if id then out.vrp='vrp:'..Config.VRP.resource..':'..tostring(id) end
 end
 return out
end
function AC.Keys(ids)
 local result,seen={},{}
 for _,kind in ipairs(Config.Connection.identifiers) do
  if type(ids[kind])=='string' and ids[kind]~='' and not seen[ids[kind]] then result[#result+1]=ids[kind];seen[ids[kind]]=true end
 end
 if Config.Identity.allowVrpFallback and ids.vrp and not seen[ids.vrp] then result[#result+1]=ids.vrp end
 return result
end
function AC.SameSession(src,session) return session~=nil and AC.sessions[src]==session and AC.Name(src)~=nil end
function AC.Finite(n) return type(n)=='number' and n==n and n~=math.huge and n~=-math.huge end
function AC.Position(p)
 if type(p)~='table' then return false end
 local bound=Config.AdminTools.worldBounds
 return AC.Finite(p.x) and AC.Finite(p.y) and AC.Finite(p.z) and math.abs(p.x)<=bound and math.abs(p.y)<=bound and math.abs(p.z)<=bound
end

AC.positions={};AC.positionSequence=0
function AC.RequestPosition(actor,target)
 AC.positionSequence=AC.positionSequence+1;local request=AC.positionSequence
 local actorSession,targetSession=AC.Session(actor),AC.Session(target)
 AC.positions[request]={actor=actor,target=target,actorSession=actorSession,targetSession=targetSession}
 SetTimeout(Config.AdminTools.positionTimeoutMs,function()
  local pending=AC.positions[request];AC.positions[request]=nil
  if pending and AC.SameSession(actor,actorSession) then AC.Notify(actor,AC.T('positionTimeout'),'danger') end
 end)
 TriggerClientEvent('bofaisal:positionRequest',target,request);return true,AC.T('positionRequested')
end
RegisterNetEvent('bofaisal:positionResult',function(request,pos)
 local src=AC.Source(source);local pending=AC.positions[AC.Int(request,1,2147483647)]
 if not src or not pending or pending.target~=src then return end
 if not AC.Position(pos) then return end
 AC.positions[request]=nil
 if not AC.SameSession(src,pending.targetSession) or not AC.SameSession(pending.actor,pending.actorSession) or not AC.Has(pending.actor,'teleport') then return end
 if AC.OneSync() then SetPlayerRoutingBucket(pending.actor,GetPlayerRoutingBucket(src)) end
 AC.grace[pending.actor]={expires=os.time()+15,all=true,checks={}}
 TriggerClientEvent('bofaisal:grace',pending.actor,15)
 TriggerClientEvent('bofaisal:teleport',pending.actor,{x=pos.x+1,y=pos.y+1,z=pos.z})
 AC.Event('admin',pending.actor,src,'teleport','client position fallback')
end)
