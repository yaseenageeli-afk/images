function AC.Notify(src,message,kind)
 TriggerClientEvent('bofaisal:notify',src,{message=AC.SafeString(message,500),kind=kind or 'info',settings=Config.Notifications})
end

function AC.Template(template,values)
 return template:gsub('{([%w_]+)}',function(key) return tostring(values[key] or '') end)
end
function AC.Announce(src,id,action,detail,rule)
 rule=rule or Config.Checks[id] or {}
 if rule.notify==false or not Config.Notifications.actions[action] then return end
 if action=='none' and not Config.Notifications.announceNone then return end
 local labels=Config.Language=='ar' and {warn='تحذير',kick='طرد',ban='باند',none='بدون عقوبة'} or {warn='Warning',kick='Kick',ban='Ban',none='None'}
 local message=AC.Template(Config.Notifications.templates[Config.Language] or Config.Notifications.templates.en,{
  name=AC.SafeString(AC.Name(src) or rule.name or '?',80),source=src,userId=AC.UserId(src) or '—',
  check=rule.label or id,action=labels[action] or action,detail=Config.Notifications.includeDetails and AC.SafeString(detail,240) or ''})
 local permission=rule.notifyPermission and rule.notifyPermission~='' and rule.notifyPermission or Config.Notifications.permission
 for _,idValue in ipairs(GetPlayers()) do local target=tonumber(idValue)
  if AC.HasPermission(target,permission) then AC.Notify(target,message,action=='ban' and 'danger' or 'warning') end
 end
end
function AC.Alert(message)
 for _,id in ipairs(GetPlayers()) do local src=tonumber(id);if AC.HasPermission(src,Config.Notifications.permission) then AC.Notify(src,message,'danger') end end
end
function AC.BanText(ban)
 return AC.T('banned')..'\n'..AC.T('reason')..': '..ban.reason..'\n'..AC.T('banId')..': '..ban.id..
 '\n'..AC.T('date')..': '..os.date('!%Y-%m-%d %H:%M UTC',ban.created)..'\n'..AC.T('expires')..': '..
 (ban.expires==0 and AC.T('permanent') or os.date('!%Y-%m-%d %H:%M UTC',ban.expires))..'\n'..Config.AppealURL
end

function AC.Capture(actor,target,quality,callback,internal)
 actor=AC.Source(actor,true);target=AC.Source(target)
 if not target or not AC.Name(target) then callback(false,AC.T('offline'));return end
 if not Config.Screenshots.enabled then callback(false,AC.T('captureDisabled'));return end
 if GetResourceState(Config.Screenshots.resource)~='started' then callback(false,AC.T('captureMissing'));return end
 if not internal and (not actor or (not AC.Has(actor,'screenshot') and not AC.Has(actor,'monitor'))) then callback(false,AC.T('denied'));return end
 if AC.shotActive>=Config.Screenshots.maxConcurrent or (AC.shotByAdmin[actor] or 0)>=Config.Screenshots.maxConcurrent then callback(false,AC.T('captureBusy'));return end
 AC.shotActive=AC.shotActive+1;AC.shotByAdmin[actor]=(AC.shotByAdmin[actor] or 0)+1
 AC.shotSequence=(AC.shotSequence or 0)+1;local request=AC.shotSequence
 local targetSession=AC.Session(target);local actorSession=actor~=0 and AC.Session(actor) or nil
 local done=false
 local function finish(ok,data)
  if done then return end;done=true;AC.pendingShots[request]=nil
  AC.shotActive=math.max(0,AC.shotActive-1);AC.shotByAdmin[actor]=math.max(0,(AC.shotByAdmin[actor] or 1)-1)
  if not AC.SameSession(target,targetSession) then callback(false,AC.T('playerChanged'));return end
  if not internal and actor~=0 and not AC.SameSession(actor,actorSession) then return end
  callback(ok,data)
 end
 local function received(err,data)
  if err and err~=false and err~='' then
   local key=({provider_missing='captureMissing',too_large='captureTooLarge',timeout='captureTimeout'})[err] or 'captureFailed'
   finish(false,AC.T(key));return end
  if type(data)~='string' then finish(false,AC.T('captureInvalid'));return end
  if #data>Config.Screenshots.maxBytes then finish(false,AC.T('captureTooLarge'));return end
  if not data:match('^data:image/jpeg;base64,[A-Za-z0-9+/=]+$') and not data:match('^data:image/png;base64,[A-Za-z0-9+/=]+$') and not data:match('^data:image/webp;base64,[A-Za-z0-9+/=]+$') then finish(false,AC.T('captureInvalid'));return end
  finish(true,data)
 end
 AC.pendingShots[request]={target=target,session=targetSession,received=received}
 SetTimeout(Config.Screenshots.timeoutMs,function() finish(false,AC.T('captureTimeout')) end)
 if Config.Screenshots.transport=='server' then
  local ok=pcall(function() exports[Config.Screenshots.resource]:requestClientScreenshot(target,{encoding='jpg',quality=Config.Screenshots.qualities[quality] or 0.45},received) end)
  if not ok then finish(false,AC.T('captureFailed')) end
 else
  TriggerClientEvent('bofaisal:captureRequest',target,request,quality or 'medium')
 end
end
RegisterNetEvent('bofaisal:captureResult',function(request,data,errorCode)
 local src=AC.Source(source);local pending=AC.pendingShots[AC.Int(request,1,2147483647)]
 if not src or not pending or pending.target~=src or not AC.SameSession(src,pending.session) then return end
 pending.received(errorCode,data)
end)
function AC.RecordBan(actor,target,reason,days,overrideName)
 local ids=AC.Identifiers(target);local keys=AC.Keys(ids)
 if #keys==0 then return nil,AC.T('missingIdentifiers') end
 AC.DB.sequence=AC.DB.sequence+1
 local ban={id=('BF-%06d'):format(AC.DB.sequence),created=os.time(),reason=AC.SafeString(reason,Config.AdminTools.reasonMaxLength),
 expires=days==0 and 0 or os.time()+days*86400,identifiers=keys,
 name=AC.SafeString(overrideName or AC.Name(target),80),actor=actor,discord=(ids.discord or ''):gsub('discord:','')}
 AC.DB.bans[ban.id]=ban;AC.dirty=true
 if not AC.Flush() then AC.DB.bans[ban.id]=nil;return nil,'Ban could not be saved' end
 return ban
end
function AC.Ban(actor,target,reason,days,callback)
 if not AC.Name(target) then return false,AC.T('offline') end
 local ban,error=AC.RecordBan(actor,target,reason,days)
 if not ban then return false,error end
 local identity=AC.Session(target);local done=false
 local function finish(data)
  if done then return end;done=true
  if data then
   local filename='data/'..ban.id..'.evidence'
   if SaveResourceFile(AC.Resource,filename,data,#data) then ban.evidence=filename;AC.dirty=true;AC.Flush() end
  end
  AC.Event('ban',actor,target,'ban',ban.id..': '..ban.reason);AC.Flush()
  if AC.Session(target)==identity and AC.Name(target) then
   local appeal=Config.AppealURL
   if not appeal:match('^https://discord%.gg/') and not appeal:match('^https://discord%.com/invite/') then appeal='' end
   TriggerClientEvent('bofaisal:banScreen',target,{id=ban.id,reason=ban.reason,created=ban.created,expires=ban.expires,appeal=appeal})
   SetTimeout(400,function()
    if AC.Session(target)==identity then DropPlayer(target,AC.BanText(ban)) end
   end)
  end
  if callback then callback(true,ban.id) end
 end
 if Config.Screenshots.evidence then AC.Capture(actor,target,'medium',function(ok,data) finish(ok and data or nil) end,true)
 else finish() end
 return true,ban.id
end
function AC.Unban(actor,id)
 local ban=AC.DB.bans[id]
 if not ban or ban.revokedAt then return false,'Unknown or revoked ban' end
 ban.revokedAt=os.time();ban.revokedBy=actor;AC.dirty=true
 if not AC.Flush() then ban.revokedAt=nil;ban.revokedBy=nil;return false,'Database write failed' end
 AC.Event('admin',actor,0,'unban',id);return true,id
end
function AC.SetMute(actor,target,minutes)
 local keys=AC.Keys(AC.Identifiers(target));if #keys==0 then return false,AC.T('missingIdentifiers') end
 local previous={}
 for _,id in ipairs(keys) do
  previous[id]=AC.DB.mutes[id]
  if minutes==nil then AC.DB.mutes[id]=nil
  else AC.DB.mutes[id]={expires=minutes==0 and 0 or os.time()+minutes*60,actor=actor} end
 end
 AC.dirty=true
 if not AC.Flush() then for _,id in ipairs(keys) do AC.DB.mutes[id]=previous[id] end;return false,'Mute could not be saved' end
 AC.Event('admin',actor,target,minutes==nil and 'unmute' or 'mute',tostring(minutes or ''))
 return true,'ok'
end
function AC.Detect(src,id,detail,origin)
 local rule=Config.Checks[id]
 src=AC.Source(src)
 if not src or not rule or not rule.enabled or not AC.Name(src) or AC.Bypass(src,id) then return end
 if origin=='client' and rule.kind~='client' and rule.kind~='mixed' then return end
 local grace=AC.grace[src]
 if grace and grace.expires>os.time() and (grace.all or grace.checks[id]) then return end
 local now=os.time();local key=src..':'..id
 local strike=AC.strikes[key] or {count=0,start=now,last=-100000,lastAlert=-100000}
 if now-strike.last<math.min(rule.cooldownSeconds or 30,5) then return end
 if now-strike.start>(rule.windowSeconds or 90) then strike.count=0;strike.start=now end
 strike.count=strike.count+1;strike.last=now;AC.strikes[key]=strike
 local state=AC.players[src];if state then state.risk=math.min(100,(state.risk or 0)+3) end
 AC.Event('detection',0,src,id,AC.SafeString(detail,400)..' ['..origin..']')
 if strike.count<(rule.strikes or 3) and Config.Notifications.announceBeforeThreshold then AC.Announce(src,id,'warn',detail,rule) end
 if strike.count<(rule.strikes or 3) or now-strike.lastAlert<(rule.cooldownSeconds or 30) then return end
 strike.lastAlert=now
 local action=rule.action
 if action=='alert' then action='warn' end
 if origin=='client' and not Config.AllowClientPunishments and (action=='ban' or action=='kick') then action='warn' end
 local reason=rule.message~='' and rule.message or rule.label or id
 if action=='ban' then
  local ok,err=AC.Ban(0,src,reason,rule.banDays or 7)
  if ok then AC.Announce(src,id,action,detail,rule) else AC.Alert(AC.T('banSaveFailed')..': '..tostring(err)) end
 elseif action=='kick' then AC.Announce(src,id,action,detail,rule);DropPlayer(src,AC.T('kick')..': '..reason)
 else AC.Announce(src,id,action,detail,rule) end
end
