local function playerState(src)
 AC.players[src]={joined=os.time(),heartbeat=os.time(),risk=0}
end
AddEventHandler('playerJoining',function() local src=AC.Source(source);if src then playerState(src);AC.Session(src) end end)
CreateThread(function() for _,id in ipairs(GetPlayers()) do playerState(tonumber(id)) end end)
AddEventHandler('playerDropped',function()
 local src=AC.Source(source)
 if not src then return end;local state=AC.tools[src]
 if state then for tool,on in pairs(state) do if on then AC.Event('admin',src,src,'tool_'..tool,'off: disconnect') end end end
 AC.players[src]=nil;AC.rates[src]=nil;AC.grace[src]=nil;AC.permits[src]=nil;AC.weaponGrants[src]=nil
 AC.sessions[src]=nil;AC.tools[src]=nil
 for id,pending in pairs(AC.connecting or {}) do if pending.source==src then AC.connecting[id]=nil end end
 for key in pairs(AC.strikes) do if key:match('^'..src..':') then AC.strikes[key]=nil end end
end)
local function safeAppeal() return Config.AppealURL:match('^https://') and Config.AppealURL or nil end
local function banCard(ban)
 local body={{type='TextBlock',text=AC.T('banned'),size='Large',weight='Bolder',wrap=true},
 {type='FactSet',facts={{title=AC.T('reason'),value=ban.reason},{title=AC.T('banId'),value=ban.id},
 {title=AC.T('date'),value=os.date('!%Y-%m-%d %H:%M UTC',ban.created)},
 {title=AC.T('expires'),value=ban.expires==0 and AC.T('permanent') or os.date('!%Y-%m-%d %H:%M UTC',ban.expires)}}}}
 local actions={};if safeAppeal() then actions={{type='Action.OpenUrl',title=AC.T('appeal'),url=safeAppeal()}} end
 return {type='AdaptiveCard',['$schema']='http://adaptivecards.io/schemas/adaptive-card.json',version='1.0',body=body,actions=actions}
end
AddEventHandler('playerConnecting',function(name,setKickReason,deferrals)
 local src=AC.Source(source)
 if not src then return end;deferrals.defer();Wait(0)
 local complete=false;local reserved={}
 AC.connecting=AC.connecting or {}
 local function finish(message)
  if complete then return end;complete=true
  if message then for _,id in ipairs(reserved) do
   if AC.connecting[id] and AC.connecting[id].source==src then AC.connecting[id]=nil end
  end end
  local ok,err
  if message~=nil then ok,err=pcall(deferrals.done,tostring(message)) else ok,err=pcall(deferrals.done) end
  if not ok then print('[BoFaisal] انتهت/أغلقت جلسة الدخول قبل الرد؛ source='..src) end
 end
 local function detected(id,message)
  local rule=Config.Checks[id]
  if not rule or not rule.enabled or AC.Bypass(src,id) then return false end
  AC.Event('detection',0,src,id,message)
  if rule.action=='alert' then rule.action='warn' end
  if rule.action=='warn' or rule.action=='none' then rule.name=name;AC.Announce(src,id,rule.action,message,rule) end
  if rule.action=='ban' then
   local recorded,err=AC.RecordBan(0,src,id,rule.banDays or 7,name)
   if recorded then AC.Announce(src,id,'ban',message,rule);AC.Event('ban',0,src,'ban',recorded.id..': '..id);AC.Flush();finish(AC.BanText(recorded))
   else finish('Protection database unavailable; try again later') end
   return true
  elseif rule.action=='kick' then AC.Announce(src,id,'kick',message,rule);finish(message);return true end
  return false
 end
 local ids=AC.Identifiers(src);local ban=AC.ActiveBan(ids)
 if ban then pcall(deferrals.presentCard,json.encode(banCard(ban)),function() end);Wait(1000);finish(AC.BanText(ban));return end
 local clean=AC.SafeString(name,200);local chars=utf8.len(clean)
 local invalid=not chars or chars<Config.Chat.minNameCharacters or chars>Config.Chat.maxNameCharacters or clean~=name
 for _,word in ipairs(Config.Chat.blockedNames) do if clean:lower():find(word:lower(),1,true) then invalid=true end end
 if invalid and detected('blocked_name',AC.T('nameRejected')) then return end
 if Config.Connection.duplicateIdentifiers and Config.Checks.duplicate_account.enabled then
  local duplicate=false
  for _,id in ipairs(AC.Keys(ids)) do
   local pending=AC.connecting[id]
   if pending and pending.source~=src and pending.expires>os.time() then duplicate=true end
  end
  for _,other in ipairs(GetPlayers()) do
   if tonumber(other)~=src then
    local otherIds=AC.Identifiers(tonumber(other))
    for _,kind in ipairs(Config.Connection.identifiers) do if ids[kind] and ids[kind]==otherIds[kind] then duplicate=true end end
   end
  end
  if duplicate and detected('duplicate_account',AC.T('duplicate')) then return end
  for _,id in ipairs(AC.Keys(ids)) do AC.connecting[id]={source=src,expires=os.time()+90};reserved[#reserved+1]=id end
 end
 local vpn=Config.Connection.vpn
 if not vpn.enabled or not Config.Checks.vpn.enabled then finish();return end
 if not vpn.url:match('^https://') or not vpn.url:find('%%s') then
  print('[BoFaisal] Invalid VPN URL');finish(vpn.failClosed and AC.T('vpnUnavailable') or nil);return
 end
 local ip=GetPlayerEndpoint(src) or '';ip=ip:gsub('([^%w%.%-])',function(c) return ('%%%02X'):format(c:byte()) end)
 local headers={};local key=GetConvar(vpn.keyConvar,'');if key~='' then headers[vpn.header]=vpn.prefix..key end
 SetTimeout(vpn.timeoutMs,function() finish(vpn.failClosed and AC.T('vpnUnavailable') or nil) end)
 local requestURL=vpn.url:gsub('%%s',function() return ip end)
 PerformHttpRequest(requestURL,function(status,body)
  if complete then return end
  local ok,data=pcall(json.decode,body or '')
  if status~=200 or not ok or type(data)~='table' or type(data.vpn)~='boolean' then finish(vpn.failClosed and AC.T('vpnUnavailable') or nil);return end
  if data.vpn and detected('vpn',AC.T('vpnRejected')) then return end
  finish()
 end,'GET','',headers)
end)
function AC.CheckChat(src,message,author)
 src=AC.Source(src);if not src then return false end
 if type(message)~='string' then return false end
 if author and author~=GetPlayerName(src) then AC.Detect(src,'fake_chat','author mismatch','server');return false end
 if AC.chatLocked and not AC.Has(src,'chatBypass') then AC.Notify(src,AC.T('chatLocked'));return false end
 if AC.MuteExpiry(src)~=nil then AC.Notify(src,AC.T('muted'));return false end
 local length=utf8.len(message)
 if not length or length>Config.Chat.maxLength or message:find('[%z\1-\8\11\12\14-\31]') then AC.Notify(src,AC.T('tooLong'));return false end
 if not AC.Rate(src,'chat',Config.Chat.burst,Config.Chat.windowSeconds) then AC.Notify(src,AC.T('rateLimit'));return false end
 if not AC.Has(src,'chatBypass') then
  for _,word in ipairs(Config.Chat.forbiddenWords) do
   if word~='' and message:lower():find(word:lower(),1,true) then AC.Notify(src,AC.T('filtered'));return false end
  end
 end
 return true
end
-- Stock FiveM chat's hook runs before broadcast. Custom chats must call CheckChat export.
local chatHooks={}
function AC.ChatHookStatus()
 local status={};for _,resource in ipairs(Config.Chat.resources) do status[resource]=chatHooks[resource]==true end;return status
end
local function hookChat()
 for _,resource in ipairs(Config.Chat.resources) do
  if not chatHooks[resource] and GetResourceState(resource)=='started' then
   local ok=pcall(function() exports[resource]:registerMessageHook(function(src,out,hook)
    src=AC.Source(src);if not src then return end
    local args=out.args or {};local message=args[#args]
    if not AC.CheckChat(src,message) then hook.cancel() end
   end) end)
   chatHooks[resource]=ok
   if not ok then print('[BoFaisal] '..resource..': '..AC.T('chatUnsupported')) end
  end
 end
end
AddEventHandler('onResourceStart',function(resource) for _,name in ipairs(Config.Chat.resources) do if resource==name then chatHooks[name]=nil;SetTimeout(500,hookChat) end end end)
AddEventHandler('onResourceStop',function(resource) chatHooks[resource]=nil end)
CreateThread(function() Wait(1000);hookChat() end)
AddEventHandler('chatMessage',function(src,author,message)
 src=AC.Source(src);if not src then return end
 -- The stock hook applies the policy before broadcast; avoid consuming chat rate twice.
 if not chatHooks.chat and not AC.CheckChat(src,message,author) then CancelEvent() end
end)
exports('CheckChat',function(src,message) src=AC.Source(src);return src and AC.CheckChat(src,message) or false end)
function AC.EntityCounts()
 if not AC.OneSync() then return {vehicles=0,peds=0,objects=0,available=false} end
 local playerPeds={};for _,id in ipairs(GetPlayers()) do playerPeds[AC.Ped(tonumber(id))]=true end
 local count=0;for _,ped in ipairs(GetAllPeds()) do if not playerPeds[ped] then count=count+1 end end
 return {vehicles=#GetAllVehicles(),peds=count,objects=#GetAllObjects(),available=true}
end
function AC.Snapshot(src,period)
 local online={}
 if AC.Has(src,'players') then
  for _,id in ipairs(GetPlayers()) do
   local target=tonumber(id);local ids=AC.Identifiers(target);local state=AC.players[target] or {}
   online[#online+1]={id=target,name=AC.SafeString(GetPlayerName(target),80),discord=(ids.discord or ''):gsub('discord:',''),
    userId=AC.UserId(target),avatar=AC.Avatar(target),ping=GetPlayerPing(target),risk=state.risk or 0,muted=AC.MuteExpiry(target)~=nil}
  end
  table.sort(online,function(a,b) if a.risk==b.risk then return a.id<b.id end;return a.risk>b.risk end)
 end
 local bans,events,checks={},{},{}
 if AC.Has(src,'ban') or AC.Has(src,'unban') then
  for _,ban in pairs(AC.DB.bans) do
   if not ban.revokedAt and (ban.expires==0 or ban.expires>os.time()) then
    bans[#bans+1]={id=ban.id,name=ban.name,reason=ban.reason,created=ban.created,expires=ban.expires,evidence=ban.evidence~=nil,actor=ban.actor}
   end
  end
  table.sort(bans,function(a,b)return a.created>b.created end)
 end
 if AC.Has(src,'logs') then for i=#AC.DB.events,math.max(1,#AC.DB.events-199),-1 do events[#events+1]=AC.DB.events[i] end end
 if AC.Has(src,'punishments') then
  for id,rule in pairs(Config.Checks) do checks[#checks+1]={id=id,enabled=rule.enabled,action=rule.action,kind=rule.kind,label=rule.label,strikes=rule.strikes,banDays=rule.banDays} end
  table.sort(checks,function(a,b)return a.id<b.id end)
 end
 local permissions={};for cap in pairs(Config.Permissions) do permissions[cap]=AC.Has(src,cap) end
 local counts=AC.EntityCounts();counts.players=#GetPlayers();counts.bans=0
 for _,ban in pairs(AC.DB.bans) do if not ban.revokedAt and (ban.expires==0 or ban.expires>os.time()) then counts.bans=counts.bans+1 end end
 local range=({day=24,week=168,month=720})[period] or 24
 local step=range==24 and 1 or 24;local chart={};local nowHour=math.floor(os.time()/3600)*3600
 for offset=range-step,0,-step do
  local point={at=nowHour-(offset+step-1)*3600,players=0,detections=0}
  for j=0,step-1 do local m=AC.DB.metrics[tostring(point.at+j*3600)]
   if m then point.players=math.max(point.players,m.peakPlayers);point.detections=point.detections+m.detections end
  end
  chart[#chart+1]=point
 end
 return {brand=Config.Brand,language=Config.Language,players=online,bans=bans,events=events,checks=checks,
 counts=counts,chart=chart,permissions=permissions,chatLocked=AC.chatLocked,tools=AC.tools[src] or {},
 chatMaxLength=Config.Chat.maxLength,entityRadiusMax=Config.Entities.radiusMax,
 capabilities={onesync=AC.OneSync(),chat=AC.ChatHookStatus(),vrp=AC.VRPPermission~=nil,screenshots=Config.Screenshots.enabled and GetResourceState(Config.Screenshots.resource)=='started',
 monitor='periodic-screenshots',clientPunishments=Config.AllowClientPunishments},
 monitor={intervalMs=Config.Screenshots.monitorIntervalMs,maxTargets=Config.Screenshots.maxTargets,maxConcurrent=Config.Screenshots.maxConcurrent}}
end
local function distance(a,b) return #(GetEntityCoords(a)-GetEntityCoords(b)) end
function AC.Cleanup(actor,kind,scope,radius,ignoreOccupied)
 if not AC.OneSync() then return false,AC.T('needOneSync') end
 if kind~='vehicle' and kind~='ped' and kind~='object' then return false,'Invalid entity type' end
 if scope~='all' and scope~='near' then return false,'Invalid scope' end
 if scope=='near' and actor==0 then return false,'Console cannot select nearby entities' end
 radius=AC.Int(radius or 100,1,Config.Entities.radiusMax);if not radius then return false,'Invalid radius' end
 if AC.cleanupRunning then return false,AC.T('cleanupBusy') end
 if actor~=0 and (AC.Ped(actor)==0 or not DoesEntityExist(AC.Ped(actor))) then return false,AC.T('pedMissing') end
 local entities=kind=='vehicle' and GetAllVehicles() or kind=='ped' and GetAllPeds() or GetAllObjects()
 local playerPeds,occupied={},{}
 for _,id in ipairs(GetPlayers()) do local ped=AC.Ped(tonumber(id));playerPeds[ped]=true
  local vehicle=ped~=0 and GetVehiclePedIsIn(ped,false) or 0;if vehicle~=0 then occupied[vehicle]=true end
 end
 local pos=actor~=0 and GetEntityCoords(AC.Ped(actor)) or nil
 local bucket=actor~=0 and GetPlayerRoutingBucket(actor) or nil
 local selected={}
 for _,entity in ipairs(entities) do
  if DoesEntityExist(entity) and not playerPeds[entity] and not (kind=='vehicle' and ignoreOccupied and occupied[entity])
   and (scope=='all' or (GetEntityRoutingBucket(entity)==bucket and #(GetEntityCoords(entity)-pos)<=radius)) then
    selected[#selected+1]=entity
  end
 end
 AC.cleanupRunning=true
 AC.Event('admin',actor,0,'cleanup',kind..' / '..scope..' / selected='..#selected)
 CreateThread(function()
  local deleted=0;local failed=0
  local ok,err=pcall(function()
   for i,entity in ipairs(selected) do
    local protected=false
    for _,id in ipairs(GetPlayers()) do local ped=AC.Ped(tonumber(id))
     if ped==entity or (kind=='vehicle' and ignoreOccupied and ped~=0 and GetVehiclePedIsIn(ped,false)==entity) then protected=true;break end
    end
    if not protected and DoesEntityExist(entity) then
     DeleteEntity(entity)
     -- Server deletion is asynchronous; give the sync tree time before counting success.
     Wait(Config.Entities.batchDelayMs)
     if not DoesEntityExist(entity) then deleted=deleted+1 else failed=failed+1 end
    end
    if i%Config.Entities.batchSize==0 then Wait(Config.Entities.batchDelayMs) end
   end
  end)
  AC.cleanupRunning=false
  AC.Event('admin',actor,0,'cleanup_complete','deleted='..deleted..' failed='..failed)
  if not ok then print('[BoFaisal] cleanup failed: '..tostring(err)) end
  if actor~=0 and AC.Name(actor) then
   AC.Notify(actor,ok and AC.Template(AC.T('cleanupComplete'),{count=deleted}) or AC.T('cleanupFailed'),ok and 'success' or 'danger')
  end
 end)
 return true,AC.T('cleanupQueued')
end
local capabilities={snapshot='menu',ban='ban',unban='unban',kick='kick',mute='mute',unmute='unmute',
 chatLock='chatLock',chatClear='chatClear',cleanup='entities',strip='weapons',teleport='teleport',screenshot='screenshot',
 monitorFrame='monitor',menuState='menu',tool='menu',policy='punishments',evidence='evidence',deleteEntity='deleteTool',espOptions='esp',diagnostics='diagnostics'}
function AC.Dispatch(src,action,p)
 src=AC.Source(src,true)
 if src==nil then return false,AC.T('denied') end
 local cap=capabilities[action]
 if action=='cleanup' and type(p)=='table' then cap=({vehicle='cleanupVehicle',ped='cleanupPed',object='cleanupObject'})[p.kind] end
 if action=='strip' and type(p)=='table' then cap=p.all==true and 'stripAll' or 'stripPlayer' end
 if action=='tool' and type(p)=='table' then cap=p.tool=='deleteTool' and 'deleteTool' or p.tool end
 if not cap or not AC.Has(src,cap) then return false,AC.T('denied') end
 if type(p)~='table' then return false,'Invalid payload' end
 local targets={ban=true,kick=true,mute=true,unmute=true,teleport=true,screenshot=true,monitorFrame=true}
 local target
 if targets[action] then target=AC.Int(p.target,1,65535);if not target or not GetPlayerName(target) then return false,AC.T('offline') end end
 if action=='snapshot' then return true,AC.Snapshot(src,p.period)
 elseif action=='diagnostics' then return true,{onesync=AC.OneSync(),ped=AC.Ped(src)~=0,
  identifiers=#AC.Keys(AC.Identifiers(src)),vrp=AC.VRPPermission~=nil,
  screenshots=GetResourceState(Config.Screenshots.resource),chat=AC.ChatHookStatus(),userId=AC.UserId(src)}
 elseif action=='espOptions' then
  local validated={}
  for key,cap in pairs({names='espNames',health='espHealth',armor='espArmor',boxes='espBoxes',lines='espLines',skeleton='espSkeleton'}) do
   if type(p[key])=='boolean' then validated[key]=p[key] and AC.Has(src,cap) end
  end
  TriggerClientEvent('bofaisal:espOptions',src,validated);return true,'ok'
 elseif action=='menuState' then
  if type(p.open)~='boolean' then return false,'Invalid menu state' end
  AC.Event('admin',src,src,'menu',p.open and 'open' or 'close');return true,'ok'
 elseif action=='ban' then
  local days=AC.Int(p.days or 7,0,Config.AdminTools.maxBanDays)
  local reason=AC.SafeString(p.reason,Config.AdminTools.reasonMaxLength)
  if not days or reason=='' then return false,'Invalid ban duration/reason' end
  return AC.Ban(src,target,reason,days)
 elseif action=='unban' then return AC.Unban(src,AC.SafeString(p.id,24))
 elseif action=='kick' then local reason=AC.SafeString(p.reason,Config.AdminTools.reasonMaxLength)
  if reason=='' then return false,'Reason required' end
  AC.Event('admin',src,target,'kick',reason);DropPlayer(target,AC.T('kick')..': '..reason);return true,'ok'
 elseif action=='mute' then local minutes=AC.Int(p.minutes or 0,0,Config.Chat.maxMuteMinutes)
  if not minutes then return false,'Invalid minutes' end;return AC.SetMute(src,target,minutes)
 elseif action=='unmute' then return AC.SetMute(src,target,nil)
 elseif action=='chatLock' then
  if type(p.locked)~='boolean' then return false,'Invalid flag' end
  AC.chatLocked=p.locked;AC.Event('admin',src,0,'chat_lock',tostring(p.locked));return true,'ok'
 elseif action=='chatClear' then TriggerClientEvent('chat:clear',-1);TriggerClientEvent('bofaisal:chatClear',-1);AC.Event('admin',src,0,'chat_clear','');return true,'ok'
 elseif action=='cleanup' then
  if p.scope=='all' and not AC.Has(src,'cleanupAll') then return false,AC.T('denied') end
  local ignore=p.ignoreOccupied;if ignore==nil then ignore=Config.Entities.ignoreOccupiedVehicles end
  if type(ignore)~='boolean' then return false,'Invalid occupancy flag' end
  return AC.Cleanup(src,p.kind,p.scope,p.radius,ignore)
 elseif action=='strip' then
  local all=p.all==true;local one=AC.Int(p.target,1,65535)
  if not all and (not one or not GetPlayerName(one)) then return false,AC.T('offline') end
  for _,id in ipairs(all and GetPlayers() or {tostring(one)}) do
   local who=tonumber(id);AC.weaponGrants[who]=nil;TriggerClientEvent('bofaisal:strip',who)
  end
  AC.Event('admin',src,one or 0,'strip_weapons',all and 'all' or tostring(one));return true,'ok'
 elseif action=='teleport' then
  if src==0 then return false,'Requires an in-game player' end
  local ped=AC.Ped(target);if ped==0 then return AC.RequestPosition(src,target) end
  local pos=GetEntityCoords(ped);if AC.OneSync() then SetPlayerRoutingBucket(src,GetPlayerRoutingBucket(target)) end
  AC.grace[src]={expires=os.time()+15,all=true,checks={}}
  TriggerClientEvent('bofaisal:grace',src,15);TriggerClientEvent('bofaisal:teleport',src,{x=pos.x+1,y=pos.y+1,z=pos.z})
  AC.Event('admin',src,target,'teleport','');return true,'ok'
 elseif action=='screenshot' or action=='monitorFrame' then
  if src==0 then return false,AC.T('pedMissing') end
  AC.Event('admin',src,target,action,p.quality or 'medium')
  AC.Capture(src,target,p.quality,function(ok,data)
   local needed=action=='screenshot' and 'screenshot' or 'monitor'
   if AC.Has(src,needed) then TriggerLatentClientEvent('bofaisal:frame',src,Config.Screenshots.transferBytesPerSecond,{target=target,ok=ok,data=data}) end
  end)
  return true,AC.T('captureRequested')
 elseif action=='evidence' then
  local ban=AC.DB.bans[AC.SafeString(p.id,24)]
  if not ban or not ban.evidence then return false,'No screenshot evidence' end
  local data=LoadResourceFile(AC.Resource,ban.evidence)
  if not data then return false,'Evidence file missing' end
  TriggerLatentClientEvent('bofaisal:frame',src,Config.Screenshots.transferBytesPerSecond,{target=ban.id,ok=true,data=data});AC.Event('admin',src,0,'view_evidence',ban.id);return true,'ok'
 elseif action=='tool' then
  if p.tool~='freecam' and p.tool~='esp' and p.tool~='deleteTool' then return false,'Unknown tool' end
  local toolcap=p.tool=='deleteTool' and 'deleteTool' or p.tool
  if not AC.Has(src,toolcap) or type(p.enabled)~='boolean' then return false,AC.T('denied') end
  AC.tools[src]=AC.tools[src] or {};AC.tools[src][p.tool]=p.enabled
  if p.tool=='esp' then
   local options={}
   for key,cap in pairs({names='espNames',health='espHealth',armor='espArmor',boxes='espBoxes',lines='espLines',skeleton='espSkeleton'}) do options[key]=AC.Has(src,cap) end
   TriggerClientEvent('bofaisal:espOptions',src,options)
  end
  TriggerClientEvent('bofaisal:tool',src,p.tool,p.enabled)
  AC.Event('admin',src,src,'tool_'..p.tool,p.enabled and 'on' or 'off');return true,'ok'
 elseif action=='policy' then
  local rule=type(p.id)=='string' and Config.Checks[p.id]
  if not rule or (p.action~='none' and p.action~='warn' and p.action~='alert' and p.action~='kick' and p.action~='ban') then return false,'Invalid policy' end
  local days=AC.Int(p.banDays or rule.banDays,0,Config.AdminTools.maxBanDays)
  if not days then return false,'Invalid duration' end
  local oldAction,oldDays=rule.action,rule.banDays
  AC.DB.policies=AC.DB.policies or {};local oldPolicy=AC.DB.policies[p.id]
  rule.action=p.action=='alert' and 'warn' or p.action;rule.banDays=days
  AC.DB.policies[p.id]={action=rule.action,banDays=days};AC.dirty=true
  if not AC.Flush() then rule.action=oldAction;rule.banDays=oldDays;AC.DB.policies[p.id]=oldPolicy;return false,'Policy could not be saved' end
  AC.Event('admin',src,0,'policy',p.id..'='..p.action);return true,'ok'
 elseif action=='deleteEntity' then
  if not AC.tools[src] or not AC.tools[src].deleteTool then return false,'Delete tool disabled' end
  local net=AC.Int(p.netId,1,2147483647);if not net then return false,'Invalid network ID' end
  local entity=NetworkGetEntityFromNetworkId(net);local ped=AC.Ped(src)
  if entity==0 or not DoesEntityExist(entity) or ped==0 or GetEntityRoutingBucket(entity)~=GetPlayerRoutingBucket(src)
   or distance(ped,entity)>Config.AdminTools.deleteDistance then return false,'Entity out of reach' end
  for _,id in ipairs(GetPlayers()) do local playerPed=AC.Ped(tonumber(id))
   if playerPed==entity or GetVehiclePedIsIn(playerPed,false)==entity then return false,'Player/occupied vehicle protected' end
  end
  AC.Event('admin',src,0,'delete_entity',tostring(GetEntityModel(entity)));DeleteEntity(entity);return true,'ok'
 end
 return false,'Unknown action'
end
RegisterNetEvent('bofaisal:rpc',function(request,action,payload)
 local src=AC.Source(source)
 if not src then return end
 if not AC.Int(request,1,2147483647) or type(action)~='string' or #action>24 then return end
 if not AC.Rate(src,'rpc',Config.Events.actionBurst,Config.Events.actionWindowSeconds) then
  TriggerClientEvent('bofaisal:rpcResult',src,request,false,AC.T('rateLimit'));return
 end
 AC.EnsurePermissions(src)
 local ok,result,data=pcall(AC.Dispatch,src,action,payload)
 if not ok then print('[BoFaisal] RPC '..action..': '..tostring(result));result=false;data=AC.T('operationFailed') end
 TriggerClientEvent('bofaisal:rpcResult',src,request,result,data)
end)
for id,policy in pairs(Config.Policy.loadSavedOverrides and AC.DB.policies or {}) do
 if Config.Checks[id] and (policy.action=='none' or policy.action=='warn' or policy.action=='alert' or policy.action=='kick' or policy.action=='ban') then
  Config.Checks[id].action=policy.action=='alert' and 'warn' or policy.action;Config.Checks[id].banDays=AC.Int(policy.banDays,0,Config.AdminTools.maxBanDays) or 7
 end
end
CreateThread(function()
 if Config.OneSyncRequired and GetConvar('onesync','off')=='off' then print('[BoFaisal] ERROR: OneSync must be enabled; server entity protections will not work.') end
 while true do
  Wait(60000)
  for id,pending in pairs(AC.connecting or {}) do if pending.expires<os.time() then AC.connecting[id]=nil end end
  local hour=tostring(math.floor(os.time()/3600)*3600);local m=AC.DB.metrics[hour] or {peakPlayers=0,detections=0}
  m.peakPlayers=math.max(m.peakPlayers,#GetPlayers());AC.DB.metrics[hour]=m;AC.dirty=true
  -- Permission revocation immediately shuts down legitimate administration tools.
  for src,tools in pairs(AC.tools) do
   for tool,on in pairs(tools) do
    local cap=tool=='deleteTool' and 'deleteTool' or tool
    if on and not AC.Has(src,cap) then tools[tool]=false;TriggerClientEvent('bofaisal:tool',src,tool,false);AC.Event('admin',src,src,'tool_'..tool,'off: permission revoked') end
   end
  end
 end
end)
