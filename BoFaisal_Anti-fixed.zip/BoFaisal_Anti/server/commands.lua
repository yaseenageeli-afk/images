local function reply(src,ok,message)
 if src==0 then print('[BoFaisal] '..tostring(message)) else AC.Notify(src,tostring(message),ok and 'success' or 'danger') end
end
local function command(name,cap,handler)
 RegisterCommand(name,function(src,args)
  src=AC.Source(src,true);if src==nil then return end
  if src~=0 then AC.EnsurePermissions(src) end
  if cap and not AC.Has(src,cap) then reply(src,false,AC.T('denied'));return end
  if not AC.Rate(src,'command',Config.Events.actionBurst,Config.Events.actionWindowSeconds) then reply(src,false,AC.T('rateLimit'));return end
  local ok,result,message=pcall(handler,src,args)
  reply(src,ok and result,ok and (message or 'ok') or 'Command failed; check server configuration')
 end,false)
end
command(Config.Commands.ban,'ban',function(s,a)return AC.Dispatch(s,'ban',{target=a[1],days=a[2],reason=table.concat(a,' ',3)})end)
command(Config.Commands.unban,'unban',function(s,a)return AC.Dispatch(s,'unban',{id=a[1]})end)
command(Config.Commands.kick,'kick',function(s,a)return AC.Dispatch(s,'kick',{target=a[1],reason=table.concat(a,' ',2)})end)
command(Config.Commands.mute,'mute',function(s,a)return AC.Dispatch(s,'mute',{target=a[1],minutes=a[2]})end)
command(Config.Commands.unmute,'unmute',function(s,a)return AC.Dispatch(s,'unmute',{target=a[1]})end)
command(Config.Commands.chatLock,'chatLock',function(s,a)return AC.Dispatch(s,'chatLock',{locked=a[1]=='on'})end)
command(Config.Commands.chatClear,'chatClear',function(s)return AC.Dispatch(s,'chatClear',{})end)
command(Config.Commands.wipe,nil,function(s,a)return AC.Dispatch(s,'cleanup',{kind=a[1],scope=a[2] or 'near',radius=a[3] or 100,ignoreOccupied=true})end)
command(Config.Commands.strip,nil,function(s,a)return AC.Dispatch(s,'strip',{target=a[1],all=a[1]=='all'})end)
command(Config.Commands.screenshot,'screenshot',function(s,a)return AC.Dispatch(s,'screenshot',{target=a[1],quality=a[2] or 'medium'})end)

command(Config.Commands.diagnostics,'diagnostics',function(s)
 local ok,data=AC.Dispatch(s,'diagnostics',{})
 if not ok then return false,data end
 return true,('OneSync=%s | Ped=%s | IDs=%s | vRP=%s | screenshot-basic=%s | Chat=%s'):format(tostring(data.onesync),tostring(data.ped),data.identifiers,tostring(data.vrp),data.screenshots,json.encode(data.chat))
end)
