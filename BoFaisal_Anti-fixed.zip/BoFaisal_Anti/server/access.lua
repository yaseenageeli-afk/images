-- cache مهم: معالجات CancelEvent يجب ألا تنتظر Proxy قبل إلغاء الحدث.
AC.permissionCache={};AC.userIds={}
function AC.UserId(src)
 src=AC.Source(src);return src and AC.userIds[src] or nil
end
function AC.HasPermission(src,permission)
 src=AC.Source(src,true);if src==0 then return true end
 if not src or type(permission)~='string' or permission=='' then return false end
 if Config.Access.allowAce and IsPlayerAceAllowed(src,permission) then return true end
 local cache=AC.permissionCache[src]
 return cache and cache.permissions[permission]==true or false
end
function AC.Has(src,cap) return AC.HasPermission(src,Config.Permissions[cap]) end
function AC.RefreshPermissions(src)
 src=AC.Source(src);if not src or not AC.Name(src) or not AC.VRPPermission then return false end
 local session=AC.Session(src);local names={}
 if AC.VRPUserId then local ok,id=pcall(AC.VRPUserId,src);if ok and id then AC.userIds[src]=id end end
 for _,p in pairs(Config.Permissions) do names[p]=true end
 names[Config.Notifications.permission]=true;names[Config.Bypass.all]=true
 for _,p in pairs(Config.Bypass.checks) do names[p]=true end
 for _,g in pairs(Config.Bypass.groups) do names[g.permission]=true end
 for _,policy in pairs(Config.Events.protected) do if type(policy.permission)=='string' then names[policy.permission]=true end end
 for _,c in pairs(Config.Checks) do if c.notifyPermission and c.notifyPermission~='' then names[c.notifyPermission]=true end end
 local permissions={}
 for permission in pairs(names) do
  local ok,result=pcall(AC.VRPPermission,src,permission)
  permissions[permission]=ok and result==true
 end
 if AC.SameSession(src,session) then AC.permissionCache[src]={at=GetGameTimer(),permissions=permissions};return true end
 return false
end
function AC.EnsurePermissions(src)
 local entry=AC.permissionCache[src]
 if not entry or GetGameTimer()-entry.at>=Config.Access.cacheSeconds*1000 then AC.RefreshPermissions(src) end
end
function AC.Bypass(src,id)
 if AC.HasPermission(src,Config.Bypass.all) or AC.Has(src,'bypass') then return true end
 if AC.HasPermission(src,Config.Bypass.checks[id]) then return true end
 for _,group in pairs(Config.Bypass.groups) do
  if AC.HasPermission(src,group.permission) then for _,key in ipairs(group.checks) do if key==id then return true end end end
 end
 return false
end
CreateThread(function()
 while true do
  for _,id in ipairs(GetPlayers()) do AC.RefreshPermissions(tonumber(id)) end
  Wait(Config.Access.cacheSeconds*1000)
 end
end)
AddEventHandler('playerDropped',function() AC.permissionCache[tonumber(source)]=nil;AC.userIds[tonumber(source)]=nil end)
