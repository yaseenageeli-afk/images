local function closeMenu()
 if BF.menu then BF.RPC('menuState',{open=false}) end
 BF.menu=false;SetNuiFocus(false,false);SendNUIMessage({type='close'})
end
local function openMenu()
 if BF.menu then closeMenu();return end
 BF.RPC('snapshot',{period='day'},function(ok,data)
  if not ok then SendNUIMessage({type='toast',data={message=data,kind='danger'}});return end
  BF.menu=true;BF.RPC('menuState',{open=true});SetNuiFocus(true,true);SendNUIMessage({type='open',data=data})
 end)
end
RegisterCommand(Config.Command,openMenu,false)
RegisterKeyMapping(Config.Command,'BoFaisal protection menu','keyboard',Config.Key)
RegisterNetEvent('bofaisal:openMenu',function() if source==65535 then openMenu() end end)
RegisterNUICallback('close',function(_,cb)closeMenu();cb({ok=true})end)
RegisterNUICallback('rpc',function(body,cb)
 if not BF.menu or type(body)~='table' then cb({ok=false,data='Menu closed'});return end
 BF.RPC(body.action,body.payload,function(ok,data)cb({ok=ok,data=data})end)
end)
RegisterNUICallback('preferences',function(body,cb)
 if not BF.menu or type(body)~='table' then cb({ok=false});return end
 for key in pairs(BF.notifications) do if type(body[key])=='boolean' then BF.notifications[key]=body[key] end end
 cb({ok=true})
end)
RegisterNUICallback('espOptions',function(body,cb)
 if not BF.menu or type(body)~='table' then cb({ok=false});return end
 BF.RPC('espOptions',body,function(ok,data) cb({ok=ok,data=data}) end)
end)
RegisterNUICallback('appeal',function(_,cb)
 if Config.AppealURL:match('^https://discord%.gg/') or Config.AppealURL:match('^https://discord%.com/invite/') then
  if type(OpenUrl)=='function' then OpenUrl(Config.AppealURL) end
 end
 cb({ok=true})
end)
local camera;local freezePed
local deleteToolGiven=false;local deleteToolPed;local previousWeapon
local function deleteWeapon(enabled)
 local weapon=GetHashKey(Config.Weapons.deleteToolWeapon)
 if enabled then
  deleteToolPed=PlayerPedId();previousWeapon=GetSelectedPedWeapon(deleteToolPed)
  deleteToolGiven=not HasPedGotWeapon(deleteToolPed,weapon,false)
  if deleteToolGiven then GiveWeaponToPed(deleteToolPed,weapon,1,false,true)
  else SetCurrentPedWeapon(deleteToolPed,weapon,true) end
 elseif deleteToolPed and DoesEntityExist(deleteToolPed) then
  if deleteToolGiven then RemoveWeaponFromPed(deleteToolPed,weapon) end
  if previousWeapon and HasPedGotWeapon(deleteToolPed,previousWeapon,false) then SetCurrentPedWeapon(deleteToolPed,previousWeapon,true) end
  deleteToolPed=nil;previousWeapon=nil;deleteToolGiven=false
 end
end
local function freecam(enabled)
 if enabled and not camera then
  local pos=GetGameplayCamCoord();local rot=GetGameplayCamRot(2)
  camera=CreateCam('DEFAULT_SCRIPTED_CAMERA',true);SetCamCoord(camera,pos.x,pos.y,pos.z);SetCamRot(camera,rot.x,rot.y,rot.z,2)
  freezePed=PlayerPedId();FreezeEntityPosition(freezePed,true)
  RenderScriptCams(true,false,0,true,true);closeMenu()
 elseif not enabled and camera then
  RenderScriptCams(false,false,0,true,true);DestroyCam(camera,false);camera=nil
  ClearFocus();if freezePed and DoesEntityExist(freezePed) then FreezeEntityPosition(freezePed,false) end;freezePed=nil
 end
end
RegisterNetEvent('bofaisal:tool',function(tool,on)
 if source~=65535 then return end
 BF.tools[tool]=on
 if tool=='freecam' then freecam(on) end
 if tool=='deleteTool' then deleteWeapon(on) end
 if tool=='deleteTool' and on then closeMenu();SendNUIMessage({type='toast',data={message='Aim with configured delete weapon, then fire. Players / occupied vehicles are protected.',kind='info'}}) end
 SendNUIMessage({type='tools',data=BF.tools})
end)
local function drawText3d(pos,text,r,g,b)
 local visible,x,y=World3dToScreen2d(pos.x,pos.y,pos.z)
 if visible then
  SetTextScale(0.0,0.29);SetTextFont(0);SetTextProportional(true);SetTextColour(r,g,b,225);SetTextCentre(true);SetTextOutline()
  BeginTextCommandDisplayText('STRING');AddTextComponentSubstringPlayerName(text);EndTextCommandDisplayText(x,y)
 end
end
local bones={{31086,39317},{39317,24818},{24818,11816},{39317,45509},{45509,61163},{61163,18905},
 {39317,40269},{40269,28252},{28252,57005},{11816,58271},{58271,63931},{63931,14201},{11816,51826},{51826,36864},{36864,52301}}
CreateThread(function()
 while true do
  if not BF.tools.freecam and not BF.tools.esp and not BF.tools.deleteTool then Wait(750)
  else
   Wait(0);local ped=PlayerPedId();local pos=GetEntityCoords(ped)
   if camera and BF.tools.freecam then
    DisableAllControlActions(0)
    local rot=GetCamRot(camera,2);local camPos=GetCamCoord(camera)
    local pitch=math.max(-89,math.min(89,rot.x-GetDisabledControlNormal(0,2)*5))
    local yaw=rot.z-GetDisabledControlNormal(0,1)*5
    local rad=math.rad(yaw);local pr=math.rad(pitch)
    local forward=vector3(-math.sin(rad)*math.cos(pr),math.cos(rad)*math.cos(pr),math.sin(pr))
    local right=vector3(math.cos(rad),math.sin(rad),0)
    local speed=Config.AdminTools.freecamSpeed*GetFrameTime()
    if IsDisabledControlPressed(0,21) then speed=speed*Config.AdminTools.freecamFastMultiplier end
    if IsDisabledControlPressed(0,32) then camPos=camPos+forward*speed end
    if IsDisabledControlPressed(0,33) then camPos=camPos-forward*speed end
    if IsDisabledControlPressed(0,34) then camPos=camPos-right*speed end
    if IsDisabledControlPressed(0,35) then camPos=camPos+right*speed end
    if IsDisabledControlPressed(0,44) then camPos=camPos+vector3(0,0,speed) end
    if IsDisabledControlPressed(0,38) then camPos=camPos-vector3(0,0,speed) end
    SetCamCoord(camera,camPos.x,camPos.y,camPos.z);SetCamRot(camera,pitch,0,yaw,2);SetFocusPosAndVel(camPos.x,camPos.y,camPos.z,0,0,0)
    if IsDisabledControlJustPressed(0,177) then BF.RPC('tool',{tool='freecam',enabled=false}) end
   end
   if BF.tools.esp then
    local count=0
    for _,player in ipairs(GetActivePlayers()) do
     local other=GetPlayerPed(player);local otherPos=GetEntityCoords(other)
     if player~=PlayerId() and #(pos-otherPos)<=Config.AdminTools.espDistance then
      count=count+1;if count>Config.AdminTools.espMaxPlayers then break end
      local text={};if BF.espOptions.names then text[#text+1]='['..GetPlayerServerId(player)..'] '..GetPlayerName(player) end
      if BF.espOptions.health then text[#text+1]='HP '..GetEntityHealth(other) end
      if BF.espOptions.armor then text[#text+1]='AR '..GetPedArmour(other) end
      drawText3d(otherPos+vector3(0,0,1.1),table.concat(text,' / '),75,180,255)
      if BF.espOptions.lines then DrawLine(pos.x,pos.y,pos.z,otherPos.x,otherPos.y,otherPos.z,43,160,255,150) end
      if BF.espOptions.skeleton then
       for _,pair in ipairs(bones) do local a=GetPedBoneCoords(other,pair[1],0,0,0);local b=GetPedBoneCoords(other,pair[2],0,0,0)
        DrawLine(a.x,a.y,a.z,b.x,b.y,b.z,43,160,255,210)
       end
      end
      if BF.espOptions.boxes then
       local on1,x1,y1=World3dToScreen2d(otherPos.x,otherPos.y,otherPos.z+1)
       local on2,x2,y2=World3dToScreen2d(otherPos.x,otherPos.y,otherPos.z-1)
       if on1 and on2 then local h=math.abs(y2-y1);local w=h*0.4;local cx=(x1+x2)/2;local cy=(y1+y2)/2
        DrawRect(cx,cy-h/2,w,0.002,43,160,255,200);DrawRect(cx,cy+h/2,w,0.002,43,160,255,200)
        DrawRect(cx-w/2,cy,0.001,h,43,160,255,200);DrawRect(cx+w/2,cy,0.001,h,43,160,255,200)
       end
      end
     end
    end
   end
   if BF.tools.deleteTool then
    DisablePlayerFiring(PlayerId(),true)
    if GetSelectedPedWeapon(ped)==GetHashKey(Config.Weapons.deleteToolWeapon) and IsDisabledControlJustPressed(0,24) then
     local aiming,entity=GetEntityPlayerIsFreeAimingAt(PlayerId())
     if aiming and DoesEntityExist(entity) and NetworkGetEntityIsNetworked(entity) then
      BF.RPC('deleteEntity',{netId=NetworkGetNetworkIdFromEntity(entity)},function(ok,data)
       if not ok then SendNUIMessage({type='toast',data={message=data,kind='danger'}}) end
      end)
     end
    end
   end
  end
 end
end)
AddEventHandler('onResourceStop',function(resource)
 if resource==GetCurrentResourceName() then freecam(false);deleteWeapon(false);SetNuiFocus(false,false) end
end)
