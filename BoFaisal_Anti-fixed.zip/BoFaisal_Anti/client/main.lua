BF={pending={},sequence=0,grace={},allGrace=GetGameTimer()+Config.Client.startupGraceSeconds*1000,
 tools={freecam=false,esp=false,deleteTool=false},notifications={chat=true,toast=true,sound=true},menu=false,espOptions={names=true,health=true,armor=true,boxes=true,lines=false,skeleton=false}}
function BF.RPC(action,payload,callback)
 BF.sequence=BF.sequence+1;if BF.sequence>2147483646 then BF.sequence=1 end
 local id=BF.sequence;BF.pending[id]=callback or function() end
 TriggerServerEvent('bofaisal:rpc',id,action,payload or {})
 SetTimeout(10000,function() if BF.pending[id] then local fn=BF.pending[id];BF.pending[id]=nil;fn(false,'Request timed out') end end)
end
RegisterNetEvent('bofaisal:rpcResult',function(id,ok,data)
 if source~=65535 then return end
 local fn=BF.pending[id];if fn then BF.pending[id]=nil;fn(ok,data) end
end)
RegisterNetEvent('bofaisal:notify',function(data)
 if source~=65535 or type(data)~='table' then return end
 if data.settings and data.settings.chat and BF.notifications.chat then TriggerEvent('chat:addMessage',{color=Config.Notifications.color,args={Config.Notifications.title,data.message}}) end
 if data.settings and data.settings.toast and BF.notifications.toast then SendNUIMessage({type='toast',data=data}) end
 if data.settings and data.settings.sound and BF.notifications.sound then PlaySoundFrontend(-1,'CHECKPOINT_NORMAL','HUD_MINI_GAME_SOUNDSET',true) end
end)
RegisterNetEvent('bofaisal:grace',function(seconds,checks)
 if source~=65535 then return end
 local untilTime=GetGameTimer()+math.min(tonumber(seconds) or 0,300)*1000
 if type(checks)~='table' then BF.allGrace=untilTime else for _,id in ipairs(checks) do BF.grace[id]=untilTime end end
end)
RegisterNetEvent('bofaisal:teleport',function(pos)
 if source~=65535 then return end
 BF.allGrace=GetGameTimer()+15000
 SetEntityCoords(PlayerPedId(),pos.x,pos.y,pos.z,false,false,false,false)
end)
RegisterNetEvent('bofaisal:strip',function()
 if source~=65535 then return end
 RemoveAllPedWeapons(PlayerPedId(),true)
 BF.allGrace=GetGameTimer()+5000
end)
RegisterNetEvent('bofaisal:frame',function(frame)
 if source~=65535 then return end
 SendNUIMessage({type='frame',data=frame})
end)
RegisterNetEvent('bofaisal:banScreen',function(ban)
 if source~=65535 then return end
 SetNuiFocus(true,true);SendNUIMessage({type='ban',data=ban,language=Config.Language})
end)
CreateThread(function()
 while true do Wait(Config.Client.heartbeatSeconds*1000);TriggerServerEvent('bofaisal:heartbeat') end
end)

-- نقل الصورة بطلب مربوط على السيرفر، لا نقبل طلب تصوير من NUI أو لاعب آخر.
RegisterNetEvent('bofaisal:captureRequest',function(request,quality)
 if source~=65535 or type(request)~='number' then return end
 if GetResourceState(Config.Screenshots.resource)~='started' then
  TriggerServerEvent('bofaisal:captureResult',request,nil,'provider_missing');return
 end
 local done=false
 local function finish(data,err)
  if done then return end;done=true
  if err then TriggerServerEvent('bofaisal:captureResult',request,nil,err);return end
  if type(data)~='string' or #data>Config.Screenshots.maxBytes then
   TriggerServerEvent('bofaisal:captureResult',request,nil,'too_large');return
  end
  TriggerLatentServerEvent('bofaisal:captureResult',Config.Screenshots.uploadBytesPerSecond,request,data)
 end
 local ok=pcall(function()
  exports[Config.Screenshots.resource]:requestScreenshot({encoding='jpg',quality=Config.Screenshots.qualities[quality] or 0.45},function(data) finish(data) end)
 end)
 if not ok then finish(nil,'provider_failed') end
 SetTimeout(Config.Screenshots.timeoutMs-1000,function() finish(nil,'timeout') end)
end)
RegisterNetEvent('bofaisal:positionRequest',function(request)
 if source~=65535 or type(request)~='number' then return end
 local ped=PlayerPedId();if not DoesEntityExist(ped) then return end
 local pos=GetEntityCoords(ped)
 TriggerServerEvent('bofaisal:positionResult',request,{x=pos.x,y=pos.y,z=pos.z})
end)
RegisterNetEvent('bofaisal:chatClear',function()
 if source==65535 then TriggerEvent('chat:clear') end
end)
RegisterNetEvent('bofaisal:espOptions',function(options)
 if source~=65535 or type(options)~='table' then return end
 for key in pairs(BF.espOptions) do if type(options[key])=='boolean' then BF.espOptions[key]=options[key] end end
end)
