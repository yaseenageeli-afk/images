-- هذا الملف يُحمّل من manifest. مصدر كل القيم هو config.lua فقط.
-- للتوافق مع التسميات القديمة؛ لا توجد صلاحيات غير مستخدمة أو محرك ثانٍ.
Permissions = {
 Menu=Config.Permissions.menu, Alerts=Config.Permissions.alerts,
 Phone=Config.Permissions.phone, BypassAll=Config.Bypass.all,
 Admin=Config.Permissions, Bypass=Config.Bypass.checks, BypassGroups=Config.Bypass.groups
}
