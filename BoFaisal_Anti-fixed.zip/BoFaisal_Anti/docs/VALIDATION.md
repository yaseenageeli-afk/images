# Validation: repair 1.1.0

45 Lua 5.4 regression tests passed using Lupa 2.8. 41 Chromium browser checks passed against mocked RPC data. All shipped Lua files parse; JavaScript syntax passes Node checks. Added tests cover zero-argument successful deferrals, normalized server IDs, vRP persistent identity fallback, per-action permissions, individual bypass isolation, OneSync-off errors, authenticated screenshot responses and size limits, missing-ped teleport requests, recipient-filtered alerts, and ESP component permissions.

No live FXServer, GTA physics, real vRP Proxy calls, screenshot-basic capture, Discord calls, or performance profiling was executed. Browser preview images contain synthetic test data.
