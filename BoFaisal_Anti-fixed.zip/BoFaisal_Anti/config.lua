-- كونفيق حماية بوفيصل: عدّل القيم والنصوص فقط؛ أسماء المفاتيح تستعملها البرمجة.
-- ضع صلاحيات vRP في القروب الموجود. التخطي الكامل مستقل عن صلاحية فتح المنيو.
Config = {}

-- لغة الرسائل: ar للعربية، en للإنجليزية
Config.Language = "ar"

-- اسم الحماية
Config.Brand = "BoFaisal AntiCheat"

-- رابط الاعتراض على الباند
Config.AppealURL = "https://discord.gg/CHANGE_ME"

-- أمر فتح القائمة
Config.Command = "acmenu"

-- زر فتح القائمة
Config.Key = "F10"

-- يتطلب حذف الكيانات تفعيل OneSync
Config.OneSyncRequired = true

-- حفظ الباندات والميوت والسجل
Config.Database = {
    flushSeconds = 15,
    maxEvents = 5000,
    path = "data/store.json",
    retentionDays = 31,
}

-- كل صلاحية مستقلة؛ أضف نصها إلى قروب vRP
Config.Permissions = {
    alerts = "bofaisal.alerts", -- استقبال رسائل الكشف والعقوبة للإدارة
    ban = "bofaisal.ban", -- باند لاعب
    bypass = "bofaisal.bypass", -- تخطي كامل للكشوفات؛ ليس صلاحية إدارة أو فك باند
    chat = "bofaisal.chat.view", -- إظهار التنبيهات في الشات
    chatBypass = "bofaisal.chat.bypass", -- تجاوز قفل الشات وفلترة الكلمات؛ لا يتجاوز الميوت
    chatClear = "bofaisal.chat.clear", -- مسح الشات
    chatLock = "bofaisal.chat.lock", -- قفل وفتح الشات
    cleanupAll = "bofaisal.entities.all", -- حذف كل الماب؛ تحتاج معها صلاحية نوع الكيان
    cleanupObject = "bofaisal.entities.object", -- حذف الأوبجكتات
    cleanupPed = "bofaisal.entities.ped", -- حذف البوتات
    cleanupVehicle = "bofaisal.entities.vehicle", -- حذف المركبات
    deleteTool = "bofaisal.entities.delete_tool", -- تفعيل سلاح حذف الكيانات
    diagnostics = "bofaisal.diagnostics", -- فحص حالة OneSync والشات والتصوير والهوية
    entities = "bofaisal.entities.view", -- عرض صفحة الكيانات
    esp = "bofaisal.esp", -- تفعيل ESP
    espArmor = "bofaisal.esp.armor", -- درع ESP
    espBoxes = "bofaisal.esp.boxes", -- مربعات ESP
    espHealth = "bofaisal.esp.health", -- صحة ESP
    espLines = "bofaisal.esp.lines", -- خطوط ESP
    espNames = "bofaisal.esp.names", -- أسماء ESP
    espSkeleton = "bofaisal.esp.skeleton", -- هيكل ESP
    evidence = "bofaisal.evidence", -- حفظ صورة وقت الباند
    freecam = "bofaisal.freecam", -- الفري كام
    kick = "bofaisal.kick", -- طرد لاعب
    logs = "bofaisal.logs", -- عرض السجلات
    menu = "admin.menu", -- فتح قائمة الحماية؛ حافظنا على صلاحية فتح قائمتك الحالية
    monitor = "bofaisal.monitor", -- المراقبة الدورية
    mute = "bofaisal.mute", -- ميوت لاعب
    phone = "bofaisal.phone", -- ظهور الحماية في جوال vRP
    players = "bofaisal.players", -- عرض اللاعبين
    punishments = "bofaisal.punishments", -- تغيير العقوبات
    screenshot = "bofaisal.screenshot", -- تصوير شاشة لاعب
    stripAll = "bofaisal.weapons.strip_all", -- سحب أسلحة جميع اللاعبين
    stripPlayer = "bofaisal.weapons.strip_player", -- سحب أسلحة لاعب
    teleport = "bofaisal.teleport", -- الانتقال للاعب
    unban = "bofaisal.unban", -- فك باند
    unmute = "bofaisal.unmute", -- فك الميوت
    weapons = "bofaisal.weapons.view", -- عرض صفحة الأسلحة
}

-- الشات والأسماء والكلمات الممنوعة
Config.Chat = {
    blockedNames = { "admin impersonator", "اسم_ممنوع" }, -- قائمة الأسماء الممنوعة
    burst = 5,
    forbiddenWords = { "كلمة_ممنوعة", "forbidden_example" }, -- قائمة الكلمات الممنوعة
    maxLength = 250, -- أقصى طول رسالة الشات
    maxMuteMinutes = 10080,
    maxNameCharacters = 48,
    minNameCharacters = 2,
    resources = { "chat" }, -- أسماء موارد الشات التي تدعم registerMessageHook
    windowSeconds = 10, -- نافذة احتساب الرصدات بالثواني
}

-- الدخول والحسابات المكررة وVPN
Config.Connection = {
    duplicateIdentifiers = true,
    identifiers = { "license", "license2", "steam", "fivem" },
    vpn = {
        enabled = false, -- تفعيل الخاصية
        failClosed = false,
        header = "Authorization",
        keyConvar = "bofaisal_vpn_key",
        prefix = "Bearer ",
        timeoutMs = 5000, -- مهلة الطلب بالملي ثانية
        url = "https://YOUR_PROVIDER.example/check?ip=%s",
    },
}

-- تكامل ديسكورد؛ الأسرار في إعدادات السيرفر فقط
Config.Discord = {
    bot = {
        enabled = false, -- تفعيل الخاصية
        tokenConvar = "bofaisal_discord_bot_token",
    },
    enabled = false, -- تفعيل الخاصية
    intervalMs = 1500,
    maxQueue = 100,
    webhookConvars = {
        admin = "bofaisal_webhook_admin",
        bans = "bofaisal_webhook_bans",
        detections = "bofaisal_webhook_detections",
    },
}

-- تنبيهات الكشف والعقوبة للإدارة
Config.Notifications = {
    actions = {
        ban = true,
        kick = true,
        none = false,
        warn = true,
    },
    announceBeforeThreshold = false, -- تنبيه الإدارة بالتحذير قبل اكتمال عدد الرصدات
    announceNone = false, -- إعلان كشف بلا عقوبة؛ فعّل actions.none أيضًا
    chat = true, -- إظهار التنبيهات في الشات
    color = { 43, 163, 255 },
    includeDetails = true, -- إظهار تفاصيل الرصد للإدارة
    permission = "bofaisal.alerts", -- برمشن مستلم التنبيهات
    sound = true, -- صوت التنبيهات
    templates = {
        ar = "اللاعب: {name} | رقم السيرفر: {source} | رقم vRP: {userId} | الكشف: {check} | العقوبة: {action} | {detail}",
        en = "Player: {name} | Server ID: {source} | vRP ID: {userId} | Detection: {check} | Action: {action} | {detail}",
    }, -- نص التنبيه: {name} الاسم، {source} رقم السيرفر، {userId} رقم vRP، {check} الكشف، {action} العقوبة، {detail} التفاصيل
    title = "حماية بوفيصل", -- عنوان التنبيه
    toast = true, -- إظهار إشعار طرف الشاشة
}

-- vRP افتراضيًا؛ allowAce يفعّل صلاحيات ACE اختياريًا
Config.Access = {
    allowAce = false, -- تفعيل صلاحيات ACE بجانب vRP
    cacheSeconds = 15, -- تحديث صلاحيات vRP كل هذا العدد من الثواني
}

-- تحميل تغييرات العقوبات المحفوظة بعد إعادة التشغيل
Config.Policy = {
    loadSavedOverrides = false, -- true يسمح للتغييرات المحفوظة تجاوز عقوبات الكونفيق
}

-- التخطيات: كامل أو مجموعة أو كشف واحد
Config.Bypass = {
    all = "bofaisal.bypass", -- صلاحية التخطي الكامل
    checks = {
        armor = "bofaisal.bypass.armor",
        blocked_name = "bofaisal.bypass.blocked_name",
        blocked_object = "bofaisal.bypass.blocked_object",
        blocked_ped = "bofaisal.bypass.blocked_ped",
        blocked_vehicle = "bofaisal.bypass.blocked_vehicle",
        blocked_weapon = "bofaisal.bypass.blocked_weapon",
        broadcast_abuse = "bofaisal.bypass.broadcast_abuse",
        devtools = "bofaisal.bypass.devtools",
        duplicate_account = "bofaisal.bypass.duplicate_account",
        entity_spawn = "bofaisal.bypass.entity_spawn",
        event_spam = "bofaisal.bypass.event_spam",
        executor = "bofaisal.bypass.executor",
        explosion = "bofaisal.bypass.explosion",
        fake_chat = "bofaisal.bypass.fake_chat",
        fast_reload = "bofaisal.bypass.fast_reload",
        fast_swim = "bofaisal.bypass.fast_swim",
        fire = "bofaisal.bypass.fire",
        freecam = "bofaisal.bypass.freecam",
        freeze_player = "bofaisal.bypass.freeze_player",
        godmode = "bofaisal.bypass.godmode",
        heal = "bofaisal.bypass.heal",
        heartbeat = "bofaisal.bypass.heartbeat",
        impossible_hit = "bofaisal.bypass.impossible_hit",
        infinite_ammo = "bofaisal.bypass.infinite_ammo",
        infinite_stamina = "bofaisal.bypass.infinite_stamina",
        invisibility = "bofaisal.bypass.invisibility",
        lua_injection = "bofaisal.bypass.lua_injection",
        menu_command = "bofaisal.bypass.menu_command",
        nightvision = "bofaisal.bypass.nightvision",
        noclip = "bofaisal.bypass.noclip",
        particles = "bofaisal.bypass.particles",
        protected_event = "bofaisal.bypass.protected_event",
        resource_stop = "bofaisal.bypass.resource_stop",
        spectate = "bofaisal.bypass.spectate",
        speed = "bofaisal.bypass.speed",
        super_jump = "bofaisal.bypass.super_jump",
        teleport = "bofaisal.bypass.teleport",
        thermal = "bofaisal.bypass.thermal",
        vehicle_model = "bofaisal.bypass.vehicle_model",
        vehicle_power = "bofaisal.bypass.vehicle_power",
        vehicle_speed = "bofaisal.bypass.vehicle_speed",
        vpn = "bofaisal.bypass.vpn",
        weapon_damage = "bofaisal.bypass.weapon_damage",
        weapon_give = "bofaisal.bypass.weapon_give",
        weapon_pellets = "bofaisal.bypass.weapon_pellets",
        weapon_rate = "bofaisal.bypass.weapon_rate",
        weapon_recoil = "bofaisal.bypass.weapon_recoil",
        weapon_remove = "bofaisal.bypass.weapon_remove",
        weapon_spawn = "bofaisal.bypass.weapon_spawn",
        weapon_spread = "bofaisal.bypass.weapon_spread",
    }, -- صلاحية تخطي كل كشف منفردًا
    groups = {
        entities = {
            checks = { "entity_spawn", "blocked_vehicle", "blocked_ped", "blocked_object" }, -- صلاحية تخطي كل كشف منفردًا
            permission = "bofaisal.bypass.entities", -- برمشن مستلم التنبيهات
        },
        movement = {
            checks = { "noclip", "teleport", "spectate", "freecam", "super_jump", "speed", "infinite_stamina", "fast_swim" }, -- صلاحية تخطي كل كشف منفردًا
            permission = "bofaisal.bypass.movement", -- برمشن مستلم التنبيهات
        },
        weapons = {
            checks = { "blocked_weapon", "weapon_damage", "weapon_rate", "fast_reload", "infinite_ammo", "weapon_give", "weapon_remove", "weapon_spawn", "impossible_hit" }, -- صلاحية تخطي كل كشف منفردًا
            permission = "bofaisal.bypass.weapons", -- برمشن مستلم التنبيهات
        },
    }, -- صلاحيات تخطي مجموعات الكشوفات
}

-- هوية ثابتة؛ رقم السيرفر المؤقت ليس معرف باند
Config.Identity = {
    allowVrpFallback = true, -- استخدام رقم vRP الثابت عند توفره
}

-- فترات الفحص والتهيئة ونبض العميل
Config.Client = {
    heartbeatSeconds = 15,
    heartbeatTimeoutSeconds = 90,
    intervalMs = 2000,
    reportCooldownSeconds = 20,
    startupGraceSeconds = 45,
    vehicleIntervalMs = 3000,
}

-- التصوير والمراقبة؛ يتطلب screenshot-basic
Config.Screenshots = {
    enabled = true, -- تفعيل الخاصية
    evidence = true, -- حفظ صورة وقت الباند
    maxBytes = 2500000, -- أقصى حجم للصورة المنقولة بالبايت
    maxConcurrent = 4,
    maxTargets = 12,
    monitorIntervalMs = 2500,
    qualities = {
        high = 0.7,
        low = 0.25,
        medium = 0.45,
    },
    resource = "screenshot-basic",
    timeoutMs = 25000, -- مهلة الطلب بالملي ثانية
    transferBytesPerSecond = 200000, -- سرعة نقل الصورة إلى الإدارة
    transport = "client", -- client افتراضيًا؛ server يستخدم تصدير السيرفر للتصوير
    uploadBytesPerSecond = 250000, -- سرعة نقل الصورة إلى السيرفر
}

-- حذف الكيانات وحدود الرسبنة والموديلات الممنوعة
Config.Entities = {
    batchDelayMs = 50,
    batchSize = 40,
    blockedObjects = { "prop_ld_bomb", "prop_gas_tank_01" },
    blockedPeds = { "s_m_y_swat_01" },
    blockedVehicles = { "RHINO", "LAZER", "HYDRA" },
    ignoreOccupiedVehicles = true, -- تجاهل السيارات التي بداخلها لاعبون
    limits = {
        object = 35,
        ped = 20,
        vehicle = 10,
    },
    maxPermitCount = 100,
    permissionsTTL = 15,
    radiusMax = 500,
    spawnWindowSeconds = 10,
}

-- الأسلحة الممنوعة وحدود الضرر والمدى والطلقات
Config.Weapons = {
    blocked = { "WEAPON_RAILGUN", "WEAPON_RPG", "WEAPON_MINIGUN" },
    deleteToolWeapon = "WEAPON_PISTOL",
    enforceGrantedWeapons = false,
    giveRemoveLimit = 5,
    giveRemoveWindowSeconds = 10,
    grantsTTLSeconds = 120,
    profiles = {
        WEAPON_CARBINERIFLE = {
            maxClip = 30,
            maxDamage = 70,
            maxPellets = 1,
            maxRange = 450,
            minReloadMs = 500,
            minShotMs = 35,
        },
        WEAPON_COMBATPISTOL = {
            maxClip = 12,
            maxDamage = 65,
            maxPellets = 1,
            maxRange = 180,
            minReloadMs = 500,
            minShotMs = 80,
        },
        WEAPON_PISTOL = {
            maxClip = 12,
            maxDamage = 60,
            maxPellets = 1,
            maxRange = 180,
            minReloadMs = 500,
            minShotMs = 80,
        },
        WEAPON_PUMPSHOTGUN = {
            maxClip = 8,
            maxDamage = 250,
            maxPellets = 12,
            maxRange = 150,
            minReloadMs = 250,
            minShotMs = 200,
        },
    },
}

-- حدود الحركة والصحة والدرع والمركبات
Config.Movement = {
    godmodeSamples = 3,
    maxArmor = 100,
    maxFootSpeed = 14,
    maxHealth = 200,
    maxJumpHeight = 7,
    maxPowerMultiplier = 100,
    maxSwimSpeed = 12,
    maxVehicleSpeed = 160,
    noclipAirSeconds = 10,
    teleportDistance = 160,
}

-- حدود التفجيرات والنيران والبارتكلز
Config.Explosions = {
    allowedParticleEffects = {
    },
    blockParticlesOnOtherPlayers = true,
    blockedTypes = { 0, 1, 2, 4, 5, 25, 32, 33, 35, 36, 37, 38 },
    cancelBlocked = true,
    maxCount = 6,
    maxDamageScale = 2,
    maxFires = 8,
    maxParticles = 15,
    windowSeconds = 10, -- نافذة احتساب الرصدات بالثواني
}

-- حدود الإيفنتات والتكاملات المحمية
Config.Events = {
    actionBurst = 15,
    actionWindowSeconds = 5,
    honeypots = { "bofaisal:decoy:grantMoney", "bofaisal:decoy:runCode" },
    protected = {
        ["example:protectedPurchase"] = {
            burst = 4,
            permission = false, -- برمشن مستلم التنبيهات
            windowSeconds = 10, -- نافذة احتساب الرصدات بالثواني
        },
    },
    reportBurst = 12,
    reportWindowSeconds = 10,
    suspiciousCommands = { "lynxmenu", "hammafia", "brutan", "redengine" },
}

-- أسماء أوامر الإدارة؛ المنطق في server/commands.lua
Config.Commands = {
    ban = "acban", -- باند لاعب
    chatClear = "acchatclear", -- مسح الشات
    chatLock = "acchatlock", -- قفل وفتح الشات
    diagnostics = "acstatus", -- فحص حالة OneSync والشات والتصوير والهوية
    kick = "ackick", -- طرد لاعب
    mute = "acmute", -- ميوت لاعب
    screenshot = "acshot", -- تصوير شاشة لاعب
    strip = "acstrip",
    unban = "acunban", -- فك باند
    unmute = "acunmute", -- فك الميوت
    wipe = "acwipe",
}

-- ربط vRP الأصلي Proxy/Tunnel والجوال
Config.VRP = {
    enabled = true, -- تفعيل الخاصية
    menuName = "BoFaisal AntiCheat",
    permissionPrefix = "",
    phoneMenus = { "phone" },
    resource = "vrp",
}

-- حدود أدوات الإدارة
Config.AdminTools = {
    deleteDistance = 100,
    espDistance = 200,
    espMaxPlayers = 32,
    freecamFastMultiplier = 4,
    freecamSpeed = 8,
    maxBanDays = 3650,
    positionTimeoutMs = 8000,
    reasonMaxLength = 240,
    worldBounds = 40000,
}

-- false: كشف العميل لا يطرد ولا يبند؛ يتحول إلى تحذير
Config.AllowClientPunishments = false

-- عقوبة وإشعار مستقلان لكل كشف؛ المعطل يحتاج دليلًا أو تكاملًا موثوقًا
Config.Checks = {
    armor = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تعبئة الدرع", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    blocked_name = {
        action = "kick", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "connection", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "اسم غير مسموح", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 1, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    blocked_object = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "أوبجكت ممنوع", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    blocked_ped = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "شخصية ممنوعة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    blocked_vehicle = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "مركبة ممنوعة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    blocked_weapon = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "mixed", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سلاح ممنوع", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    broadcast_abuse = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إرسال كلام غير مصرح للجميع", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    devtools = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "أدوات المطور", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    duplicate_account = {
        action = "kick", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "connection", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "حساب مكرر", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 1, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    entity_spawn = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سبام رسبنة الكيانات", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    event_spam = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سبام الإيفنتات", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    executor = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إيفنت طُعم للإكسكيوتر", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    explosion = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تفجيرات ممنوعة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    fake_chat = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "انتحال الشات", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    fast_reload = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سرعة التلقيم", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    fast_swim = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "السباحة السريعة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    fire = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سبام الحرائق", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    freecam = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الفري كام", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    }, -- الفري كام
    freeze_player = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تجميد لاعب آخر", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    godmode = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "القود مود", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    heal = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تعبئة الدم", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    heartbeat = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "انقطاع استجابة العميل", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    impossible_hit = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إصابة من مسافة مستحيلة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    infinite_ammo = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الرصاص اللانهائي", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    infinite_stamina = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الركض دون تعب", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    invisibility = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الاختفاء", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    lua_injection = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "حقن Lua", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    menu_command = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "أمر منيو مشبوه", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    nightvision = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الرؤية الليلية", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    noclip = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الطيران / نوكليب", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    particles = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إساءة استخدام البارتكلز", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    protected_event = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إيفنت غير مصرح", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    resource_stop = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إيقاف مورد الحماية", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    spectate = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "السبكتيت", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    speed = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سرعة الركض", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    super_jump = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "القفز العالي", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    teleport = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الانتقال غير المصرح", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    }, -- الانتقال للاعب
    thermal = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "الرؤية الحرارية", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    vehicle_model = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تغيير موديل المركبة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    vehicle_power = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تغيير قوة المحرك", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    vehicle_speed = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سرعة المركبة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    vpn = {
        action = "kick", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "connection", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "اتصال VPN", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 1, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_damage = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تغيير ضرر السلاح", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_give = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "إعطاء سلاح للآخرين", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_pellets = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "عدد الطلقات", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_rate = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سرعة إطلاق النار", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_recoil = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تغيير الارتداد", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_remove = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = true, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "سحب سلاح الآخرين", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_spawn = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "server", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "رسبنة الأسلحة", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
    weapon_spread = {
        action = "warn", -- العقوبة: none بدون، warn تحذير، kick طرد، ban باند
        banDays = 7, -- مدة الباند بالأيام؛ صفر دائم
        cooldownSeconds = 30, -- مهلة تكرار التنبيه بالثواني
        enabled = false, -- تفعيل الخاصية
        kind = "client", -- مصدر الدليل: client عميل، server سيرفر، mixed مشترك، connection دخول
        label = "تغيير انتشار الطلقات", -- اسم الكشف في المنيو والتنبيه
        message = "", -- سبب العقوبة؛ فارغ يستخدم اسم الكشف
        notify = true, -- إرسال تنبيه هذا الكشف
        notifyPermission = "", -- برمشن مستلم تنبيه هذا الكشف؛ فارغ يتبع البرمشن العام
        strikes = 3, -- عدد الرصدات قبل العقوبة
        windowSeconds = 90, -- نافذة احتساب الرصدات بالثواني
    },
}

-- رسائل العربية والإنجليزية القابلة للتعديل
Config.Locales = {
    ar = {
        alert = "تنبيه الحماية",
        appeal = "تقديم اعتراض",
        banId = "رقم الحظر",
        banSaveFailed = "لم يُنفذ الباند بسبب فشل حفظ البيانات",
        banned = "أنت محظور من السيرفر",
        captureBusy = "طلبات التصوير ممتلئة؛ انتظر وأعد المحاولة",
        captureDisabled = "التصوير معطل في الكونفيق",
        captureFailed = "فشل مورد التصوير؛ راجع F8 وكونسول screenshot-basic",
        captureInvalid = "وصلت صورة بصيغة غير صالحة",
        captureMissing = "مورد screenshot-basic غير مشغل على السيرفر",
        captureRequested = "تم طلب الصورة؛ انتظر وصولها",
        captureTimeout = "انتهت مهلة التصوير؛ تحقق من screenshot-basic على العميل واتصال الشبكة",
        captureTooLarge = "حجم الصورة تجاوز الحد؛ استخدم جودة أقل أو عدّل maxBytes",
        chatLocked = "الشات مقفل",
        chatUnsupported = "مورد الشات المعدل يحتاج ربط CheckChat قبل إرسال الرسالة",
        cleanupBusy = "عملية تنظيف أخرى قيد التنفيذ",
        cleanupComplete = "انتهى التنظيف: {count} كيانًا",
        cleanupFailed = "تعذر إكمال الحذف؛ تحقق من OneSync وكونسول السيرفر",
        cleanupQueued = "تم بدء التنظيف؛ سيظهر عدد المحذوف بعد انتهائه",
        date = "التاريخ",
        denied = "ليست لديك صلاحية",
        duplicate = "حسابك متصل بالفعل",
        expires = "ينتهي",
        filtered = "الرسالة تحتوي كلمة ممنوعة",
        kick = "تم طردك",
        missingIdentifiers = "تعذر الحصول على لايسنس أو رقم vRP ثابت للاعب؛ تأكد من رقم السيرفر واتصال vRP",
        muted = "أنت مكتوم",
        nameRejected = "اسم الدخول غير مسموح",
        needOneSync = "هذه العملية تتطلب OneSync؛ أضف set onesync on وأعد تشغيل السيرفر",
        offline = "اللاعب غير متصل",
        operationFailed = "تعذر تنفيذ العملية؛ راجع تفاصيل الخطأ في كونسول السيرفر",
        pedMissing = "لم تظهر شخصية اللاعب بعد؛ انتظر حتى يدخل اللعبة",
        permanent = "دائم",
        playerChanged = "اللاعب فصل أو تغيرت جلسة اتصاله",
        positionRequested = "تم طلب إحداثيات اللاعب؛ انتظر الاستجابة",
        positionTimeout = "اللاعب لم يرسل إحداثياته خلال المهلة",
        rateLimit = "انتظر قبل تكرار العملية",
        reason = "السبب",
        tooLong = "الرسالة طويلة",
        vpnRejected = "الاتصال عبر VPN غير مسموح",
        vpnUnavailable = "تعذر التحقق من الاتصال، حاول لاحقًا",
    },
    en = {
        alert = "Protection alert",
        appeal = "Appeal this ban",
        banId = "Ban ID",
        banSaveFailed = "Ban not applied: database save failed",
        banned = "You are banned from this server",
        captureBusy = "Capture queue is busy",
        captureDisabled = "Screenshots are disabled",
        captureFailed = "Screenshot provider failed; check F8/provider log",
        captureInvalid = "Invalid screenshot data",
        captureMissing = "screenshot-basic is not started",
        captureRequested = "Capture requested; waiting for image",
        captureTimeout = "Capture timeout; check client screenshot-basic and network",
        captureTooLarge = "Image exceeds maxBytes; lower quality",
        chatLocked = "Chat is locked",
        chatUnsupported = "Custom chat needs CheckChat integration before broadcast",
        cleanupBusy = "Cleanup already running",
        cleanupComplete = "Cleanup completed: {count} entities",
        cleanupFailed = "Cleanup failed; check OneSync and server log",
        cleanupQueued = "Cleanup started; completion count will follow",
        date = "Date",
        denied = "Permission denied",
        duplicate = "Your account is already connected",
        expires = "Expires",
        filtered = "Message contains a blocked word",
        kick = "You were kicked",
        missingIdentifiers = "No persistent license or vRP ID; verify server ID and framework",
        muted = "You are muted",
        nameRejected = "Invalid player name",
        needOneSync = "Enable OneSync and restart FXServer",
        offline = "Player is offline",
        operationFailed = "Operation failed; inspect server console",
        pedMissing = "Player ped is not available yet",
        permanent = "Permanent",
        playerChanged = "Player session changed",
        positionRequested = "Player position requested",
        positionTimeout = "Player position timed out",
        rateLimit = "Please slow down",
        reason = "Reason",
        tooLong = "Message is too long",
        vpnRejected = "VPN connections are not allowed",
        vpnUnavailable = "Connection check unavailable; try again",
    },
}
