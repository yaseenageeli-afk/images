"""Offline regression tests for real server code, with mocked FiveM natives.
Run: python -m pip install lupa==2.8 && python tests/test_server.py
These do not replace an FXServer integration test.
"""
from pathlib import Path
import json
import unittest
from lupa.lua54 import LuaRuntime, lua_type
ROOT = Path(__file__).resolve().parents[1]

class ServerTests(unittest.TestCase):
    def setUp(self):
        self.lua = LuaRuntime(unpack_returned_tuples=True)
        def to_python(value):
            if lua_type(value) != 'table':
                return value
            keys = list(value.keys())
            if keys and set(keys) == set(range(1, len(keys) + 1)):
                return [to_python(value[i]) for i in range(1,len(keys)+1)]
            return {str(k):to_python(v) for k,v in value.items()}
        self.lua.globals().py_encode = lambda v: json.dumps(to_python(v),ensure_ascii=False)
        self.lua.globals().py_decode = lambda s: self.lua.table_from(json.loads(s),recursive=True)
        self.lua.execute(r'''
        json={encode=py_encode,decode=py_decode}
        handlers={};clients={};threads={};timers={};commands={};files={};deleted={};dropped={}
        mockPlayers={[1]='Administrator',[2]='Player',[3]='Player <script>alert(1)</script>'}
        mockAces={[1]={},[2]={},[3]={}}
        now=100000;mockPermission=false;caller='trusted_inventory';cancelled=false;saveOK=true
        local exp={}
        exports=setmetatable({},{__call=function(_,name,fn)exp[name]=fn end,__index=function(_,k)return exp[k] end})
        function CreateThread(fn) threads[#threads+1]=fn end
        function Wait() end
        function SetTimeout(ms,fn) timers[#timers+1]={ms=ms,fn=fn} end
        function GetCurrentResourceName() return 'BoFaisal-AntiCheat' end
        function GetInvokingResource() return caller end
        function GetGameTimer() return now end
        function LoadResourceFile(_,path) return files[path] end
        function SaveResourceFile(_,path,data) if saveOK then files[path]=data;return true end;return false end
        function RegisterNetEvent(name,fn) if fn then handlers[name]=fn end end
        function AddEventHandler(name,fn) handlers[name]=fn end
        function RegisterCommand(name,fn) commands[name]=fn end
        function TriggerClientEvent(name,target,...) clients[#clients+1]={name=name,target=target,args={...}} end
        function TriggerLatentClientEvent(name,target,bps,...) TriggerClientEvent(name,target,...) end
        function GetPlayerName(src) return mockPlayers[tonumber(src)] end
        function GetPlayerIdentifiers(src) return {'license:user'..src,'steam:user'..src,'discord:123'..src,'ip:127.0.0.1'} end
        function GetPlayerIdentifierByType(src,kind) return kind..':user'..src end
        function GetPlayers() local t={};for id in pairs(mockPlayers) do t[#t+1]=tostring(id) end;table.sort(t);return t end
        function IsPlayerAceAllowed(src,permission) return mockPermission or (mockAces[src] and mockAces[src][permission]) or false end
        function GetResourceState(name) return 'missing' end
        function GetConvar(name,default) if name=='onesync' then return 'on' end;return default end
        function GetPlayerPing(src) return 45 end
        function GetPlayerEndpoint(src) return '127.0.0.1' end
        function DropPlayer(src,reason) dropped[#dropped+1]={src=src,reason=reason} end
        function CancelEvent() cancelled=true end
        function PerformHttpRequest(url,cb,method,body,headers) lastHTTP={url=url,body=body,headers=headers};cb(200,'{"vpn":false}',{}) end
        local hash=100;local hashes={}
        function GetHashKey(name) if not hashes[name] then hash=hash+1;hashes[name]=hash end;return hashes[name] end
        function GetPlayerPed(src) return tonumber(src)*10 end
        local vector={}
        function vector.__sub(a,b) return setmetatable({x=a.x-b.x,y=a.y-b.y,z=a.z-b.z},vector) end
        function vector.__len(a) return math.sqrt(a.x*a.x+a.y*a.y+a.z*a.z) end
        entities={[10]={kind=1,model=1000,owner=1,x=0,y=0,z=0},[20]={kind=1,model=1000,owner=2,x=1,y=0,z=0},[30]={kind=1,model=1000,owner=3,x=2,y=0,z=0},
          [40]={kind=2,model=1001,owner=2,x=3,y=0,z=0},[50]={kind=3,model=1002,owner=2,x=4,y=0,z=0},[60]={kind=1,model=1003,owner=2,x=5,y=0,z=0}}
        vehicles={[10]=40}
        function GetEntityCoords(entity) local e=entities[entity] or {x=0,y=0,z=0};return setmetatable({x=e.x,y=e.y,z=e.z},vector) end
        function GetEntityType(entity) return entities[entity].kind end
        function GetEntityModel(entity) return entities[entity].model end
        function NetworkGetEntityOwner(entity) return entities[entity].owner end
        function NetworkGetEntityFromNetworkId(id) return entities[id] and id or 0 end
        function GetEntityRoutingBucket(entity) return entities[entity].bucket or 0 end
        function GetPlayerRoutingBucket(src) return 0 end
        function SetPlayerRoutingBucket(src,bucket) end
        function GetVehiclePedIsIn(ped) return vehicles[ped] or 0 end
        function DoesEntityExist(entity) return entities[entity]~=nil end
        function DeleteEntity(entity) deleted[#deleted+1]=entity;entities[entity]=nil end
        function GetAllVehicles() return {40} end
        function GetAllObjects() return {50} end
        function GetAllPeds() return {10,20,30,60} end
        ''')
        for file in ['config.lua','permissions.lua','server/database.lua','server/runtime.lua','server/access.lua','server/discord.lua','server/punishments.lua','server/detections.lua','server/main.lua','server/commands.lua']:
            self.lua.execute((ROOT/file).read_text())
            if file=='config.lua': self.lua.execute('Config.Access.allowAce=true')
        self.lua.execute("for _,id in ipairs(GetPlayers()) do AC.players[tonumber(id)]={joined=os.time()-100,heartbeat=os.time(),risk=0} end")
    def run_lua(self,script): return self.lua.execute(script)
    def test_deferral_success_has_no_native_arguments(self):
        self.run_lua("source='2';handlers.playerConnecting('Player',function()end,{defer=function()end,done=function(...)assert(select('#',...)==0) end});assert(AC.Name('2')=='Player');assert(AC.Ped(0)==0)")
    def test_persistent_vrp_identity_not_server_source(self):
        self.run_lua("function GetPlayerIdentifiers()return {} end;AC.userIds[2]=501;local ids=AC.Identifiers('2');assert(ids.vrp=='vrp:vrp:501');assert(AC.Keys(ids)[1]=='vrp:vrp:501');AC.userIds[2]=nil;assert(#AC.Keys(AC.Identifiers(2))==0)")
    def test_no_onesync_cleanup_returns_specific_error(self):
        self.run_lua("mockPermission=true;function GetConvar(name,default)if name=='onesync' then return 'off' end;return default end;function GetPlayerPed()error('native called without OneSync')end;local ok,err=AC.Dispatch(1,'cleanup',{kind='object',scope='near',radius=100});assert(not ok and err==AC.T('needOneSync'));assert(#deleted==0);assert(AC.EntityCounts().available==false)")
    def test_capture_cross_source_replay_and_png(self):
        self.run_lua("mockAces[1][Config.Permissions.screenshot]=true;function GetResourceState()return 'started' end;local received=0;AC.Capture(1,2,'medium',function(ok,data)assert(ok and data=='data:image/png;base64,AAAA');received=received+1 end);local id=AC.shotSequence;source=3;handlers['bofaisal:captureResult'](id,'data:image/png;base64,AAAA');assert(received==0);source='2';handlers['bofaisal:captureResult'](id,'data:image/png;base64,AAAA');assert(received==1 and AC.shotActive==0);handlers['bofaisal:captureResult'](id,'data:image/png;base64,AAAA');assert(received==1)")
    def test_capture_oversize_releases_slot(self):
        self.run_lua("mockPermission=true;function GetResourceState()return 'started' end;Config.Screenshots.maxBytes=20;local failure;AC.Capture(1,2,'medium',function(ok,err)assert(not ok);failure=err end);source=2;handlers['bofaisal:captureResult'](AC.shotSequence,string.rep('a',21));assert(failure==AC.T('captureTooLarge') and AC.shotActive==0)")
    def test_teleport_missing_ped_bound_response(self):
        self.run_lua("mockAces[1][Config.Permissions.teleport]=true;function GetPlayerPed()return 0 end;assert(AC.Dispatch(1,'teleport',{target=2}));local id=AC.positionSequence;source=3;handlers['bofaisal:positionResult'](id,{x=20,y=20,z=20});assert(AC.positions[id]);source=2;handlers['bofaisal:positionResult'](id,{x=0/0,y=20,z=20});assert(AC.positions[id]);handlers['bofaisal:positionResult'](id,{x=20,y=20,z=20});assert(not AC.positions[id]);assert(clients[#clients].name=='bofaisal:teleport' and clients[#clients].target==1)")
    def test_granular_permissions_do_not_imply_other_actions(self):
        self.run_lua("mockAces[1][Config.Permissions.menu]=true;assert(not AC.Bypass(1,'noclip'));mockAces[1][Config.Permissions.chat]=true;assert(not AC.Dispatch(1,'chatClear',{}));mockAces[1][Config.Permissions.mute]=true;assert(not AC.Dispatch(1,'unmute',{target=2}));mockAces[1][Config.Permissions.stripPlayer]=true;assert(not AC.Dispatch(1,'strip',{all=true}));mockAces[1][Config.Permissions.cleanupObject]=true;assert(not AC.Dispatch(1,'cleanup',{kind='object',scope='all',radius=100}))")
    def test_spawn_bypass_does_not_bypass_blocked_vehicle(self):
        self.run_lua("mockAces[2][Config.Bypass.checks.entity_spawn]=true;entities[40].model=GetHashKey('RHINO');handlers.entityCreating(40);assert(cancelled);cancelled=false;mockAces[2][Config.Bypass.checks.blocked_vehicle]=true;handlers.entityCreating(40);assert(not cancelled)")
    def test_warning_notification_recipient_and_details(self):
        self.run_lua("mockAces[1]['custom.staff.alert']=true;Config.Notifications.permission='custom.staff.alert';Config.Checks.speed.strikes=1;AC.userIds[2]=501;AC.Detect(2,'speed','movement report','client');assert(#clients==1 and clients[1].target==1);local msg=clients[1].args[1].message;assert(msg:find('501') and msg:find('Player') and msg:find('تحذير') and msg:find('سرعة الركض'))")
    def test_esp_enable_masks_unauthorized_components(self):
        self.run_lua("mockAces[1][Config.Permissions.esp]=true;mockAces[1][Config.Permissions.espNames]=true;assert(AC.Dispatch(1,'tool',{tool='esp',enabled=true}));assert(clients[1].name=='bofaisal:espOptions');assert(clients[1].args[1].names and not clients[1].args[1].health and not clients[1].args[1].skeleton)")
    def test_every_lua_file_parses(self):
        parse=self.lua.eval('function(s,n) local f,e=load(s,n);return f~=nil,e end')
        for file in ROOT.rglob('*.lua'):
            with self.subTest(file=file.name): self.assertTrue(parse(file.read_text(),str(file))[0])
    def test_no_privileged_action_without_permissions(self):
        self.run_lua('''
        for _,action in ipairs({'snapshot','ban','unban','kick','mute','unmute','chatLock','chatClear','cleanup','strip','teleport','screenshot','monitorFrame','tool','policy','evidence','deleteEntity','menuState'}) do
          local ok=AC.Dispatch(2,action,{target=3,days=7,reason='test'})
          assert(ok==false,'Unauthorized action: '..action)
        end
        assert(#clients==0 and #dropped==0 and #deleted==0)
        ''')
    def test_permission_per_capability(self):
        self.run_lua('''
        mockAces[1][Config.Permissions.menu]=true
        local ok,data=AC.Dispatch(1,'snapshot',{})
        assert(ok and #data.players==0 and #data.bans==0 and #data.events==0)
        assert(AC.Dispatch(1,'ban',{target=2,days=7,reason='test'})==false)
        assert(AC.Dispatch(1,'tool',{tool='freecam',enabled=true})==false)
        ''')
    def test_ban_persist_reconnect_and_unban(self):
        self.run_lua('''
        mockPermission=true;Config.Screenshots.evidence=false
        local ok,id=AC.Dispatch(1,'ban',{target=2,days=7,reason='confirmed violation'})
        assert(ok and id=='BF-000001');assert(files[Config.Database.path])
        local serialized=json.decode(files[Config.Database.path]);assert(serialized.bans[id].reason=='confirmed violation')
        assert(AC.ActiveBan(AC.Identifiers(2)).id==id)
        timers[#timers].fn();assert(dropped[1].src==2)
        assert(AC.Dispatch(1,'unban',{id=id}));assert(AC.ActiveBan(AC.Identifiers(2))==nil)
        ''')
    def test_permanent_and_expired_bans(self):
        self.run_lua('''
        mockPermission=true;Config.Screenshots.evidence=false
        local ok,id=AC.Ban(1,2,'test',0);assert(ok and AC.DB.bans[id].expires==0)
        AC.DB.bans[id].expires=os.time()-1;assert(AC.ActiveBan(AC.Identifiers(2))==nil)
        ''')
    def test_fail_closed_corrupt_database(self):
        self.run_lua('''files[Config.Database.path]='corrupt';local ok=pcall(AC.LoadStore);assert(not ok)''')
    def test_failed_ban_save_does_not_drop(self):
        self.run_lua('''saveOK=false;Config.Screenshots.evidence=false;assert(AC.Ban(1,2,'test',7)==false);assert(#dropped==0);assert(AC.ActiveBan(AC.Identifiers(2))==nil)''')
    def test_mute_unmute_and_indefinite(self):
        self.run_lua('''
        mockPermission=true
        assert(AC.Dispatch(1,'mute',{target=2,minutes=10}));assert(AC.MuteExpiry(2)>os.time())
        assert(not AC.CheckChat(2,'hello'))
        assert(AC.Dispatch(1,'unmute',{target=2}));assert(AC.MuteExpiry(2)==nil)
        assert(AC.Dispatch(1,'mute',{target=2,minutes=0}));assert(AC.MuteExpiry(2)==0)
        assert(AC.Dispatch(1,'unmute',{target=2}));assert(AC.MuteExpiry(2)==nil)
        ''')
    def test_chat_filter_lock_bypass_and_impersonation(self):
        self.run_lua('''
        Config.Chat.forbiddenWords={'blocked','ممنوع'}
        assert(not AC.CheckChat(2,'this is blocked'));assert(not AC.CheckChat(2,'نص ممنوع'))
        assert(not AC.CheckChat(2,string.rep('a',Config.Chat.maxLength+1)))
        AC.chatLocked=true;assert(not AC.CheckChat(2,'hello'))
        mockAces[2][Config.Permissions.chatBypass]=true;assert(AC.CheckChat(2,'blocked'))
        assert(not AC.CheckChat(2,'hello','another player'))
        ''')
    def test_rpc_rate_limit(self):
        self.run_lua('''
        source=2
        for i=1,20 do handlers['bofaisal:rpc'](i,'snapshot',{}) end
        assert(#clients==20);assert(clients[20].args[2]==false and clients[20].args[3]==AC.T('rateLimit'))
        ''')
    def test_rate_reset_and_cross_player_isolation(self):
        self.run_lua("assert(AC.Rate(2,'a',1,5));assert(not AC.Rate(2,'a',1,5));assert(AC.Rate(3,'a',1,5));now=now+5000;assert(AC.Rate(2,'a',1,5))")
    def test_client_cannot_claim_server_detection(self):
        self.run_lua("source=2;handlers['bofaisal:report']('executor','spoof');assert(#AC.DB.events==0)")
    def test_client_automatic_ban_disabled(self):
        self.run_lua('''
        Config.Checks.godmode.action='ban';Config.Checks.godmode.strikes=1
        AC.Detect(2,'godmode','untrusted flag','client');assert(next(AC.DB.bans)==nil);assert(#dropped==0)
        assert(#AC.DB.events==1)
        ''')
    def test_client_grace(self):
        self.run_lua("assert(exports.GrantGrace(2,20,{'teleport'}));AC.Detect(2,'teleport','legitimate teleport','client');assert(#AC.DB.events==0)")
    def test_no_remote_grace_export(self):
        self.run_lua("caller=nil;assert(not exports.GrantGrace(2,20));assert(not exports.PermitSpawn(2,'vehicle',nil,1))")
    def test_blocked_spawn_cancelled_and_permission_consumed(self):
        self.run_lua('''
        entities[40].model=GetHashKey(Config.Entities.blockedVehicles[1])
        handlers.entityCreating(40);assert(cancelled)
        cancelled=false;assert(exports.PermitSpawn(2,'vehicle',{Config.Entities.blockedVehicles[1]},1,15))
        handlers.entityCreating(40);assert(not cancelled)
        handlers.entityCreating(40);assert(cancelled)
        ''')
    def test_spawn_flood_bounded(self):
        self.run_lua('''for i=1,Config.Entities.limits.object+1 do handlers.entityCreating(50) end;assert(cancelled)''')
    def test_explosions_and_multi_fire_cancelled(self):
        self.run_lua('''
        handlers.explosionEvent(2,{explosionType=Config.Explosions.blockedTypes[1],damageScale=1});assert(cancelled)
        cancelled=false;local fires={};for i=1,20 do fires[i]={} end;handlers.fireEvent(2,fires);assert(cancelled)
        ''')
    def test_particle_attack_on_player(self):
        self.run_lua("handlers.ptFxEvent(2,{entityNetId=30,effectHash=555});assert(cancelled)")
    def test_weapon_damage_and_range(self):
        self.run_lua('''
        handlers.weaponDamageEvent(2,{weaponType=GetHashKey('WEAPON_PISTOL'),overrideDefaultDamage=true,weaponDamage=200,hitGlobalId=30});assert(cancelled)
        cancelled=false;entities[30].x=10000
        handlers.weaponDamageEvent(2,{weaponType=GetHashKey('WEAPON_PISTOL'),weaponDamage=1,hitGlobalId=30});assert(cancelled)
        ''')
    def test_weapon_removal_of_other_player(self):
        self.run_lua("handlers.removeAllWeaponsEvent(2,{pedId=30});assert(cancelled)")
    def test_entity_deletion_protects_player_and_occupied_car(self):
        self.run_lua('''
        mockPermission=true;AC.tools[1]={deleteTool=true}
        assert(not AC.Dispatch(1,'deleteEntity',{netId=20}));assert(not AC.Dispatch(1,'deleteEntity',{netId=40}))
        assert(AC.Dispatch(1,'deleteEntity',{netId=50}));assert(deleted[1]==50)
        ''')
    def test_cleanup_near_bucket_and_occupied_protection(self):
        self.run_lua('''
        mockPermission=true;entities[50].bucket=10
        local before=#threads;assert(AC.Dispatch(1,'cleanup',{kind='object',scope='near',radius=100}));threads[#threads]();assert(#deleted==0)
        assert(AC.Dispatch(1,'cleanup',{kind='vehicle',scope='all',radius=100,ignoreOccupied=true}));threads[#threads]();assert(#deleted==0)
        assert(AC.Dispatch(1,'cleanup',{kind='ped',scope='all',radius=100}));threads[#threads]();assert(#deleted==1 and deleted[1]==60)
        ''')
    def test_policy_persists_and_rejects_unknown_action(self):
        self.run_lua('''
        mockPermission=true;assert(AC.Dispatch(1,'policy',{id='speed',action='none',banDays=1}))
        assert(Config.Checks.speed.action=='none');assert(json.decode(files[Config.Database.path]).policies.speed.action=='none')
        assert(not AC.Dispatch(1,'policy',{id='speed',action='runCode'}))
        ''')
    def test_protected_handler_rate_and_permission(self):
        self.run_lua('''
        count=0;assert(exports.RegisterProtectedEvent('example:protectedPurchase',function(src,value) assert(src==2 and value==42);count=count+1 end))
        source=2;for i=1,10 do handlers['example:protectedPurchase'](42) end;assert(count==4)
        assert(not exports.RegisterProtectedEvent('unknown:event',function()end))
        ''')
    def test_invalid_action_payloads(self):
        self.run_lua('''
        mockPermission=true
        assert(not AC.Dispatch(1,'ban',{target=2,days=-1,reason='test'}))
        assert(not AC.Dispatch(1,'ban',{target=2,days=0.5,reason='test'}))
        assert(not AC.Dispatch(1,'ban',{target=2,days=7,reason=''}))
        assert(not AC.Dispatch(1,'tool',{tool='godmode',enabled=true}))
        assert(not AC.Dispatch(1,'chatLock',{locked='false'}))
        assert(not AC.Dispatch(1,'mute',{target=2,minutes=-2}))
        ''')
    def test_screenshot_failure_and_timeout_release(self):
        self.run_lua('''
        Config.Screenshots.transport='server';called=false;AC.Capture(1,2,'medium',function(ok)assert(not ok);called=true end,true);assert(called)
        function GetResourceState(name) if name==Config.Screenshots.resource then return 'started' end;return 'missing' end
        exports[Config.Screenshots.resource]={requestClientScreenshot=function(_,target,opts,cb)screenshotCallback=cb end}
        AC.Capture(0,2,'medium',function(ok)assert(not ok);called=true end,true)
        assert(AC.shotActive==1);timers[#timers].fn();assert(AC.shotActive==0)
        screenshotCallback(nil,'data:image/jpeg;base64,aGVsbG8=');assert(AC.shotActive==0)
        ''')
    def test_snapshot_does_not_leak_identifiers_or_webhooks(self):
        self.run_lua('''
        mockPermission=true;Config.Screenshots.evidence=false;local ok,id=AC.Ban(1,2,'test',7)
        local data=AC.Snapshot(1,'week');assert(data.players[1].identifiers==nil and data.bans[1].identifiers==nil)
        assert(data.webhook==nil and #data.chart==7 and data.counts.peds==1)
        ''')
    def test_failed_mute_and_policy_save_roll_back(self):
        self.run_lua("mockPermission=true;saveOK=false;assert(not AC.Dispatch(1,'mute',{target=2,minutes=10}));assert(AC.MuteExpiry(2)==nil);assert(not AC.Dispatch(1,'policy',{id='speed',action='ban'}));assert(Config.Checks.speed.action=='warn')")
    def test_connection_duplicate_and_ban_deferrals(self):
        self.run_lua('''
        function deferral() return {defer=function()end,presentCard=function(card)lastCard=card end,done=function(message)connectionMessage=message end} end
        source=2;handlers.playerConnecting('Player',function()end,deferral());assert(connectionMessage==nil)
        local oldIdentifiers=GetPlayerIdentifiers
        function GetPlayerIdentifiers(src) if tonumber(src)==3 then return oldIdentifiers(2) end;return oldIdentifiers(src) end
        source=3;handlers.playerConnecting('Other',function()end,deferral());assert(connectionMessage==AC.T('duplicate'))
        Config.Screenshots.evidence=false;AC.Ban(0,2,'stored test',7)
        source=2;handlers.playerConnecting('Player',function()end,deferral());assert(lastCard and connectionMessage:find('BF%-000001'))
        ''')
    def test_trusted_report_integration_only(self):
        self.run_lua("Config.Checks.freeze_player.enabled=true;caller=nil;assert(not exports.ReportDetection(2,'freeze_player','x'));caller='trusted_resource';assert(exports.ReportDetection(2,'freeze_player','x'));assert(#AC.DB.events==1)")
    def test_phone_delete_tool_uses_own_permission(self):
        self.run_lua("mockAces[1][Config.Permissions.deleteTool]=true;assert(AC.Dispatch(1,'tool',{tool='deleteTool',enabled=true}));assert(AC.tools[1].deleteTool)")
    def test_connection_actions_none_alert_ban(self):
        self.run_lua('''
        function deferral() return {defer=function()end,presentCard=function()end,done=function(message)connectionMessage=message end} end
        Config.Chat.blockedNames={'Player'};source=2
        Config.Checks.blocked_name.action='none';handlers.playerConnecting('Player',function()end,deferral());assert(connectionMessage==nil)
        Config.Checks.blocked_name.action='warn';handlers.playerConnecting('Player',function()end,deferral());assert(connectionMessage==nil)
        Config.Checks.blocked_name.action='ban';handlers.playerConnecting('Player',function()end,deferral());assert(AC.ActiveBan(AC.Identifiers(2)));assert(connectionMessage:find('BF%-000001'))
        ''')
    def test_vpn_rejection_url_escaping_and_failure(self):
        self.run_lua('''
        function deferral() return {defer=function()end,presentCard=function()end,done=function(message)connectionMessage=message end} end
        Config.Connection.vpn.enabled=true;Config.Checks.vpn.enabled=true;Config.Connection.vpn.url='https://provider.example/check?ip=%s&encoded=%20'
        function PerformHttpRequest(url,cb)lastURL=url;cb(200,'{"vpn":true}',{}) end
        source=2;handlers.playerConnecting('Player',function()end,deferral());assert(connectionMessage==AC.T('vpnRejected'));assert(lastURL:find('encoded=%%20'))
        Config.Connection.vpn.failClosed=true
        function PerformHttpRequest(url,cb)cb(500,'',{}) end
        handlers.playerConnecting('Player',function()end,deferral());assert(connectionMessage==AC.T('vpnUnavailable'))
        ''')
    def test_locales_have_same_keys(self):
        self.run_lua('for k in pairs(Config.Locales.ar) do assert(Config.Locales.en[k],k) end;for k in pairs(Config.Locales.en) do assert(Config.Locales.ar[k],k) end')

if __name__ == '__main__': unittest.main(verbosity=2)
