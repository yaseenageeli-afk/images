-- مثال فقط: انسخ الصلاحيات إلى القروب الموجود في vrp/cfg/groups.lua.
-- لا تستبدل ملف قروباتك ولا تكرر اسم قروب موجود.
return {
  ["bofaisal_admin"] = {
    "bofaisal.alerts", -- استقبال رسائل الكشف والعقوبة للإدارة
    "bofaisal.ban", -- باند لاعب
    "bofaisal.chat.view", -- عرض صفحة الشات
    "bofaisal.chat.clear", -- مسح الشات
    "bofaisal.chat.lock", -- قفل وفتح الشات
    "bofaisal.entities.all", -- حذف كل الماب؛ تحتاج معها صلاحية نوع الكيان
    "bofaisal.entities.object", -- حذف الأوبجكتات
    "bofaisal.entities.ped", -- حذف البوتات
    "bofaisal.entities.vehicle", -- حذف المركبات
    "bofaisal.entities.delete_tool", -- تفعيل سلاح حذف الكيانات
    "bofaisal.diagnostics", -- فحص حالة OneSync والشات والتصوير والهوية
    "bofaisal.entities.view", -- عرض صفحة الكيانات
    "bofaisal.esp", -- تفعيل ESP
    "bofaisal.esp.armor", -- درع ESP
    "bofaisal.esp.boxes", -- مربعات ESP
    "bofaisal.esp.health", -- صحة ESP
    "bofaisal.esp.lines", -- خطوط ESP
    "bofaisal.esp.names", -- أسماء ESP
    "bofaisal.esp.skeleton", -- هيكل ESP
    "bofaisal.evidence", -- عرض صورة دليل الباند
    "bofaisal.freecam", -- الفري كام
    "bofaisal.kick", -- طرد لاعب
    "bofaisal.logs", -- عرض السجلات
    "admin.menu", -- فتح قائمة الحماية؛ حافظنا على صلاحية فتح قائمتك الحالية
    "bofaisal.monitor", -- المراقبة الدورية
    "bofaisal.mute", -- ميوت لاعب
    "bofaisal.phone", -- ظهور الحماية في جوال vRP
    "bofaisal.players", -- عرض اللاعبين
    "bofaisal.punishments", -- تغيير العقوبات
    "bofaisal.screenshot", -- تصوير شاشة لاعب
    "bofaisal.weapons.strip_all", -- سحب أسلحة جميع اللاعبين
    "bofaisal.weapons.strip_player", -- سحب أسلحة لاعب
    "bofaisal.teleport", -- الانتقال للاعب
    "bofaisal.unban", -- فك باند
    "bofaisal.unmute", -- فك الميوت
    "bofaisal.weapons.view", -- عرض صفحة الأسلحة
  },
  ["bofaisal_owner_bypass"] = {
    "bofaisal.bypass", -- تخطي كل الكشوفات؛ لا تمنحها لجميع الإدارة
  },
  ["bofaisal_movement_bypass"] = {
    "bofaisal.bypass.movement", -- تخطي مجموعة الحركة
  },
  ["bofaisal_individual_bypass"] = {
    "bofaisal.bypass.noclip", -- تخطي الطيران فقط
    "bofaisal.bypass.blocked_weapon", -- تخطي السلاح الممنوع فقط
  },
}
