'use strict';
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const resource=typeof GetParentResourceName==='function'?GetParentResourceName():'BoFaisal-AntiCheat';
const state={open:false,data:null,page:'dashboard',lang:'ar',period:'day',search:'',eventFilter:'all',
 monitor:false,targets:new Set(),quality:'medium',frames:new Map(),frameTimes:new Map(),cursor:0,
 scope:'near',radius:100,ignoreOccupied:true,esp:{names:true,health:true,armor:true,boxes:true,lines:false,skeleton:false},
 notifications:{chat:true,toast:true,sound:true}};
const pages=[['dashboard','◈','menu'],['entities','◇','entities'],['weapons','⌁','weapons'],['players','♙','players'],['monitor','▣','monitor'],['tools','⚙','menu'],['chat','▤','chat'],['bans','⊘','ban'],['policies','⚖','punishments'],['events','≡','logs'],['settings','⌘','menu']];
const t=key=>LOCALES[state.lang]?.[key]??LOCALES.en[key]??key;
const label=id=>state.data?.checks?.find(c=>c.id===id)?.label??CHECK_LABELS[state.lang]?.[id]??id.replaceAll('_',' ');
const can=cap=>Boolean(state.data?.permissions?.[cap]);
const date=at=>at?new Date(at*1000).toLocaleString(state.lang==='ar'?'ar-SA':'en-GB',{calendar:'gregory'}):t('permanent');
const time=at=>new Date(at*1000).toLocaleTimeString(state.lang==='ar'?'ar-SA':'en-GB',{hour:'2-digit',minute:'2-digit'});
async function nui(route,body={}) {
 const response=await fetch(`https://${resource}/${route}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
 if(!response.ok)throw new Error(`HTTP ${response.status}`);
 return response.json();
}
async function rpc(action,payload={},silent=false) {
 try{const result=await nui('rpc',{action,payload});if(!result.ok&&!silent)toast(result.data||t('error'),'danger');return result;}
 catch(error){if(!silent)toast(t('error'),'danger');return {ok:false,data:String(error.message)};}
}
function toast(message,kind='info'){
 const node=document.createElement('div');node.className=`toast ${kind}`;node.textContent=String(message);$('#toasts').append(node);
 while($('#toasts').children.length>5)$('#toasts').firstChild.remove();setTimeout(()=>node.remove(),5000);
}
async function refresh(){if(!state.open)return;const result=await rpc('snapshot',{period:state.period},true);if(result.ok){state.data=result.data;render();}else $('#status').textContent=result.data||t('error');}
function translated(){document.documentElement.lang=state.lang;document.documentElement.dir=state.lang==='ar'?'rtl':'ltr';document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=t(el.dataset.i18n));$('#language').textContent=state.lang==='ar'?'EN':'عربي';}
function button(key,action,payload={},kind='',cap){if(cap&&!can(cap))return '';return `<button class="button ${kind}" data-action="${action}" data-payload="${esc(JSON.stringify(payload))}">${esc(t(key))}</button>`;}
function toggle(key,on,attrs=''){return `<label class="field"><span>${esc(t(key))}</span><span class="switch"><input type="checkbox" ${on?'checked':''} ${attrs}><span></span></span></label>`;}
function empty(key){return `<div class="empty">${esc(t(key))}</div>`;}
function tabs(keys,current,attr){return `<div class="segments">${keys.map(k=>`<button ${attr}="${k}" class="${current===k?'active':''}">${esc(t(k))}</button>`).join('')}</div>`;}
function card(title,content,head=''){return `<section class="card"><div class="card-header"><h2>${esc(t(title))}</h2>${head}</div>${content}</section>`;}
function identity(player){return `<span class="identity">${player.avatar?`<img class="avatar" src="${esc(player.avatar)}" alt="">`:`<span class="avatar">${esc(player.name?.slice(0,1)||'?')}</span>`}<span>${esc(player.name)}<small>vRP: ${esc(player.userId??'—')} · Discord: ${esc(player.discord||'—')}</small></span></span>`;}
function chart(points,field,color){
 const width=700,height=165,max=Math.max(1,...points.map(p=>Number(p[field])||0));
 const coords=points.map((p,i)=>[20+i*(width-40)/Math.max(1,points.length-1),height-15-(Number(p[field])||0)*(height-35)/max]);
 const grid=[0,1,2,3].map(i=>`<line x1="20" y1="${20+i*42}" x2="680" y2="${20+i*42}" stroke="#253344" stroke-dasharray="3 6"/>`).join('');
 const path=coords.map((p,i)=>`${i?'L':'M'}${p[0]},${p[1]}`).join(' ');
 return `<svg class="charts" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" aria-label="${esc(t(field==='players'?'playersChart':'detectionsChart'))}"><defs><linearGradient id="gradient-${field}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${color}" stop-opacity=".25"/><stop offset="1" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>${grid}<path d="${path} L680,${height} L20,${height} Z" fill="url(#gradient-${field})"/><path d="${path}" fill="none" stroke="${color}" stroke-width="2"/></svg>`;
}
function eventRows(events){return events.length?`<div class="timeline">${events.map(e=>`<div class="timeline-item"><time class="timeline-time">${esc(time(e.at))}</time><span class="timeline-mark ${esc(e.category)}"></span><div class="timeline-info"><strong>${esc(label(e.code))}</strong><span class="pill ${e.category==='ban'?'red':e.category==='detection'?'amber':'blue'}">${esc(t(e.category))}</span><p>${esc(e.name)} ${e.target?`#${Number(e.target)}`:''} · ${esc(e.detail)}</p></div></div>`).join('')}</div>`:empty('noEvents');}
function dashboard(){
 const d=state.data,c=d.counts,points=d.chart||[],total=points.reduce((n,p)=>n+p.detections,0);
 const stats=[['onlinePlayers',c.players,'♙'],['vehicles',c.vehicles,'◇'],['peds',c.peds,'♧'],['activeBans',c.bans,'⊘'],['objects',c.objects,'▧'],['detections',total,'⌁']];
 return `<div class="grid stats">${stats.map(([key,n,icon])=>`<section class="stat"><span class="stat-label">${esc(t(key))}</span><span class="stat-icon">${icon}</span><div class="stat-value">${Number(n).toLocaleString('en')}</div><div class="stat-caption">${esc(t(key==='detections'?'recordedCount':'liveCount'))}</div></section>`).join('')}</div>`+
 card('activity',`<div class="legend"><span><i></i>${esc(t('playersChart'))}</span><span><i class="gold"></i>${esc(t('detectionsChart'))}</span></div><div class="grid split"><div><p>${esc(t('playersChart'))}</p><div class="chart-headline">${Math.max(0,...points.map(p=>p.players))}</div>${chart(points,'players','#2198f3')}</div><div><p>${esc(t('detectionsChart'))}</p><div class="chart-headline">${total}</div>${chart(points,'detections','#edba55')}</div></div><div class="chart-labels"><span>${points.length?esc(date(points[0].at)):''}</span><span>${points.length?esc(date(points.at(-1).at)):''}</span></div>`,tabs(['day','week','month'],state.period,'data-period'))+
 `<div style="height:16px"></div>`+card('recent',eventRows((d.events||[]).slice(0,4)),can('logs')?'<button class="button small" data-page="events">'+esc(t('viewAll'))+'</button>':'');
}
function players(){
 const q=state.search.toLowerCase();const list=(state.data.players||[]).filter(p=>[p.name,p.id,p.discord].some(v=>String(v).toLowerCase().includes(q)));
 return `<div class="toolbar"><label class="search"><span>⌕</span><input id="search" placeholder="${esc(t('search'))}" value="${esc(state.search)}"></label><span class="pill blue">${list.length} / ${state.data.counts.players}</span></div><p class="notice">${esc(t('riskHint'))}</p><div class="card table-wrap"><table><thead><tr>${['player','id','risk','ping','status','actions'].map(k=>`<th>${esc(t(k))}</th>`).join('')}</tr></thead><tbody>${list.map(p=>`<tr><td>${identity(p)}</td><td>${p.id}</td><td><span class="risk-track ${p.risk>=50?'high':''}">${Array.from({length:6},(_,i)=>`<i class="${i<Math.ceil(p.risk/17)?'filled':''}"></i>`).join('')}<span class="chip-number">${p.risk}</span></span></td><td>${p.ping} ms</td><td><span class="pill ${p.muted?'amber':'green'}">${esc(t(p.muted?'muted':'normal'))}</span></td><td><div class="actions">${button('teleport','teleport',{target:p.id},'small','teleport')}${button('screenshot','screenshot',{target:p.id},'small','screenshot')}${button('ban','banForm',{target:p.id},'small danger','ban')}${button('kick','kickForm',{target:p.id},'small','kick')}${button(p.muted?'unmute':'mute',p.muted?'unmute':'muteForm',{target:p.id},'small',p.muted?'unmute':'mute')}</div></td></tr>`).join('')}</tbody></table>${list.length?'':empty('noPlayers')}</div>`;
}
function entities(){return `${state.data.capabilities.onesync?'':`<div class="notice">${esc(t('needOneSync'))}</div>`}<section class="card"><div class="toolbar"><h2>${esc(t('scope'))}</h2>${tabs(['near','all'],state.scope,'data-scope')}</div><div class="field"><span>${esc(t('radius'))}</span><span id="radius-value">${state.radius} ${esc(t('meters'))}</span></div><input id="radius" type="range" min="1" max="${state.data.entityRadiusMax}" value="${state.radius}" aria-label="${esc(t('radius'))}">${toggle('ignoreOccupied',state.ignoreOccupied,'id="ignoreOccupied"')}<p class="hint">${esc(t('cleanupHint'))}</p></section><div style="height:16px"></div><div class="grid split">${[['vehicle','deleteVehicles',state.data.counts.vehicles],['ped','deletePeds',state.data.counts.peds],['object','deleteObjects',state.data.counts.objects]].map(([kind,key,count])=>card(key,`<div class="stat-value">${count}</div><p class="hint">${esc(t('cleanupHint'))}</p>${button('cleanup','cleanupForm',{kind},'wide',({vehicle:'cleanupVehicle',ped:'cleanupPed',object:'cleanupObject'})[kind])} `)).join('')}</div>`;}
function weapons(){return `<div class="notice">${esc(t('profileLimits'))}</div><div class="grid split">${card('strip',`<p class="hint">${esc(t('stripHint'))}</p><div class="toolbar"><input id="strip-target" type="number" min="1" placeholder="${esc(t('target'))}">${button('strip','stripOne',{},'primary','stripPlayer')}</div>`)}${card('deleteTool',`<p class="hint">${esc(t('deleteToolHint'))}</p>${toggle('deleteTool',state.data.tools.deleteTool,'data-tool="deleteTool" '+(can('deleteTool')?'':'disabled'))}`)}</div><div style="height:16px"></div><section class="card danger-card"><h2>${esc(t('stripAll'))}</h2><p class="hint">${esc(t('confirmStrip'))}</p>${button('stripAll','stripAllForm',{},'danger wide','stripAll')}</section>`;}
function tools(){return `<div class="grid split">${can('freecam')?card('freecam',`<p class="hint">${esc(t('freecamHint'))}</p>${toggle('freecam',state.data.tools.freecam,'data-tool="freecam"')}`):''}${can('esp')?card('esp',`<p class="hint">${esc(t('espHint'))}</p>${toggle('esp',state.data.tools.esp,'data-tool="esp"')}${Object.entries(state.esp).map(([key,on])=>toggle(key,on,`data-esp="${key}" ${can('esp'+key[0].toUpperCase()+key.slice(1))?'':'disabled'}`)).join('')}`):''}</div>`;}
function chat(){return `<div class="grid split">${card('chat',`${toggle('chatLock',state.data.chatLocked,'id="chat-lock" '+(can('chatLock')?'':'disabled'))}<p class="hint">${esc(t('chatHint'))}</p>${button('chatClear','chatClearForm',{},'danger wide','chatClear')}`)}${card('mute',`<div class="toolbar"><input id="mute-target" type="number" min="1" placeholder="${esc(t('target'))}"></div><div class="toolbar">${button('mute','muteTarget',{},'primary','mute')}${button('unmute','unmuteTarget',{},'','unmute')}</div>`)}</div><div style="height:16px"></div>${card('filter',`<div class="field"><span>${esc(t('maxLength'))}</span><span class="pill blue">${state.data.chatMaxLength}</span></div><p>${esc(t('filterHint'))}</p>`)}`;}
function bans(){
 const q=state.search.toLowerCase();const list=(state.data.bans||[]).filter(b=>[b.id,b.name,b.reason].some(v=>String(v).toLowerCase().includes(q)));
 return `<div class="toolbar"><label class="search"><span>⌕</span><input id="search" value="${esc(state.search)}" placeholder="${esc(t('banSearch'))}"></label><span class="pill red">${list.length}</span></div><div class="card table-wrap"><table><thead><tr>${['banId','player','reason','created','expires','actions'].map(k=>`<th>${esc(t(k))}</th>`).join('')}</tr></thead><tbody>${list.map(b=>`<tr><td>${esc(b.id)}</td><td>${esc(b.name)}</td><td>${esc(b.reason)}</td><td>${esc(date(b.created))}</td><td>${esc(date(b.expires))}</td><td><div class="actions">${button('unban','unbanForm',{id:b.id},'small danger','unban')}${b.evidence?button('evidence','evidence',{id:b.id},'small','evidence'):''}</div></td></tr>`).join('')}</tbody></table>${list.length?'':empty('noBans')}</div>`;
}
function policies(){
 const q=state.search.toLowerCase();const checks=(state.data.checks||[]).filter(c=>[c.id,label(c.id)].some(v=>v.toLowerCase().includes(q)));
 return `<div class="notice">${esc(t('heuristicNotice'))}</div><div class="toolbar"><label class="search"><span>⌕</span><input id="search" value="${esc(state.search)}" placeholder="${esc(t('policySearch'))}"></label></div><div class="grid policy-grid">${checks.map(c=>`<section class="card"><div class="policy-row"><div><strong>${esc(label(c.id))}</strong><small>${esc(t(c.kind))} · ${c.strikes} ${esc(t('detections'))}</small></div><span class="pill ${c.enabled?'blue':'amber'}">${esc(t(c.enabled?'enabled':'notImplemented'))}</span></div><div class="policy-row"><span class="muted">${esc(t('policies'))}</span><div class="segments">${['none','warn','kick','ban'].map(a=>`<button data-policy="${esc(c.id)}" data-policy-action="${a}" class="${c.action===a?'active':''}">${esc(t(a))}</button>`).join('')}</div></div><label class="field"><span>${esc(t('banDuration'))}</span><input type="number" min="0" max="3650" data-ban-days="${esc(c.id)}" value="${c.banDays}" style="width:75px"></label></section>`).join('')}</div>`;
}
function events(){const list=(state.data.events||[]).filter(e=>(state.eventFilter==='all'||e.category===state.eventFilter)&&[e.code,e.detail,e.name,e.target].some(v=>String(v).toLowerCase().includes(state.search.toLowerCase())));return `<div class="toolbar">${tabs(['all','detection','ban','admin'],state.eventFilter,'data-category')}<label class="search"><span>⌕</span><input id="search" value="${esc(state.search)}" placeholder="${esc(t('search'))}"></label></div>${card('events',eventRows(list))}`;}
function monitor(){
 const available=state.data.capabilities.screenshots;
 return `<div class="notice">${esc(t('monitorNotice'))}</div><div class="toolbar"><select id="quality" aria-label="${esc(t('monitor'))}">${[['low','low'],['medium','medium'],['high','highQuality']].map(([v,k])=>`<option value="${v}" ${state.quality===v?'selected':''}>${esc(t(k))}</option>`).join('')}</select><button id="monitor-toggle" class="button ${state.monitor?'danger':'primary'}" ${available?'':'disabled'}>${esc(t(state.monitor?'stopMonitor':'startMonitor'))}</button><span class="pill ${available?'blue':'amber'}">${esc(available?t('monitorLimit')+': '+state.data.monitor.maxTargets:t('unavailable'))}</span></div><section class="card"><div class="card-header"><h2>${esc(t('chooseTargets'))}</h2><small class="muted">${state.targets.size} / ${state.data.monitor.maxTargets}</small></div><div class="toolbar">${(state.data.players||[]).map(p=>`<label class="status-row"><input type="checkbox" data-monitor-target="${p.id}" ${state.targets.has(p.id)?'checked':''}>${esc(p.name)} #${p.id}</label>`).join('')}</div></section><div style="height:16px"></div><div class="monitor-grid">${[...state.targets].map(id=>{const p=state.data.players.find(x=>x.id===id);const frame=state.frames.get(id);return `<button class="monitor-tile" data-frame="${id}">${frame?`<img src="${esc(frame)}" alt="${esc(p?.name||id)}">`:`<span class="frame-placeholder">▣</span>`}<span class="frame-time" data-frame-time="${id}">${esc(state.frameTimes.has(id)?time(state.frameTimes.get(id)):t('waitingFrame'))}</span><span class="monitor-label"><strong>${esc(p?.name||id)} #${id}</strong><small>● ${esc(t(state.quality==='high'?'highQuality':state.quality))}</small></span></button>`;}).join('')}</div>`;
}
function settings(){return `<div class="grid split">${card('notifications',Object.entries(state.notifications).map(([key,on])=>toggle(key==='chat'?'chatNotifications':key,on,`data-notification="${key}"`)).join(''))}${card('integration',`<div class="field"><span>OneSync</span><span class="pill ${state.data.capabilities.onesync?'green':'amber'}">${esc(t(state.data.capabilities.onesync?'enabled':'unavailable'))}</span></div><div class="field"><span>vRP Proxy / Tunnel</span><span class="pill ${state.data.capabilities.vrp?'green':'amber'}">${esc(t(state.data.capabilities.vrp?'enabled':'unavailable'))}</span></div><div class="field"><span>${esc(t('screenshotIntegration'))}</span><span class="pill ${state.data.capabilities.screenshots?'green':'amber'}">${esc(t(state.data.capabilities.screenshots?'enabled':'unavailable'))}</span></div><div class="field"><span>${esc(t('clientAutoBan'))}</span><span class="pill amber">${esc(t(state.data.capabilities.clientPunishments?'enabled':'disabled'))}</span></div><p class="hint">${esc(t('profileLimits'))}</p>`)}</div><div style="height:16px"></div>${card('permissions',`<div class="toolbar">${Object.entries(state.data.permissions).filter(([,on])=>on).map(([key])=>`<span class="pill blue">${esc(key)}</span>`).join('')}</div>`)}`;}
const renderers={dashboard,players,monitor,entities,weapons,tools,chat,bans,policies,events,settings};
function render(){
 if(!state.data)return;
 const allowed=pages.filter(([, ,cap])=>can(cap)||(cap==='ban'&&can('unban')));
 if(!allowed.some(([page])=>page===state.page))state.page=allowed[0]?.[0]||'dashboard';
 $('#clock').textContent=new Date().toLocaleTimeString('en-GB');$('#brand').textContent=state.data.brand;$('#online').textContent=`${state.data.counts.players} ${t('onlinePlayers')}`;
 $('#nav').innerHTML=allowed.map(([page,icon])=>`<button class="nav-item ${state.page===page?'active':''}" data-page="${page}"><span class="nav-icon">${icon}</span><span>${esc(t(page))}</span>${page==='players'?`<span class="nav-badge">${state.data.counts.players}</span>`:''}</button>`).join('');
 $('#breadcrumb').textContent=t(state.page);$('#page-name').textContent=t(state.page);$('#page-description').textContent=t(state.page+'Desc');
 $('#content').innerHTML=renderers[state.page]();translated();$('#status').textContent=t('connected');
}
function form(title,fields,submit){
 const dialog=$('#dialog');dialog.classList.remove('frame-dialog');dialog.innerHTML=`<form id="action-form"><h2>${esc(title)}</h2><div class="dialog-fields">${fields.map(f=>f.type==='notice'?`<p>${esc(f.label)}</p>`:`<label>${esc(f.label)}<${f.type==='textarea'?'textarea':'input'} name="${esc(f.name)}" ${f.type==='textarea'?'':`type="${esc(f.type||'text')}"`} ${f.min!==undefined?`min="${f.min}"`:''} ${f.max!==undefined?`max="${f.max}"`:''} ${f.required?'required':''} ${f.type==='textarea'?'':`value="${esc(f.value??'')}"`} ${f.maxLength?`maxlength="${f.maxLength}"`:''}>${f.type==='textarea'?esc(f.value??'')+'</textarea>':''}</label>`).join('')}</div><div class="dialog-buttons"><button type="button" class="button" id="dialog-cancel">${esc(t('cancel'))}</button><button class="button primary" type="submit">${esc(t('confirm'))}</button></div></form>`;
 $('#dialog-cancel').onclick=()=>dialog.close();$('#action-form').onsubmit=async e=>{e.preventDefault();const submitButton=e.target.querySelector('[type=submit]');submitButton.disabled=true;const values=Object.fromEntries(new FormData(e.target));try{const ok=await submit(values);if(ok!==false)dialog.close();}finally{submitButton.disabled=false;}};dialog.showModal();
}
function confirmAction(message,action,payload){form(t('confirmDanger'),[{type:'notice',label:message}],async()=>execute(action,payload));}
async function execute(action,payload){const result=await rpc(action,payload);if(result.ok){toast(typeof result.data==='string'&&result.data!=='ok'?result.data:t('saved'),'success');await refresh();}return result.ok;}
function waitingFrame(id){
 const dialog=$('#dialog');dialog.dataset.frame=String(id);dialog.classList.add('frame-dialog');dialog.innerHTML=`<h2>${esc(t('frame'))} #${esc(id)}</h2><p>${esc(t('waitingFrame'))}</p><div class="dialog-buttons"><button class="button" id="dialog-cancel">${esc(t('close'))}</button></div>`;$('#dialog-cancel').onclick=()=>dialog.close();if(!dialog.open)dialog.showModal();
}
function showFrame(id){
 const frame=state.frames.get(id);const dialog=$('#dialog');dialog.classList.add('frame-dialog');dialog.dataset.frame=String(id);
 dialog.innerHTML=`<h2>${esc(t('frame'))} #${esc(id)}</h2>${frame?`<img class="capture-full" src="${esc(frame)}" alt="${esc(t('frame'))}">`:`<p>${esc(t('noFrame'))}</p>`}<div class="dialog-buttons"><button class="button" id="dialog-cancel">${esc(t('close'))}</button></div>`;
 $('#dialog-cancel').onclick=()=>dialog.close();if(!dialog.open)dialog.showModal();
}
$('#dialog').addEventListener('close',()=>{delete $('#dialog').dataset.frame;});
async function handleAction(action,p){
 if(action==='banForm')return form(t('ban')+' #'+p.target,[{name:'reason',type:'textarea',label:t('reason'),required:true,maxLength:240},{name:'days',type:'number',label:t('days'),min:0,max:3650,value:7,required:true}],v=>execute('ban',{target:p.target,reason:v.reason,days:Number(v.days)}));
 if(action==='kickForm')return form(t('kick')+' #'+p.target,[{name:'reason',type:'textarea',label:t('reason'),required:true,maxLength:240}],v=>execute('kick',{target:p.target,reason:v.reason}));
 if(action==='muteForm')return form(t('mute')+' #'+p.target,[{name:'minutes',type:'number',label:t('minutes'),min:0,max:10080,value:10,required:true}],v=>execute('mute',{target:p.target,minutes:Number(v.minutes)}));
 if(action==='unbanForm')return confirmAction(t('unban')+' '+p.id,'unban',p);
 if(action==='cleanupForm')return confirmAction(t('confirmCleanup'),'cleanup',{kind:p.kind,scope:state.scope,radius:state.radius,ignoreOccupied:state.ignoreOccupied});
 if(action==='stripAllForm')return confirmAction(t('confirmStrip'),'strip',{all:true});
 if(action==='chatClearForm')return confirmAction(t('chatClear'),'chatClear',{});
 if(action==='stripOne')return execute('strip',{target:Number($('#strip-target').value)});
 if(action==='muteTarget'||action==='unmuteTarget'){
  const target=Number($('#mute-target').value);if(!Number.isInteger(target)||target<1)return toast(t('invalidNumber'),'danger');
  return handleAction(action==='muteTarget'?'muteForm':'unmute',{target});
 }
 if(action==='screenshot'){state.captureTarget=Number(p.target);waitingFrame(p.target);const result=await rpc('screenshot',{...p,quality:state.quality});if(!result.ok){state.captureTarget=null;if($('#dialog').open)$('#dialog').close();}return;}
 if(action==='evidence'){state.captureTarget=p.id;await rpc('evidence',p);return;}
 return execute(action,p);
}
document.addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b||b.disabled)return;
 if(b.dataset.page){state.page=b.dataset.page;state.search='';if(state.page!=='monitor')state.monitor=false;render();return;}
 if(b.dataset.period){state.period=b.dataset.period;await refresh();return;}
 if(b.dataset.scope){state.scope=b.dataset.scope;render();return;}
 if(b.dataset.category){state.eventFilter=b.dataset.category;render();return;}
 if(b.dataset.action){await handleAction(b.dataset.action,JSON.parse(b.dataset.payload||'{}'));return;}
 if(b.dataset.policy){const c=state.data.checks.find(x=>x.id===b.dataset.policy);await execute('policy',{id:c.id,action:b.dataset.policyAction,banDays:c.banDays});return;}
 if(b.dataset.frame){showFrame(Number(b.dataset.frame));return;}
 if(b.id==='monitor-toggle'){state.monitor=!state.monitor;render();return;}
});
document.addEventListener('input',e=>{
 if(e.target.id==='search'){state.search=e.target.value;const start=e.target.selectionStart,end=e.target.selectionEnd;render();$('#search').focus();$('#search').setSelectionRange(start,end);}
 if(e.target.id==='radius'){state.radius=Number(e.target.value);$('#radius-value').textContent=`${state.radius} ${t('meters')}`;}
});
document.addEventListener('change',async e=>{
 const el=e.target;
 if(el.id==='ignoreOccupied')state.ignoreOccupied=el.checked;
 if(el.id==='quality')state.quality=el.value;
 if(el.id==='chat-lock')await execute('chatLock',{locked:el.checked});
 if(el.dataset.tool){await execute('tool',{tool:el.dataset.tool,enabled:el.checked});}
 if(el.dataset.esp){state.esp[el.dataset.esp]=el.checked;await rpc('espOptions',state.esp);}
 if(el.dataset.notification){state.notifications[el.dataset.notification]=el.checked;await nui('preferences',state.notifications);}
 if(el.dataset.monitorTarget){
  const id=Number(el.dataset.monitorTarget);if(el.checked){if(state.targets.size>=state.data.monitor.maxTargets){el.checked=false;toast(t('monitorLimit'),'danger');return;}state.targets.add(id);}else{state.targets.delete(id);state.frames.delete(id);state.frameTimes.delete(id);}render();
 }
 if(el.dataset.banDays){const c=state.data.checks.find(x=>x.id===el.dataset.banDays);await execute('policy',{id:c.id,action:c.action,banDays:Number(el.value)});}
});
async function close(){state.open=false;state.monitor=false;state.frames.clear();state.frameTimes.clear();$('#app').hidden=true;if($('#dialog').open)$('#dialog').close();await nui('close').catch(()=>{});}
$('#close').onclick=close;$('#refresh').onclick=refresh;$('#language').onclick=()=>{state.lang=state.lang==='ar'?'en':'ar';render();};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&state.open&&!$('#dialog').open)close();});
window.addEventListener('message',e=>{
 const message=e.data;if(!message||typeof message!=='object')return;
 if(message.type==='open'){state.data=message.data;state.lang=message.data.language||'ar';state.open=true;$('#app').hidden=false;render();}
 if(message.type==='close'){state.open=false;state.monitor=false;$('#app').hidden=true;if($('#dialog').open)$('#dialog').close();}
 if(message.type==='toast'&&state.notifications.toast)toast(message.data.message,message.data.kind);
 if(message.type==='tools'&&state.data){state.data.tools=message.data;if(state.open)render();}
 if(message.type==='frame'){
  const f=message.data;f.target=/^\d+$/.test(String(f.target))?Number(f.target):f.target;
  if(!f.ok){toast(f.data||t('noFrame'),'danger');if(state.captureTarget===f.target){state.captureTarget=null;if($('#dialog').open)$('#dialog').close();}return;}
  if(typeof f.data!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(f.data))return;
  if(!state.open)return;
  state.frames.set(f.target,f.data);state.frameTimes.set(f.target,Date.now()/1000);
  while(state.frames.size>32){const key=state.frames.keys().next().value;state.frames.delete(key);state.frameTimes.delete(key);}
  if(state.page==='monitor'){
   const tile=document.querySelector(`[data-frame="${Number(f.target)}"]`);if(tile){const old=tile.querySelector('img,.frame-placeholder');const img=document.createElement('img');img.src=f.data;img.alt=t('frame');old.replaceWith(img);tile.querySelector('.frame-time').textContent=time(Date.now()/1000);}
  }
  if(state.captureTarget===f.target||$('#dialog').dataset.frame===String(f.target)){state.captureTarget=null;showFrame(f.target);}
 }
 if(message.type==='ban'){
  state.lang=message.language||state.lang;const b=message.data;
  $('#app').hidden=true;$('#ban-screen').hidden=false;$('#ban-screen').innerHTML=`<section class="ban-card"><div class="ban-icon">⊘</div><h1>${esc(t('banned'))}</h1><p>${esc(b.reason)}</p><div class="ban-facts">${[['banId',b.id],['created',date(b.created)],['expires',date(b.expires)],['reason',b.reason]].map(([k,v])=>`<div><small>${esc(t(k))}</small><strong>${esc(v)}</strong></div>`).join('')}</div><button class="button primary wide" id="appeal">${esc(t('appeal'))}</button></section>`;
  translated();$('#appeal').onclick=()=>{if(typeof b.appeal==='string'&&/^https:\/\/(discord\.gg\/|discord\.com\/invite\/)/.test(b.appeal)&&typeof window.invokeNative==='function')window.invokeNative('openUrl',b.appeal);};
 }
});
setInterval(()=>{if(state.open)$('#clock').textContent=new Date().toLocaleTimeString('en-GB');},1000);
setInterval(refresh,10000);
let monitorBusy=false;let lastMonitor=0;
setInterval(async()=>{
 if(monitorBusy||!state.open||!state.monitor||state.page!=='monitor'||!can('monitor'))return;
 if(Date.now()-lastMonitor<Math.max(2500,state.data.monitor.intervalMs))return;lastMonitor=Date.now();
 const ids=[...state.targets].filter(id=>state.data.players.some(p=>p.id===id));if(!ids.length)return;
 monitorBusy=true;const count=Math.min(ids.length,state.data.monitor.maxConcurrent);const batch=[];
 for(let i=0;i<count;i++)batch.push(ids[(state.cursor+i)%ids.length]);state.cursor=(state.cursor+count)%ids.length;
 try{await Promise.all(batch.map(target=>rpc('monitorFrame',{target,quality:state.quality},true)));}finally{monitorBusy=false;}
},500);
