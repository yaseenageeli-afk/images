-- Codex: server-authorized camera sessions, sector chat and shared police chat.
local B=BoFaisaL
local X={sessions={},channels={},sequence=0};B.Extra=X
local function cfg(key)return (Config.Extra and Config.Extra[key]) or {} end
local function vrp(uid,key)return B.Framework.hasPermission(uid,key)==true end
local function cameraAllowed(uid)
 local c=cfg('Cameras')
 return c.Enabled~=false and B.Gov.getProfile(uid,true).isMilitary==true and vrp(uid,c.Permission or 'police.cameras')
end
function X.capabilities(uid)
 local p=B.Gov.getProfile(uid,true)
 return {cameras=cameraAllowed(uid),sector=cfg('SectorChat').Enabled~=false and p.isMilitary==true and p.memberSector~=nil,
 shared=cfg('SharedChat').Enabled~=false and vrp(uid,cfg('SharedChat').Permission or 'police.em')}
end
local function channel(uid,kind)
 if kind=='shared' then
  if cfg('SharedChat').Enabled==false or not vrp(uid,cfg('SharedChat').Permission or 'police.em') then return nil end
  return 'shared','الشات المشترك'
 elseif kind=='sector' then
  local p=B.Gov.getProfile(uid,true)
  if cfg('SectorChat').Enabled==false or not p.isMilitary or not p.memberSector then return nil end
  return 'sector:'..p.memberSector,B.Gov.sectorLabel(p.memberSector)
 end
end
local function history(key)
 X.channels[key]=X.channels[key] or {};return X.channels[key]
end
B.RPC.register('extras:capabilities',{feature='Ipad',military=true,allowVacation=true},function(ctx)return X.capabilities(ctx.user_id)end)
B.RPC.register('extras:chat:history',{cooldown=500},function(ctx,data)
 local key,label=channel(ctx.user_id,data.kind);if not key then return nil,L('err_no_permission')end
 return {kind=data.kind,label=label,messages=history(key)}
end)
B.RPC.register('extras:chat:send',{cooldown=1200},function(ctx,data)
 local key,label=channel(ctx.user_id,data.kind);if not key then return nil,L('err_no_permission')end
 local text=B.RPC.text(data.text,500);if not text then return nil,L('err_invalid_request')end
 X.sequence=X.sequence+1
 local message={id=X.sequence,user_id=ctx.user_id,name=Utils.sanitize(ctx.name,64),text=text,time=B.now()}
 B.Logs.add('communications','chat_send',{actor=ctx.user_id,title=data.kind=='sector' and 'رسالة شات القطاع' or 'رسالة الشات المشترك',fields={{'القناة',label},{'الرسالة',text}}})
 local list=history(key);list[#list+1]=message
 local limit=math.min(100,math.max(10,tonumber(cfg(data.kind=='shared' and 'SharedChat' or 'SectorChat').MaxMessages) or 100))
 while #list>limit do table.remove(list,1)end
 -- Fresh authorization for EVERY receiver. No broadcast event and no client-supplied sector.
 for source,uid in pairs(B.Players.bySource)do
  if channel(uid,data.kind)==key then TriggerClientEvent('bofaisal_police:ipad:push',source,'extraChat',{kind=data.kind,label=label,message=message})end
 end
 return {message=message}
end)
function X.stop(source)
 if X.sessions[source]then local session=X.sessions[source];B.Logs.add('surveillance','camera_stop',{actor=session.user_id,title='إنهاء مشاهدة كاميرا',fields={{'الكاميرا',session.id}}});X.sessions[source]=nil;TriggerClientEvent('bofaisal_police:camera:stop',source)end
end
B.RPC.register('extras:cameras:list',{feature='Ipad',military=true,cooldown=500},function(ctx)
 if not cameraAllowed(ctx.user_id)then return nil,L('err_no_permission')end
 local list={};for id,c in pairs(Config.SecurityCameras or {})do
  list[#list+1]={id=id,label=c.label or ('كاميرا '..id),online=c.isOnline~=false,canRotate=c.canRotate==true}
 end
 table.sort(list,function(a,b)return a.id<b.id end);return {list=list}
end)
B.RPC.register('extras:cameras:watch',{feature='Ipad',military=true,cooldown=800},function(ctx,data)
 if not cameraAllowed(ctx.user_id)then X.stop(ctx.source);return nil,L('err_no_permission')end
 local id=B.RPC.int(data.id,1,10000);local c=id and (Config.SecurityCameras or {})[id]
 if not c or c.isOnline==false then return nil,L('err_invalid_request')end
 B.Logs.add('surveillance','camera_watch',{actor=ctx.user_id,title='مشاهدة كاميرا مراقبة',fields={{'الكاميرا',id},{'الاسم',c.label}}})
 X.sequence=X.sequence+1
 local token=tostring(ctx.user_id)..':'..tostring(X.sequence)
 X.sessions[ctx.source]={user_id=ctx.user_id,id=id,token=token,expires=B.now()+25}
 TriggerClientEvent('bofaisal_police:camera:start',ctx.source,{id=id,token=token,label=c.label,coords=c.coords,rotation=c.rotation,canRotate=c.canRotate==true})
 return {id=id,label=c.label,canRotate=c.canRotate==true}
end)
B.RPC.register('extras:cameras:heartbeat',{cooldown=8000},function(ctx)
 local s=X.sessions[ctx.source];local c=s and (Config.SecurityCameras or {})[s.id]
 if not s or s.user_id~=ctx.user_id or not c or c.isOnline==false or not cameraAllowed(ctx.user_id)then
  X.stop(ctx.source);return nil,L('err_no_permission')
 end
 s.expires=B.now()+25;TriggerClientEvent('bofaisal_police:camera:lease',ctx.source);return {active=true}
end)
B.RPC.register('extras:cameras:stop',{},function(ctx,data)
 local session=X.sessions[ctx.source]
 if session and data.token==session.token then X.stop(ctx.source)end
 return {stopped=true}
end)
B.RPC.register('extras:pose',{feature='Ipad',military=true,cooldown=1000},function(ctx,data)
 if cfg('Poses').Enabled==false or not B.Officers.isOnDuty(ctx.user_id)then return nil,L('err_not_on_duty')end
 local command=({steady='e poG83',ready='e poG82',rest='e poG84'})[data.pose]
 if not command then return nil,L('err_invalid_request')end
 B.Logs.add('field','military_pose',{actor=ctx.user_id,title='وقفة عسكرية',fields={{'الوقفة',({steady='الثبات',ready='الإستعداد',rest='الراحة'})[data.pose]},{'الأمر',command}}})
 TriggerClientEvent('bofaisal_police:pose',ctx.source,command);return {ok=true}
end)
function X.sweep()
 for source,s in pairs(X.sessions)do
  if B.now()>s.expires or B.Players.getUserId(source)~=s.user_id or not cameraAllowed(s.user_id)then X.stop(source)end
 end
end
CreateThread(function()while true do Wait(5000);X.sweep()end end)
B.on('playerDropped',function(_,source)if source then X.sessions[source]=nil end end)
