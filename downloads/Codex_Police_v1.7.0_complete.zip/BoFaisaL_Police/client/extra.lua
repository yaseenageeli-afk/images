-- Cameras render the game through the tablet's transparent viewport. No player teleport.
local cam,session,originalYaw,originalPitch,lease
local requested=false
local function stop()
 requested=false
 local active=cam~=nil
 if cam then RenderScriptCams(false,false,0,true,true);DestroyCam(cam,false)end
 cam,session=nil,nil
 if active then ClearFocus();ClearTimecycleModifier();UI.send('ipad:push',{type='cameraStopped',data={}})end
end
BoFaisaL.stopSecurityCamera=stop
RegisterNetEvent('bofaisal_police:camera:start',function(data)
 if not requested or not BoFaisaL.isIpadOpen() then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=data.token})end);return end
 stop();requested=true;session=data;originalYaw=data.rotation.z;originalPitch=data.rotation.x;lease=GetGameTimer()+25000
 cam=CreateCam('DEFAULT_SCRIPTED_CAMERA',true)
 SetCamCoord(cam,data.coords.x,data.coords.y,data.coords.z);SetCamRot(cam,data.rotation.x,data.rotation.y,data.rotation.z,2);SetCamFov(cam,65.0)
 SetFocusPosAndVel(data.coords.x,data.coords.y,data.coords.z,0.0,0.0,0.0)
 SetCamActive(cam,true);RenderScriptCams(true,false,0,true,true);SetTimecycleModifier('scanline_cam_cheap')
end)
RegisterNetEvent('bofaisal_police:camera:stop',stop)
RegisterNetEvent('bofaisal_police:camera:lease',function()if cam then lease=GetGameTimer()+25000 end end)
RegisterNUICallback('cameraPrepare',function(_,cb)requested=true;cb({ok=true})end)
RegisterNUICallback('cameraStop',function(_,cb)
 local token=session and session.token;stop();cb({ok=true});
 if token then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=token})end)end
end)
RegisterNUICallback('cameraControl',function(data,cb)
 if not cam or not session then cb({ok=false});return end
 local r=GetCamRot(cam,2);local fov=GetCamFov(cam)
 if data.direction=='state' then -- Read telemetry without changing the camera.
 elseif data.direction=='zoomIn' then fov=math.max(30,fov-2);SetCamFov(cam,fov)
 elseif data.direction=='zoomOut' then fov=math.min(85,fov+2);SetCamFov(cam,fov)
 elseif data.direction=='reset' then
  SetCamRot(cam,originalPitch,session.rotation.y,originalYaw,2);SetCamFov(cam,65.0)
 else
  if not session.canRotate then cb({ok=false});return end
  local step=({left=-2.5,right=2.5,up=2.5,down=-2.5})[data.direction]
  if not step then cb({ok=false});return end
  -- Wrapping yaw gives uninterrupted full turns; pitch stops before a flipped camera.
  local pitch=math.max(-85,math.min(85,r.x+((data.direction=='up' or data.direction=='down')and step or 0)))
  local yaw=(r.z+((data.direction=='left' or data.direction=='right')and step or 0)+360)%360
  SetCamRot(cam,pitch,r.y,yaw,2)
 end
 r=GetCamRot(cam,2);cb({ok=true,data={yaw=(r.z+360)%360,pitch=r.x,zoom=65.0/GetCamFov(cam)}})
end)
RegisterNetEvent('bofaisal_police:pose',function(command)
 -- Fixed commands only. Never execute arbitrary strings received from the UI.
 if command=='e poG83' or command=='e poG82' or command=='e poG84' then
  BoFaisaL.closeIpad();UI.focus('menu',false);ExecuteCommand(command)
 end
end)
AddEventHandler('bofaisal_police:client:closed',function(layer)if layer=='ipad'then stop()end end)
AddEventHandler('onResourceStop',function(name)if name==GetCurrentResourceName()then stop()end end)
CreateThread(function()while true do
 Wait(cam and 100 or 1000)
 if cam and (GetGameTimer()>lease or IsEntityDead(PlayerPedId()))then
  local token=session and session.token;stop();if token then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=token})end)end
 end
end end)
