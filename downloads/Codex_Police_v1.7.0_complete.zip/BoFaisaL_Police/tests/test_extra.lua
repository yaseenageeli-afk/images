Config={};dofile('config/extra.lua')
local handlers,pushes,threads={},{},{}
local grants={[1]={isMilitary=true,memberSector='north'},[2]={isMilitary=true,memberSector='north'},[3]={isMilitary=true,memberSector='south'},[4]={isMilitary=false}}
local permissions={[1]={['police.cameras']=true,['police.em']=true},[2]={['police.em']=true},[3]={['police.em']=true},[4]={['police.em']=true}}
local now=1000;local duty=true
Utils={sanitize=function(s,max)return tostring(s):sub(1,max)end}
function L(k)return k end
function TriggerClientEvent(name,source,kind,data)pushes[#pushes+1]={event=name,source=source,kind=kind,data=data}end
function CreateThread(fn)threads[#threads+1]=fn end
BoFaisaL={Logs={add=function()end},RPC={register=function(name,opts,fn)handlers[name]={opts=opts,fn=fn}end,text=function(v,max)if type(v)=='string' and v:match('%S')then return v:sub(1,max)end end,int=function(v,min,max)if type(v)=='number' and v%1==0 and v>=min and v<=max then return v end end},
 Framework={hasPermission=function(uid,p)return permissions[uid] and permissions[uid][p]==true end},
 Gov={getProfile=function(uid)return grants[uid]or {isMilitary=false}end,sectorLabel=function(id)return id end},
 Players={bySource={[10]=1,[20]=2,[30]=3,[40]=4},getUserId=function(src)return ({[10]=1,[20]=2,[30]=3,[40]=4})[src]end},
 Officers={isOnDuty=function()return duty end},now=function()return now end,on=function()end}
dofile('server/extra.lua')
local n=0;local function check(label,c)assert(c,label);n=n+1 end
local function run(name,uid,data)return handlers[name].fn({user_id=uid,source=uid*10,name='Officer '..uid},data or {})end
local c=run('extras:capabilities',1);check('three authorized capabilities',c.cameras and c.sector and c.shared)
check('camera permission independent',not run('extras:capabilities',2).cameras)
local list=run('extras:cameras:list',1);check('all 68 cameras imported',#list.list==68)
check('unauthorized camera list denied',run('extras:cameras:list',2)==nil)
check('unknown camera denied',run('extras:cameras:watch',1,{id=99})==nil)
Config.SecurityCameras[1].isOnline=false;check('offline camera denied',run('extras:cameras:watch',1,{id=1})==nil);Config.SecurityCameras[1].isOnline=true
check('authorized camera starts',run('extras:cameras:watch',1,{id=1})~=nil)
check('camera lease registered',BoFaisaL.Extra.sessions[10].id==1)
local token=BoFaisaL.Extra.sessions[10].token
run('extras:cameras:stop',1,{token='old-token'});check('stale camera stop cannot end new session',BoFaisaL.Extra.sessions[10]~=nil)
check('heartbeat renews authorized session',run('extras:cameras:heartbeat',1)~=nil)
permissions[1]['police.cameras']=nil;check('revoked camera permission stops session',run('extras:cameras:heartbeat',1)==nil and BoFaisaL.Extra.sessions[10]==nil)
pushes={};local message=run('extras:chat:send',1,{kind='sector',sector='south',text='<img onerror=alert(1)>'})
check('sector send accepted',message~=nil);check('sector recipients verified',#pushes==2 and pushes[1].source~=30 and pushes[2].source~=30)
check('recipient sees same sector history',#run('extras:chat:history',2,{kind='sector'}).messages==1)
check('different sector history isolated',#run('extras:chat:history',3,{kind='sector'}).messages==0)
check('nonmilitary sector denied',run('extras:chat:history',4,{kind='sector'})==nil)
pushes={};check('shared send accepted',run('extras:chat:send',4,{kind='shared',text='مشترك'})~=nil)
check('all police.em recipients included',#pushes==4)
permissions[2]['police.em']=nil;pushes={};run('extras:chat:send',1,{kind='shared',text='تحديث'})
check('revoked permission excluded immediately',#pushes==3);check('revoked shared history denied',run('extras:chat:history',2,{kind='shared'})==nil)
check('nontext chat rejected',run('extras:chat:send',1,{kind='shared',text={}})==nil)
check('unknown channel rejected',run('extras:chat:send',1,{kind='all',text='hi'})==nil)
grants[2].memberSector='south';pushes={};run('extras:chat:send',1,{kind='sector',text='north'})
check('sector transfer excludes old sector',#pushes==1 and pushes[1].source==10)
for i=1,110 do run('extras:chat:send',1,{kind='shared',text=tostring(i)})end
check('bounded shared history',#run('extras:chat:history',1,{kind='shared'}).messages==100)
permissions[1]['police.cameras']=true;run('extras:cameras:watch',1,{id=2});now=1026;BoFaisaL.Extra.sweep();check('expired camera lease cleared',BoFaisaL.Extra.sessions[10]==nil)
for pose,command in pairs({steady='e poG83',ready='e poG82',rest='e poG84'})do
 pushes={};check(pose..' pose allowed',run('extras:pose',1,{pose=pose})~=nil and pushes[1].kind==command)
end
check('arbitrary command refused',run('extras:pose',1,{pose='quit'})==nil)
duty=false;check('off duty poses refused',run('extras:pose',1,{pose='rest'})==nil)
print('Extra services security checks passed: '..n)
