local payloads,dbRows,warnings,statuses={},{},{},{}
Config={Logs={Database=true,DiscordUTCOffsetHours=3},Webhooks={enabled=true,general='https://example.invalid/webhook',mentionless=true}}
Utils={utf8len=function(s)return utf8.len(s)or #s end,utf8sub=function(s,a,b)return s:sub(utf8.offset(s,a)or 1,(utf8.offset(s,b+1)or (#s+1))-1)end,toUserId=function(v)if type(v)=='number'and v%1==0 then return v end end}
json={encode=function(v)if v.embeds then payloads[#payloads+1]=v end;return '{}'end,decode=function()return {retry_after=.5}end}
promise={new=function()return {resolve=function(self,v)self.value=v end}end};Citizen={Await=function(p)return p.value end,Wait=function()end}
function SetTimeout()end
local requests=0;function PerformHttpRequest(url,cb,method,body)
 requests=requests+1;assert(body:find('"allowed_mentions":{"parse":%[%]}'));cb(table.remove(statuses,1)or 204,'{}')
end
function L(k)return k end
BoFaisaL={now=function()return 0 end,Players={name=function(uid)return 'User '..uid end},
 DB={ready=true,id=function(v)return v or 'NULL'end,executeAsync=function(sql,args)dbRows[#dbRows+1]=args end},
 thread=function(fn)fn()end,debug=function()end,print=function()end,warn=function(msg)warnings[#warnings+1]=msg end}
assert(loadfile('server/core/logs.lua'))()
local n=0;local function check(label,c)assert(c,label);n=n+1 end
local function field(embed,name)for _,f in ipairs(embed.fields)do if f.name==name then return f.value end end end
BoFaisaL.Logs.add('field','cuff',{actor=101,target=202,title='تقييد',fields={{'السبب','@everyone `bad`'}}})
local e=payloads[1].embeds[1]
check('actor vRP id prominent',field(e,'🆔 آيدي vRP للمنفّذ')=='101')
check('target vRP id prominent',field(e,'🆔 آيدي vRP للمستهدف')=='202')
check('name from vRP user lookup',field(e,'log_field_actor'):find('User 101')~=nil)
check('date UTC offset explicit',field(e,'🕒 الساعة')=='03:00:00 (UTC+3)')
check('Discord machine timestamp UTC',e.timestamp=='1970-01-01T00:00:00Z')
check('operation reference included',field(e,'🔎 مرجع العملية')=='0-1')
check('database stores vRP ids',dbRows[1][3]==101 and dbRows[1][5]==202)
check('mention escaped',field(e,'السبب'):find('@everyone',1,true)==nil)
statuses={429,500,204};local start=requests;BoFaisaL.Logs.add('ehsan','donate',{actor=0,target=-7})
check('zero and negative vRP ids retained',field(payloads[#payloads].embeds[1],'🆔 آيدي vRP للمنفّذ')=='0')
check('429 and server errors retried',requests-start==3)
statuses={0,0,0,0};start=requests;BoFaisaL.Logs.add('security','test',{actor=101})
check('timeout retry bounded',requests-start==4)
check('failed delivery is visible',#warnings==1)
BoFaisaL.Logs.add('general','automatic',{})
check('automatic events identified',field(payloads[#payloads].embeds[1],'المنفّذ')=='النظام • إجراء تلقائي')
local fields={};for i=1,40 do fields[i]={name=string.rep('n',300),value=string.rep('v',2000)}end
BoFaisaL.Logs.webhook('statistics',{title=string.rep('t',300),description=string.rep('d',5000),fields=fields})
e=payloads[#payloads].embeds[1];check('field count bounded',#e.fields<=25)
local count=Utils.utf8len(e.title)+Utils.utf8len(e.description)+Utils.utf8len(e.footer.text)+Utils.utf8len(e.author.name)
for _,f in ipairs(e.fields)do check('individual field limits',Utils.utf8len(f.name)<=250 and Utils.utf8len(f.value)<=1000);count=count+Utils.utf8len(f.name)+Utils.utf8len(f.value) end
check('aggregate embed limit',count<=5800)
Config.Webhooks.enabled=false;start=requests;local before=#dbRows;BoFaisaL.Logs.add('field','cuff',{actor=101})
check('webhook disabled but database logging remains',requests==start and #dbRows==before+1)
print('Log embed, vRP identity and delivery checks passed: '..n)
