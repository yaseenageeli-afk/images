local events,callbacks,threads={},{},{};local destroyed,renderOff,focusCleared,command=false,false,false,nil
local fov=65;local currentTime=0;local ipadOpen=true;local rot={x=-35,y=0,z=10};local sent={}
Config={};UI={send=function(_,data)sent[#sent+1]=data end,focus=function()end}
BoFaisaL={isIpadOpen=function()return ipadOpen end,closeIpad=function()ipadOpen=false end,rpc=function()return true end}
function RegisterNetEvent(n,f)events[n]=f end;function RegisterNUICallback(n,f)callbacks[n]=f end
function AddEventHandler(n,f)events[n]=f end;function CreateThread(f)threads[#threads+1]=f end
function GetGameTimer()return currentTime end;function CreateCam()return 123 end
function SetCamCoord()end;function SetCamRot(_,x,y,z)rot={x=x,y=y,z=z}end;function GetCamRot()return rot end
function SetCamFov(_,value)fov=value end;function GetCamFov()return fov end;function SetFocusPosAndVel()end;function SetCamActive()end;function SetTimecycleModifier()end
function RenderScriptCams(active)if not active then renderOff=true end end;function DestroyCam()destroyed=true end
function ClearFocus()focusCleared=true end;function ClearTimecycleModifier()end;function ExecuteCommand(c)command=c end
function GetCurrentResourceName()return 'BoFaisaL_Police' end
assert(loadfile('client/extra.lua'))()
local n=0;local function check(label,c)assert(c,label);n=n+1 end
local callback=function()end
callbacks.cameraPrepare({},callback)
events['bofaisal_police:camera:start']({id=1,token='new',coords={x=1,y=2,z=3},rotation={x=-35,y=0,z=10},canRotate=true})
callbacks.cameraControl({direction='right'},callback);check('authorized rotatable feed turns',rot.z==12.5)
for i=1,144 do callbacks.cameraControl({direction='right'},callback)end
check('full 360 degree rotation wraps continuously',rot.z==12.5)
for i=1,100 do callbacks.cameraControl({direction='up'},callback)end
check('camera can tilt upward without flipping',rot.x==85)
for i=1,100 do callbacks.cameraControl({direction='down'},callback)end
check('camera can tilt downward without flipping',rot.x==-85)
callbacks.cameraControl({direction='zoomIn'},callback);check('zoom narrows field of view',fov==63)
callbacks.cameraControl({direction='reset'},callback);check('reset returns original camera orientation',rot.x==-35 and rot.z==10 and fov==65)
callbacks.cameraStop({},callback);check('close destroys camera and restores game view',destroyed and renderOff and focusCleared)
destroyed=false;callbacks.cameraPrepare({},callback);callbacks.cameraStop({},callback)
events['bofaisal_police:camera:start']({id=1,token='late',coords={x=1,y=2,z=3},rotation={x=-35,y=0,z=10},canRotate=true})
rot={x=-35,y=0,z=10};callbacks.cameraControl({direction='right'},callback);check('late response after close cannot start camera',rot.z==10)
events['bofaisal_police:pose']('quit');check('arbitrary command ignored',command==nil)
events['bofaisal_police:pose']('e poG83');check('approved emote executes and closes tablet',command=='e poG83' and not ipadOpen)
print('Camera client cleanup checks passed: '..n)
