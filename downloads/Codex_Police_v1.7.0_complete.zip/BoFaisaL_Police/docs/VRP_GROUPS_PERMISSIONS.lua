-- مرجع للنسخ إلى القروبات الموجودة عندك؛ لا تستبدل vrp/cfg/groups.lua بهذا الملف.
-- إضافة هذه السلاسل لا تعطي رتبة عسكرية: اسم القروب يجب أن يطابق Config.Government.
return {
    police_officer = { "police.em" }, -- الشات المشترك
    police_camera_operator = { "police.em", "police.cameras" }, -- الشات والكاميرات؛ يتطلب رتبة لفتح التابلت والكاميرات
    codex_admin = { "player.owner" }, -- الإدارة فقط: اللوحة، مراجعة إحسان، والإعفاءات الحالية
}
