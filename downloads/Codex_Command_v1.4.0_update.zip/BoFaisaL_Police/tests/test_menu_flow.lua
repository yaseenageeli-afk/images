-- Run from the resource directory: lua tests/test_menu_flow.lua
local root = MENU_TEST_ROOT or '.'
local function loadFile(path) assert(loadfile(root..'/'..path))() end
Config = nil
function IsDuplicityVersion() return true end
loadFile('config/config.lua');loadFile('config/settings.lua');loadFile('config/locale.lua')
local beforeRanks, beforePerms = Config.Government, Config.Permissions
loadFile('shared/presentation.lua');loadFile('shared/setup.lua')
function L(key) return Locale[key] or key end
local n=0
local function check(label,c) assert(c,label);n=n+1 end
check('no rank or permission replacement',beforeRanks==Config.Government and beforePerms==Config.Permissions)
check('main and tablet labels',Locale.menu_police=='القائمة العسكرية' and Locale.menu_ipad=='🧭 مركز القيادة')
check('original duty-only setting',Config.Duty.MenuOnlyClockWhenOff==true)
local profile={isMilitary=true,perms={clock=true,ipad=true,citizenInquiry=true,wanted=true,fines=true,jail=true,badge=true,equipment=true,securityAlert=true,fineInquiry=true,jailCheck=true,jailModify=true,jailMonitor=true,jailRelease=true,impound=true,impoundInquiry=true,impoundRelease=true,barricades=true,fieldCuff=true}}
local duty,vacation=false,false
local opened,lastAction,lastTab
BoFaisaL={
 Players={bySource={[10]=1},getUserId=function()return 1 end},
 Gov={FIELD_PERM_LIST={'fieldCuff'},getProfile=function()return profile end,cached=function()return profile end,
 has=function(p,key)return p.perms[key]==true end,
 hasAny=function(p,keys)if type(keys)=='string' then return p.perms[keys]==true end;for _,key in ipairs(keys)do if p.perms[key] then return true end end;return false end,
 summary=function()return {rank='اختبار',sectorLabel='قطاع',ministryLabel='وزارة'} end},
 Officers={isOnDuty=function()return duty end,clockIn=function()duty=true;return true end,clockOut=function()duty=false;return 60 end},
 Vacation={isOnVacation=function()return vacation end,finish=function()vacation=false;return true end},
 Ipad={},RPC={register=function()end},
 Menu={open=function(_,menu)opened=menu end,registerMain=function()end},
 feature=function(key)return Config.Features[key] and Config.Features[key].enabled~=false end,
 notify=function()end,Absher={open=function()lastAction='absher' end},Ehsan={open=function()lastAction='ehsan' end},
 Reports={createFlow=function()end},
 Citizens={inquiryFlow=function()end},Wanted={createFlow=function()end},Fines={openMenu=function()end},Jail={openMenu=function()end},
 Badge={show=function()end},Field={menu=function()return {items={}}end},Equipment={},Alert={},Impound={menu=function()return {items={}}end},Barricades={menu=function()return {items={}}end},
}
loadFile('server/policemenu.lua')
local menu=BoFaisaL.PoliceMenu.build(10)
check('off-duty shows one option',#menu.items==1 and menu.items[1].label=='تسجيل الدخول')
-- Use the supplied toggle implementation, rather than a fake refresh callback.
loadFile('server/ipad.lua')
Utils={humanDuration=function()return 'دقيقة' end}
menu.items[1].action(10)
local expected={'🧭 مركز القيادة','تسجيل الخروج','🪪 التحقق المدني','📢 إصدار تعميم','🧾 الضبط والمخالفات','🔒 إجراءات التوقيف','🎖️ إبراز الشارة','🚓 المهام الميدانية','🛡️ الدعم والتجهيز','🔎 البحث والاستعلام','🚘 إدارة الحجز','🚧 تنظيم الحواجز'}
check('login changes duty and refreshes menu',duty and opened~=nil)
check('all original options remain',#opened.items==#expected)
for i,label in ipairs(expected)do check('order '..i,opened.items[i].label==label)end
BoFaisaL.Ipad.open=function(_,tab)lastTab=tab end
opened.items[1].action(10)
check('first option opens tablet',lastTab=='office')
opened.items[2].action(10)
check('logout refreshes login-only menu',not duty and #opened.items==1 and opened.items[1].label=='تسجيل الدخول')
local entries=BoFaisaL.PoliceMenu.mainEntries(10)
local byLabel={};for _,item in ipairs(entries)do byLabel[item.label]=item end
check('three separate phone/main entries',byLabel['القائمة العسكرية'] and byLabel['أبشر'] and byLabel['إحسان'])
byLabel['إحسان'].action(10);check('Ehsan opens directly',lastAction=='ehsan')
byLabel['أبشر'].action(10);check('Absher opens directly',lastAction=='absher')
Config.Features.Absher.enabled=false
entries=BoFaisaL.PoliceMenu.mainEntries(10)
local hasEhsan=false;for _,item in ipairs(entries)do if item.label=='إحسان' then hasEhsan=true end;check('Absher disabled independently',item.label~='أبشر')end
check('Ehsan remains when Absher is disabled',hasEhsan)
Config.Features.Absher.enabled=true;Config.Ehsan.Enabled=false
entries=BoFaisaL.PoliceMenu.mainEntries(10)
local hasAbsher=false;for _,item in ipairs(entries)do if item.label=='أبشر' then hasAbsher=true end;check('Ehsan disabled independently',item.label~='إحسان')end
check('Absher remains when Ehsan disabled',hasAbsher)
print('Original menu flow and independent service checks passed: '..n)
