fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'Codex Police'
author 'Codex (interface and additions); base: Made By LR'
description 'BoFaisaL_Police — organisational police & government operations platform for Universal vRP'
version '1.6.1'

ui_page 'web/index.html'

-- Shared with clients. Never put secrets in these files (see config/server.lua).
shared_scripts {
    'config/config.lua',        -- القوائم، قوائم الأغراض، الرتب
    'config/coords.lua',        -- الإحداثيات
    'config/settings.lua',      -- باقي الإعدادات
    'config/integrations.lua',
    'config/locale.lua',
    'config/notifications.lua', -- كلام الإشعارات
    'shared/utils.lua',
    'shared/presentation.lua',
    'shared/setup.lua',
    'shared/locations.lua',
}

server_scripts {
    'config/server.lua',
    'config/extra.lua',
    'server/core/bootstrap.lua',
    'server/core/framework.lua',
    'server/core/database.lua',
    'server/core/players.lua',
    'server/core/rpc.lua',
    'server/core/logs.lua',
    'server/integrations/base.lua',
    'server/integrations/inventory.lua',
    'server/integrations/vehicles.lua',
    'server/integrations/player.lua',
    'server/core/menu.lua',
    'server/government.lua',
    'server/immunity.lua',
    'server/mugshots.lua',
    'server/confirm.lua',
    'server/spectate.lua',
    'server/targets.lua',
    'server/officers.lua',
    'server/vacation.lua',
    'server/affairs.lua',
    'server/statistics.lua',
    'server/roster.lua',
    'server/extra.lua',
    'server/ipad.lua',
    'server/reports.lua',
    'server/wanted.lua',
    'server/citizens.lua',
    'server/fines.lua',
    'server/jail.lua',
    'server/field.lua',
    'server/equipment.lua',
    'server/security.lua',
    'server/barricades.lua',
    'server/impound.lua',
    'server/policemenu.lua',
    'server/commands.lua',
    'server/badge.lua',
    'server/panel.lua',
    'server/points.lua',
    'server/absher.lua',
    'server/ehsan.lua',
    'server/main.lua',
}

client_scripts {
    'client/main.lua',
    'client/integrations.lua',
    'client/ui.lua',
    'client/mugshot.lua',
    'client/confirm.lua',
    'client/ipad.lua',
    'client/extra.lua',
    'client/spectate.lua',
    'client/jail.lua',
    'client/security.lua',
    'client/barricades.lua',
    'client/points.lua',
    'client/commands.lua',
    'client/badge.lua',
}

files {
    'web/index.html',
    'web/css/*.css',
    'web/js/*.js',
    'web/assets/*.*',
    'web/assets/fonts/*.*',
}

-- Cfx Escrow: the config files stay readable so buyers can edit them. Everything else is encrypted.
escrow_ignore {
    'config/*.lua',
}
