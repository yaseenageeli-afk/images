--[[
    BoFaisaL_Police — server bootstrap: namespace, console output, internal event bus.
]]

BoFaisaL = BoFaisaL or {}
BoFaisaL.version = "1.2.2"
BoFaisaL.resource = GetCurrentResourceName()
BoFaisaL.ready = false

-- The resource folder must keep this name; any other name stops the script at start-up (server/main.lua).
BoFaisaL.requiredName = "BoFaisaL_Police"
BoFaisaL.blocked = BoFaisaL.resource ~= BoFaisaL.requiredName

local function fmt(msg, ...)
    if select("#", ...) > 0 then
        local ok, out = pcall(string.format, msg, ...)
        if ok then return out end
    end
    return tostring(msg)
end

function BoFaisaL.print(msg, ...)
    print("^5[BoFaisaL_Police]^7 " .. fmt(msg, ...))
end

function BoFaisaL.warn(msg, ...)
    print("^3[BoFaisaL_Police]^7 " .. fmt(msg, ...))
end

function BoFaisaL.error(msg, ...)
    print("^1[BoFaisaL_Police]^7 " .. fmt(msg, ...))
end

-- Categories: permissions, groups, sectors, ministries, integrations, database, jail, impound, spectate, rpc
function BoFaisaL.debug(category, msg, ...)
    if not Config.Debug then return end
    print(("^6[BoFaisaL_Police:%s]^7 %s"):format(category, fmt(msg, ...)))
end

function BoFaisaL.now()
    return os.time()
end

function BoFaisaL.feature(name)
    local f = Config.Features and Config.Features[name]
    return f ~= nil and f.enabled ~= false
end

-- Config.Targeting.AllowSelf: a player may do everything on himself (testing).
function BoFaisaL.allowSelf()
    return Config.Targeting ~= nil and Config.Targeting.AllowSelf == true
end

-- Runs fn in a new thread and reports errors with a traceback instead of failing silently.
function BoFaisaL.thread(fn, ...)
    local args = table.pack(...)
    Citizen.CreateThread(function()
        local ok, err = xpcall(fn, debug.traceback, table.unpack(args, 1, args.n))
        if not ok then BoFaisaL.error("thread error: %s", tostring(err)) end
    end)
end

---------------------------------------------------------------------------
-- Internal event bus (module to module)
---------------------------------------------------------------------------
local listeners = {}

function BoFaisaL.on(name, fn)
    listeners[name] = listeners[name] or {}
    table.insert(listeners[name], fn)
end

function BoFaisaL.emit(name, ...)
    local list = listeners[name]
    if not list then return end
    for i = 1, #list do
        local ok, err = xpcall(list[i], debug.traceback, ...)
        if not ok then BoFaisaL.error("listener '%s' failed: %s", name, tostring(err)) end
    end
end

---------------------------------------------------------------------------
-- Server → client helpers
---------------------------------------------------------------------------
function BoFaisaL.toClient(src, event, ...)
    if src then TriggerClientEvent("bofaisal_police:" .. event, src, ...) end
end

function BoFaisaL.ui(src, action, data)
    if src then TriggerClientEvent("bofaisal_police:ui", src, action, data or {}) end
end

-- Server → client request with a response (client-side facts only, e.g. own clothing).
local creq = { id = 0, pending = {} }

function BoFaisaL.clientRequest(src, name, args, timeoutMs)
    creq.id = creq.id + 1
    local id = creq.id
    local p = promise.new()
    creq.pending[id] = { src = src, p = p }
    TriggerClientEvent("bofaisal_police:creq", src, id, name, args or {})
    SetTimeout(timeoutMs or 5000, function()
        local entry = creq.pending[id]
        if entry then
            creq.pending[id] = nil
            entry.p:resolve({ ok = false })
        end
    end)
    local r = Citizen.Await(p)
    if not r.ok then return nil end
    return r.value
end

RegisterNetEvent("bofaisal_police:cres", function(id, value)
    local src = source
    local entry = creq.pending[id]
    if not entry or entry.src ~= src then return end -- only the asked client may answer
    creq.pending[id] = nil
    entry.p:resolve({ ok = true, value = value })
end)
