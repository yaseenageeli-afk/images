--[[
    BoFaisaL_Police — vehicle impound (حجز المركبات)

    Flow: the vehicle next to the officer (Config.Impound.PickVehicle: the nearest one, or the
    plate typed by the officer) → owner from the garage adapter → reason / fee → F5/F6 → record.
    With vRP every vehicle of a player carries the same plate (his registration / id): the model
    tells them apart.
    Active impounds are cached in memory so garage exports answer without database waits.
    Config.Impound.BlockSpawn: an impounded vehicle (plate + model) that appears anywhere (any
    garage script) is deleted at once and its owner is told, no garage linking needed.
]]

local Impound = { cache = {}, byPlate = {} } -- cache: [record id] = record (status impounded) · byPlate: [plate] = { [record id] = true }
BoFaisaL.Impound = Impound

local DB, P, Gov, Logs, Officers, Confirm, RPC = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers, BoFaisaL.Confirm, BoFaisaL.RPC
local I = BoFaisaL.Integrations

local function cfg() return Config.Impound or {} end

local function plateVariants(plate)
    plate = Utils.normalizePlate(plate)
    local list = { plate }
    local prefix = Utils.normalizePlate((Config.Integrations.VehicleGarage or {}).platePrefix or "")
    if prefix ~= "" then
        if plate:sub(1, #prefix) == prefix then
            list[#list + 1] = Utils.trim(plate:sub(#prefix + 1))
        else
            list[#list + 1] = prefix .. " " .. plate
        end
    end
    return list
end

-- Model hashes as unsigned 32-bit numbers (the game returns them signed or unsigned).
local function hash32(h)
    h = math.tointeger(tonumber(h) or 0) or 0
    return h % 4294967296
end

local function sameModel(a, b)
    a, b = tostring(a or ""):lower(), tostring(b or ""):lower()
    return a == "" or b == "" or a == b
end

-- Active impounds indexed by plate: a lookup is one step however many vehicles are impounded.
local function cacheAdd(r)
    local id = tonumber(r.id)
    Impound.cache[id] = r
    local plate = Utils.normalizePlate(r.plate or "")
    Impound.byPlate[plate] = Impound.byPlate[plate] or {}
    Impound.byPlate[plate][id] = true
end

local function cacheRemove(id)
    id = tonumber(id)
    local r = Impound.cache[id]
    if not r then return end
    Impound.cache[id] = nil
    local plate = Utils.normalizePlate(r.plate or "")
    local ids = Impound.byPlate[plate]
    if ids then
        ids[id] = nil
        if next(ids) == nil then Impound.byPlate[plate] = nil end
    end
end

-- Active impounds of a plate (any garage prefix spelling): list of records.
local function recordsFor(plate)
    local list = {}
    for _, variant in ipairs(plateVariants(plate or "")) do
        for id in pairs(Impound.byPlate[variant] or {}) do
            if Impound.cache[id] then list[#list + 1] = Impound.cache[id] end
        end
    end
    return list
end

-- Active impound of this plate (and model, when both are known: one plate, several vehicles).
function Impound.find(plate, model)
    for _, r in ipairs(recordsFor(plate)) do
        if model == nil or sameModel(r.model, model) then return r end
    end
    return nil
end

function Impound.location(id)
    for _, loc in ipairs(cfg().Locations or {}) do
        if loc.id == id then return loc end
    end
    return nil
end

function Impound.nearestLocation(coords)
    local best, bestDist
    for _, loc in ipairs(cfg().Locations or {}) do
        local d = coords and Utils.dist(coords, loc.coords) or 0
        if not bestDist or d < bestDist then best, bestDist = loc, d end
    end
    return best
end

local function record(r)
    local loc = Impound.location(r.location_id)
    return {
        id = tonumber(r.id), plate = r.plate, model = r.model,
        owner = { id = tonumber(r.owner_id), name = r.owner_name },
        officer = { id = tonumber(r.officer_id), name = r.officer_name },
        location = loc and loc.label or r.location_id, locationId = r.location_id,
        reason = r.reason, fee = tonumber(r.fee), status = r.status,
        createdAt = tonumber(r.created_at), releasedAt = tonumber(r.released_at), releaseType = r.release_type,
    }
end

function Impound.load()
    Impound.cache, Impound.byPlate = {}, {}
    for _, r in ipairs(DB.query("SELECT * FROM bofaisal_police_impounds WHERE status = 'impounded'")) do
        cacheAdd(r)
    end
    BoFaisaL.debug("impound", "%d active impounds cached", Utils.count(Impound.cache))
end

local function gate(source, perm)
    local user_id = P.getUserId(source)
    if not user_id then return nil end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("Impound") or not Gov.has(profile, perm) then
        BoFaisaL.notify(source, "err_no_permission", nil, "error")
        return nil
    end
    if not Officers.dutyOk(user_id, perm == "impoundInquiry" and "inquiries" or "impound") then
        BoFaisaL.notify(source, "err_not_on_duty", nil, "error")
        return nil
    end
    return user_id
end

-- Finds a vehicle with this plate (and model hash, when given) within `radius` of the officer
-- (server-side when possible).
function Impound.vehicleNear(source, plate, radius, modelHash)
    local origin = P.coords(source)
    if not origin then return nil end
    local variants = Utils.toSet(plateVariants(plate))
    if P.oneSync() and GetAllVehicles then
        for _, veh in ipairs(GetAllVehicles()) do
            if DoesEntityExist(veh) and variants[Utils.normalizePlate(GetVehicleNumberPlateText(veh) or "")]
                and (not modelHash or GetEntityModel(veh) == modelHash) then
                local d = Utils.dist(origin, GetEntityCoords(veh))
                if d <= radius then
                    return { entity = veh, netId = NetworkGetNetworkIdFromEntity(veh), model = GetEntityModel(veh), dist = d }
                end
            end
        end
        return nil
    end
    local v = BoFaisaL.clientRequest(source, "vehicleByPlate", { plate = plate, plates = plateVariants(plate), radius = radius, model = modelHash }, 4000)
    if type(v) ~= "table" or not v.netId then return nil end
    return { entity = nil, netId = tonumber(v.netId), model = tonumber(v.model), dist = tonumber(v.dist) or radius }
end

local function deleteVehicle(source, veh, plate)
    if not cfg().DeleteVehicle or not veh then return end
    if veh.entity and DoesEntityExist(veh.entity) then
        DeleteEntity(veh.entity)
    elseif veh.netId then
        -- The client only deletes a vehicle that carries one of these plates.
        TriggerClientEvent("bofaisal_police:vehicle:delete", source, veh.netId, plateVariants(plate))
    end
end

---------------------------------------------------------------------------
-- Impounding
---------------------------------------------------------------------------
function Impound.execute(source, context, reasonLabel, fee)
    local officerId = gate(source, "impound")
    if not officerId then return end
    if BoFaisaL.Immunity.blocks(source, context.owner, "Impound") then return end -- مانع حجز
    local officerCoords = P.coords(source)
    local loc = Impound.nearestLocation(officerCoords)
    if not loc then return BoFaisaL.notify(source, "impound_no_locations", nil, "error") end
    local ownerName = P.name(context.owner)
    local accepted, reason = Confirm.forAction("impound", source, P.getSource(context.owner), {
        title = L("confirm_impound_title"),
        message = L("confirm_impound_msg", { plate = context.plate }),
        details = {
            { L("field_plate"), context.plate },
            { L("field_owner"), ("%s | رقم الهوية: %d"):format(ownerName, context.owner) },
            { L("field_model"), context.model ~= "" and context.model or "-" },
            { L("field_reason"), reasonLabel },
            { L("field_fee"), "$" .. Utils.money(fee) },
            { L("field_location"), loc.label },
        },
        icon = "impound",
    })
    if not accepted then return BoFaisaL.notify(source, Confirm.failMessage(reason, Confirm.mode("impound") == "self"), nil, "error") end

    officerId = gate(source, "impound")
    if not officerId then return end
    -- The same vehicle (plate + model) must still be next to the officer.
    local veh = Impound.vehicleNear(source, context.plate, (cfg().VehicleRadius or 8.0) + 2.0, context.hash)
    if not veh then return BoFaisaL.notify(source, "impound_vehicle_far", nil, "error") end
    if Impound.find(context.plate, context.model) and not cfg().AllowReimpound then return BoFaisaL.notify(source, "impound_already", nil, "error") end

    local now = BoFaisaL.now()
    local row = {
        plate = context.plate, model = context.model or "", owner_id = context.owner, owner_name = ownerName,
        officer_id = officerId, officer_name = P.name(officerId), location_id = loc.id, reason = reasonLabel,
        fee = fee, model_hash = hash32(context.hash or veh.model), status = "impounded", created_at = now,
    }
    row.id = DB.insert(
        "INSERT INTO bofaisal_police_impounds (plate, model, owner_id, owner_name, officer_id, officer_name, location_id, reason, fee, model_hash, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'impounded', ?)",
        { row.plate, row.model, row.owner_id, row.owner_name, row.officer_id, row.officer_name, row.location_id, row.reason, row.fee, row.model_hash, now }
    )
    if not row.id then return BoFaisaL.notify(source, "err_internal", nil, "error") end
    cacheAdd(row)
    Officers.increment(officerId, "impounds_issued", 1)
    I.ImpoundHooks.onImpound(row)
    deleteVehicle(source, veh, row.plate)
    Impound.sendBlocked(row.owner_id)

    BoFaisaL.notify(source, "impound_done_officer", { plate = row.plate, location = loc.label }, "success")
    local ownerSrc = P.getSource(row.owner_id)
    if ownerSrc and cfg().NotifyOwner then
        BoFaisaL.notify(ownerSrc, "impound_owner_notice", { plate = row.plate, location = loc.label, fee = Utils.money(fee), reason = reasonLabel }, "warning", 12)
    end
    Logs.add("impound", "impound", {
        actor = officerId, target = row.owner_id, targetLabel = L("log_field_owner"),
        fields = {
            { L("field_plate"), row.plate, true }, { L("field_model"), row.model ~= "" and row.model or "-", true },
            { L("field_reason"), reasonLabel, true }, { L("field_fee"), "$" .. Utils.money(fee), true },
            { L("field_location"), loc.label, true }, { L("log_field_impound"), "#" .. row.id, true },
        },
    })
end

-- Name of a model hash: the owner's garage first, then the game's name for it (asked to the officer).
local function modelName(source, owner, hash)
    local name = I.Garage.modelFromHash(owner, hash)
    if name then return name end
    local display = hash and BoFaisaL.clientRequest(source, "modelName", { model = hash }, 3000)
    return type(display) == "string" and display ~= "" and display:lower() or ""
end

-- "حجز مركبة": vehicle next to the officer → owner → reason menu.
function Impound.flow(source, parent)
    local officerId = gate(source, "impound")
    if not officerId then return end
    local radius = cfg().VehicleRadius or 8.0
    local plate, veh
    if cfg().PickVehicle == "plate" then
        local values = I.Popup.input(source, L("impound_title"), {
            { key = "plate", label = L("field_plate"), type = "text", max = cfg().PlateMaxLength or 8 },
        })
        if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
        plate = Utils.normalizePlate(values.plate)
        if plate == "" then return BoFaisaL.notify(source, "impound_bad_plate", nil, "error") end
        veh = Impound.vehicleNear(source, plate, radius)
        if not veh then return BoFaisaL.notify(source, "impound_vehicle_far", nil, "error") end
    else
        -- The nearest vehicle: its plate is read from the vehicle itself.
        veh = BoFaisaL.Field.nearestVehicle(source, radius)
        if not veh or veh.plate == "" then return BoFaisaL.notify(source, "field_no_vehicle", nil, "error") end
        plate = veh.plate
    end
    local owner = I.Garage.findByPlate(plate)
    if not owner then return BoFaisaL.notify(source, "impound_no_owner", { plate = plate }, "error") end
    if BoFaisaL.Immunity.blocks(source, owner.owner, "Impound") then return end -- مانع حجز
    local context = { plate = plate, owner = owner.owner, hash = veh.model, model = owner.model or modelName(source, owner.owner, veh.model) }
    if Impound.find(plate, context.model) and not cfg().AllowReimpound then return BoFaisaL.notify(source, "impound_already", nil, "error") end

    local items = {}
    for _, r in ipairs(cfg().Reasons or {}) do
        items[#items + 1] = {
            label = r.label,
            description = L("impound_menu_desc", { fee = Utils.money(r.fee or cfg().DefaultFee or 0) }),
            action = function(src) Impound.execute(src, context, r.label, math.floor(tonumber(r.fee) or cfg().DefaultFee or 0)) end,
        }
    end
    if cfg().AllowCustomReason then
        items[#items + 1] = {
            label = L("impound_custom_reason"),
            description = L("impound_custom_reason_desc", { fee = Utils.money(cfg().DefaultFee or 0) }),
            action = function(src)
                local v = I.Popup.input(src, L("impound_custom_reason"), { { key = "reason", label = L("field_reason"), type = "text", max = 120 } })
                if not v then return BoFaisaL.notify(src, "action_cancelled", nil, "info") end
                Impound.execute(src, context, v.reason, math.floor(cfg().DefaultFee or 0))
            end,
        }
    end
    BoFaisaL.Menu.open(source, {
        title = L("impound_reason_title"),
        subtitle = ("%s%s • %s | رقم الهوية: %s"):format(plate, context.model ~= "" and (" — " .. context.model) or "", P.name(owner.owner), tostring(owner.owner)),
        items = items,
        parent = parent,
    })
end

---------------------------------------------------------------------------
-- Impounded vehicles cannot leave any garage (Config.Impound.BlockSpawn)
--   OneSync: the server sees every new vehicle and deletes an impounded one.
--   Without OneSync: the owner's client gets his impounded vehicles and deletes them itself.
---------------------------------------------------------------------------
-- Active impound of this vehicle: same plate (any garage prefix) and same model.
function Impound.blockedVehicle(plate, modelHash)
    plate = Utils.normalizePlate(plate or "")
    if plate == "" then return nil end
    modelHash = hash32(modelHash)
    for _, r in ipairs(recordsFor(plate)) do
        local h = hash32(r.model_hash)
        if h == 0 and (r.model or "") ~= "" then h = hash32(GetHashKey(r.model)) end
        if h == 0 or h == modelHash then return r end
    end
    return nil
end

local function blockedVars(r)
    local loc = Impound.location(r.location_id)
    return { plate = r.plate, location = loc and loc.label or r.location_id, fee = Utils.money(tonumber(r.fee) or 0) }
end

-- Without OneSync: the owner's impounded vehicles go to his client.
function Impound.sendBlocked(user_id)
    if cfg().BlockSpawn == false or P.oneSync() then return end
    local src = P.getSource(tonumber(user_id))
    if not src then return end
    local list = {}
    for _, r in pairs(Impound.cache) do
        if tonumber(r.owner_id) == tonumber(user_id) then
            local h = hash32(r.model_hash)
            if h == 0 and (r.model or "") ~= "" then h = hash32(GetHashKey(r.model)) end
            list[#list + 1] = { plates = plateVariants(r.plate), model = h, message = L("impound_spawn_blocked", blockedVars(r)) }
        end
    end
    TriggerClientEvent("bofaisal_police:impound:blocked", src, list)
end

-- Population types of the game's own traffic (random / parked / patrol / scenario cars): a
-- player's vehicle is never one of them, so they are not checked at all.
local AMBIENT = { [1] = true, [2] = true, [3] = true, [4] = true, [5] = true }

-- OneSync: every new vehicle is checked once its plate is set (garages set it right after spawning).
AddEventHandler("entityCreated", function(entity)
    if cfg().BlockSpawn == false or next(Impound.cache) == nil then return end
    if not DoesEntityExist(entity) or GetEntityType(entity) ~= 2 then return end
    if GetEntityPopulationType and AMBIENT[GetEntityPopulationType(entity)] then return end
    Citizen.CreateThread(function()
        for _, delay in ipairs({ 500, 2000 }) do -- checked at 0.5 s and 2.5 s (late garages)
            Citizen.Wait(delay)
            if not DoesEntityExist(entity) then return end
            local r = Impound.blockedVehicle(GetVehicleNumberPlateText(entity), GetEntityModel(entity))
            if r then
                local spawner = NetworkGetFirstEntityOwner and NetworkGetFirstEntityOwner(entity) or NetworkGetEntityOwner(entity)
                DeleteEntity(entity)
                -- The player who took it out, and the owner (once, when it is the same player).
                local told = {}
                for _, src in ipairs({ tonumber(spawner) or 0, tonumber(P.getSource(tonumber(r.owner_id))) or 0 }) do
                    if src > 0 and not told[src] and GetPlayerName(src) then
                        told[src] = true
                        BoFaisaL.notify(src, "impound_spawn_blocked", blockedVars(r), "error", 10)
                    end
                end
                BoFaisaL.debug("impound", "blocked impounded vehicle %s (#%s) from leaving a garage", tostring(r.plate), tostring(r.id))
                return
            end
        end
    end)
end)

---------------------------------------------------------------------------
-- Inquiry / release (police)
---------------------------------------------------------------------------
function Impound.listFor(owner_id)
    local list = {}
    for _, r in ipairs(DB.query("SELECT * FROM bofaisal_police_impounds WHERE owner_id = ? ORDER BY (status = 'impounded') DESC, id DESC LIMIT " .. (cfg().InquiryLimit or 50), { owner_id })) do
        list[#list + 1] = record(r)
    end
    return list
end

function Impound.inquiryFlow(source)
    local officerId = gate(source, "impoundInquiry")
    if not officerId then return end
    local values = I.Popup.input(source, L("impound_inquiry_title"), { { key = "id", label = L("field_owner_id"), type = "number" } })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    if not P.exists(values.id) then return BoFaisaL.notify(source, "err_unknown_id", nil, "error") end
    local lines, count = {}, 0
    for _, r in ipairs(Impound.listFor(values.id)) do
        if r.status == "impounded" then
            count = count + 1
            if #lines < 4 then lines[#lines + 1] = ("%s — %s — $%s"):format(r.plate, r.model or "-", Utils.money(r.fee)) end
        end
    end
    BoFaisaL.infoCard(source, {
        title = L("impound_inquiry_title"),
        file = values.id,
        rows = {
            { L("card_name"), P.name(values.id) },
            { L("card_id"), values.id },
            { L("card_impounded_count"), count },
        },
        lines = lines,
    })
    Logs.add("impound", "impound_inquiry", { actor = officerId, target = values.id })
end

function Impound.release(id, releaseType, byId)
    local r = DB.single("SELECT * FROM bofaisal_police_impounds WHERE id = ? AND status = 'impounded'", { id })
    if not r then return nil end
    local changed = DB.execute(
        "UPDATE bofaisal_police_impounds SET status = 'released', released_at = ?, release_type = ?, released_by_id = ?, released_by_name = ? WHERE id = ? AND status = 'impounded'",
        { BoFaisaL.now(), releaseType, DB.id(byId), byId and P.name(byId) or "", id }
    )
    if changed < 1 then return nil end
    cacheRemove(r.id)
    I.ImpoundHooks.onRelease(r)
    Impound.sendBlocked(tonumber(r.owner_id))
    return r
end

function Impound.releaseFlow(source, parent)
    local officerId = gate(source, "impoundRelease")
    if not officerId then return end
    local values = I.Popup.input(source, L("impound_release_title"), { { key = "id", label = L("field_owner_id"), type = "number" } })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    local items = {}
    for _, rec in ipairs(Impound.listFor(values.id)) do
        if rec.status == "impounded" then
            items[#items + 1] = {
                label = ("%s — %s"):format(rec.plate, rec.model ~= "" and rec.model or "-"),
                description = ("%s • $%s • %s"):format(rec.reason, Utils.money(rec.fee), rec.location),
                action = function(src)
                    local accepted, reason = Confirm.forAction("impoundRelease", src, P.getSource(values.id), {
                        title = L("confirm_impound_release_title"),
                        message = L("confirm_impound_release_msg", { plate = rec.plate }),
                        details = { { L("field_owner"), ("%s | رقم الهوية: %d"):format(rec.owner.name, rec.owner.id) }, { L("field_reason"), rec.reason } },
                        icon = "impound",
                    })
                    if not accepted then return BoFaisaL.notify(src, Confirm.failMessage(reason, true), nil, "error") end
                    local byId = gate(src, "impoundRelease")
                    if not byId then return end
                    local r = Impound.release(rec.id, "police", byId)
                    if not r then return BoFaisaL.notify(src, "impound_not_found", nil, "error") end
                    BoFaisaL.notify(src, "impound_released_officer", { plate = r.plate }, "success")
                    local ownerSrc = P.getSource(tonumber(r.owner_id))
                    if ownerSrc then BoFaisaL.notify(ownerSrc, "impound_released_owner", { plate = r.plate }, "success") end
                    Logs.add("impound", "impound_release", { actor = byId, target = tonumber(r.owner_id), targetLabel = L("log_field_owner"),
                        fields = { { L("field_plate"), r.plate, true }, { L("log_field_impound"), "#" .. r.id, true } } })
                end,
            }
        end
    end
    if #items == 0 then return BoFaisaL.notify(source, "impound_none_for_owner", nil, "info") end
    BoFaisaL.Menu.open(source, { title = L("impound_release_title"), subtitle = ("%s | رقم الهوية: %d"):format(P.name(values.id), values.id), items = items, parent = parent })
end

function Impound.menu(source, parent)
    local user_id = P.getUserId(source)
    local profile = Gov.getProfile(user_id, true)
    local items = {}
    if Gov.has(profile, "impound") and MenuOn("impound_action") then
        items[#items + 1] = { label = L("impound_action"), description = L("impound_action_desc"), action = function(src) Impound.flow(src, function(s) return Impound.menu(s, parent) end) end }
    end
    if Gov.has(profile, "impoundInquiry") and MenuOn("impound_inquiry_title") then
        items[#items + 1] = { label = L("impound_inquiry_title"), description = L("impound_inquiry_desc"), action = function(src) Impound.inquiryFlow(src) end }
    end
    if Gov.has(profile, "impoundRelease") and MenuOn("impound_release_title") then
        items[#items + 1] = { label = L("impound_release_title"), description = L("impound_release_desc"), action = function(src) Impound.releaseFlow(src, function(s) return Impound.menu(s, parent) end) end }
    end
    return { title = L("menu_impound"), items = items, parent = parent }
end

---------------------------------------------------------------------------
-- Owners: payment at impound centres
---------------------------------------------------------------------------
function Impound.nearCentre(source)
    local coords = P.coords(source)
    if not coords then return nil end
    for _, loc in ipairs(cfg().Locations or {}) do
        if Utils.dist(coords, loc.coords) <= (loc.radius or 3.0) + 2.0 then return loc end
    end
    return nil
end

-- Reads the impounded rows only (idx_owner_status), never the released history.
function Impound.ownerView(user_id)
    local list = {}
    for _, r in ipairs(DB.query("SELECT * FROM bofaisal_police_impounds WHERE owner_id = ? AND status = 'impounded' ORDER BY id DESC LIMIT " .. (cfg().InquiryLimit or 50), { user_id })) do
        list[#list + 1] = record(r)
    end
    return { list = list, wallet = BoFaisaL.Framework.getMoney(user_id), bank = BoFaisaL.Framework.getBankMoney(user_id) }
end

-- The owner pays the fee at an impound centre or a fine payment point. Returns the released
-- record, or nil + error.
-- remote = true: from منصة أبشر (allowed anywhere when Config.Absher.RemoteRelease).
function Impound.payRelease(source, user_id, id, remote)
    local loc = (remote == true and BoFaisaL.Absher and BoFaisaL.Absher.remoteRelease() and { label = BoFaisaL.Absher.title() })
        or Impound.nearCentre(source) or (BoFaisaL.Fines and BoFaisaL.Fines.nearPoint(source))
    if not loc then return nil, L("impound_centre_far") end
    local r = id and DB.single("SELECT * FROM bofaisal_police_impounds WHERE id = ? AND owner_id = ? AND status = 'impounded'", { id, user_id })
    if not r then return nil, L("impound_not_found") end
    local fee = tonumber(r.fee) or 0
    if not I.Money.pay(user_id, fee, cfg().PaymentMethod) then return nil, L("impound_no_money", { fee = Utils.money(fee) }) end
    if not Impound.release(id, "paid", user_id) then
        I.Money.give(user_id, fee) -- refund: somebody released it meanwhile
        return nil, L("impound_not_found")
    end
    BoFaisaL.notify(source, "impound_paid", { plate = r.plate, fee = Utils.money(fee) }, "success", 10)
    Logs.add("impound", "impound_paid", { actor = user_id, fields = {
        { L("field_plate"), r.plate, true }, { L("field_fee"), "$" .. Utils.money(fee), true }, { L("field_location"), loc.label, true },
    } })
    return r, loc
end

RPC.register("impound:pay", { feature = "Impound", cooldown = 2000 }, function(ctx, data)
    local r, err = Impound.payRelease(ctx.source, ctx.user_id, RPC.int(data.id, 1), data.remote == true)
    if not r then return nil, err end
    return Impound.ownerView(ctx.user_id)
end)

BoFaisaL.on("playerReady", function(user_id, source)
    Impound.sendBlocked(user_id)
    if not cfg().NotifyOnLogin then return end
    local count = 0
    for _, r in pairs(Impound.cache) do
        if tonumber(r.owner_id) == user_id then count = count + 1 end
    end
    if count > 0 then BoFaisaL.notify(source, "impound_login_notice", { count = count }, "warning", 12) end
end)

---------------------------------------------------------------------------
-- Garage exports (the existing garage calls these)
---------------------------------------------------------------------------
-- model (optional): with vRP every vehicle of a player has the same plate.
exports("IsVehicleImpounded", function(plate, model)
    return Impound.find(plate or "", type(model) == "string" and model or nil) ~= nil
end)

-- ownerId + plate or model. Returns nil or { impounded, plate, location, fee, reason, message }
exports("GetImpoundStatus", function(ownerId, plateOrModel)
    ownerId = tonumber(ownerId)
    local needle = type(plateOrModel) == "string" and plateOrModel or ""
    local variants = Utils.toSet(plateVariants(needle))
    for _, r in pairs(Impound.cache) do
        if tonumber(r.owner_id) == ownerId and (variants[r.plate] or (r.model ~= "" and r.model:lower() == needle:lower())) then
            local loc = Impound.location(r.location_id)
            return {
                impounded = true, plate = r.plate, location = loc and loc.label or r.location_id,
                fee = tonumber(r.fee), reason = r.reason, message = L("impound_garage_message"),
            }
        end
    end
    return nil
end)

exports("GetImpoundedVehicles", function(ownerId)
    ownerId = tonumber(ownerId)
    local list = {}
    for _, r in pairs(Impound.cache) do
        if tonumber(r.owner_id) == ownerId then
            list[#list + 1] = { plate = r.plate, model = r.model, fee = tonumber(r.fee), reason = r.reason, location = r.location_id }
        end
    end
    return list
end)

RPC.register("impound:open", { feature = "Impound", cooldown = 1000 }, function(ctx)
    local loc = Impound.nearCentre(ctx.source)
    if not loc then return nil, L("impound_centre_far") end
    local view = Impound.ownerView(ctx.user_id)
    view.location = loc.label
    return view
end)
