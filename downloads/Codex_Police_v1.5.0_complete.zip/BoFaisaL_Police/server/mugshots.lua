--[[
    BoFaisaL_Police — character photos (صورة شخصية اللاعب)

    Each player's own client takes a headshot of his character (game headshot → small image in
    the UI) when he joins and every few minutes, and uploads it here. The last photo is kept in
    bofaisal_police_mugshots, so wanted posters / reports / the ID card show it even when the
    player is offline or far away.

    Images travel with latent events (made for large data) and the UI caches them by the
    "updated_at" stamp, so each photo is sent once.
]]

local Mugshots = { at = {}, last = {} }
BoFaisaL.Mugshots = Mugshots

local DB, P, Gov = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov

local function cfg() return Config.Mugshot or {} end
local MAX_SIZE = 150000 -- characters of the data URL

function Mugshots.load()
    -- Filled first, then swapped in: lists never see an empty table while it is read.
    local at = {}
    for _, row in ipairs(DB.query("SELECT user_id, updated_at FROM bofaisal_police_mugshots")) do
        at[tonumber(row.user_id)] = tonumber(row.updated_at)
    end
    Mugshots.at = at
end

-- Stamp of the stored photo (0 = none). Lists send it so the UI knows what to ask for.
function Mugshots.stamp(user_id)
    return Mugshots.at[tonumber(user_id)] or 0
end

-- Upload from the player's own client (his own character only).
RegisterNetEvent("bofaisal_police:mugshot:upload", function(data)
    local src = source
    local uid = P.bySource[src]
    if not uid or cfg().Enabled == false then return end
    if type(data) ~= "string" or #data > MAX_SIZE or not data:match("^data:image/[%a]+;base64,[%w%+/=]+$") then return end
    local now = BoFaisaL.now()
    if Mugshots.last[uid] and now - Mugshots.last[uid] < 20 then return end
    Mugshots.last[uid] = now
    DB.execute("INSERT INTO bofaisal_police_mugshots (user_id, image, updated_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE image = VALUES(image), updated_at = VALUES(updated_at)",
        { uid, data, now })
    Mugshots.at[uid] = now
end)

-- Requests per player: Config.Mugshot.RequestBurst in a row, then RequestCooldown seconds of wait.
local requests = {} -- [user_id] = { count, last, blockedUntil }
local function requestAllowed(uid)
    local burst = math.max(1, tonumber(cfg().RequestBurst) or 5)
    local wait = math.max(0, tonumber(cfg().RequestCooldown) or 5) * 1000
    local now = GetGameTimer()
    local r = requests[uid]
    if not r then r = { count = 0, last = 0, blockedUntil = 0 } requests[uid] = r end
    if now < r.blockedUntil then return false end
    if now - r.last > wait then r.count = 0 end -- spread-out requests never add up
    r.last = now
    r.count = r.count + 1
    if r.count >= burst then
        r.count = 0
        r.blockedUntil = now + wait
    end
    return true
end

-- The UI asks for photos it does not have yet: one latent event per photo.
RegisterNetEvent("bofaisal_police:mugshot:request", function(ids)
    local src = source
    local uid = P.bySource[src]
    if not uid or type(ids) ~= "table" then return end
    if not requestAllowed(uid) then return end
    if not Gov.cached(uid).isMilitary and not (BoFaisaL.Vacation and BoFaisaL.Vacation.isOnVacation(uid)) then return end
    local wanted, count = {}, 0
    for _, v in ipairs(ids) do
        local id = Utils.toInt(v)
        if id and not wanted[id] and count < 40 then wanted[id] = true count = count + 1 end
    end
    -- One query for every stored photo asked; each photo still travels alone (latent event).
    local stored = {}
    for id in pairs(wanted) do
        if Mugshots.at[id] then stored[#stored + 1] = id end
    end
    local rows = {}
    if #stored > 0 then
        local marks = string.rep("?, ", #stored):sub(1, -3)
        for _, row in ipairs(DB.query("SELECT user_id, image, updated_at FROM bofaisal_police_mugshots WHERE user_id IN (" .. marks .. ")", stored)) do
            rows[tonumber(row.user_id)] = row
        end
    end
    for id in pairs(wanted) do
        local row = rows[id]
        if row and row.image and row.image ~= "" then
            TriggerLatentClientEvent("bofaisal_police:mugshot:data", src, 60000, id, tonumber(row.updated_at), row.image)
        else
            TriggerClientEvent("bofaisal_police:mugshot:data", src, id, 0, false)
        end
    end
end)

BoFaisaL.on("playerDropped", function(user_id) Mugshots.last[user_id] = nil requests[user_id] = nil end)

-- Photos of players who have not joined for Config.Mugshot.KeepDays days are removed (at start
-- and every 6 hours), so the table does not keep every player ever seen.
Citizen.CreateThread(function()
    while not BoFaisaL.ready do Citizen.Wait(1000) end
    while true do
        local days = tonumber(cfg().KeepDays) or 0
        if days > 0 and DB.ready then
            local removed = DB.execute(
                "DELETE m FROM bofaisal_police_mugshots m JOIN bofaisal_police_players p ON p.user_id = m.user_id WHERE p.last_seen > 0 AND p.last_seen < ?",
                { BoFaisaL.now() - days * 86400 })
            if removed > 0 then
                Mugshots.load()
                BoFaisaL.debug("database", "removed %d old character photos", removed)
            end
        end
        Citizen.Wait(6 * 3600 * 1000)
    end
end)
