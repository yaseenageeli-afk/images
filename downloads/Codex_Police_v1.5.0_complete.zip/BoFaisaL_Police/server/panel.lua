--[[
    BoFaisaL_Police — إدارة اللوحة (server-wide UI theme + locations editor)

    Theme:     accent colour, notification colour / transparency, notification positions.
    Locations: fine payment points, impound centres, jail entry / exit / centre / radius /
               return point, jail tasks and the recall HQ (shared/locations.lua applies them).

    Only players with the vRP permission Config.PanelAdmin.Permission (vrp/cfg/groups.lua) can
    read or change them. Both are stored in bofaisal_police_meta, checked after every write, and
    pushed to every client so everyone sees the same thing.
]]

local Panel = { theme = {}, locations = {} }
BoFaisaL.Panel = Panel

local DB, P, Logs, RPC = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Logs, BoFaisaL.RPC

local function cfg() return Config.PanelAdmin or {} end

Panel.POSITIONS = { "toasts", "infocards", "broadcasts", "confirm", "wanted", "alert", "jail", "idcard", "progress", "hint", "badge" }
local POSITION_SET = Utils.toSet(Panel.POSITIONS)

function Panel.canEdit(user_id)
    if cfg().Enabled == false or not user_id then return false end
    local perm = cfg().Permission
    if type(perm) ~= "string" or perm == "" then return false end
    return BoFaisaL.Framework.hasPermission(user_id, perm) == true
end

---------------------------------------------------------------------------
-- Storage (bofaisal_police_meta) — every write is read back to be sure it was saved.
---------------------------------------------------------------------------
local function store(key, value)
    local encoded = json.encode(value)
    DB.execute("INSERT INTO bofaisal_police_meta (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", { key, encoded })
    local back = DB.scalar("SELECT v FROM bofaisal_police_meta WHERE k = ?", { key })
    if back ~= encoded then
        BoFaisaL.error("إدارة اللوحة: could not save '%s' in bofaisal_police_meta (check the database / table).", key)
        return false
    end
    return true
end

local function fetch(key)
    local raw = DB.scalar("SELECT v FROM bofaisal_police_meta WHERE k = ?", { key })
    local ok, data = pcall(json.decode, raw or "")
    return ok and type(data) == "table" and data or {}
end

---------------------------------------------------------------------------
-- Theme
---------------------------------------------------------------------------
local function hexColor(v)
    return type(v) == "string" and v:match("^#%x%x%x%x%x%x$") and v:lower() or nil
end

local function sanitizeTheme(t)
    if type(t) ~= "table" then return {} end
    local out = { accent = hexColor(t.accent), noteColor = hexColor(t.noteColor) }
    local alpha = tonumber(t.noteAlpha)
    if alpha then out.noteAlpha = Utils.clamp(alpha, 0.3, 1.0) end
    -- Sizes: the iPad (share of the screen) and the windows.
    local ipad = tonumber(t.ipadSize)
    if ipad then out.ipadSize = Utils.clamp(ipad, 0.3, 0.95) end
    local sheet = tonumber(t.sheetScale)
    if sheet then out.sheetScale = Utils.clamp(sheet, 0.6, 1.6) end
    -- Look of the jail counter.
    if t.jailHud == "digital" or t.jailHud == "split" or t.jailHud == "minimal" or t.jailHud == "strip" then out.jailHud = t.jailHud end
    -- Look of the inquiry cards.
    if t.infoCard == "file" or t.infoCard == "classic" then out.infoCard = t.infoCard end
    -- Look of the notifications.
    if t.toast == "gradient" or t.toast == "ring" or t.toast == "classic" then out.toast = t.toast end
    -- Transparency of the inquiry cards (left side).
    local infoAlpha = tonumber(t.infoAlpha)
    if infoAlpha then out.infoAlpha = Utils.clamp(infoAlpha, 0.3, 1.0) end
    -- Look of the wanted alert.
    if t.wanted == "poster" or t.wanted == "classic" then out.wanted = t.wanted end
    -- Look of the F5 / F6 confirmation.
    if t.confirm == "compact" or t.confirm == "classic" then out.confirm = t.confirm end
    -- Look of the vehicle search window.
    if t.vehicleSearch == "list" or t.vehicleSearch == "classic" then out.vehicleSearch = t.vehicleSearch end
    -- Look of the fines and impounded vehicles windows (points and منصة أبشر).
    if t.finesLook == "cards" or t.finesLook == "classic" then out.finesLook = t.finesLook end
    if t.impoundLook == "cards" or t.impoundLook == "classic" then out.impoundLook = t.impoundLook end
    -- Look of the key hints (barricades, stop monitoring).
    if t.keyHint == "pill" or t.keyHint == "glass" or t.keyHint == "bar" or t.keyHint == "keycap" then out.keyHint = t.keyHint end
    -- Elements shown in the layout editor ("العناصر"), the same for every admin. An empty list is
    -- kept as a marker so "ولا شي" survives (an empty Lua table would be saved as "never chosen").
    if type(t.editorShown) == "table" then
        local list, seen = {}, {}
        for _, key in ipairs(t.editorShown) do
            if POSITION_SET[key] and not seen[key] then
                seen[key] = true
                list[#list + 1] = key
            end
        end
        out.editorShown = #list > 0 and list or { "none" }
    end
    -- Each element: box in % of the screen (x, y = top-left corner, w, h = size) and its size s.
    if type(t.positions) == "table" then
        out.positions = {}
        for key, pos in pairs(t.positions) do
            if POSITION_SET[key] and type(pos) == "table" then
                local x, y = tonumber(pos.x), tonumber(pos.y)
                if x and y then
                    local p = { x = Utils.clamp(x, 0, 100), y = Utils.clamp(y, 0, 100) }
                    local w, hgt, size = tonumber(pos.w), tonumber(pos.h), tonumber(pos.s)
                    if w and hgt then p.w, p.h = Utils.clamp(w, 0, 100), Utils.clamp(hgt, 0, 100) end
                    if size then p.s = Utils.clamp(size, 0.5, 1.8) end
                    out.positions[key] = p
                end
            end
        end
    end
    return out
end

---------------------------------------------------------------------------
-- Locations
---------------------------------------------------------------------------
local function num(v, min, max)
    v = tonumber(v)
    if not v or v ~= v or v == math.huge or v == -math.huge then return nil end
    return Utils.clamp(v, min, max)
end

local function point(p, withHeading)
    if type(p) ~= "table" then return nil end
    local x, y, z = num(p.x, -10000, 10000), num(p.y, -10000, 10000), num(p.z, -1000, 3000)
    if not x or not y or not z then return nil end
    local out = { x = x, y = y, z = z }
    if withHeading then out.h = num(p.h, 0, 360) or 0.0 end
    return out
end

local function label(v) return Utils.sanitize(tostring(v or ""), 60) end

-- Only shapes listed in Config.MarkerStyles.
local function markerStyle(v)
    if type(v) ~= "string" then return nil end
    for _, s in ipairs(Config.MarkerStyles or {}) do
        if s.id == v then return v end
    end
    return nil
end
local function id(v, fallback)
    return (type(v) == "string" and v:match("^[%w_%-]+$") and #v <= 32) and v or fallback
end

local function pointList(list, prefix)
    local out = {}
    for i, p in ipairs(type(list) == "table" and list or {}) do
        if #out >= 30 then break end
        local pos = point(p)
        if pos then
            pos.id = id(p.id, prefix .. i)
            pos.label = label(p.label)
            pos.radius = num(p.radius, 0.5, 50) or 2.0
            pos.style = markerStyle(p.style)
            out[#out + 1] = pos
        end
    end
    return out
end

local SANITIZE = {
    finePoints = function(v) return pointList(v, "fine_") end,
    impounds = function(v) return pointList(v, "impound_") end,
    jail = function(v)
        if type(v) ~= "table" then return nil end
        return {
            entry = point(v.entry, true), exit = point(v.exit, true), center = point(v.center),
            radius = num(v.radius, 10, 3000),
            returnPoint = v.returnPoint == false and false or point(v.returnPoint),
        }
    end,
    jailTasks = function(v)
        local out = {}
        local types = (Config.Jail.Tasks and Config.Jail.Tasks.Types) or {}
        local diffs = (Config.Jail.Tasks and Config.Jail.Tasks.Difficulties) or {}
        for i, t in ipairs(type(v) == "table" and v or {}) do
            if #out >= 30 then break end
            local pos = point(t)
            if pos and types[t.type] and diffs[t.difficulty] then
                pos.id = id(t.id, "task_" .. i)
                pos.label = label(t.label)
                pos.radius = num(t.radius, 0.5, 20) or 2.0
                pos.type, pos.difficulty = t.type, t.difficulty
                pos.duration = num(t.duration, 5, 600) or 20
                pos.reduction = num(t.reduction, 0, 3600) or 60
                pos.cooldown = num(t.cooldown, 0, 7200) or 120
                pos.style = markerStyle(t.style)
                pos.ui = (BoFaisaL.Jail and BoFaisaL.Jail.TASK_UIS[t.ui]) and t.ui or nil -- look on screen
                out[#out + 1] = pos
            end
        end
        return out
    end,
    recallHQ = function(v) return point(v) end,
}

-- The places in use right now (overrides or config), as plain tables for the UI.
local function plain(v) return v and { x = v.x, y = v.y, z = v.z } or nil end
function Panel.current()
    local function list(src)
        local out = {}
        for _, p in ipairs(src or {}) do
            out[#out + 1] = { id = p.id, label = p.label or "", x = p.coords.x, y = p.coords.y, z = p.coords.z, radius = p.radius, style = p.style or (p.marker and p.marker.style) }
        end
        return out
    end
    local tasks = {}
    for _, t in ipairs((Config.Jail.Tasks and Config.Jail.Tasks.List) or {}) do
        tasks[#tasks + 1] = {
            id = t.id, label = t.label or "", x = t.coords.x, y = t.coords.y, z = t.coords.z, radius = t.radius,
            type = t.type, difficulty = t.difficulty, duration = t.duration, reduction = t.reduction, cooldown = t.cooldown,
            style = t.style or (t.marker and t.marker.style),
            ui = BoFaisaL.Jail and BoFaisaL.Jail.taskUi(t) or "corners",
        }
    end
    local entry, exit = plain(Config.Jail.Entry), plain(Config.Jail.Exit)
    if entry then entry.h = Config.Jail.EntryHeading or 0 end
    if exit then exit.h = Config.Jail.ExitHeading or 0 end
    local taskTypes, difficulties = {}, {}
    for k, def in pairs((Config.Jail.Tasks and Config.Jail.Tasks.Types) or {}) do taskTypes[#taskTypes + 1] = { id = k, label = def.label or k } end
    for k in pairs((Config.Jail.Tasks and Config.Jail.Tasks.Difficulties) or {}) do difficulties[#difficulties + 1] = k end
    table.sort(taskTypes, function(a, b) return a.id < b.id end)
    table.sort(difficulties)
    local styles = {}
    for _, s in ipairs(Config.MarkerStyles or {}) do styles[#styles + 1] = { id = s.id, label = s.label or s.id, color = s.color } end
    return {
        finePoints = list(Config.Fines.PaymentPoints),
        impounds = list(Config.Impound.Locations),
        jail = { entry = entry, exit = exit, center = plain(Config.Jail.Center), radius = Config.Jail.Radius, returnPoint = plain(Config.Jail.ReturnLocation) },
        jailTasks = tasks,
        recallHQ = plain(Config.Recall and Config.Recall.HQ),
        edited = {
            finePoints = Panel.locations.finePoints ~= nil, impounds = Panel.locations.impounds ~= nil, jail = Panel.locations.jail ~= nil,
            jailTasks = Panel.locations.jailTasks ~= nil, recallHQ = Panel.locations.recallHQ ~= nil,
        },
        taskTypes = taskTypes,
        markerStyles = styles,
        styleDefaults = Config.MarkerStyleDefaults or {},
        difficulties = difficulties,
        taskUis = { { id = "corners", label = L("task_ui_corners") }, { id = "segments", label = L("task_ui_segments") }, { id = "classic", label = L("task_ui_classic") } },
    }
end

local function applyLocations()
    ApplyLocations(Panel.locations)
    TriggerClientEvent("bofaisal_police:locations", -1, Panel.locations)
    if BoFaisaL.Jail and BoFaisaL.Jail.refreshPlaces then BoFaisaL.Jail.refreshPlaces() end
end

---------------------------------------------------------------------------
-- Load / join
---------------------------------------------------------------------------
function Panel.load()
    Panel.theme = sanitizeTheme(fetch("ui_theme"))
    local saved = fetch("locations")
    Panel.locations = {}
    for section, fn in pairs(SANITIZE) do
        if saved[section] ~= nil then Panel.locations[section] = fn(saved[section]) end
    end
    ApplyLocations(Panel.locations)
end

BoFaisaL.on("playerReady", function(_, source)
    TriggerClientEvent("bofaisal_police:theme", source, Panel.theme)
    TriggerClientEvent("bofaisal_police:locations", source, Panel.locations)
end)

---------------------------------------------------------------------------
-- RPC
---------------------------------------------------------------------------
local function gate(ctx)
    if not Panel.canEdit(ctx.user_id) then return false end
    return true
end

RPC.register("panel:get", {}, function(ctx)
    if not gate(ctx) then return nil, L("err_no_permission") end
    return { theme = Panel.theme }
end)

RPC.register("panel:save", { cooldown = 150 }, function(ctx, data)
    if not gate(ctx) then return nil, L("err_no_permission") end
    local incoming = sanitizeTheme(data.theme)
    -- An empty save would wipe the stored theme: refuse it (use "الافتراضي" to reset).
    if next(incoming) == nil then return nil, L("panel_save_empty") end
    if not incoming.positions then incoming.positions = Panel.theme.positions end
    if not store("ui_theme", incoming) then return nil, L("panel_save_failed") end
    Panel.theme = incoming
    TriggerClientEvent("bofaisal_police:theme", -1, Panel.theme)
    Logs.add("affairs", "panel_save", { actor = ctx.user_id, noWebhook = true })
    return Panel.theme
end)

RPC.register("panel:reset", { cooldown = 150 }, function(ctx)
    if not gate(ctx) then return nil, L("err_no_permission") end
    if not store("ui_theme", {}) then return nil, L("panel_save_failed") end
    Panel.theme = {}
    TriggerClientEvent("bofaisal_police:theme", -1, Panel.theme)
    Logs.add("affairs", "panel_reset", { actor = ctx.user_id, noWebhook = true })
    return Panel.theme
end)

RPC.register("panel:locations", {}, function(ctx)
    if not gate(ctx) then return nil, L("err_no_permission") end
    return Panel.current()
end)

-- data = { section = "finePoints" | ..., value = ..., reset = true (back to config/coords.lua) }
RPC.register("panel:locations:save", { cooldown = 150 }, function(ctx, data)
    if not gate(ctx) then return nil, L("err_no_permission") end
    local fn = type(data.section) == "string" and SANITIZE[data.section]
    if not fn then return nil, L("err_invalid_request") end
    local nextLocations = {}
    for k, v in pairs(Panel.locations) do nextLocations[k] = v end
    if data.reset then
        nextLocations[data.section] = nil
    else
        local value = fn(data.value)
        if value == nil then return nil, L("err_invalid_request") end
        nextLocations[data.section] = value
    end
    if not store("locations", nextLocations) then return nil, L("panel_save_failed") end
    Panel.locations = nextLocations
    applyLocations()
    Logs.add("affairs", "panel_locations", { actor = ctx.user_id, noWebhook = true, fields = { { "section", data.section } } })
    return Panel.current()
end)

-- The admin's position (for "موقعي الحالي").
RPC.register("panel:here", {}, function(ctx)
    if not gate(ctx) then return nil, L("err_no_permission") end
    local c = P.coords(ctx.source)
    if not c then return nil, L("err_internal") end
    local ped = GetPlayerPed(ctx.source)
    local heading = (ped and ped ~= 0) and GetEntityHeading(ped) or 0.0
    -- z = where the player stands (teleports) · gz = the ground under him (markers sit on it).
    local ground = BoFaisaL.clientRequest(ctx.source, "panel:ground", {}, 3000)
    local gz = type(ground) == "table" and tonumber(ground.z) or (c.z - 0.98)
    return { x = Utils.round(c.x, 2), y = Utils.round(c.y, 2), z = Utils.round(c.z, 2), gz = Utils.round(gz, 2), h = Utils.round(heading, 1) }
end)

-- Teleport the admin to a point (to check it).
RPC.register("panel:goto", { cooldown = 500 }, function(ctx, data)
    if not gate(ctx) then return nil, L("err_no_permission") end
    local p = point(data)
    if not p then return nil, L("err_invalid_request") end
    P.teleport(ctx.source, p)
    return true
end)
