--[[
    BoFaisaL_Police — statistics: the Top 10 by POINTS

    Points (Config.Points): every N fines issued, N jails, N minutes of attendance (and,
    optionally, reports handled / vehicles impounded) give P points. The Top 10 shows the
    points only. Only officers inside the viewer's "statistics" scope are ranked.
]]

local Stats = {}
BoFaisaL.Stats = Stats

local DB, P, Gov, Officers = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Officers

-- Rows of every active officer, kept in memory and dropped on any write to bofaisal_police_officers
-- (a fine, a jail, a clock-out, a reset, a new rank...). The points are worked out from them on
-- every request (with the running session), so they are always exactly up to date while the
-- database is read only after something changed.
local officerRows, rowsVersion = nil, 0
DB.watch("bofaisal_police_officers", function()
    officerRows = nil
    rowsVersion = rowsVersion + 1
end)

local function activeOfficers()
    if officerRows then return officerRows end
    local version = rowsVersion
    local rows = DB.query("SELECT user_id, name, rank_group, sector, groups_json, attendance_total, fines_issued, jails_issued, reports_handled, impounds_issued FROM bofaisal_police_officers WHERE active = 1")
    -- Kept only when nothing was written while it was read (else the next request reads again).
    if version == rowsVersion then officerRows = rows end
    return rows
end

local function visible(profile, uid, groups)
    if uid == profile.user_id then return profile.isMilitary end
    local resolved = Gov.resolve(groups)
    return resolved.primary ~= nil and Gov.canOnRank(profile, "statistics", resolved.primary)
end

-- Points of one officer: { fines, jails, attendance (seconds), reports, impounds } → points.
function Stats.points(counts)
    local c = Config.Points or {}
    local function part(rule, value)
        local every, points = tonumber(rule and rule.Every) or 0, tonumber(rule and rule.Points) or 0
        if every <= 0 or points == 0 then return 0 end
        return math.floor((value or 0) / every) * points
    end
    return part(c.Fines, counts.fines)
        + part(c.Jails, counts.jails)
        + part({ Every = c.Attendance and c.Attendance.EveryMinutes, Points = c.Attendance and c.Attendance.Points }, math.floor((counts.attendance or 0) / 60))
        + part(c.Reports, counts.reports)
        + part(c.Impounds, counts.impounds)
end

-- Points of an bofaisal_police_officers row (+ the running session).
local function rowPoints(row)
    return Stats.points({
        fines = tonumber(row.fines_issued) or 0, jails = tonumber(row.jails_issued) or 0,
        attendance = (tonumber(row.attendance_total) or 0) + Officers.sessionSeconds(tonumber(row.user_id)),
        reports = tonumber(row.reports_handled) or 0, impounds = tonumber(row.impounds_issued) or 0,
    })
end

-- How points are earned, as short texts for the iPad ("كل 3 مخالفات = نقطة").
function Stats.rules()
    local c, list = Config.Points or {}, {}
    local function add(key, rule, every)
        local points = tonumber(rule and rule.Points) or 0
        if (every or 0) > 0 and points ~= 0 then list[#list + 1] = L(key, { every = every, points = points }) end
    end
    add("points_rule_fines", c.Fines, tonumber(c.Fines and c.Fines.Every))
    add("points_rule_jails", c.Jails, tonumber(c.Jails and c.Jails.Every))
    add("points_rule_attendance", c.Attendance, tonumber(c.Attendance and c.Attendance.EveryMinutes))
    add("points_rule_reports", c.Reports, tonumber(c.Reports and c.Reports.Every))
    add("points_rule_impounds", c.Impounds, tonumber(c.Impounds and c.Impounds.Every))
    return list
end

-- The officer's points and his place among every active officer (same points = same place).
function Stats.standing(user_id)
    user_id = tonumber(user_id)
    local mine, all = nil, {}
    for _, row in ipairs(activeOfficers()) do
        local pts = rowPoints(row)
        if tonumber(row.user_id) == user_id then mine = pts end
        all[#all + 1] = pts
    end
    local position = 0
    if mine then
        position = 1
        for _, p in ipairs(all) do
            if p > mine then position = position + 1 end
        end
    end
    return { points = mine or 0, position = position, total = #all }
end

function Stats.top(profile)
    local cfg = Config.Statistics or {}
    local list = {}
    for _, row in ipairs(activeOfficers()) do
        local uid = tonumber(row.user_id)
        local groups = Officers.decodeGroups(row.groups_json)
        if visible(profile, uid, groups) then
            local attendance = (tonumber(row.attendance_total) or 0) + Officers.sessionSeconds(uid)
            local resolved = Gov.resolve(groups)
            list[#list + 1] = {
                user_id = uid,
                name = (row.name and row.name ~= "") and row.name or P.name(uid),
                rank = resolved.primary and Gov.rankLabel(resolved.primary.group) or "",
                sectorLabel = resolved.memberSector and Gov.sectorLabel(resolved.memberSector)
                    or (resolved.primary and Gov.describeRank(resolved.primary).ministryLabel) or "",
                points = Stats.points({
                    fines = tonumber(row.fines_issued) or 0, jails = tonumber(row.jails_issued) or 0, attendance = attendance,
                    reports = tonumber(row.reports_handled) or 0, impounds = tonumber(row.impounds_issued) or 0,
                }),
                attendance = attendance, -- tie-break only (not shown)
            }
        end
    end
    table.sort(list, function(a, b)
        if a.points ~= b.points then return a.points > b.points end
        return a.attendance > b.attendance
    end)
    local top = {}
    for i = 1, math.min(cfg.Top or 10, #list) do
        list[i].position = i
        list[i].attendance = nil
        -- Profile picture (Discord...) like the other lists: the saved one, fetched in the background when missing.
        list[i].avatar = BoFaisaL.Integrations.ProfileImage.fast(list[i].user_id)
        top[i] = list[i]
    end
    return top
end

function Stats.sendWebhook(actorId, top)
    local fields = {}
    for _, o in ipairs(top) do
        fields[#fields + 1] = {
            name = ("#%d • %s | رقم الهوية: %s"):format(o.position, BoFaisaL.Logs.discordSafe(o.name), tostring(o.user_id)),
            value = L("top_webhook_row", { sector = o.sectorLabel ~= "" and o.sectorLabel or "-", points = o.points }),
            inline = false,
        }
    end
    BoFaisaL.Logs.webhook("statistics", {
        title = L("top_webhook_title", { count = #top }),
        description = #top == 0 and L("top_empty") or L("top_webhook_by", { name = BoFaisaL.Logs.who(actorId) }),
        fields = fields,
    })
    BoFaisaL.Logs.add("statistics", "top_report", { actor = actorId, noWebhook = true, fields = { { L("log_field_count"), #top } } })
end

BoFaisaL.RPC.register("affairs:top", { feature = "Affairs", perm = "statistics" }, function(ctx)
    return Stats.top(ctx.profile)
end)

BoFaisaL.RPC.register("affairs:topWebhook", { feature = "Affairs", perm = "statistics",
    cooldown = ((Config.Statistics and Config.Statistics.WebhookCooldown) or 60) * 1000 }, function(ctx)
    if not BoFaisaL.Logs.hasWebhook("statistics") then return nil, L("top_no_webhook") end
    Stats.sendWebhook(ctx.user_id, Stats.top(ctx.profile))
    return true
end)
