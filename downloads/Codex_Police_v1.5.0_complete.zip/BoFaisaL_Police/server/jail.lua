--[[
    BoFaisaL_Police — jail (السجن)

    * Sentences require the target's confirmation (F5 / F6).
    * The remaining time lives on the server (1 s tick) and is persisted every PersistInterval.
    * Original clothing and cuff state are saved in the database BEFORE they are changed and are
      restored on release — also after a resource or server restart.
    * Escapes are detected server-side (OneSync) and only ever affect players marked as jailed.
    * Task rewards are validated on the server (position, duration, cooldown, caps).
]]

local Jail = { active = {}, tasks = {}, taskCooldowns = {} }
BoFaisaL.Jail = Jail

local DB, P, Gov, Logs, Officers, Confirm, Targets, RPC =
    BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers, BoFaisaL.Confirm, BoFaisaL.Targets, BoFaisaL.RPC
local I = BoFaisaL.Integrations

local function cfg() return Config.Jail or {} end

local function center() return cfg().Center or cfg().Entry end
local function returnPoint() return cfg().ReturnLocation or cfg().Entry end

function Jail.isJailed(user_id)
    local e = Jail.active[tonumber(user_id)]
    return e ~= nil and not e.pendingRelease
end

-- Prisoners serving a sentence right now (online or not).
function Jail.count()
    local n = 0
    for _, e in pairs(Jail.active) do
        if not e.pendingRelease then n = n + 1 end
    end
    return n
end

function Jail.findReason(id)
    for _, r in ipairs(cfg().Reasons or {}) do
        if r.id == id then return r end
    end
    return nil
end

function Jail.status(user_id)
    local e = Jail.active[tonumber(user_id)]
    if not e or e.pendingRelease then return { jailed = false } end
    return {
        jailed = true,
        user_id = e.user_id,
        name = P.name(e.user_id),
        remaining = e.remaining,
        total = e.total,
        reason = e.reason_label,
        officer = e.officer_id and { id = e.officer_id, name = e.officer_name } or nil,
        jailName = cfg().Name,
        startedAt = e.started_at,
        online = P.isOnline(e.user_id),
    }
end

local function clientState(e)
    local tasks = {}
    if cfg().Tasks and cfg().Tasks.Enabled then
        for _, t in ipairs(cfg().Tasks.List or {}) do
            local typeDef = cfg().Tasks.Types and cfg().Tasks.Types[t.type] or {}
            tasks[#tasks + 1] = {
                id = t.id, label = t.label, coords = Utils.vec(t.coords), radius = t.radius or 2.0,
                typeLabel = typeDef.label or t.type, duration = t.duration, reduction = t.reduction,
                marker = t.marker or cfg().Tasks.Marker,
            }
        end
    end
    return {
        name = cfg().Name,
        remaining = e.remaining,
        total = e.total,
        reason = e.reason_label,
        officer = e.officer_name,
        center = Utils.vec(center()),
        radius = cfg().Radius,
        escape = cfg().Escape and cfg().Escape.Enabled == true,
        hud = not cfg().Hud or cfg().Hud.Enabled ~= false,
        style = cfg().Hud and cfg().Hud.Style or "digital", -- إدارة اللوحة can choose another look
        tasks = tasks,
    }
end

Jail.clientState = clientState

-- Places changed in إدارة اللوحة: prisoners in jail right now get the new task points (markers,
-- map icons) and the new centre / radius at once, not only on their next sentence.
function Jail.refreshPlaces()
    for uid, e in pairs(Jail.active) do
        local src = not e.pendingRelease and not e.finishing and P.byUser[uid]
        if src then TriggerClientEvent("bofaisal_police:jail:start", src, clientState(e)) end
    end
end

local function persist(e)
    DB.execute("UPDATE bofaisal_police_jail SET remaining_seconds = ?, added_seconds = ?, reduced_seconds = ?, updated_at = ? WHERE user_id = ?",
        { math.max(0, e.remaining), e.added, e.reduced, BoFaisaL.now(), e.user_id })
    e.dirty = false
end

local function sync(e)
    local src = P.getSource(e.user_id)
    if src then TriggerClientEvent("bofaisal_police:jail:sync", src, math.max(0, e.remaining)) end
end

---------------------------------------------------------------------------
-- Applying / releasing
---------------------------------------------------------------------------
local function jailPreset()
    return { Male = cfg().Clothing.Male, Female = cfg().Clothing.Female, Uniform = cfg().Clothing.Uniform ~= false }
end

-- Puts an online prisoner in jail: teleport, cuffs, clothing, HUD.
function Jail.apply(e, src)
    -- The client needs a moment to teleport and load collision: no escape checks meanwhile.
    e.grace = GetGameTimer() + 15000
    -- Clothes BEFORE the teleport: vRP puts clothes on by recreating the character (new ped),
    -- which during a teleport would leave the player where he was.
    -- The clothes saved when he was jailed are the base (no extra round trip to the client).
    if cfg().Clothing and cfg().Clothing.Enabled then I.Clothing.applyPreset(src, jailPreset(), I.Clothing.decode(e.clothing)) end
    P.teleport(src, cfg().Entry, cfg().EntryHeading)
    if cfg().Handcuff and cfg().Handcuff.Enabled then I.Handcuff.set(src, true) end
    TriggerClientEvent("bofaisal_police:jail:start", src, clientState(e))
    Officers.pushState(e.user_id)
    BoFaisaL.debug("jail", "applied sentence of %d (%ds left)", e.user_id, e.remaining)
end

-- Clothing, cuffs, teleport to the exit and HUD removal.
local function physicalRelease(e, src)
    if cfg().Clothing and cfg().Clothing.Enabled then
        local original = I.Clothing.decode(e.clothing)
        if original then
            I.Clothing.set(src, original)
            -- Again a moment later: on join vRP applies its own saved clothes after spawning,
            -- which would otherwise put the jail clothes back on.
            local uid = e.user_id
            SetTimeout(3000, function()
                if P.getSource(uid) == src and not Jail.active[uid] then I.Clothing.set(src, original) end
            end)
        end
    end
    if cfg().Handcuff and cfg().Handcuff.Enabled and cfg().Handcuff.RemoveOnRelease ~= false then
        I.Handcuff.set(src, false)
    end
    P.teleport(src, cfg().Exit, cfg().ExitHeading)
    TriggerClientEvent("bofaisal_police:jail:end", src)
    Jail.tasks[e.user_id] = nil
end

function Jail.start(target_id, target_src, info)
    local now = BoFaisaL.now()
    -- The clothes worn right now are saved BEFORE the jail clothes go on (3 tries).
    local clothing = ""
    if cfg().Clothing and cfg().Clothing.Enabled then
        for _ = 1, 3 do
            local current = I.Clothing.get(target_src)
            if current then clothing = I.Clothing.encode(current) break end
            Citizen.Wait(300)
        end
        if clothing == "" then BoFaisaL.warn("Could not read the clothes of %d before jailing: they cannot be restored.", target_id) end
    end
    local wasCuffed = I.Handcuff.isCuffed(target_src)
    local e = {
        user_id = target_id,
        officer_id = info.officer_id, -- nil = no officer
        officer_name = info.officer_name or "",
        reason_id = info.reason_id or "",
        reason_label = info.reason_label or "",
        total = info.seconds,
        remaining = info.seconds,
        added = 0,
        reduced = 0,
        started_at = now,
        clothing = clothing,
        was_cuffed = wasCuffed and 1 or 0,
    }
    DB.execute("DELETE FROM bofaisal_police_jail WHERE user_id = ?", { target_id })
    DB.execute(
        "INSERT INTO bofaisal_police_jail (user_id, name, officer_id, officer_name, reason_id, reason_label, total_seconds, remaining_seconds, added_seconds, reduced_seconds, started_at, updated_at, clothing, was_cuffed) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?, ?, ?)",
        { target_id, P.name(target_id), DB.id(e.officer_id), e.officer_name, e.reason_id, e.reason_label, e.total, e.remaining, now, now, clothing, e.was_cuffed }
    )
    Jail.active[target_id] = e
    Jail.apply(e, target_src)
    return e
end

-- endType: "served" | "released" | "modified". Writes history/logs now; the physical release
-- happens immediately when online or on the next join otherwise.
function Jail.finish(user_id, endType, byId, reason)
    local e = Jail.active[user_id]
    if not e or e.finishing or e.pendingRelease then return false end
    e.finishing = true
    local now = BoFaisaL.now()
    DB.execute(
        "INSERT INTO bofaisal_police_jail_history (user_id, name, officer_id, officer_name, reason_label, total_seconds, started_at, ended_at, end_type, released_by_id, released_by_name, release_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        { user_id, P.name(user_id), DB.id(e.officer_id), e.officer_name, e.reason_label, e.total, e.started_at, now, endType,
          DB.id(byId), byId and P.name(byId) or "", reason or "" }
    )
    local src = P.getSource(user_id)
    local vars = { target = P.name(user_id), target_id = user_id, officer = byId and P.name(byId) or "", officer_id = byId }
    if endType == "released" then
        I.Chat.announce("JailRelease", vars, { src })
        Logs.add("jail", "jail_release", { actor = byId, target = user_id, fields = { { L("log_field_reason"), reason or "-" } } })
    elseif endType == "served" then
        I.Chat.announce("JailServed", vars, { src })
        Logs.add("jail", "jail_served", { target = user_id, fields = { { L("log_field_total"), Utils.humanDuration(e.total) } } })
    elseif endType == "bail" then
        I.Chat.announce("JailBail", vars, { src })
        Logs.add("jail", "jail_bail", { actor = byId, target = user_id, fields = { { L("field_bail"), reason or "-" } } })
    end
    if src then
        physicalRelease(e, src)
        DB.execute("DELETE FROM bofaisal_police_jail WHERE user_id = ?", { user_id })
        Jail.active[user_id] = nil
        if endType == "bail" then
            BoFaisaL.notify(src, "jail_bailed_target", { name = vars.officer }, "success", 10)
        else
            BoFaisaL.notify(src, endType == "released" and "jail_released_target" or "jail_served_target", { reason = reason or "" }, "success", 10)
        end
        Officers.pushState(user_id)
    else
        e.remaining = 0
        e.pendingRelease = true
        e.finishing = false
        persist(e)
    end
    return true
end

---------------------------------------------------------------------------
-- Sentencing (officer flow)
---------------------------------------------------------------------------
local function officerAllowed(user_id)
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("Jail") or not Gov.has(profile, "jail") then return false, L("err_no_permission") end
    if not Officers.dutyOk(user_id, "jail") then return false, L("err_not_on_duty") end
    return true
end

function Jail.sentence(officerSrc, reasonId, targetSrc, targetId)
    local officerId = P.getUserId(officerSrc)
    if not officerId then return end
    local ok, err = officerAllowed(officerId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    local reason = Jail.findReason(reasonId)
    if not reason then return BoFaisaL.notify(officerSrc, "err_invalid_request", nil, "error") end
    if targetId == officerId and not BoFaisaL.Targets.allowSelf() then return BoFaisaL.notify(officerSrc, "target_self", nil, "error") end
    if Jail.isJailed(targetId) then return BoFaisaL.notify(officerSrc, "jail_already", nil, "error") end
    ok, err = Targets.check(officerSrc, targetSrc, targetId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    if BoFaisaL.Immunity.blocks(officerSrc, targetId, "Jail") then return end -- مانع سجن
    if BoFaisaL.Immunity.officerProtected(targetId, "Jail", officerId) then return BoFaisaL.notify(officerSrc, "officer_protected_jail", nil, "error") end

    local minutes = Utils.clamp(math.floor(tonumber(reason.duration) or 1), cfg().MinMinutes or 1, cfg().MaxMinutes or 300)
    local officerName, targetName = P.name(officerId), P.name(targetId)
    -- "self": the officer confirms (message written for him) | "target": the prisoner confirms.
    local selfConfirm = Confirm.mode("jail") == "self"
    if not selfConfirm then BoFaisaL.notify(officerSrc, "confirm_waiting", { name = targetName }, "info") end
    local accepted, why = Confirm.forAction("jail", officerSrc, targetSrc, {
        title = L("confirm_jail_title"),
        message = selfConfirm and L("confirm_jail_self_msg", { name = targetName, id = targetId })
            or L("confirm_jail_msg", { officer = officerName, officer_id = officerId }),
        details = {
            { L("field_jail"), cfg().Name },
            { L("field_reason"), reason.label },
            { L("field_duration"), L("minutes_value", { minutes = minutes }) },
        },
        timeout = cfg().ConfirmTimeout,
        icon = "jail",
    })
    if not accepted then
        BoFaisaL.notify(officerSrc, Confirm.failMessage(why, selfConfirm), nil, "error")
        if why == "rejected" then
            Logs.add("jail", "jail_rejected", { actor = officerId, target = targetId, fields = { { L("field_reason"), reason.label } } })
        end
        return
    end

    ok, err = officerAllowed(officerId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    if P.bySource[targetSrc] ~= targetId then return BoFaisaL.notify(officerSrc, "err_target_offline", nil, "error") end
    if Jail.isJailed(targetId) then return BoFaisaL.notify(officerSrc, "jail_already", nil, "error") end

    Jail.start(targetId, targetSrc, {
        officer_id = officerId, officer_name = officerName, reason_id = reason.id, reason_label = reason.label, seconds = minutes * 60,
    })
    Officers.increment(officerId, "jails_issued", 1)
    local vars = { officer = officerName, officer_id = officerId, target = targetName, target_id = targetId, minutes = minutes, reason = reason.label, jail = cfg().Name }
    BoFaisaL.notify(targetSrc, "jail_target_notice", {
        officer = officerName, jail = cfg().Name, duration = L("minutes_value", { minutes = minutes }), reason = reason.label,
    }, "error", 12)
    BoFaisaL.notify(officerSrc, "jail_officer_done", vars, "success")
    I.Chat.announce("Jail", vars, { officerSrc, targetSrc })
    Logs.add("jail", "jail", {
        actor = officerId, target = targetId, actorName = officerName, targetName = targetName,
        fields = {
            { L("field_reason"), reason.label, true },
            { L("field_duration"), L("minutes_value", { minutes = minutes }), true },
            { L("field_jail"), cfg().Name, true },
        },
    })
    if Config.Wanted and Config.Wanted.ClearOnJail then BoFaisaL.Wanted.clearForTarget(targetId, officerId, "wanted_clear_jail") end
end

function Jail.menu(source, parent)
    local items = {}
    for _, r in ipairs(cfg().Reasons or {}) do
        items[#items + 1] = {
            label = r.label,
            description = L("jail_menu_desc", { duration = L("minutes_value", { minutes = Utils.clamp(math.floor(tonumber(r.duration) or 1), cfg().MinMinutes or 1, cfg().MaxMinutes or 300) }) }),
            action = function(src)
                local ok, err = officerAllowed(P.getUserId(src))
                if not ok then return BoFaisaL.notify(src, err, nil, "error") end
                Targets.nearest(src, function(targetSrc, targetId)
                    Jail.sentence(src, r.id, targetSrc, targetId)
                end)
            end,
        }
    end
    return { title = L("menu_jail"), subtitle = cfg().Name, items = items, parent = parent }
end

function Jail.openMenu(source, parent)
    local ok, err = officerAllowed(P.getUserId(source))
    if not ok then return BoFaisaL.notify(source, err, nil, "error") end
    BoFaisaL.Menu.open(source, Jail.menu(source, parent))
end

---------------------------------------------------------------------------
-- Management (استعلامات)
---------------------------------------------------------------------------
local function requirePerm(source, perm)
    local user_id = P.getUserId(source)
    if not user_id then return nil end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("Jail") or not Gov.has(profile, perm) then
        BoFaisaL.notify(source, "err_no_permission", nil, "error")
        return nil
    end
    if not Officers.dutyOk(user_id, "inquiries") then
        BoFaisaL.notify(source, "err_not_on_duty", nil, "error")
        return nil
    end
    return user_id, profile
end

-- Prisoners list as menu items (onlineOnly for spectating).
function Jail.prisonerMenu(source, title, onlineOnly, onPick, parent)
    local items = {}
    local list = {}
    for uid, e in pairs(Jail.active) do
        if not e.pendingRelease and (not onlineOnly or P.isOnline(uid)) then list[#list + 1] = e end
    end
    table.sort(list, function(a, b) return a.remaining < b.remaining end)
    for _, e in ipairs(list) do
        local online = P.isOnline(e.user_id)
        items[#items + 1] = {
            label = ("%s | رقم الهوية: %d"):format(P.name(e.user_id), e.user_id),
            description = L("jail_prisoner_desc", { remaining = Utils.mmss(e.remaining), reason = e.reason_label, state = online and L("online") or L("offline") }),
            action = function(src) onPick(src, e.user_id) end,
        }
    end
    if #items == 0 then
        BoFaisaL.notify(source, "jail_no_prisoners", nil, "info")
        return nil
    end
    return { title = title, items = items, parent = parent }
end

---------------------------------------------------------------------------
-- Bail (كفالة المساجين) — paid by anyone at a fine payment point
---------------------------------------------------------------------------
local function bailCfg() return cfg().Bail or {} end

-- Price of the bail: every month left (= one minute) costs PricePerMonth (old name: PricePerMinute).
function Jail.bailPrice(e)
    local b = bailCfg()
    local months = math.max(1, math.ceil((e.remaining or 0) / 60))
    local price = months * (tonumber(b.PricePerMonth) or tonumber(b.PricePerMinute) or 1000)
    price = math.max(price, tonumber(b.MinPrice) or 0)
    if (tonumber(b.MaxPrice) or 0) > 0 then price = math.min(price, tonumber(b.MaxPrice)) end
    return math.floor(price), months
end

local function bailAllowed(e)
    if not e or e.pendingRelease or e.finishing then return false end
    for _, id in ipairs(bailCfg().BlockedReasons or {}) do
        if id == e.reason_id then return false end
    end
    return true
end

function Jail.bail(source, payerId, targetId)
    if bailCfg().Enabled == false then return BoFaisaL.notify(source, "jail_bail_disabled", nil, "error") end
    if payerId == targetId and not BoFaisaL.allowSelf() then return BoFaisaL.notify(source, "jail_bail_self", nil, "error") end
    local e = Jail.active[targetId]
    if not bailAllowed(e) then return BoFaisaL.notify(source, "jail_bail_unavailable", nil, "error") end
    local price, months = Jail.bailPrice(e)
    local accepted = Confirm.ask(source, {
        title = L("jail_bail_confirm_title"),
        message = L("jail_bail_confirm_msg", { name = P.name(targetId), id = targetId }),
        details = {
            { L("field_reason"), e.reason_label ~= "" and e.reason_label or "-" },
            { L("card_remaining"), L("minutes_value", { minutes = months }) },
            { L("field_bail"), "$" .. Utils.money(price) },
        },
        icon = "jail",
    })
    if not accepted then return end
    -- Still at the point, still jailed, same price (the time kept running while confirming).
    if not (BoFaisaL.Fines and BoFaisaL.Fines.nearPoint(source)) then return BoFaisaL.notify(source, "fine_point_far", nil, "error") end
    e = Jail.active[targetId]
    if not bailAllowed(e) then return BoFaisaL.notify(source, "jail_bail_unavailable", nil, "error") end
    price = math.min(price, (Jail.bailPrice(e)))
    if not I.Money.pay(payerId, price, (Config.Fines and Config.Fines.PaymentMethod) or "bank") then
        return BoFaisaL.notify(source, "jail_bail_no_money", { price = Utils.money(price) }, "error")
    end
    if not Jail.finish(targetId, "bail", payerId, "$" .. Utils.money(price)) then
        I.Money.give(payerId, price) -- refund: released meanwhile
        return BoFaisaL.notify(source, "jail_bail_unavailable", nil, "error")
    end
    BoFaisaL.notify(source, "jail_bail_done", { name = P.name(targetId), price = Utils.money(price) }, "success", 10)
end

-- Prisoners that can be bailed out, with their price.
function Jail.bailMenu(source, parent)
    local list = {}
    for _, e in pairs(Jail.active) do
        if bailAllowed(e) then list[#list + 1] = e end
    end
    if #list == 0 then
        BoFaisaL.notify(source, "jail_no_prisoners", nil, "info")
        return nil
    end
    table.sort(list, function(a, b) return a.remaining < b.remaining end)
    local items = {}
    for _, e in ipairs(list) do
        local price, months = Jail.bailPrice(e)
        items[#items + 1] = {
            label = ("%s | رقم الهوية: %d"):format(P.name(e.user_id), e.user_id),
            description = L("jail_bail_desc", { price = Utils.money(price), months = months, reason = e.reason_label }),
            action = function(src) Jail.bail(src, P.getUserId(src), e.user_id) end,
        }
    end
    return { title = L("point_bail"), items = items, parent = parent }
end

function Jail.checkFlow(source)
    local user_id = requirePerm(source, "jailCheck")
    if not user_id then return end
    local values = I.Popup.input(source, L("jail_check_title"), { { key = "id", label = L("field_citizen_id"), type = "number" } })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    if not requirePerm(source, "jailCheck") then return end
    if not P.exists(values.id) then return BoFaisaL.notify(source, "err_unknown_id", nil, "error") end
    local status = Jail.status(values.id)
    local rows = {
        { L("card_name"), P.name(values.id) },
        { L("card_id"), values.id },
        { L("card_status"), status.jailed and L("card_status_jailed") or L("card_status_free") },
    }
    if status.jailed then
        rows[#rows + 1] = { L("card_remaining"), Utils.mmss(status.remaining) }
        rows[#rows + 1] = { L("card_reason"), status.reason or "-" }
        rows[#rows + 1] = { L("card_officer"), status.officer and status.officer.name or "-" }
    end
    BoFaisaL.infoCard(source, { title = L("jail_check_title"), file = values.id, rows = rows,
        stamp = status.jailed and { text = L("card_stamp_jailed"), tone = "bad" } or nil })
    Logs.add("jail", "jail_check", { actor = user_id, target = values.id })
end

function Jail.modify(adminSrc, adminId, targetId, mode, minutes)
    local e = Jail.active[targetId]
    if not e or e.pendingRelease then return BoFaisaL.notify(adminSrc, "jail_not_jailed", nil, "error") end
    local before = e.remaining
    local after = before
    if mode == "add" then after = before + minutes * 60
    elseif mode == "remove" then after = before - minutes * 60
    else after = minutes * 60 end
    after = math.min(after, (cfg().MaxMinutes or 300) * 60)

    local accepted, reason = Confirm.forAction("jailModify", adminSrc, P.getSource(targetId), {
        title = L("confirm_jail_modify_title"),
        message = L("confirm_jail_modify_msg", { name = P.name(targetId), id = targetId }),
        details = {
            { L("jail_modify_before"), Utils.mmss(before) },
            { L("jail_modify_after"), Utils.mmss(math.max(0, after)) },
        },
        icon = "jail",
    })
    if not accepted then return BoFaisaL.notify(adminSrc, Confirm.failMessage(reason, true), nil, "error") end
    local _, profile = requirePerm(adminSrc, "jailModify")
    if not profile then return end
    e = Jail.active[targetId]
    if not e or e.pendingRelease then return BoFaisaL.notify(adminSrc, "jail_not_jailed", nil, "error") end

    Logs.add("jail", "jail_modify", {
        actor = adminId, target = targetId,
        fields = { { L("jail_modify_before"), Utils.mmss(before), true }, { L("jail_modify_after"), Utils.mmss(math.max(0, after)), true }, { L("jail_modify_mode"), L("jail_mode_" .. mode), true } },
    })
    if after <= 0 then
        Jail.finish(targetId, "released", adminId, L("jail_modify_zero"))
    else
        e.remaining = after
        persist(e)
        sync(e)
        local src = P.getSource(targetId)
        if src then BoFaisaL.notify(src, "jail_modified_target", { remaining = Utils.mmss(after) }, "info") end
    end
    BoFaisaL.notify(adminSrc, "jail_modified_admin", { remaining = Utils.mmss(math.max(0, after)) }, "success")
end

function Jail.modifyFlow(source, parent)
    local adminId = requirePerm(source, "jailModify")
    if not adminId then return end
    local onPick
    local function listMenu(s) return Jail.prisonerMenu(s, L("menu_jail_modify"), false, onPick, parent) end
    onPick = function(src, targetId)
        local modes = {}
        for _, mode in ipairs({ "add", "remove", "set" }) do
            modes[#modes + 1] = {
                label = L("jail_mode_" .. mode),
                action = function(s)
                    local values = I.Popup.input(s, L("jail_mode_" .. mode), {
                        { key = "minutes", label = L("field_minutes"), type = "number", min = mode == "set" and 1 or 1, max = cfg().MaxMinutes or 300 },
                    })
                    if not values then return BoFaisaL.notify(s, "action_cancelled", nil, "info") end
                    local id = requirePerm(s, "jailModify")
                    if id then Jail.modify(s, id, targetId, mode, values.minutes) end
                end,
            }
        end
        BoFaisaL.Menu.open(src, { title = ("%s | رقم الهوية: %d"):format(P.name(targetId), targetId), items = modes, parent = listMenu })
    end
    local menu = listMenu(source)
    if menu then BoFaisaL.Menu.open(source, menu) end
end

function Jail.monitorFlow(source, parent)
    if not requirePerm(source, "jailMonitor") then return end
    local menu = Jail.prisonerMenu(source, L("menu_jail_monitor"), true, function(src, targetId)
        if not requirePerm(src, "jailMonitor") then return end
        local targetSrc = P.getSource(targetId)
        if not targetSrc or not Jail.isJailed(targetId) then return BoFaisaL.notify(src, "err_target_offline", nil, "error") end
        local adminId = P.getUserId(src)
        local ok, err = BoFaisaL.Spectate.start(src, targetSrc, "prisoner", function()
            return BoFaisaL.feature("Jail") and Jail.isJailed(targetId) and Gov.has(Gov.cached(adminId), "jailMonitor")
        end)
        if not ok then BoFaisaL.notify(src, err, nil, "error") end
    end, parent)
    if menu then BoFaisaL.Menu.open(source, menu) end
end

function Jail.releaseFlow(source, parent)
    if not requirePerm(source, "jailRelease") then return end
    local menu = Jail.prisonerMenu(source, L("menu_jail_release"), false, function(src, targetId)
        local values = I.Popup.input(src, L("jail_release_title"), {
            { key = "reason", label = L("field_release_reason"), type = "textarea", max = 200 },
        })
        if not values then return BoFaisaL.notify(src, "jail_release_reason_required", nil, "error") end
        local adminId = requirePerm(src, "jailRelease")
        if not adminId then return end
        local accepted, why = Confirm.forAction("jailRelease", src, P.getSource(targetId), {
            title = L("confirm_jail_release_title"),
            message = L("confirm_jail_release_msg", { name = P.name(targetId), id = targetId }),
            details = { { L("field_release_reason"), values.reason } },
            icon = "jail",
        })
        if not accepted then return BoFaisaL.notify(src, Confirm.failMessage(why, true), nil, "error") end
        adminId = requirePerm(src, "jailRelease")
        if not adminId then return end
        if not Jail.isJailed(targetId) then return BoFaisaL.notify(src, "jail_not_jailed", nil, "error") end
        Jail.finish(targetId, "released", adminId, values.reason)
        BoFaisaL.notify(src, "jail_released_admin", { name = P.name(targetId), id = targetId }, "success")
    end, parent)
    if menu then BoFaisaL.Menu.open(source, menu) end
end

---------------------------------------------------------------------------
-- Escapes
---------------------------------------------------------------------------
function Jail.onEscape(user_id, src)
    local e = Jail.active[user_id]
    if not e or e.pendingRelease or e.finishing then return end
    local esc = cfg().Escape or {}
    if not esc.Enabled then return end
    local now = GetGameTimer()
    if (e.lastEscape and now - e.lastEscape < 6000) or (e.grace and now < e.grace) then return end
    e.lastEscape = now
    e.grace = now + 6000
    P.teleport(src, returnPoint(), cfg().EntryHeading)
    local added = 0
    local cap = (esc.MaxAddedMinutes or 60) * 60
    if (esc.AddMinutes or 0) > 0 and e.added < cap then
        added = math.min((esc.AddMinutes or 0) * 60, cap - e.added)
        -- Never above the longest sentence (MaxMinutes).
        added = math.max(0, math.min(added, (cfg().MaxMinutes or 300) * 60 - e.remaining))
        e.remaining = e.remaining + added
        e.added = e.added + added
        persist(e)
    end
    sync(e)
    TriggerClientEvent("bofaisal_police:jail:escape", src, esc.Message or "", added)
    BoFaisaL.notify(src, esc.Message or "", nil, "error", 8)
    Logs.add("jail", "jail_escape", { target = user_id, fields = { { L("log_field_added"), Utils.humanDuration(added) } } })
end

-- Client-side perimeter report (used without OneSync). Only ever makes things worse for the
-- reporting prisoner, so trusting it is safe.
RPC.register("jail:escaped", { feature = "Jail", cooldown = 3000 }, function(ctx)
    if not Jail.isJailed(ctx.user_id) then return true end
    if P.oneSync() then
        local c = P.coords(ctx.source)
        if not c or Utils.dist2d(c, center()) <= (cfg().Radius or 150) then return true end
    end
    Jail.onEscape(ctx.user_id, ctx.source)
    return true
end)

---------------------------------------------------------------------------
-- Tasks
---------------------------------------------------------------------------
local function findTask(id)
    for _, t in ipairs((cfg().Tasks and cfg().Tasks.List) or {}) do
        if t.id == id then return t end
    end
    return nil
end

local function atTask(src, task)
    local c = P.coords(src)
    return c ~= nil and Utils.dist(c, task.coords) <= (task.radius or 2.0) + 1.0
end

RPC.register("jail:taskStart", { feature = "Jail", cooldown = 1000 }, function(ctx, data)
    local tcfg = cfg().Tasks or {}
    if not tcfg.Enabled then return nil, L("err_feature_disabled") end
    if not Jail.isJailed(ctx.user_id) then return nil, L("jail_not_jailed_self") end
    local task = type(data.id) == "string" and findTask(data.id)
    if not task then return nil, L("err_invalid_request") end
    if Jail.tasks[ctx.user_id] then return nil, L("jail_task_busy") end
    local cooldowns = Jail.taskCooldowns[ctx.user_id] or {}
    Jail.taskCooldowns[ctx.user_id] = cooldowns
    if cooldowns[task.id] and cooldowns[task.id] > BoFaisaL.now() then
        return nil, L("jail_task_cooldown", { seconds = cooldowns[task.id] - BoFaisaL.now() })
    end
    if not atTask(ctx.source, task) then return nil, L("jail_task_far") end
    Jail.tasks[ctx.user_id] = { id = task.id, startedAt = GetGameTimer() }
    local typeDef = tcfg.Types and tcfg.Types[task.type] or {}
    local difficulty = tcfg.Difficulties and tcfg.Difficulties[task.difficulty] or { checks = 1, speed = 1, zone = 0.2 }
    return {
        id = task.id, label = task.label, duration = task.duration,
        anim = { scenario = typeDef.scenario, dict = typeDef.dict, name = typeDef.anim, prop = typeDef.prop },
        difficulty = difficulty,
        ui = Jail.taskUi(task),
    }
end)

-- Look of the task on screen (chosen per task in إدارة اللوحة): "corners" | "segments".
Jail.TASK_UIS = { corners = true, segments = true, classic = true }
function Jail.taskUi(task)
    local tcfg = cfg().Tasks or {}
    if task and Jail.TASK_UIS[task.ui] then return task.ui end
    return Jail.TASK_UIS[tcfg.UiStyle] and tcfg.UiStyle or "corners"
end

-- Stepping on a task point opens its Builder Menu ("بدء المهمة"), stepping off closes it,
-- like the fine / impound points.
Jail.taskMenus = {} -- [source] = id of the task whose menu is open

local function taskMenu(src, task)
    local user_id = P.getUserId(src)
    local readyAt = (Jail.taskCooldowns[user_id] or {})[task.id]
    local wait = readyAt and (readyAt - BoFaisaL.now()) or 0
    local item
    if wait > 0 then
        item = {
            label = L("jail_task_menu_start"), description = L("jail_task_menu_wait", { time = Utils.mmss(wait) }),
            action = function(s) BoFaisaL.notify(s, "jail_task_cooldown", { seconds = wait }, "error") end,
        }
    else
        item = {
            label = L("jail_task_menu_start"),
            description = L("jail_task_menu_desc", { duration = task.duration or 20, reduction = Utils.humanDuration(task.reduction or 0) }),
            action = function(s)
                Jail.taskMenus[s] = nil
                BoFaisaL.Menu.close(s)
                TriggerClientEvent("bofaisal_police:jail:runTask", s, task.id)
            end,
        }
    end
    return { title = (task.label or "") ~= "" and task.label or L("jail_task_menu_title"), items = { item } }
end

RPC.register("jail:taskMenu", { feature = "Jail", cooldown = 700 }, function(ctx, data)
    if not (cfg().Tasks or {}).Enabled then return nil, L("err_feature_disabled") end
    if not Jail.isJailed(ctx.user_id) then return nil, L("jail_not_jailed_self") end
    local task = type(data.id) == "string" and findTask(data.id)
    if not task then return nil, L("err_invalid_request") end
    if not atTask(ctx.source, task) then return nil, L("jail_task_far") end
    Jail.taskMenus[ctx.source] = task.id
    BoFaisaL.Menu.open(ctx.source, taskMenu(ctx.source, task))
    return true
end)

RPC.register("jail:taskLeave", { feature = "Jail" }, function(ctx)
    if Jail.taskMenus[ctx.source] then
        Jail.taskMenus[ctx.source] = nil
        BoFaisaL.Menu.close(ctx.source)
    end
    return true
end)

BoFaisaL.on("playerDropped", function(_, source) if source then Jail.taskMenus[source] = nil end end)

RPC.register("jail:taskComplete", { feature = "Jail", cooldown = 500 }, function(ctx, data)
    local session = Jail.tasks[ctx.user_id]
    Jail.tasks[ctx.user_id] = nil
    if not session or session.id ~= data.id then return nil, L("err_invalid_request") end
    local e = Jail.active[ctx.user_id]
    if not e or e.pendingRelease then return nil, L("jail_not_jailed_self") end
    local task = findTask(session.id)
    if not task then return nil, L("err_invalid_request") end
    if data.success ~= true then return { reduced = 0, failed = true } end
    if GetGameTimer() - session.startedAt < (task.duration * 1000) - 1500 then return nil, L("jail_task_too_fast") end
    if not atTask(ctx.source, task) then return nil, L("jail_task_far") end

    local tcfg = cfg().Tasks or {}
    Jail.taskCooldowns[ctx.user_id][task.id] = BoFaisaL.now() + (task.cooldown or 120)
    local maxTotal = math.floor(e.total * (tcfg.MaxReductionPercent or 50) / 100)
    local allowed = math.max(0, maxTotal - e.reduced)
    local reduction = math.min(task.reduction or 0, allowed, math.max(0, e.remaining - (tcfg.MinRemaining or 60)))
    if reduction <= 0 then return { reduced = 0, capped = true } end
    e.remaining = e.remaining - reduction
    e.reduced = e.reduced + reduction
    persist(e)
    sync(e)
    Logs.add("jail", "jail_task", { target = ctx.user_id, fields = { { L("field_task"), task.label, true }, { L("log_field_reduced"), Utils.humanDuration(reduction), true } } })
    return { reduced = reduction, remaining = e.remaining }
end)

RPC.register("jail:taskCancel", { feature = "Jail" }, function(ctx)
    Jail.tasks[ctx.user_id] = nil
    return true
end)

---------------------------------------------------------------------------
-- Lifecycle, timers and persistence
---------------------------------------------------------------------------
function Jail.load()
    Jail.active = {}
    for _, row in ipairs(DB.query("SELECT * FROM bofaisal_police_jail")) do
        local uid = tonumber(row.user_id)
        Jail.active[uid] = {
            user_id = uid,
            officer_id = tonumber(row.officer_id), -- nil = no officer
            officer_name = row.officer_name or "",
            reason_id = row.reason_id or "",
            reason_label = row.reason_label or "",
            total = tonumber(row.total_seconds) or 0,
            remaining = tonumber(row.remaining_seconds) or 0,
            added = tonumber(row.added_seconds) or 0,
            reduced = tonumber(row.reduced_seconds) or 0,
            started_at = tonumber(row.started_at) or 0,
            clothing = row.clothing or "",
            was_cuffed = tonumber(row.was_cuffed) or 0,
            pendingRelease = (tonumber(row.remaining_seconds) or 0) <= 0,
        }
    end
    BoFaisaL.debug("jail", "%d sentences loaded", Utils.count(Jail.active))
end

-- Join / restart / respawn: re-apply the sentence (never re-saving the original clothing).
BoFaisaL.on("playerReady", function(user_id, source)
    local e = Jail.active[user_id]
    if not e then return end
    if e.pendingRelease or e.remaining <= 0 then
        physicalRelease(e, source)
        DB.execute("DELETE FROM bofaisal_police_jail WHERE user_id = ?", { user_id })
        Jail.active[user_id] = nil
        BoFaisaL.notify(source, "jail_served_target", nil, "success", 10)
        Officers.pushState(user_id)
        return
    end
    Jail.apply(e, source)
end)

BoFaisaL.on("playerRespawn", function(user_id, source)
    local e = Jail.active[user_id]
    if e and not e.pendingRelease then
        SetTimeout(1500, function()
            if Jail.active[user_id] == e and P.getSource(user_id) == source then Jail.apply(e, source) end
        end)
    end
end)

BoFaisaL.on("playerDropped", function(user_id)
    local e = Jail.active[user_id]
    if e then persist(e) end
    Jail.tasks[user_id] = nil
end)

-- 1 s authoritative timer. Counts elapsed game time, so server hitches do not stretch sentences.
Citizen.CreateThread(function()
    local last = GetGameTimer()
    while true do
        Citizen.Wait(1000)
        local step = math.floor((GetGameTimer() - last) / 1000)
        last = last + step * 1000
        local countOffline = cfg().CountOfflineTime == true
        for uid, e in pairs(Jail.active) do
            if step > 0 and not e.pendingRelease and not e.finishing and (countOffline or P.byUser[uid]) then
                e.remaining = e.remaining - step
                e.dirty = true
                if e.remaining <= 0 then
                    e.remaining = 0
                    BoFaisaL.thread(Jail.finish, uid, "served", nil, nil) -- nil = nobody released him (0 is a real id)
                end
            end
        end
    end
end)

-- Persistence + periodic HUD re-sync.
Citizen.CreateThread(function()
    while true do
        Citizen.Wait((cfg().PersistInterval or 30) * 1000)
        for _, e in pairs(Jail.active) do
            if e.dirty and not e.finishing then
                persist(e)
                sync(e)
            end
        end
    end
end)

-- Escape detection (server-side positions, OneSync).
Citizen.CreateThread(function()
    while true do
        local esc = cfg().Escape or {}
        Citizen.Wait((esc.CheckInterval or 2) * 1000)
        if esc.Enabled and P.oneSync() then
            local c, radius = center(), cfg().Radius or 150
            for uid, e in pairs(Jail.active) do
                local src = not e.pendingRelease and not e.finishing and P.byUser[uid]
                if src then
                    local pos = P.coords(src)
                    if pos and Utils.dist2d(pos, c) > radius then Jail.onEscape(uid, src) end
                end
            end
        end
    end
end)

-- Resource stop: hand the latest remaining times to the database driver immediately.
AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, e in pairs(Jail.active) do
        if not e.finishing then
            DB.fire("UPDATE bofaisal_police_jail SET remaining_seconds = ?, added_seconds = ?, reduced_seconds = ?, updated_at = ? WHERE user_id = ?",
                { math.max(0, e.remaining), e.added, e.reduced, BoFaisaL.now(), e.user_id })
        end
    end
end)

-- Config.Jail.Handcuff.Enforce: this prisoner must stay cuffed right now (online, not on a task).
function Jail.keepsCuffs(user_id)
    local cuffs = cfg().Handcuff or {}
    local e = Jail.active[tonumber(user_id)]
    return cuffs.Enabled == true and cuffs.Enforce == true and e ~= nil and not e.pendingRelease and not e.finishing
        and not Jail.tasks[e.user_id] and P.byUser[e.user_id] ~= nil
end

-- Keep prisoners restrained (uncuffed by another script: cuffed again at the next check).
Citizen.CreateThread(function()
    while true do
        local cuffs = cfg().Handcuff or {}
        Citizen.Wait((cuffs.EnforceInterval or 15) * 1000)
        for uid in pairs(Jail.active) do
            if Jail.keepsCuffs(uid) then
                local src = P.byUser[uid]
                if src and not I.Handcuff.isCuffed(src) then I.Handcuff.set(src, true) end
            end
        end
    end
end)
