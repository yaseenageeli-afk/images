--[[
    BoFaisaL_Police — nearby target (fines, jail, field options)

    Every action goes straight to the closest player (no list to choose from). The target comes
    from SERVER-SIDE positions and is re-validated when it is used, so a player can never act
    on someone who is not really next to them.
]]

local Targets = {}
BoFaisaL.Targets = Targets

local P = BoFaisaL.Players

function Targets.radius()
    return (Config.Targeting and Config.Targeting.Radius) or 4.0
end

-- Config.Targeting.AllowSelf: the officer can pick himself (fines, jail, field options).
function Targets.allowSelf()
    return BoFaisaL.allowSelf()
end

-- The closest player, no list to choose from (himself only when nobody else is near and
-- Config.Targeting.AllowSelf). onPick(targetSource, targetUserId) runs in this thread.
function Targets.nearest(source, onPick, radius)
    local entry = P.nearby(source, radius or Targets.radius())[1]
    if not entry and Targets.allowSelf() then
        local me = P.bySource[source]
        if me then entry = { source = source, user_id = me } end
    end
    if not entry then return BoFaisaL.notify(source, "target_none", nil, "error") end
    onPick(entry.source, entry.user_id)
end

-- Re-validates a target right before acting.
function Targets.check(source, targetSource, targetUserId, radius)
    if not targetSource or not GetPlayerName(targetSource) then return false, L("err_target_offline") end
    if P.bySource[targetSource] ~= targetUserId then return false, L("err_target_offline") end
    if P.distance(source, targetSource) > (radius or Targets.radius()) + 1.0 then
        return false, L("target_too_far")
    end
    return true
end
