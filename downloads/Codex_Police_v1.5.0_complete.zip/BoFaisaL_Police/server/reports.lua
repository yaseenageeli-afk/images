--[[
    BoFaisaL_Police — citizen reports (إبلاغ عن مجرم → البلاغات)

    Status flow: new (جديد) → claimed (مستلم) → closed (تم الانتهاء)
    Every report expires ExpireMinutes after it was filed, claimed or not (status "expired").
    An officer holds one claimed report at a time (OneAtATime).
]]

local Reports = { lastByReporter = {} }
BoFaisaL.Reports = Reports

local DB, P, Gov, Logs, Officers, RPC = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers, BoFaisaL.RPC

local function cfg() return Config.Reports or {} end
local function expireSeconds() return (tonumber(cfg().ExpireMinutes) or 90) * 60 end

-- Marks every open report older than ExpireMinutes as expired.
function Reports.expire()
    local now = BoFaisaL.now()
    DB.execute("UPDATE bofaisal_police_reports SET status = 'expired', updated_at = ? WHERE status IN ('new', 'claimed') AND created_at <= ?",
        { now, now - expireSeconds() })
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(60000)
        pcall(Reports.expire)
        -- Cooldowns that are over are forgotten (the table never grows with every player ever seen).
        local now, cooldown = BoFaisaL.now(), cfg().Cooldown or 60
        for uid, at in pairs(Reports.lastByReporter) do
            if now - at >= cooldown then Reports.lastByReporter[uid] = nil end
        end
    end
end)

local function row(r)
    local targetId = tonumber(r.target_id)
    return {
        id = tonumber(r.id),
        reporter = { id = tonumber(r.reporter_id), name = r.reporter_name },
        target = { id = targetId, name = r.target_name, online = P.isOnline(targetId), mugshotAt = BoFaisaL.Mugshots.stamp(targetId) },
        expiresAt = tonumber(r.created_at) + expireSeconds(),
        reason = r.reason,
        status = r.status,
        assigned = tonumber(r.assigned_id) and { id = tonumber(r.assigned_id), name = r.assigned_name } or nil, -- NULL = not claimed
        hasLocation = (tonumber(r.pos_x) or 0) ~= 0 or (tonumber(r.pos_y) or 0) ~= 0,
        createdAt = tonumber(r.created_at),
        updatedAt = tonumber(r.updated_at),
    }
end

-- alert: the on-screen alert, like the wanted one (Config.Reports.Alert), with quick open.
local function notifyOfficers(key, vars, alert)
    local mode = cfg().NotifyOfficers or "onduty"
    if mode == "none" then return end
    local targets = mode == "all" and Officers.militarySources() or Officers.onDutySources()
    for _, src in ipairs(targets) do
        local uid = P.bySource[src]
        if uid and Gov.has(Gov.cached(uid), "reports") then
            BoFaisaL.notify(src, key, vars, "warning", 8)
            TriggerClientEvent("bofaisal_police:ipad:push", src, "reports", {})
            if alert and cfg().Alert ~= false then TriggerClientEvent("bofaisal_police:wanted:alert", src, alert) end
        end
    end
end

-- Creates a report. Returns the report id or nil, error.
-- byOfficer = true: "تعميم بلاغ" from the police menu (no citizen cooldown / open-report limit).
function Reports.create(reporterId, reporterSrc, targetId, reason, byOfficer)
    if not BoFaisaL.feature(byOfficer and "Reports" or "CitizenReport") then return nil, L("err_feature_disabled") end
    local c = cfg()
    local now = BoFaisaL.now()
    local last = Reports.lastByReporter[reporterId]
    if not byOfficer and last and now - last < (c.Cooldown or 60) then
        return nil, L("report_cooldown", { seconds = (c.Cooldown or 60) - (now - last) })
    end
    targetId = Utils.toUserId(targetId)
    if not targetId or not P.exists(targetId) then return nil, L("err_unknown_id") end
    if c.OnlineTargetsOnly and not P.isOnline(targetId) then return nil, L("report_target_offline") end
    if targetId == reporterId and not (c.AllowSelfReport or BoFaisaL.allowSelf()) then return nil, L("report_self") end
    if BoFaisaL.Immunity.officerProtected(targetId, "Reports", reporterId) then return nil, L("report_target_officer") end
    reason = Utils.sanitize(reason or "", c.MaxReasonLength or 250)
    if reason == "" then return nil, L("report_reason_required") end
    local open = tonumber(DB.scalar("SELECT COUNT(*) AS c FROM bofaisal_police_reports WHERE reporter_id = ? AND status IN ('new', 'claimed')", { reporterId })) or 0
    if not byOfficer and open >= (c.MaxOpenPerReporter or 3) then return nil, L("report_too_many") end

    local pos = { x = 0.0, y = 0.0, z = 0.0 }
    if c.StoreLocation then pos = P.coords(reporterSrc) or pos end
    local reporterName, targetName = P.name(reporterId), P.name(targetId)
    local id = DB.insert(
        "INSERT INTO bofaisal_police_reports (reporter_id, reporter_name, target_id, target_name, reason, status, pos_x, pos_y, pos_z, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, ?)",
        { reporterId, reporterName, targetId, targetName, reason, pos.x, pos.y, pos.z, now, now }
    )
    if not id then return nil, L("err_internal") end
    Reports.lastByReporter[reporterId] = now

    notifyOfficers("report_new_officers", { id = id, target = targetName, target_id = targetId, reason = reason }, {
        kind = "report", tab = "reports", id = id, name = targetName, user_id = targetId, reason = reason,
        quickOpen = c.QuickOpen,
        mugshotAt = BoFaisaL.Mugshots and BoFaisaL.Mugshots.stamp(targetId) or nil, -- character photo
    })
    Logs.add("reports", "report_create", {
        actor = reporterId, target = targetId, actorName = reporterName, targetName = targetName,
        actorLabel = L("log_field_reporter"), targetLabel = L("log_field_reported"),
        fields = { { L("log_field_report"), "#" .. id, true } }, description = reason,
    })
    return id
end

-- Builder Menu flow: "إبلاغ عن مجرم" (available to everyone).
function Reports.createFlow(source)
    local user_id = P.getUserId(source)
    if not user_id then return end
    if not BoFaisaL.feature("CitizenReport") then return BoFaisaL.notify(source, "err_feature_disabled", nil, "error") end
    local values = BoFaisaL.Integrations.Popup.input(source, L("report_title"), {
        { key = "id", label = L("field_target_id"), type = "number" },
        { key = "reason", label = L("field_reason"), type = "textarea", max = cfg().MaxReasonLength or 250 },
    })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    local id, err = Reports.create(user_id, source, values.id, values.reason)
    if not id then return BoFaisaL.notify(source, err, nil, "error") end
    BoFaisaL.notify(source, "report_sent", { id = id }, "success")
end

---------------------------------------------------------------------------
-- iPad
---------------------------------------------------------------------------
-- Open reports only (new + claimed); expired ones disappear by themselves.
-- Expired ones are left out by their age (the minute loop marks them in the database).
RPC.register("reports:list", { feature = "Reports", perm = "reports", duty = "reports" }, function(ctx)
    local list = {}
    for _, r in ipairs(DB.query("SELECT * FROM bofaisal_police_reports WHERE status IN ('new', 'claimed') AND created_at > ? ORDER BY id DESC LIMIT " .. (cfg().ListLimit or 100),
        { BoFaisaL.now() - expireSeconds() })) do
        list[#list + 1] = row(r)
    end
    return { list = list, me = ctx.user_id, now = BoFaisaL.now() }
end)

RPC.register("reports:claim", { feature = "Reports", perm = "reports", duty = "reports", cooldown = 800 }, function(ctx, data)
    local id = RPC.int(data.id, 1)
    if not id then return nil, L("err_invalid_request") end
    Reports.expire()
    if cfg().OneAtATime ~= false then
        local mine = tonumber(DB.scalar("SELECT COUNT(*) AS c FROM bofaisal_police_reports WHERE assigned_id = ? AND status = 'claimed'", { ctx.user_id })) or 0
        if mine > 0 then return nil, L("report_one_at_a_time") end
    end
    local now = BoFaisaL.now()
    local changed = DB.execute(
        "UPDATE bofaisal_police_reports SET status = 'claimed', assigned_id = ?, assigned_name = ?, updated_at = ? WHERE id = ? AND status = 'new'",
        { ctx.user_id, ctx.name, now, id }
    )
    if changed < 1 then return nil, L("report_already_claimed") end
    local r = DB.single("SELECT * FROM bofaisal_police_reports WHERE id = ?", { id })
    Logs.add("reports", "report_claim", { actor = ctx.user_id, fields = { { L("log_field_report"), "#" .. id, true } } })
    if r and cfg().NotifyReporterOnClaim then
        local reporterSrc = P.getSource(tonumber(r.reporter_id))
        if reporterSrc then BoFaisaL.notify(reporterSrc, "report_claimed_reporter", { id = id, officer = ctx.name }, "success") end
    end
    return row(r)
end)

-- "تم الانتهاء من البلاغ": only the officer who claimed it. It counts for that officer.
RPC.register("reports:finish", { feature = "Reports", perm = "reports", duty = "reports", cooldown = 800 }, function(ctx, data)
    local id = RPC.int(data.id, 1)
    if not id then return nil, L("err_invalid_request") end
    Reports.expire()
    local r = DB.single("SELECT * FROM bofaisal_police_reports WHERE id = ?", { id })
    if not r or r.status ~= "claimed" then return nil, L("report_not_found") end
    if tonumber(r.assigned_id) ~= ctx.user_id then return nil, L("report_not_assigned") end
    local changed = DB.execute("UPDATE bofaisal_police_reports SET status = 'closed', updated_at = ? WHERE id = ? AND status = 'claimed'",
        { BoFaisaL.now(), id })
    if changed < 1 then return nil, L("report_not_found") end
    Officers.increment(ctx.user_id, "reports_handled", 1)
    Logs.add("reports", "report_closed", { actor = ctx.user_id, fields = { { L("log_field_report"), "#" .. id, true } } })
    r.status = "closed"
    return row(r)
end)

RPC.register("reports:waypoint", { feature = "Reports", perm = "reports" }, function(ctx, data)
    local id = RPC.int(data.id, 1)
    local r = id and DB.single("SELECT pos_x, pos_y FROM bofaisal_police_reports WHERE id = ?", { id })
    if not r or ((tonumber(r.pos_x) or 0) == 0 and (tonumber(r.pos_y) or 0) == 0) then return nil, L("report_no_location") end
    TriggerClientEvent("bofaisal_police:waypoint", ctx.source, tonumber(r.pos_x), tonumber(r.pos_y))
    return true
end)
