-- Original BoFaisaL module: in-game mutual aid. Not affiliated with a real charity.
local Ehsan = {}
BoFaisaL.Ehsan = Ehsan
local DB, RPC, P, FW = BoFaisaL.DB, BoFaisaL.RPC, BoFaisaL.Players, BoFaisaL.Framework
local function cfg() return Config.Ehsan or {} end
local busy = false
local function enabled() return cfg().Enabled == true and DB.ready end
local function admin(uid) return FW.call("hasPermission",uid,cfg().AdminPermission or "player.owner") == true end
local function locked(fn)
    if busy then return nil,"عملية قيد التنفيذ، حاول بعد لحظات" end
    busy=true
    local ok,result,err=xpcall(fn,debug.traceback)
    busy=false
    if not ok then BoFaisaL.error("ehsan: %s",tostring(result));return nil,"تعذر إكمال العملية؛ راجع سجل الإدارة" end
    return result,err
end
local schemas={
[[CREATE TABLE IF NOT EXISTS bofaisal_police_ehsan_cases (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id BIGINT NOT NULL,
 name VARCHAR(64) NOT NULL, reason VARCHAR(240) NOT NULL,
 target INT NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'pending',
 created_at INT NOT NULL, KEY idx_user_status(user_id,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],
[[CREATE TABLE IF NOT EXISTS bofaisal_police_ehsan_donations (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, case_id INT NOT NULL,
 donor_id BIGINT NOT NULL, recipient_id BIGINT NOT NULL,
 amount INT NOT NULL, donor_before INT NOT NULL, recipient_before INT NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'prepared',
 created_at INT NOT NULL, KEY idx_case_status(case_id,status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]]
}
for _,sql in ipairs(schemas) do DB.schema[#DB.schema+1]=sql end
local function raised(id)
    return tonumber(DB.scalar("SELECT COALESCE(SUM(amount),0) FROM bofaisal_police_ehsan_donations WHERE case_id=? AND status='paid'",{id})) or 0
end
local function view(ctx,data)
    if not enabled() then return nil,"خدمة إحسان غير متاحة" end
    local page=RPC.int(data.page or 1,1,100000) or 1
    local size=math.max(1,math.min(50,tonumber(cfg().PageSize) or 20))
    size=math.floor(size)
    local where="(status IN ('active','completed') OR user_id=?)"
    local isAdmin=admin(ctx.user_id)
    if isAdmin then where="1=1" end
    local params=isAdmin and {} or {ctx.user_id}
    local list=DB.query("SELECT * FROM bofaisal_police_ehsan_cases WHERE "..where.." ORDER BY id DESC LIMIT "..size.." OFFSET "..((page-1)*size),params)
    for _,r in ipairs(list) do
        r.id=tonumber(r.id); r.user_id=tonumber(r.user_id);r.target=tonumber(r.target)
        r.raised=raised(r.id);r.online=P.isOnline(r.user_id);r.own=r.user_id==ctx.user_id
    end
    local unresolved=tonumber(DB.scalar("SELECT COUNT(*) FROM bofaisal_police_ehsan_donations WHERE status IN ('prepared','deducted','credited')"))
    if unresolved==nil then return nil,"تعذر قراءة سجل التبرعات" end
    local history=DB.query("SELECT id,case_id,donor_id,recipient_id,amount,status,created_at FROM bofaisal_police_ehsan_donations WHERE donor_id=? OR recipient_id=? ORDER BY id DESC LIMIT 10",{ctx.user_id,ctx.user_id})
    return {list=list,history=history,page=page,hasNext=#list==size,admin=isAdmin,user_id=ctx.user_id,name=ctx.name,
        min=cfg().MinDonation or 1,max=cfg().MaxDonation or 100000,maxTarget=cfg().MaxTarget or 1000000,
        wallet=FW.getMoney(ctx.user_id),bank=FW.getBankMoney(ctx.user_id),blocked=unresolved>0,approval=cfg().RequireApproval~=false}
end
RPC.register("ehsan:list",{cooldown=400},view)
RPC.register("ehsan:create",{cooldown=1500},function(ctx,data)
    if not enabled() then return nil,"خدمة إحسان غير متاحة" end
    return locked(function()
        local amount=RPC.int(data.amount,1,cfg().MaxTarget or 1000000)
        local reason=RPC.text(data.reason,240)
        if not amount or not reason then return nil,"أدخل مبلغًا صحيحًا ووصفًا للحالة" end
        local old=DB.single("SELECT id FROM bofaisal_police_ehsan_cases WHERE user_id=? AND (status IN ('pending','active') OR created_at>?) LIMIT 1",{ctx.user_id,BoFaisaL.now()-math.floor((cfg().CreateCooldownHours or 24)*3600)})
        if old then return nil,"لديك حالة مفتوحة أو لم تنته مهلة إنشاء حالة جديدة" end
        local status=cfg().RequireApproval==false and "active" or "pending"
        local id=DB.insert("INSERT INTO bofaisal_police_ehsan_cases(user_id,name,reason,target,status,created_at) VALUES(?,?,?,?,?,?)",{ctx.user_id,ctx.name,reason,amount,status,BoFaisaL.now()})
        if not id then return nil,"تعذر حفظ الحالة" end
        BoFaisaL.Logs.add("ehsan","ehsan_case_created",{actor=ctx.user_id,fields={{"الحالة",id},{"المبلغ",amount}}})
        return view(ctx,{})
    end)
end)
RPC.register("ehsan:moderate",{cooldown=1000},function(ctx,data)
    if not enabled() then return nil,"خدمة إحسان غير متاحة" end
    return locked(function()
        local id=RPC.int(data.id,1);local action=RPC.oneOf(data.decision,{"approve","reject","cancel"})
        if not id or not action then return nil,"طلب غير صحيح" end
        local r=DB.single("SELECT * FROM bofaisal_police_ehsan_cases WHERE id=?",{id})
        if not r then return nil,"الحالة غير موجودة" end
        if action=="cancel" then
            if tonumber(r.user_id)~=ctx.user_id and not admin(ctx.user_id) then return nil,"ليست لديك صلاحية" end
            if r.status~="pending" and r.status~="active" then return nil,"الحالة مغلقة" end
        elseif not admin(ctx.user_id) or r.status~="pending" then return nil,"ليست لديك صلاحية أو الحالة ليست قيد المراجعة" end
        local status=action=="approve" and "active" or action=="reject" and "rejected" or "cancelled"
        if DB.execute("UPDATE bofaisal_police_ehsan_cases SET status=? WHERE id=? AND status=?",{status,id,r.status})~=1 then return nil,"تعذر تحديث الحالة" end
        BoFaisaL.Logs.add("ehsan","ehsan_case_"..status,{actor=ctx.user_id,target=tonumber(r.user_id),fields={{"الحالة",id}}})
        return view(ctx,{})
    end)
end)
RPC.register("ehsan:donate",{cooldown=2000},function(ctx,data)
    if not enabled() then return nil,"خدمة إحسان غير متاحة" end
    return locked(function()
        -- Fail closed on an interrupted wallet operation. No automatic replay: vRP wallets and SQL do not share a transaction.
        local unresolved=tonumber(DB.scalar("SELECT COUNT(*) FROM bofaisal_police_ehsan_donations WHERE status IN ('prepared','deducted','credited')"))
        if unresolved==nil or unresolved>0 then return nil,"التبرعات موقوفة حتى مراجعة الإدارة لسجل العمليات" end
        local id=RPC.int(data.id,1);local amount=RPC.int(data.amount,cfg().MinDonation or 1,cfg().MaxDonation or 100000)
        if not id or not amount then return nil,"مبلغ أو حالة غير صحيحة" end
        local r=DB.single("SELECT * FROM bofaisal_police_ehsan_cases WHERE id=? AND status='active'",{id})
        if not r then return nil,"الحالة غير متاحة للتبرع" end
        local uid=tonumber(r.user_id)
        if uid==ctx.user_id then return nil,"لا يمكنك التبرع لحالتك" end
        local recipient=P.getSource(uid)
        if not recipient then return nil,"يجب أن يكون المستفيد متصلًا لاستلام الدعم" end
        if amount>tonumber(r.target)-raised(id) then return nil,"المبلغ يتجاوز المتبقي للحالة" end
        local donorBefore=FW.getMoney(ctx.user_id); local recipientBefore=FW.getMoney(uid)
        if donorBefore<amount then return nil,"رصيدك النقدي غير كافٍ" end
        local tx=DB.insert("INSERT INTO bofaisal_police_ehsan_donations(case_id,donor_id,recipient_id,amount,status,created_at,donor_before,recipient_before) VALUES(?,?,?,?,?,?,?,?)",{id,ctx.user_id,uid,amount,"prepared",BoFaisaL.now(),donorBefore,recipientBefore})
        if not tx then return nil,"تعذر تسجيل العملية" end
        if P.getSource(uid)~=recipient or P.getSource(ctx.user_id)~=ctx.source then
            DB.execute("UPDATE bofaisal_police_ehsan_donations SET status='failed' WHERE id=?",{tx})
            return nil,"تغير اتصال أحد الطرفين" end
        if not FW.pay(ctx.user_id,amount,"wallet") then
            -- A false result can be a timeout after mutation; only mark failed if the wallet is unchanged.
            if FW.getMoney(ctx.user_id)==donorBefore then DB.execute("UPDATE bofaisal_police_ehsan_donations SET status='failed' WHERE id=?",{tx}) end
            return nil,"تعذر خصم التبرع" end
        if FW.getMoney(ctx.user_id)~=donorBefore-amount then return nil,"تحتاج العملية مراجعة الإدارة" end
        if DB.execute("UPDATE bofaisal_police_ehsan_donations SET status='deducted' WHERE id=? AND status='prepared'",{tx})~=1 then return nil,"تحتاج العملية مراجعة الإدارة" end
        if P.getSource(uid)~=recipient then return nil,"انقطع المستفيد؛ العملية محفوظة للمراجعة" end
        FW.giveMoney(uid,amount)
        if FW.getMoney(uid)~=recipientBefore+amount then return nil,"تحتاج عملية الإيداع مراجعة الإدارة" end
        if DB.execute("UPDATE bofaisal_police_ehsan_donations SET status='credited' WHERE id=? AND status='deducted'",{tx})~=1 then return nil,"تحتاج العملية مراجعة الإدارة" end
        if DB.execute("UPDATE bofaisal_police_ehsan_donations SET status='paid' WHERE id=? AND status='credited'",{tx})~=1 then return nil,"تحتاج العملية مراجعة الإدارة" end
        if raised(id)>=tonumber(r.target) then DB.execute("UPDATE bofaisal_police_ehsan_cases SET status='completed' WHERE id=?",{id}) end
        BoFaisaL.Logs.add("ehsan","ehsan_donation_paid",{actor=ctx.user_id,target=uid,fields={{"العملية",tx},{"الحالة",id},{"المبلغ",amount}}})
        return view(ctx,{})
    end)
end)
function Ehsan.open(src)
    local ctx,err=RPC.context(src,{})
    if not ctx then return end
    local d,message=view(ctx,{})
    if not d then return BoFaisaL.ui(src,"toast",{message=message,kind="error"}) end
    BoFaisaL.ui(src,"panel",{kind="ehsan",phone=false,title="إحسان",data=d})
end
RegisterCommand((cfg().Command or "ehsan"),function(src) if src>0 then BoFaisaL.thread(Ehsan.open,src) end end,false)
