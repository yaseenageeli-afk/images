--[[
    BoFaisaL_Police — vacations (الإجازات)

    Balance-based: every officer has a balance in MINUTES. Taking a vacation saves the exact
    military groups, removes them, gives the configured inactive (unemployed) group and
    reserves the whole balance. The balance runs down only while the officer is in the server
    (Config.Vacation.CountOffline = false): leaving pauses it (paused_at), joining again pushes
    the end time forward by the time away. When it reaches zero the vacation ends and the exact
    groups are restored. Breaking a vacation early gives the unused minutes back.
    The `days` column of bofaisal_police_vacations stores the reserved MINUTES.
]]

local Vacation = { active = {} } -- [user_id] = vacation row
BoFaisaL.Vacation = Vacation

local DB, P, Gov, Logs, F = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Framework

local function cfg() return Config.Vacation or {} end

local function decode(raw)
    local ok, list = pcall(json.decode, raw or "[]")
    return ok and type(list) == "table" and list or {}
end

function Vacation.isOnVacation(user_id)
    return Vacation.active[tonumber(user_id)] ~= nil
end

function Vacation.get(user_id)
    return Vacation.active[tonumber(user_id)]
end

-- When the vacation would end if the officer stays in the server from now on.
function Vacation.endsAt(row)
    local pausedAt = row and tonumber(row.paused_at) or 0
    if pausedAt > 0 then return BoFaisaL.now() + math.max(0, tonumber(row.end_at) - pausedAt) end
    return row and tonumber(row.end_at) or 0
end

local function countOffline() return cfg().CountOffline == true end

-- Freezes the time left (officer left / script stopped).
local function pause(row, now)
    if countOffline() or not row or (tonumber(row.paused_at) or 0) > 0 then return end
    row.paused_at = now or BoFaisaL.now()
    DB.execute("UPDATE bofaisal_police_vacations SET paused_at = ? WHERE id = ?", { row.paused_at, row.id })
end

-- Starts counting again: the end moves forward by the time spent away.
local function resume(row, now)
    local pausedAt = row and tonumber(row.paused_at) or 0
    if pausedAt <= 0 then return end
    now = now or BoFaisaL.now()
    row.end_at = tonumber(row.end_at) + math.max(0, now - pausedAt)
    row.paused_at = 0
    DB.execute("UPDATE bofaisal_police_vacations SET end_at = ?, paused_at = 0 WHERE id = ?", { row.end_at, row.id })
end

function Vacation.load()
    Vacation.active = {}
    local now = BoFaisaL.now()
    for _, row in ipairs(DB.query("SELECT * FROM bofaisal_police_vacations WHERE status = 'active'")) do
        Vacation.active[tonumber(row.user_id)] = row
        -- Nobody is attached yet: every vacation waits for its officer (joining resumes it).
        pause(row, now)
    end
    Vacation.checkReset()
end

-- Every ResetEveryDays days, every officer's balance goes back to DefaultBalance
-- (used or not). The first start only records the date; it does not reset.
function Vacation.checkReset()
    local days = tonumber(cfg().ResetEveryDays) or 0
    if days <= 0 then return end
    local now = BoFaisaL.now()
    local last = tonumber(DB.scalar("SELECT v FROM bofaisal_police_meta WHERE k = 'vacation_reset_at'"))
    if not last then
        DB.execute("INSERT INTO bofaisal_police_meta (k, v) VALUES ('vacation_reset_at', ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", { tostring(now) })
        return
    end
    if now - last < days * 86400 then return end
    DB.execute("UPDATE bofaisal_police_officers SET vacation_balance = ?", { cfg().DefaultBalance or 0 })
    DB.execute("UPDATE bofaisal_police_meta SET v = ? WHERE k = 'vacation_reset_at'", { tostring(now) })
    Logs.add("affairs", "vacation_reset", { fields = { { L("log_field_minutes"), cfg().DefaultBalance or 0 } } })
    for uid in pairs(P.byUser) do BoFaisaL.Officers.pushState(uid) end
end

-- Minutes of balance left right now (while on vacation: the unused part of the reservation).
-- A paused vacation keeps the time it had when it was paused.
function Vacation.remainingMinutes(row)
    if not row then return 0 end
    local pausedAt = tonumber(row.paused_at) or 0
    local at = pausedAt > 0 and pausedAt or BoFaisaL.now()
    return math.max(0, math.floor((tonumber(row.end_at) - at) / 60))
end

-- Uses the WHOLE balance: the vacation lasts until the balance runs out or it is broken.
function Vacation.request(user_id, source, profile)
    if not BoFaisaL.feature("Vacation") then return nil, L("err_feature_disabled") end
    if Vacation.active[user_id] then return nil, L("vacation_already") end
    local original = Gov.militaryGroups(profile.groups or {})
    if #original == 0 then return nil, L("err_not_military") end

    local record = BoFaisaL.Officers.sync(user_id, profile)
    local minutes = record and (tonumber(record.vacation_balance) or 0) or 0
    if minutes < math.max(1, cfg().MinBalance or 1) then
        return nil, L("vacation_no_balance", { balance = minutes })
    end
    local charged = DB.execute(
        "UPDATE bofaisal_police_officers SET vacation_balance = vacation_balance - ? WHERE user_id = ? AND vacation_balance >= ?",
        { minutes, user_id, minutes }
    )
    if charged < 1 then return nil, L("vacation_no_balance", { balance = minutes }) end

    if BoFaisaL.Officers.isOnDuty(user_id) then BoFaisaL.Officers.clockOut(user_id, "vacation") end

    local now = BoFaisaL.now()
    local inactive = cfg().InactiveGroup or ""
    local row = {
        user_id = user_id, days = minutes, start_at = now, end_at = now + minutes * 60,
        original_groups = json.encode(original), inactive_group = inactive, status = "active", restored = 0,
    }
    row.id = DB.insert(
        "INSERT INTO bofaisal_police_vacations (user_id, days, start_at, end_at, original_groups, inactive_group, status) VALUES (?, ?, ?, ?, ?, ?, 'active')",
        { user_id, minutes, row.start_at, row.end_at, row.original_groups, inactive }
    )
    if not row.id then
        DB.execute("UPDATE bofaisal_police_officers SET vacation_balance = vacation_balance + ? WHERE user_id = ?", { minutes, user_id })
        return nil, L("err_internal")
    end

    -- Mark the vacation before changing groups so group listeners know why ranks disappear.
    Vacation.active[user_id] = row
    for _, group in ipairs(original) do F.removeUserGroup(user_id, group) end
    if inactive ~= "" then F.addUserGroup(user_id, inactive) end
    Gov.getProfile(user_id, true)

    Logs.add("affairs", "vacation_start", {
        actor = user_id,
        fields = { { L("log_field_minutes"), minutes }, { L("log_field_groups"), table.concat(original, ", ") } },
    })
    BoFaisaL.Officers.pushState(user_id)
    return row
end

-- Gives back the exact saved groups (player must be online).
function Vacation.restore(user_id, row)
    if row.inactive_group and row.inactive_group ~= "" then F.removeUserGroup(user_id, row.inactive_group) end
    for _, group in ipairs(decode(row.original_groups)) do
        if Gov.ranks[group] then F.addUserGroup(user_id, group) end
    end
    DB.execute("UPDATE bofaisal_police_vacations SET restored = 1 WHERE id = ?", { row.id })
    Gov.getProfile(user_id, true)
end

-- status: "ended" (expired) | "broken" (كسر الإجازة) | "cancelled" (dismissed while on vacation)
function Vacation.finish(user_id, status, byUserId)
    local row = Vacation.active[user_id]
    if not row then return nil, L("vacation_none") end
    Vacation.active[user_id] = nil
    local now = BoFaisaL.now()

    -- Unused minutes go back to the balance (broken early or cancelled by a dismissal).
    local refund = 0
    if status ~= "ended" then refund = Vacation.remainingMinutes(row) end
    DB.execute("UPDATE bofaisal_police_vacations SET status = ?, ended_at = ?, ended_by = ?, restored = ? WHERE id = ?",
        { status, now, DB.id(byUserId), status == "cancelled" and 1 or 0, row.id })
    if refund > 0 then
        DB.execute("UPDATE bofaisal_police_officers SET vacation_balance = LEAST(vacation_balance + ?, ?) WHERE user_id = ?",
            { refund, cfg().MaxBalance or 600, user_id })
    end

    local online = P.isOnline(user_id)
    if status == "cancelled" then
        if row.inactive_group and row.inactive_group ~= "" then BoFaisaL.Officers.setGroup(user_id, row.inactive_group, false) end
    elseif online then
        Vacation.restore(user_id, row)
    end

    Logs.add("affairs", "vacation_" .. status, {
        actor = byUserId, -- nil = ended by itself
        target = byUserId ~= user_id and user_id or nil,
        fields = { { L("log_field_refund"), refund } },
    })
    if online then
        BoFaisaL.notify(P.getSource(user_id), "vacation_finished_" .. status, { refund = refund }, "info")
        BoFaisaL.Officers.pushState(user_id)
    end
    return true
end

-- Joins: finish expired vacations and restore vacations that ended while offline.
BoFaisaL.on("playerReady", function(user_id)
    local row = Vacation.active[user_id]
    if row then resume(row) end -- back in the server: the vacation counts again
    if row and tonumber(row.end_at) <= BoFaisaL.now() then Vacation.finish(user_id, "ended", nil) end
    for _, pending in ipairs(DB.query(
        "SELECT * FROM bofaisal_police_vacations WHERE user_id = ? AND restored = 0 AND status IN ('ended', 'broken')", { user_id })) do
        Vacation.restore(user_id, pending)
        BoFaisaL.notify(P.getSource(user_id), "vacation_restored", nil, "success")
    end
end)

-- Left the server: the time left is frozen until the next join.
BoFaisaL.on("playerDropped", function(user_id)
    pause(Vacation.active[tonumber(user_id)])
end)

-- Script stopped: freeze every running vacation (the next start resumes them on join).
AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    local now = BoFaisaL.now()
    for _, row in pairs(Vacation.active) do pause(row, now) end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait((cfg().CheckInterval or 30) * 1000)
        local now = BoFaisaL.now()
        for uid, row in pairs(Vacation.active) do
            if (tonumber(row.paused_at) or 0) == 0 and tonumber(row.end_at) <= now then Vacation.finish(uid, "ended", nil) end
        end
        pcall(Vacation.checkReset)
    end
end)

---------------------------------------------------------------------------
-- RPC
---------------------------------------------------------------------------
BoFaisaL.RPC.register("vacation:request", { feature = "Vacation", perm = "vacation", cooldown = 3000 }, function(ctx, data)
    local row, err = Vacation.request(ctx.user_id, ctx.source, ctx.profile)
    if not row then return nil, err end
    return { endsAt = row.end_at, minutes = row.days }
end)

BoFaisaL.RPC.register("vacation:break", { feature = "Vacation", military = true, allowVacation = true, cooldown = 3000 }, function(ctx)
    if not Vacation.isOnVacation(ctx.user_id) then return nil, L("vacation_none") end
    local ok, err = Vacation.finish(ctx.user_id, "broken", ctx.user_id)
    if not ok then return nil, err end
    return true
end)
