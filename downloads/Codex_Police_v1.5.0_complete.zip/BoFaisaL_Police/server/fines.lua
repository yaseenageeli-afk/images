--[[
    BoFaisaL_Police — fines (المخالفات)

    A fine is recorded only after the target accepts it (F5). Unpaid fines are paid at a
    payment point (server validates the player's position) or charged immediately (AutoCharge).
]]

local Fines = { lastIssue = {}, paying = {} }
BoFaisaL.Fines = Fines

local DB, P, Gov, Logs, Officers, Confirm, Targets, RPC =
    BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers, BoFaisaL.Confirm, BoFaisaL.Targets, BoFaisaL.RPC
local I = BoFaisaL.Integrations

local function cfg() return Config.Fines or {} end

function Fines.categories()
    local list = {}
    for _, cat in ipairs(cfg().Categories or {}) do
        if cat.enabled ~= false then
            local fines = {}
            for _, f in ipairs(cat.fines or {}) do
                if f.enabled ~= false then fines[#fines + 1] = f end
            end
            if #fines > 0 then list[#list + 1] = { id = cat.id, label = cat.label, fines = fines } end
        end
    end
    return list
end

function Fines.find(categoryId, fineId)
    for _, cat in ipairs(Fines.categories()) do
        if cat.id == categoryId then
            for _, f in ipairs(cat.fines) do
                if f.id == fineId then return cat, f end
            end
        end
    end
    return nil, nil
end

local function officerAllowed(user_id)
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("Fines") or not Gov.has(profile, "fines") then return false, L("err_no_permission") end
    if not Officers.dutyOk(user_id, "fines") then return false, L("err_not_on_duty") end
    return true
end
Fines.officerAllowed = officerAllowed

-- Amount of a fine, never above Config.Fines.MaxAmount (0 = no limit).
function Fines.amountOf(fine)
    local amount = math.max(0, math.floor(tonumber(fine and fine.amount) or 0))
    local max = tonumber(cfg().MaxAmount) or 0
    if max > 0 then amount = math.min(amount, max) end
    return amount
end

-- The officer's share of a fine (Config.Fines.OfficerShare %), paid with the money adapter.
-- when = "issue" (when he writes it) or "paid" (when it is paid); Config.Fines.ShareOn picks one.
function Fines.giveShare(officerId, amount, when)
    local pct = tonumber(cfg().OfficerShare) or 0
    if pct <= 0 or not officerId then return 0 end
    if (cfg().ShareOn or "issue") ~= when then return 0 end
    local share = math.floor((tonumber(amount) or 0) * math.min(pct, 100) / 100)
    if share <= 0 then return 0 end
    I.Money.give(officerId, share)
    local src = P.getSource(officerId)
    if src then BoFaisaL.notify(src, "fine_share", { amount = Utils.money(share), percent = pct }, "success") end
    return share
end

function Fines.issue(officerSrc, categoryId, fineId, targetSrc, targetId)
    local officerId = P.getUserId(officerSrc)
    if not officerId then return end
    local ok, err = officerAllowed(officerId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    local cat, fine = Fines.find(categoryId, fineId)
    if not fine then return BoFaisaL.notify(officerSrc, "err_invalid_request", nil, "error") end
    -- A copy with the capped amount (the config table itself is left as it is).
    fine = setmetatable({ amount = Fines.amountOf(fine) }, { __index = fine })
    if targetId == officerId and not BoFaisaL.Targets.allowSelf() then return BoFaisaL.notify(officerSrc, "target_self", nil, "error") end
    local now = GetGameTimer()
    if Fines.lastIssue[officerId] and now - Fines.lastIssue[officerId] < (cfg().Cooldown or 5) * 1000 then
        return BoFaisaL.notify(officerSrc, "err_cooldown", nil, "error")
    end
    ok, err = Targets.check(officerSrc, targetSrc, targetId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    if BoFaisaL.Immunity.blocks(officerSrc, targetId, "Fine") then return end -- مانع مخالفة
    if BoFaisaL.Immunity.officerProtected(targetId, "Fines", officerId) then return BoFaisaL.notify(officerSrc, "officer_protected_fine", nil, "error") end
    Fines.lastIssue[officerId] = now

    local officerName, targetName = P.name(officerId), P.name(targetId)
    -- "self": the officer confirms (message written for him) | "target": the citizen confirms.
    local selfConfirm = Confirm.mode("fine") == "self"
    if not selfConfirm then BoFaisaL.notify(officerSrc, "confirm_waiting", { name = targetName }, "info") end
    local accepted, reason = Confirm.forAction("fine", officerSrc, targetSrc, {
        title = L("confirm_fine_title"),
        message = selfConfirm and L("confirm_fine_self_msg", { name = targetName, id = targetId })
            or L("confirm_fine_msg", { officer = officerName, officer_id = officerId }),
        details = {
            { L("field_category"), cat.label },
            { L("field_fine"), fine.label },
            { L("field_amount"), "$" .. Utils.money(fine.amount) },
        },
        timeout = cfg().ConfirmTimeout,
        icon = "fine",
    })
    if not accepted then
        BoFaisaL.notify(officerSrc, Confirm.failMessage(reason, selfConfirm), nil, "error")
        if reason == "rejected" then
            Logs.add("fines", "fine_rejected", { actor = officerId, target = targetId, fields = { { L("field_fine"), fine.label } } })
        end
        return
    end

    -- Re-validate after the wait: officer still authorised and target still connected.
    ok, err = officerAllowed(officerId)
    if not ok then return BoFaisaL.notify(officerSrc, err, nil, "error") end
    if P.bySource[targetSrc] ~= targetId then return BoFaisaL.notify(officerSrc, "err_target_offline", nil, "error") end

    local created = BoFaisaL.now()
    local id = DB.insert(
        "INSERT INTO bofaisal_police_fines (target_id, target_name, officer_id, officer_name, category, category_label, fine_id, label, amount, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'unpaid', ?)",
        { targetId, targetName, officerId, officerName, cat.id, cat.label, fine.id, fine.label, fine.amount, created }
    )
    if not id then return BoFaisaL.notify(officerSrc, "err_internal", nil, "error") end
    Officers.increment(officerId, "fines_issued", 1)

    local paid = false
    if cfg().AutoCharge and I.Money.pay(targetId, fine.amount, cfg().PaymentMethod) then
        DB.execute("UPDATE bofaisal_police_fines SET status = 'paid', paid_at = ? WHERE id = ?", { created, id })
        paid = true
    end
    -- Officer's share: now, or (ShareOn = "paid") when the fine is paid — already, with AutoCharge.
    Fines.giveShare(officerId, fine.amount, "issue")
    if paid then Fines.giveShare(officerId, fine.amount, "paid") end

    local vars = { officer = officerName, officer_id = officerId, target = targetName, target_id = targetId, amount = Utils.money(fine.amount), label = fine.label }
    BoFaisaL.notify(officerSrc, "fine_issued_officer", vars, "success")
    if cfg().Receipt ~= false then
        -- The citizen gets a paper receipt (left side, closes with F5) instead of the notice.
        BoFaisaL.infoCard(targetSrc, {
            receipt = true,
            title = L("receipt_title"), file = id,
            stamp = paid and { text = L("receipt_paid"), tone = "ok" } or { text = L("receipt_unpaid"), tone = "bad" },
            rows = {
                { L("receipt_fine"), fine.label },
                { L("receipt_category"), cat.label },
                { L("receipt_officer"), officerName },
                { L("receipt_date"), os.date("%Y/%m/%d %H:%M", created) },
            },
            amount = "$" .. Utils.money(fine.amount),
            note = not paid and L("receipt_where") or nil,
            duration = cfg().ReceiptSeconds or 15,
        })
    else
        BoFaisaL.notify(targetSrc, paid and "fine_issued_target_paid" or "fine_issued_target", vars, "warning", 10)
    end
    I.Chat.announce("Fine", vars, { officerSrc, targetSrc })
    Logs.add("fines", "fine_issue", {
        actor = officerId, target = targetId, actorName = officerName, targetName = targetName,
        fields = {
            { L("field_fine"), fine.label, true },
            { L("field_category"), cat.label, true },
            { L("field_amount"), "$" .. Utils.money(fine.amount), true },
            { L("log_field_fine_id"), "#" .. id, true },
            { L("log_field_status"), paid and L("fine_status_paid") or L("fine_status_unpaid"), true },
        },
    })
end

---------------------------------------------------------------------------
-- Menus
---------------------------------------------------------------------------
-- Menu builders return menu tables; `parent(source)` returns the parent menu table.
function Fines.rootMenu(source, parent)
    local items = {}
    for _, cat in ipairs(Fines.categories()) do
        items[#items + 1] = {
            label = cat.label,
            description = L("fines_count", { count = #cat.fines }),
            action = function(src) BoFaisaL.Menu.open(src, Fines.categoryMenu(src, cat.id, parent)) end,
        }
    end
    return { title = L("menu_fines"), items = items, parent = parent }
end

function Fines.categoryMenu(source, categoryId, parent)
    local items, title = {}, L("menu_fines")
    for _, cat in ipairs(Fines.categories()) do
        if cat.id == categoryId then
            title = cat.label
            for _, fine in ipairs(cat.fines) do
                items[#items + 1] = {
                    label = fine.label,
                    description = L("fine_menu_desc", { amount = Utils.money(Fines.amountOf(fine)) }),
                    action = function(src)
                        local ok, err = officerAllowed(P.getUserId(src))
                        if not ok then return BoFaisaL.notify(src, err, nil, "error") end
                        Targets.nearest(src, function(targetSrc, targetId)
                            Fines.issue(src, cat.id, fine.id, targetSrc, targetId)
                        end)
                    end,
                }
            end
        end
    end
    return { title = title, items = items, parent = function(s) return Fines.rootMenu(s, parent) end }
end

function Fines.openMenu(source, parent)
    local ok, err = officerAllowed(P.getUserId(source))
    if not ok then return BoFaisaL.notify(source, err, nil, "error") end
    BoFaisaL.Menu.open(source, Fines.rootMenu(source, parent))
end

---------------------------------------------------------------------------
-- Inquiry (استعلام عن مخالفات)
---------------------------------------------------------------------------
local function fineItem(f)
    return {
        id = tonumber(f.id), category = f.category_label, label = f.label, amount = tonumber(f.amount),
        officer = { id = tonumber(f.officer_id), name = f.officer_name }, createdAt = tonumber(f.created_at),
        paidAt = tonumber(f.paid_at), status = f.status,
    }
end

function Fines.list(target_id)
    local rows = DB.query(
        "SELECT * FROM bofaisal_police_fines WHERE target_id = ? ORDER BY (status = 'unpaid') DESC, id DESC LIMIT " .. (cfg().InquiryLimit or 50),
        { target_id }
    )
    local list, unpaidTotal, unpaidCount = {}, 0, 0
    for _, f in ipairs(rows) do
        local unpaid = f.status == "unpaid"
        if unpaid then
            unpaidTotal = unpaidTotal + (tonumber(f.amount) or 0)
            unpaidCount = unpaidCount + 1
        end
        list[#list + 1] = fineItem(f)
    end
    return { list = list, unpaidTotal = unpaidTotal, unpaidCount = unpaidCount }
end

function Fines.inquiryFlow(source)
    local user_id = P.getUserId(source)
    if not user_id then return end
    local function allowed()
        return BoFaisaL.feature("Fines") and BoFaisaL.feature("Inquiries") and Gov.has(Gov.getProfile(user_id, true), "fineInquiry")
    end
    if not allowed() then return BoFaisaL.notify(source, "err_no_permission", nil, "error") end
    if not Officers.dutyOk(user_id, "inquiries") then return BoFaisaL.notify(source, "err_not_on_duty", nil, "error") end
    local values = I.Popup.input(source, L("fine_inquiry_title"), {
        { key = "id", label = L("field_citizen_id"), type = "number" },
    })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    if not allowed() then return BoFaisaL.notify(source, "err_no_permission", nil, "error") end
    if not P.exists(values.id) then return BoFaisaL.notify(source, "err_unknown_id", nil, "error") end
    local data = Fines.list(values.id)
    local lines = {}
    for _, f in ipairs(data.list) do
        if f.status == "unpaid" and #lines < 3 then lines[#lines + 1] = ("%s — $%s"):format(f.label, Utils.money(f.amount)) end
    end
    BoFaisaL.infoCard(source, {
        title = L("fine_inquiry_title"),
        file = values.id,
        rows = {
            { L("card_name"), P.name(values.id) },
            { L("card_id"), values.id },
            { L("card_unpaid_count"), data.unpaidCount },
            { L("card_unpaid_total"), "$" .. Utils.money(data.unpaidTotal) },
        },
        lines = lines,
    })
    Logs.add("fines", "fine_inquiry", { actor = user_id, target = values.id })
end

---------------------------------------------------------------------------
-- Payment points
---------------------------------------------------------------------------
function Fines.nearPoint(source)
    local coords = P.coords(source)
    if not coords then return nil end
    for _, point in ipairs(cfg().PaymentPoints or {}) do
        if Utils.dist(coords, point.coords) <= (point.radius or 1.5) + 2.0 then return point end
    end
    return nil
end

-- Unpaid fines of a player: { list, total, count } (no distance check).
-- Reads the unpaid rows only (idx_target_status), never the paid history.
function Fines.payView(user_id)
    local rows = DB.query(
        "SELECT * FROM bofaisal_police_fines WHERE target_id = ? AND status = 'unpaid' ORDER BY id DESC LIMIT " .. (cfg().InquiryLimit or 50),
        { user_id }
    )
    local list, total = {}, 0
    for _, f in ipairs(rows) do
        total = total + (tonumber(f.amount) or 0)
        list[#list + 1] = fineItem(f)
    end
    return { list = list, total = total, count = #list, wallet = BoFaisaL.Framework.getMoney(user_id), bank = BoFaisaL.Framework.getBankMoney(user_id) }
end

function Fines.openPayment(source, user_id)
    if not Fines.nearPoint(source) then return nil, L("fine_point_far") end
    return Fines.payView(user_id)
end

-- Pays unpaid fines: all = true, or the given ids. Must stand at a payment point.
-- user_id pays; targetId = whose fines (another player, "تسديد مخالفات الآخرين"), default user_id.
-- Returns the refreshed payment view (of targetId), or nil + error.
-- remote = true: from منصة أبشر (allowed anywhere when Config.Absher.RemotePay).
function Fines.pay(source, user_id, all, idList, targetId, remote)
    local fromPhone = remote == true and BoFaisaL.Absher and BoFaisaL.Absher.remotePay()
    if not fromPhone and not Fines.nearPoint(source) then return nil, L("fine_point_far") end
    targetId = tonumber(targetId) or user_id
    if Fines.paying[targetId] then return nil, L("err_cooldown") end
    Fines.paying[targetId] = true
    local ctx = { source = source, user_id = targetId, payer = user_id }
    local data = { all = all, ids = idList }
    local ok, result, err = pcall(function()
        local ids = {}
        if data.all == true then
            for _, row in ipairs(DB.query("SELECT id FROM bofaisal_police_fines WHERE target_id = ? AND status = 'unpaid'", { ctx.user_id })) do
                ids[#ids + 1] = tonumber(row.id)
            end
        elseif type(data.ids) == "table" then
            for i = 1, math.min(#data.ids, 100) do
                local id = Utils.toInt(data.ids[i])
                if id then ids[#ids + 1] = id end
            end
        end
        if #ids == 0 then return nil, L("fine_none_selected") end
        local marks = string.rep("?, ", #ids):sub(1, -3)
        local params = { ctx.user_id }
        for _, id in ipairs(ids) do params[#params + 1] = id end
        local rows = DB.query("SELECT id, amount, officer_id FROM bofaisal_police_fines WHERE target_id = ? AND status = 'unpaid' AND id IN (" .. marks .. ")", params)
        if #rows == 0 then return nil, L("fine_none_selected") end
        local total, payIds = 0, {}
        for _, r in ipairs(rows) do
            total = total + (tonumber(r.amount) or 0)
            payIds[#payIds + 1] = tonumber(r.id)
        end
        if not I.Money.pay(ctx.payer, total, cfg().PaymentMethod) then return nil, L("fine_no_money", { amount = Utils.money(total) }) end
        local marks2 = string.rep("?, ", #payIds):sub(1, -3)
        local params2 = { BoFaisaL.now(), ctx.user_id }
        for _, id in ipairs(payIds) do params2[#params2 + 1] = id end
        DB.execute("UPDATE bofaisal_police_fines SET status = 'paid', paid_at = ? WHERE target_id = ? AND status = 'unpaid' AND id IN (" .. marks2 .. ")", params2)
        -- ShareOn = "paid": each officer gets his share of the fines he wrote.
        for _, r in ipairs(rows) do Fines.giveShare(tonumber(r.officer_id), tonumber(r.amount), "paid") end
        Logs.add("fines", "fine_paid", { actor = ctx.payer, target = ctx.payer ~= ctx.user_id and ctx.user_id or nil, fields = {
            { L("field_amount"), "$" .. Utils.money(total), true }, { L("log_field_count"), #payIds, true },
        } })
        local vars = { amount = Utils.money(total), count = #payIds }
        if ctx.payer == ctx.user_id then
            BoFaisaL.notify(ctx.source, "fine_paid", vars, "success")
        else
            vars.name = P.name(ctx.user_id)
            BoFaisaL.notify(ctx.source, "fine_paid_for", vars, "success")
            local targetSrc = P.getSource(ctx.user_id)
            if targetSrc then BoFaisaL.notify(targetSrc, "fine_paid_by_other", { name = P.name(ctx.payer), amount = vars.amount, count = vars.count }, "success", 10) end
        end
        return Fines.payView(ctx.user_id)
    end)
    Fines.paying[targetId] = nil
    if not ok then
        BoFaisaL.error("fines:pay failed: %s", tostring(result))
        return nil, L("err_internal")
    end
    return result, err
end

RPC.register("fines:pay", { feature = "Fines", cooldown = 1500 }, function(ctx, data)
    return Fines.pay(ctx.source, ctx.user_id, data.all == true, data.ids, nil, data.remote == true)
end)

RPC.register("fines:open", { feature = "Fines", cooldown = 1000 }, function(ctx)
    local data, err = Fines.openPayment(ctx.source, ctx.user_id)
    if not data then return nil, err end
    return data
end)

-- The fine cooldown of an officer who left is forgotten (the table never grows with every officer ever seen).
BoFaisaL.on("playerDropped", function(user_id) Fines.lastIssue[user_id] = nil end)
