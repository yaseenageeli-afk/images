--[[
    BoFaisaL_Police — show the badge (إظهار الشارة)

    The officer plays the badge animation (the badge in his hand) and the players in front of him
    see his card for a few seconds: name, rank, sector, ministry, badge number, character photo.
    Texts and fields come from Config.Badge.
]]

local Badge = { last = {} } -- [user_id] = game timer of the last show (cooldown)
BoFaisaL.Badge = Badge

local P, Gov, Officers = BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Officers

local function cfg() return Config.Badge or {} end

-- What the card shows (the ministry follows the officer's rank).
function Badge.data(user_id, profile)
    local d = profile.primary and Gov.describeRank(profile.primary) or {}
    local record = Officers.get(user_id) or {}
    return {
        user_id = user_id,
        number = user_id,
        name = P.name(user_id),
        rank = d.label or "",
        sector = (d.sectorLabel and d.sectorLabel ~= "") and d.sectorLabel or "",
        ministry = d.ministryLabel or "",
        country = cfg().Country or "",
        title = cfg().Title or "",
        issued = tonumber(record.created_at) or BoFaisaL.now(),
        mugshotAt = BoFaisaL.Mugshots and BoFaisaL.Mugshots.stamp(user_id) or nil,
        fields = cfg().Fields or {},
        seconds = cfg().Seconds or 8,
    }
end

function Badge.show(source)
    local user_id = P.getUserId(source)
    if not user_id then return end
    if not BoFaisaL.feature("Badge") then return BoFaisaL.notify(source, "err_feature_disabled", nil, "error") end
    local profile = Gov.getProfile(user_id, true)
    if not profile.isMilitary or not Gov.has(profile, "badge") then return BoFaisaL.notify(source, "err_no_permission", nil, "error") end
    if cfg().RequireDuty and not Officers.isOnDuty(user_id) then return BoFaisaL.notify(source, "err_not_on_duty", nil, "error") end
    local now = GetGameTimer()
    if Badge.last[user_id] and now - Badge.last[user_id] < (cfg().Cooldown or 5) * 1000 then
        return BoFaisaL.notify(source, "err_cooldown", nil, "error")
    end
    Badge.last[user_id] = now

    local data = Badge.data(user_id, profile)
    TriggerClientEvent("bofaisal_police:badge:anim", source)
    local nearby = P.nearby(source, cfg().Distance or 3.0)
    -- Config.Badge.NearestOnly: only the closest player sees it (the list is closest first).
    if cfg().NearestOnly and #nearby > 1 then nearby = { nearby[1] } end
    for _, p in ipairs(nearby) do BoFaisaL.ui(p.source, "badge", data) end
    if cfg().ShowSelf ~= false then BoFaisaL.ui(source, "badge", data) end
    if #nearby > 0 then
        BoFaisaL.notify(source, "badge_shown", { count = #nearby }, "success")
    else
        BoFaisaL.notify(source, "badge_nobody", nil, "info")
    end
end

BoFaisaL.on("playerDropped", function(user_id) Badge.last[user_id] = nil end)
