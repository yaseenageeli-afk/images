--[[
    BoFaisaL_Police — citizen inquiry (استعلام عن مواطن)

    Shows the FiveM name, vRP id, job, profile image, fines and wanted status. Character names
    are never used.
]]

local Citizens = {}
BoFaisaL.Citizens = Citizens

local DB, P, Gov, Logs, Officers = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers

function Citizens.card(target_id)
    local last = (Config.CitizenInquiry and tonumber(Config.CitizenInquiry.History)) or 3
    local recent = DB.query(
        "SELECT id, category_label, label, amount, officer_name, officer_id, created_at, status FROM bofaisal_police_fines WHERE target_id = ? ORDER BY id DESC LIMIT " .. last,
        { target_id }
    )
    local totalRow = DB.single("SELECT COUNT(*) AS c, COALESCE(SUM(amount), 0) AS s FROM bofaisal_police_fines WHERE target_id = ? AND status = 'unpaid'", { target_id })
    local wanted = BoFaisaL.Wanted.getActive(target_id)
    local jail = BoFaisaL.Jail and BoFaisaL.Jail.status(target_id)
    local fines = {}
    for _, f in ipairs(recent) do
        fines[#fines + 1] = {
            id = tonumber(f.id), category = f.category_label, label = f.label, amount = tonumber(f.amount), status = f.status,
            officer = { id = tonumber(f.officer_id), name = f.officer_name }, createdAt = tonumber(f.created_at),
        }
    end
    -- Last sentences: the current one (if any) first, then the finished ones.
    local jails = {}
    if jail and jail.jailed then
        jails[#jails + 1] = { reason = jail.reason, seconds = jail.total, officer = jail.officer and jail.officer.name or "", startedAt = jail.startedAt, current = true }
    end
    for _, j in ipairs(DB.query(
        "SELECT reason_label, total_seconds, officer_name, started_at FROM bofaisal_police_jail_history WHERE user_id = ? ORDER BY started_at DESC LIMIT " .. last,
        { target_id })) do
        if #jails < last then
            jails[#jails + 1] = { reason = j.reason_label, seconds = tonumber(j.total_seconds), officer = j.officer_name, startedAt = tonumber(j.started_at) }
        end
    end
    return {
        user_id = target_id,
        name = P.name(target_id),
        online = P.isOnline(target_id),
        job = BoFaisaL.Integrations.Job.get(target_id),
        avatar = BoFaisaL.Integrations.ProfileImage.fast(target_id),
        fines = {
            count = tonumber(totalRow and totalRow.c) or 0,
            total = tonumber(totalRow and totalRow.s) or 0,
            list = fines,
        },
        wanted = wanted and {
            active = true, reason = wanted.reason, by = wanted.created_by_name, byId = tonumber(wanted.created_by_id),
            createdAt = tonumber(wanted.created_at),
        } or { active = false },
        jailed = jail and jail.jailed or false,
        jails = jails,
    }
end

-- Builder Menu flow: "استعلام عن مواطن"
function Citizens.inquiryFlow(source)
    local user_id = P.getUserId(source)
    if not user_id then return end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("CitizenInquiry") or not Gov.has(profile, "citizenInquiry") then
        return BoFaisaL.notify(source, "err_no_permission", nil, "error")
    end
    if not Officers.dutyOk(user_id, "citizenInquiry") then return BoFaisaL.notify(source, "err_not_on_duty", nil, "error") end
    local values = BoFaisaL.Integrations.Popup.input(source, L("citizen_inquiry_title"), {
        { key = "id", label = L("field_citizen_id"), type = "number" },
    })
    if not values then return BoFaisaL.notify(source, "action_cancelled", nil, "info") end
    -- The input can stay open for minutes: re-check against live groups.
    if not Gov.has(Gov.getProfile(user_id, true), "citizenInquiry") then return BoFaisaL.notify(source, "err_no_permission", nil, "error") end
    if not P.exists(values.id) then return BoFaisaL.notify(source, "err_unknown_id", nil, "error") end
    if not P.isOnline(values.id) then return BoFaisaL.notify(source, "citizen_offline", nil, "info") end
    local card = Citizens.card(values.id)
    -- Shown as an info card (left side), like the other inquiries.
    -- Records as fields { reason, amount / length, date } so the police file lines them up.
    local function when(ts) return ts and ts > 0 and os.date("%m/%d %H:%M", ts) or "-" end
    local fineRecords, jailRecords = {}, {}
    for _, f in ipairs(card.fines.list) do
        fineRecords[#fineRecords + 1] = { f.label, "$" .. Utils.money(f.amount), when(f.createdAt) }
    end
    for _, j in ipairs(card.jails) do
        jailRecords[#jailRecords + 1] = {
            (j.reason or "-") .. (j.current and (" (" .. L("card_jailed_now") .. ")") or ""),
            L("minutes_value", { minutes = math.floor((j.seconds or 0) / 60) }), when(j.startedAt),
        }
    end
    -- Stamp on the file: wanted / jailed in red, otherwise clean in green.
    local stamp = card.wanted.active and { text = L("card_stamp_wanted"), tone = "bad" }
        or card.jailed and { text = L("card_stamp_jailed"), tone = "bad" }
        or { text = L("card_stamp_clean"), tone = "ok" }
    local rows = {
        { L("card_name"), card.name },
        { L("card_id"), card.user_id },
        { L("card_job"), card.job or "-" },
        { L("card_status"), card.online and L("online") or L("offline"), card.online and "ok" or nil },
        { L("card_wanted"), card.wanted.active and L("yes") or L("no"), card.wanted.active and "bad" or nil },
        { L("card_jailed"), card.jailed and L("yes") or L("no"), card.jailed and "bad" or nil },
        { L("card_unpaid_count"), card.fines.count, card.fines.count > 0 and "bad" or nil },
        { L("card_unpaid_total"), "$" .. Utils.money(card.fines.total), card.fines.total > 0 and "bad" or nil },
    }
    if card.wanted.active and card.wanted.reason and card.wanted.reason ~= "" then
        rows[#rows + 1] = { L("card_wanted_reason"), card.wanted.reason, "bad" }
    end
    BoFaisaL.infoCard(source, {
        title = L("citizen_inquiry_title"),
        fileTitle = L("card_file_title"),
        file = card.user_id,
        stamp = stamp,
        rows = rows,
        sections = {
            { title = L("card_last_fines"), records = fineRecords, empty = L("card_none") },
            { title = L("card_last_jails"), records = jailRecords, empty = L("card_none") },
        },
        duration = (Config.UI and Config.UI.CitizenCardSeconds) or 20,
    })
    Logs.add("field", "citizen_inquiry", { actor = user_id, target = values.id })
end
