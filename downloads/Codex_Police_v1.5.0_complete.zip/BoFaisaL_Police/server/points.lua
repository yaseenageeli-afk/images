--[[
    BoFaisaL_Police — menus of the fine payment points and impound centres

    Like the classic vRP areas: stepping on a point opens its own Builder Menu, stepping off
    closes it (the client only reports enter / leave, the server checks the distance).
        سداد المخالفات : عرض المخالفات · سداد المخالفات
        حجز المركبات   : عرض المركبات المحجوزة · فك الحجز (pay → the vehicle appears with you inside)
]]

local Points = { open = {} } -- [source] = "fines" | "impound"
BoFaisaL.Points = Points

local P, RPC = BoFaisaL.Players, BoFaisaL.RPC

local finesMenu

-- Fines of another player (by ID): pay all of them, or one by one, with the payer's money.
local function othersFinesMenu(source, targetId, back, quiet)
    local data = BoFaisaL.Fines.list(targetId)
    local unpaid = {}
    for _, f in ipairs(data.list) do if f.status == "unpaid" then unpaid[#unpaid + 1] = f end end
    if #unpaid == 0 then
        if not quiet then BoFaisaL.notify(source, "point_fines_others_none", { name = P.name(targetId) }, "info") end
        return nil
    end
    local function pay(src, all, ids)
        local _, err = BoFaisaL.Fines.pay(src, P.getUserId(src), all, ids, targetId)
        if err then return BoFaisaL.notify(src, err, nil, "error") end
        if Points.open[src] ~= "fines" then return end
        local m = othersFinesMenu(src, targetId, back, true) -- all paid: straight back, no notice
        if m then BoFaisaL.Menu.open(src, m) else local again = BoFaisaL.Fines.nearPoint(src) if again then BoFaisaL.Menu.open(src, finesMenu(src, again)) end end
    end
    local items = {
        {
            label = L("point_fines_others_all"), description = L("point_fines_pay_desc", { amount = Utils.money(data.unpaidTotal or 0), count = #unpaid }),
            action = function(src) pay(src, true) end,
        },
    }
    for _, f in ipairs(unpaid) do
        items[#items + 1] = {
            label = ("%s — $%s"):format(f.label, Utils.money(f.amount)), description = f.category or "",
            action = function(src) pay(src, false, { f.id }) end,
        }
    end
    return { title = ("%s | %s %d"):format(P.name(targetId), L("id_label"), targetId), items = items, parent = back }
end

-- سداد المخالفات: تسديد المخالفات · فك حجز المركبات · تسديد مخالفات الآخرين · كفالة المساجين
function finesMenu(source, point)
    local user_id = P.getUserId(source)
    local view = BoFaisaL.Fines.openPayment(source, user_id) or { list = {}, total = 0, count = 0 }
    local back = function(s) local again = BoFaisaL.Fines.nearPoint(s) return again and finesMenu(s, again) or { title = "", items = {} } end
    local items = {}

    -- Own fines: the payment window (pick some, or pay all).
    items[#items + 1] = {
        label = L("point_fines_pay_own"),
        description = (view.count or 0) > 0 and L("point_fines_pay_desc", { amount = Utils.money(view.total or 0), count = view.count }) or L("point_fines_none"),
        action = function(src)
            local uid = P.getUserId(src)
            local data = BoFaisaL.Fines.openPayment(src, uid)
            if not data or (data.count or 0) == 0 then return BoFaisaL.notify(src, "point_fines_none", nil, "info") end
            BoFaisaL.ui(src, "panel", { kind = "finePay", title = L("point_fines_pay_own"), data = data })
        end,
    }

    -- Impounded vehicles of the player: pay the fee here, then take it out of the garage.
    if BoFaisaL.feature("Impound") then
        local vehicles = BoFaisaL.Impound.ownerView(user_id).list
        items[#items + 1] = {
            label = L("point_impound_release_vehicles"),
            description = #vehicles > 0 and L("point_impound_view_desc", { count = #vehicles }) or L("point_impound_none"),
            action = function(src)
                local list = BoFaisaL.Impound.ownerView(P.getUserId(src)).list
                if #list == 0 then return BoFaisaL.notify(src, "point_impound_none", nil, "info") end
                BoFaisaL.ui(src, "panel", { kind = "impoundPay", title = L("point_impound_release_vehicles"), data = { list = list } })
            end,
        }
    end

    -- Someone else's fines (by ID).
    items[#items + 1] = {
        label = L("point_fines_others"), description = L("point_fines_others_desc"),
        action = function(src)
            local values = BoFaisaL.Integrations.Popup.input(src, L("point_fines_others"), {
                { key = "id", label = L("field_citizen_id"), type = "number" },
            })
            if not values then return end
            if not P.exists(values.id) then return BoFaisaL.notify(src, "err_unknown_id", nil, "error") end
            if values.id == P.getUserId(src) and not BoFaisaL.allowSelf() then return BoFaisaL.notify(src, "point_fines_others_self", nil, "info") end
            local m = othersFinesMenu(src, values.id, back)
            if m then BoFaisaL.Menu.open(src, m) end
        end,
    }

    -- Bail: release a prisoner by paying for the time left.
    if BoFaisaL.feature("Jail") and Config.Jail and Config.Jail.Bail and Config.Jail.Bail.Enabled ~= false then
        items[#items + 1] = {
            label = L("point_bail"), description = L("point_bail_desc"),
            action = function(src)
                local m = BoFaisaL.Jail.bailMenu(src, back)
                if m then BoFaisaL.Menu.open(src, m) end
            end,
        }
    end
    return { title = point.label ~= "" and point.label or L("point_fines_title"), items = items }
end

local function impoundMenu(source, loc)
    local user_id = P.getUserId(source)
    local list = BoFaisaL.Impound.ownerView(user_id).list
    local function back(s) local l = BoFaisaL.Impound.nearCentre(s) return l and impoundMenu(s, l) or { title = "", items = {} } end
    local items = {
        {
            label = L("point_impound_view"), description = L("point_impound_view_desc", { count = #list }),
            action = function(src)
                local uid = P.getUserId(src)
                BoFaisaL.ui(src, "panel", { kind = "impoundPay", title = L("point_impound_view"),
                    data = { list = BoFaisaL.Impound.ownerView(uid).list, readonly = true } })
            end,
        },
    }
    if #list > 0 then
        items[#items + 1] = {
            label = L("point_impound_release"), description = L("point_impound_release_desc"),
            action = function(src)
                -- Pays and releases from the window: the owner takes the vehicle out of his garage.
                BoFaisaL.ui(src, "panel", { kind = "impoundPay", title = L("point_impound_release"),
                    data = { list = BoFaisaL.Impound.ownerView(P.getUserId(src)).list } })
            end,
        }
    end
    return { title = loc.label ~= "" and loc.label or L("point_impound_title"), items = items }
end

-- The client says it stepped on a point: open that point's menu (distance checked here).
RPC.register("points:enter", { cooldown = 700 }, function(ctx, data)
    local kind = data.kind
    if kind == "fines" and BoFaisaL.feature("Fines") then
        local point = BoFaisaL.Fines.nearPoint(ctx.source)
        if not point then return nil, L("fine_point_far") end
        Points.open[ctx.source] = "fines"
        BoFaisaL.Menu.open(ctx.source, finesMenu(ctx.source, point))
        return true
    elseif kind == "impound" and BoFaisaL.feature("Impound") then
        local loc = BoFaisaL.Impound.nearCentre(ctx.source)
        if not loc then return nil, L("impound_centre_far") end
        Points.open[ctx.source] = "impound"
        BoFaisaL.Menu.open(ctx.source, impoundMenu(ctx.source, loc))
        return true
    end
    return nil, L("err_invalid_request")
end)

-- Stepped off: close the menu this point opened.
RPC.register("points:leave", {}, function(ctx)
    if Points.open[ctx.source] then
        Points.open[ctx.source] = nil
        BoFaisaL.Menu.close(ctx.source)
    end
    return true
end)

BoFaisaL.on("playerDropped", function(_, source) if source then Points.open[source] = nil end end)
