-- BoFaisaL dashboard extension. Base attribution: see NOTICE.md.
local Absher = {}
BoFaisaL.Absher = Absher
local RPC, DB, P, FW = BoFaisaL.RPC, BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Framework
local function cfg() return Config.Absher or {} end
function Absher.title() return cfg().Title or "أبشر" end
function Absher.remotePay() return BoFaisaL.feature("Absher") and cfg().RemotePay ~= false end
function Absher.remoteRelease() return BoFaisaL.feature("Absher") and cfg().RemoteRelease ~= false end
function Absher.summary(uid)
    local f = DB.single("SELECT COUNT(*) AS count, COALESCE(SUM(amount),0) AS total FROM bofaisal_police_fines WHERE target_id = ? AND status = 'unpaid'", {uid}) or {}
    local vehicles = BoFaisaL.feature("Impound") and BoFaisaL.Impound.ownerView(uid).list or {}
    local wanted = BoFaisaL.feature("Wanted") and BoFaisaL.Wanted.getActive(uid) or nil
    local jail = BoFaisaL.feature("Jail") and BoFaisaL.Jail.status(uid) or nil
    return { name = P.name(uid), user_id = uid, wallet = FW.getMoney(uid), bank = FW.getBankMoney(uid),
        finesCount = tonumber(f.count) or 0, finesTotal = tonumber(f.total) or 0,
        vehiclesCount = #vehicles, wanted = wanted ~= nil,
        jailed = jail ~= nil and jail.jailed == true,
        fines = BoFaisaL.feature("Fines"), impound = BoFaisaL.feature("Impound") }
end
function Absher.open(source)
    if not BoFaisaL.feature("Absher") then return BoFaisaL.notify(source,"err_feature_disabled",nil,"error") end
    local uid = P.getUserId(source)
    if not uid then return end
    BoFaisaL.ui(source,"panel",{kind="absher",phone=true,title=Absher.title(),data=Absher.summary(uid)})
end
RPC.register("absher:view", {feature="Absher",cooldown=400}, function(ctx,data)
    if data.view == "profile" then return {kind="absher",data=Absher.summary(ctx.user_id)} end
    if data.view == "fines" or data.view == "finesPay" then
        if not BoFaisaL.feature("Fines") then return nil,L("err_feature_disabled") end
        local d = BoFaisaL.Fines.payView(ctx.user_id)
        d.remote=true; d.readonly=data.view=="fines" or not Absher.remotePay()
        if not Absher.remotePay() then d.note=L("absher_pay_at_point") end
        return {kind="finePay",data=d}
    end
    if data.view == "impound" or data.view == "impoundPay" then
        if not BoFaisaL.feature("Impound") then return nil,L("err_feature_disabled") end
        local d={list=BoFaisaL.Impound.ownerView(ctx.user_id).list,remote=true,readonly=data.view=="impound" or not Absher.remoteRelease()}
        if not Absher.remoteRelease() then d.note=L("absher_release_at_centre") end
        return {kind="impoundPay",data=d}
    end
    return nil,L("err_invalid_request")
end)
