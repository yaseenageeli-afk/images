--[[
    BoFaisaL_Police — iPad (القائمة العسكرية): bootstrap, مكتبي and المتصلين.
]]

local Ipad = {}
BoFaisaL.Ipad = Ipad

local P, Gov, Officers, Vacation, RPC = BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Officers, BoFaisaL.Vacation, BoFaisaL.RPC

function Ipad.canOpen(user_id, profile)
    if not BoFaisaL.feature("Ipad") then return false end
    if Vacation.isOnVacation(user_id) then return true end
    return profile.isMilitary and Gov.has(profile, "ipad")
end

function Ipad.office(user_id)
    local record = Officers.get(user_id) or {}
    local session = Officers.sessionSeconds(user_id)
    local vac = Vacation.get(user_id)
    return {
        finesIssued = tonumber(record.fines_issued) or 0,
        jailsIssued = tonumber(record.jails_issued) or 0,
        reportsHandled = tonumber(record.reports_handled) or 0,
        impoundsIssued = tonumber(record.impounds_issued) or 0,
        session = session,
        attendance = (tonumber(record.attendance_total) or 0) + session,
        onDuty = Officers.isOnDuty(user_id),
        code = Officers.codeOf(user_id, record),
        vacationBalance = tonumber(record.vacation_balance) or 0,
        vacation = vac and { active = true, endsAt = BoFaisaL.Vacation.endsAt(vac), startedAt = tonumber(vac.start_at), minutes = tonumber(vac.days) } or { active = false },
        lastClockIn = tonumber(record.last_clock_in) or 0,
        lastClockOut = tonumber(record.last_clock_out) or 0,
        standing = BoFaisaL.Stats and BoFaisaL.Stats.standing(user_id) or nil, -- نقاطي وترتيبي
    }
end

-- Opens the iPad for a player (server decides; the client only renders).
function Ipad.open(source, tab)
    local user_id = P.getUserId(source)
    if not user_id then return end
    local profile = Gov.getProfile(user_id, true)
    if not Ipad.canOpen(user_id, profile) then
        BoFaisaL.notify(source, "err_no_permission", nil, "error")
        return
    end
    TriggerClientEvent("bofaisal_police:ipad:open", source, tab or "office")
end

RPC.register("ipad:bootstrap", { feature = "Ipad", military = true, allowVacation = true }, function(ctx)
    if not Ipad.canOpen(ctx.user_id, ctx.profile) then return nil, L("err_no_permission") end
    local summary = Gov.summary(ctx.profile)
    local onVacation = Vacation.isOnVacation(ctx.user_id)
    local perms = {}
    if not onVacation then
        for _, p in ipairs(summary.permissions) do perms[p] = true end
    end
    return {
        me = {
            user_id = ctx.user_id,
            name = ctx.name,
            avatar = BoFaisaL.Integrations.ProfileImage.fast(ctx.user_id),
            rank = summary.rank,
            sectorLabel = summary.sectorLabel,
            ministryLabel = summary.ministryLabel,
            military = summary.military,
            vacation = onVacation,
        },
        perms = perms,
        features = {
            clock = BoFaisaL.feature("Clock"),
            reports = BoFaisaL.feature("Reports") and BoFaisaL.feature("CitizenReport"),
            wanted = BoFaisaL.feature("Wanted"),
            affairs = BoFaisaL.feature("Affairs") and perms.affairs == true,
            roster = BoFaisaL.feature("Roster"),
            vacation = BoFaisaL.feature("Vacation"),
        },
        office = Ipad.office(ctx.user_id),
        codeMax = (Config.MilitaryCode and Config.MilitaryCode.MaxLength) or 12,
        codeLinked = BoFaisaL.Roster.linked(), -- الكود من الجدول العسكري: ما يتعدل من مكتبي
        protocolsImage = (Config.Ipad and Config.Ipad.ProtocolsImage) or "assets/protocols.png",
        panelAdmin = BoFaisaL.Panel and BoFaisaL.Panel.canEdit(ctx.user_id) or false,
        now = BoFaisaL.now(),
    }
end)

RPC.register("ipad:office", { feature = "Ipad", military = true, allowVacation = true }, function(ctx)
    if not Ipad.canOpen(ctx.user_id, ctx.profile) then return nil, L("err_no_permission") end
    if not Vacation.isOnVacation(ctx.user_id) and not Gov.has(ctx.profile, "office") then return nil, L("err_no_permission") end
    local office = Ipad.office(ctx.user_id)
    office.now = BoFaisaL.now()
    return office
end)

RPC.register("ipad:online", { feature = "Ipad", perm = "online" }, function()
    return { list = Officers.onlineList(), now = BoFaisaL.now() }
end)

RPC.register("office:clock", { feature = "Clock", perm = "clock", cooldown = 2000 }, function(ctx)
    if Officers.isOnDuty(ctx.user_id) then
        local duration = Officers.clockOut(ctx.user_id, "manual")
        return { onDuty = false, duration = duration }
    end
    local ok, err = Officers.clockIn(ctx.user_id, ctx.source, ctx.profile)
    if not ok then return nil, err end
    return { onDuty = true }
end)

RPC.register("office:setCode", { feature = "Ipad", perm = "militaryCode", cooldown = 2000 }, function(ctx, data)
    if type(data.code) ~= "string" then return nil, L("err_invalid_request") end
    if BoFaisaL.Roster.linked() then return nil, L("err_code_linked") end
    Officers.sync(ctx.user_id, ctx.profile)
    local code = Officers.setCode(ctx.user_id, ctx.source, data.code)
    return { code = code }
end)

-- Toggle from the Builder Menu entry "تسجيل الدخول / تسجيل الخروج".
function Ipad.toggleDuty(source)
    local user_id = P.getUserId(source)
    if not user_id then return end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("Clock") or not Gov.has(profile, "clock") then
        return BoFaisaL.notify(source, "err_no_permission", nil, "error")
    end
    if Officers.isOnDuty(user_id) then
        local duration = Officers.clockOut(user_id, "manual")
        BoFaisaL.notify(source, "duty_out", { duration = Utils.humanDuration(duration or 0) }, "info")
    else
        local ok, err = Officers.clockIn(user_id, source, profile)
        if ok then BoFaisaL.notify(source, "duty_in", nil, "success") else BoFaisaL.notify(source, err, nil, "error") end
    end
    -- Re-open the police menu: full menu after clocking in, clock-in only after clocking out.
    BoFaisaL.Menu.open(source, BoFaisaL.PoliceMenu.build(source))
end
