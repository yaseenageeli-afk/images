--[[
    BoFaisaL_Police — logging (database + Discord webhooks). Server only.

    Logs.add(category, action, {
        actor = user_id, target = user_id,          -- names are resolved as FiveM names
        fields = { { "label", "value" }, ... },
        description = "...",
    })
]]

local Logs = {}
BoFaisaL.Logs = Logs

local COLORS = {
    general = 0x8B5CF6, recruitment = 0x22C55E, affairs = 0x8B5CF6, attendance = 0x38BDF8,
    reports = 0xF59E0B, wanted = 0xEF4444, fines = 0xF97316, jail = 0xA855F7, impound = 0x3B82F6,
    field = 0x14B8A6, security = 0xDC2626, statistics = 0xEAB308,
}

-- One queue per webhook URL (each URL has its own Discord rate limit), and up to 10 log entries
-- in one message: a busy server never waits behind another category or drops its logs.
local MAX_QUEUE = 250       -- entries waiting per URL (the oldest goes when full)
local MAX_BATCH = 10        -- embeds in one message (Discord limit)
local MAX_CHARS = 5800      -- characters of every embed of one message together (Discord limit 6000)
local GAP = 600             -- ms between two messages to the same URL (Discord allows 5 every 2 s)
local queues = {}           -- [url] = { items = {}, pumping = false }

local function clip(s, n)
    s = tostring(s or "")
    if Utils.utf8len(s) > n then return Utils.utf8sub(s, 1, n - 1) .. "…" end
    return s
end

-- Player supplied text must never ping or format in Discord.
local function discordSafe(s)
    s = tostring(s or "")
    if Config.Webhooks and Config.Webhooks.mentionless ~= false then
        s = s:gsub("@", "@\u{200B}")
    end
    s = s:gsub("`", "'")
    return s
end
Logs.discordSafe = discordSafe

local function urlFor(category)
    local hooks = Config.Webhooks
    if not hooks or hooks.enabled == false then return nil end
    local url = hooks[category]
    if type(url) ~= "string" or url == "" then url = hooks.general end
    if type(url) ~= "string" or url == "" then return nil end
    return url
end

-- Characters Discord counts for an embed (title, description, fields, footer).
local function embedChars(embed)
    local n = Utils.utf8len(embed.title or "") + Utils.utf8len(embed.description or "")
    for _, f in ipairs(embed.fields or {}) do n = n + Utils.utf8len(f.name or "") + Utils.utf8len(f.value or "") end
    if embed.footer then n = n + Utils.utf8len(embed.footer.text or "") end
    return n
end

local function post(url, embeds)
    local hooks = Config.Webhooks or {}
    local payload = { username = hooks.username or "Police", embeds = embeds }
    if type(hooks.avatar) == "string" and hooks.avatar ~= "" then payload.avatar_url = hooks.avatar end
    -- Never ping anyone. Appended as text because an empty Lua table has no fixed JSON type.
    local body = json.encode(payload):sub(1, -2) .. ',"allowed_mentions":{"parse":[]}}'
    local p = promise.new()
    local finished = false
    PerformHttpRequest(url, function(status, resBody)
        if finished then return end
        finished = true
        p:resolve({ status = status, body = resBody })
    end, "POST", body, { ["Content-Type"] = "application/json" })
    SetTimeout(15000, function()
        if finished then return end
        finished = true
        p:resolve({ status = 0 })
    end)
    return Citizen.Await(p)
end

local function pump(url)
    local q = queues[url]
    if q.pumping then return end
    q.pumping = true
    BoFaisaL.thread(function()
        while #q.items > 0 do
            -- The next entries that fit in one message (one alone when it was refused in a batch).
            local batch, chars = {}, 0
            while #q.items > 0 and #batch < MAX_BATCH do
                local item = q.items[1]
                if #batch > 0 and (item.single or chars + item.chars > MAX_CHARS) then break end
                table.remove(q.items, 1)
                batch[#batch + 1] = item
                chars = chars + item.chars
                if item.single then break end
            end
            local embeds = {}
            for i, item in ipairs(batch) do embeds[i] = item.embed end
            local r = post(url, embeds)
            if r.status == 429 then
                local retry = 2.0
                local ok, decoded = pcall(json.decode, r.body or "")
                if ok and type(decoded) == "table" and tonumber(decoded.retry_after) then
                    retry = tonumber(decoded.retry_after)
                    if retry > 100 then retry = retry / 1000 end
                end
                -- Back at the front, in the same order (three tries each).
                for i = #batch, 1, -1 do
                    local item = batch[i]
                    item.tries = (item.tries or 0) + 1
                    if item.tries <= 3 then table.insert(q.items, 1, item) end
                end
                Citizen.Wait(math.floor(math.max(retry, 0.5) * 1000))
            else
                if r.status == 400 and #batch > 1 then
                    -- One bad entry must not lose the others: each is sent again on its own.
                    for i = #batch, 1, -1 do
                        batch[i].single = true
                        table.insert(q.items, 1, batch[i])
                    end
                elseif r.status and r.status >= 400 then
                    BoFaisaL.debug("integrations", "webhook responded %s", tostring(r.status))
                end
                Citizen.Wait(GAP)
            end
        end
        q.pumping = false
    end)
end

-- True when a webhook URL is configured for this category (or the general one).
function Logs.hasWebhook(category)
    return urlFor(category) ~= nil
end

-- Sends a raw embed to the webhook of a category.
function Logs.webhook(category, embed)
    local url = urlFor(category)
    if not url then return end
    local hooks = Config.Webhooks
    embed.color = embed.color or COLORS[category] or COLORS.general
    if type(hooks.footer) == "string" and hooks.footer ~= "" then embed.footer = { text = hooks.footer } end
    embed.timestamp = os.date("!%Y-%m-%dT%H:%M:%SZ")
    if embed.title then embed.title = clip(embed.title, 250) end
    if embed.description then embed.description = clip(embed.description, 4000) end
    local q = queues[url]
    if not q then
        q = { items = {}, pumping = false }
        queues[url] = q
    end
    if #q.items >= MAX_QUEUE then
        table.remove(q.items, 1)
        BoFaisaL.debug("integrations", "webhook queue full: the oldest log was dropped")
    end
    q.items[#q.items + 1] = { embed = embed, chars = embedChars(embed) }
    pump(url)
end

local function who(user_id, name)
    return ("%s | رقم الهوية: %s"):format(discordSafe(name or BoFaisaL.Players.name(user_id)), tostring(user_id))
end
Logs.who = who

function Logs.add(category, action, entry)
    entry = entry or {}
    local now = BoFaisaL.now()
    -- nil = no player (every id is a real player, 0 and negatives included)
    local actorId = Utils.toUserId(entry.actor)
    local targetId = Utils.toUserId(entry.target)
    local actorName = actorId and (entry.actorName or BoFaisaL.Players.name(actorId)) or ""
    local targetName = targetId and (entry.targetName or BoFaisaL.Players.name(targetId)) or ""
    local title = entry.title or L("log_" .. action)

    local details = {}
    for _, f in ipairs(entry.fields or {}) do
        details[#details + 1] = { tostring(f[1]), tostring(f[2]) }
    end
    if entry.description then details[#details + 1] = { "description", tostring(entry.description) } end

    if Config.Logs and Config.Logs.Database ~= false and BoFaisaL.DB.ready then
        BoFaisaL.DB.executeAsync(
            "INSERT INTO bofaisal_police_logs (category, action, actor_id, actor_name, target_id, target_name, details, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            { category, action, BoFaisaL.DB.id(actorId), actorName, BoFaisaL.DB.id(targetId), targetName, json.encode(details), now }
        )
    end

    if Config.Logs and Config.Logs.Console then
        BoFaisaL.print("[%s] %s — %s → %s", category, action, actorName ~= "" and who(actorId, actorName) or "-", targetName ~= "" and who(targetId, targetName) or "-")
    end

    if entry.noWebhook then return end

    local fields = {}
    if actorId then fields[#fields + 1] = { name = entry.actorLabel or L("log_field_actor"), value = who(actorId, actorName), inline = true } end
    if targetId then fields[#fields + 1] = { name = entry.targetLabel or L("log_field_target"), value = who(targetId, targetName), inline = true } end
    for _, f in ipairs(entry.fields or {}) do
        if #fields >= 24 then break end
        local value = tostring(f[2] == nil and "-" or f[2])
        if value == "" then value = "-" end
        fields[#fields + 1] = { name = clip(f[1], 250), value = clip(discordSafe(value), 1000), inline = f[3] == true }
    end

    Logs.webhook(category, {
        title = title,
        description = entry.description and discordSafe(entry.description) or nil,
        fields = fields,
    })
end
