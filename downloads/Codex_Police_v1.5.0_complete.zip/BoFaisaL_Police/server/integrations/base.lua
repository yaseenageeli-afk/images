--[[
    BoFaisaL_Police — integration registry, notifications, popups and chat.
]]

local I = { status = {} }
BoFaisaL.Integrations = I

local function cfg(name)
    return (Config.Integrations and Config.Integrations[name]) or {}
end
I.cfg = cfg

local function resourceUp(name)
    return type(name) == "string" and name ~= "" and GetResourceState(name) == "started"
end
I.resourceUp = resourceUp

-- Records availability once and prints the standard console message when missing.
function I.report(name, available, detail)
    I.status[name] = { available = available, detail = detail }
    if not available then
        BoFaisaL.warn("%s integration unavailable.%s", name, detail and (" (" .. detail .. ")") or "")
    else
        BoFaisaL.debug("integrations", "%s → %s", name, detail or "ok")
    end
end

function I.available(name)
    local s = I.status[name]
    return s == nil or s.available
end

---------------------------------------------------------------------------
-- Notify
---------------------------------------------------------------------------
local Notify = {}
I.Notify = Notify

function Notify.send(src, message, kind, duration)
    if not src or not message or message == "" then return end
    TriggerClientEvent("bofaisal_police:notify", src, message, kind or "info", duration or (Config.UI and Config.UI.NotifySeconds) or 6)
end

-- Info card (left side): short inquiry results written as "label: value" rows.
--   card = { title = "...", rows = { { "الاسم", "..." }, ... }, lines = { "..." } }
function BoFaisaL.infoCard(src, card)
    if not src or type(card) ~= "table" then return end
    card.duration = card.duration or (Config.UI and Config.UI.InfoCardSeconds) or 12
    BoFaisaL.ui(src, "infocard", card)
end

-- BoFaisaL.notify(src, "locale_key", vars, kind) or a plain text
function BoFaisaL.notify(src, key, vars, kind, duration)
    local text = (Locale and Locale[key]) and L(key, vars) or tostring(key)
    Notify.send(src, text, kind, duration)
end

---------------------------------------------------------------------------
-- Popup / input
--   fields = { { key = "id", label = "...", type = "number"|"text"|"textarea", required = true, max = 250, min = 1 } }
---------------------------------------------------------------------------
local Popup = { pending = {}, seq = 0 }
I.Popup = Popup

local function validate(values, fields)
    if type(values) ~= "table" then return nil end
    local out = {}
    for _, f in ipairs(fields) do
        local raw = values[f.key]
        if f.type == "number" then
            local n = Utils.toInt(raw)
            if n == nil then
                if f.required ~= false then return nil end
            else
                if (f.min and n < f.min) or (f.max and n > f.max) then return nil end
                out[f.key] = n
            end
        else
            local s = Utils.sanitize(type(raw) == "string" and raw or (raw ~= nil and tostring(raw) or ""), f.max or 250, f.type == "textarea")
            if s == "" and f.required ~= false then return nil end
            out[f.key] = s
        end
    end
    return out
end
Popup.validate = validate

local function builtin(src, title, fields, timeout)
    Popup.seq = Popup.seq + 1
    local id = Popup.seq
    local p = promise.new()
    Popup.pending[id] = { src = src, p = p }
    local clientFields = {}
    for i, f in ipairs(fields) do
        clientFields[i] = { key = f.key, label = f.label, type = f.type or "text", max = f.max, min = f.min, placeholder = f.placeholder, default = f.default }
    end
    TriggerClientEvent("bofaisal_police:dialog:open", src, id, title, clientFields)
    SetTimeout(timeout * 1000, function()
        local entry = Popup.pending[id]
        if entry then
            Popup.pending[id] = nil
            TriggerClientEvent("bofaisal_police:dialog:close", src, id)
            entry.p:resolve({})
        end
    end)
    local r = Citizen.Await(p)
    if not r.values then return nil end
    return validate(r.values, fields)
end

-- Blocks until the player answers. Returns validated values or nil (cancel / invalid / timeout).
function Popup.input(src, title, fields)
    local c = cfg("Popup")
    local t = c.type or "vrp"
    local timeout = tonumber(c.timeout) or 120
    if t == "custom" and type(c.custom) == "function" then
        local ok, values = pcall(c.custom, src, title, fields)
        if not ok then
            BoFaisaL.debug("integrations", "Popup.custom: %s", tostring(values))
            return nil
        end
        return validate(values, fields)
    end
    if t == "vrp" and BoFaisaL.Framework.available then
        local values = {}
        for _, f in ipairs(fields) do
            local label = f.label
            if #fields == 1 and title and title ~= f.label then label = title .. " — " .. f.label end
            local v = BoFaisaL.Framework.prompt(src, label, f.default and tostring(f.default) or "", timeout * 1000)
            if v == nil then return nil end
            v = Utils.trim(tostring(v))
            if v == "" and f.required ~= false then return nil end
            values[f.key] = v
        end
        return validate(values, fields)
    end
    return builtin(src, title, fields, timeout)
end

function Popup.cancelFor(src)
    for id, entry in pairs(Popup.pending) do
        if entry.src == src then
            Popup.pending[id] = nil
            entry.p:resolve({})
        end
    end
end

BoFaisaL.RPC.register("dialog:submit", {}, function(ctx, data)
    local id = Utils.toInt(data.id)
    local entry = id and Popup.pending[id]
    if not entry or entry.src ~= ctx.source then return nil, L("err_invalid_request") end
    Popup.pending[id] = nil
    entry.p:resolve({ values = type(data.values) == "table" and data.values or {} })
    return true
end)

BoFaisaL.RPC.register("dialog:cancel", {}, function(ctx, data)
    local id = Utils.toInt(data.id)
    local entry = id and Popup.pending[id]
    if entry and entry.src == ctx.source then
        Popup.pending[id] = nil
        entry.p:resolve({})
    end
    return true
end)

---------------------------------------------------------------------------
-- Chat announcements
---------------------------------------------------------------------------
local Chat = {}
I.Chat = Chat

-- targets: -1 (everyone) or a list of sources
function Chat.send(targets, title, message, color)
    local c = cfg("Chat")
    if c.type == "custom" and type(c.custom) == "function" then
        local list = targets
        if targets == -1 then
            list = {}
            for _, p in ipairs(BoFaisaL.Players.online()) do list[#list + 1] = p.source end
        end
        local ok, err = pcall(c.custom, list, title, message, color)
        if not ok then BoFaisaL.debug("integrations", "Chat.custom: %s", tostring(err)) end
        return
    end
    local payload = { color = color or { 37, 99, 235 }, multiline = true, args = { title or L("menu_police"), message } }
    if targets == -1 then
        TriggerClientEvent("chat:addMessage", -1, payload)
    else
        for _, src in ipairs(targets or {}) do
            TriggerClientEvent("chat:addMessage", src, payload)
        end
    end
end

-- One chat line with colour codes (^0 white, ^3 yellow, ^5 light blue ...), no author.
function Chat.line(targets, text)
    local c = cfg("Chat")
    if c.type == "custom" and type(c.custom) == "function" then
        local list = targets
        if targets == -1 then
            list = {}
            for _, p in ipairs(BoFaisaL.Players.online()) do list[#list + 1] = p.source end
        end
        local ok, err = pcall(c.custom, list, nil, text, nil)
        if not ok then BoFaisaL.debug("integrations", "Chat.custom: %s", tostring(err)) end
        return
    end
    local payload = { multiline = true, args = { text } }
    if targets == -1 then
        TriggerClientEvent("chat:addMessage", -1, payload)
    else
        for _, src in ipairs(targets or {}) do
            TriggerClientEvent("chat:addMessage", src, payload)
        end
    end
end

-- Player text must not carry chat colour codes.
local function chatSafe(v) return (tostring(v == nil and "" or v):gsub("%^%d", "")) end

-- Ministry of the officer: the tag at the start of every line ("[وزارة الداخلية]").
local function officerMinistry(officer_id)
    officer_id = Utils.toUserId(officer_id)
    if not officer_id then return nil end
    local profile = BoFaisaL.Gov.getProfile(officer_id)
    local rank = profile and profile.primary and BoFaisaL.Gov.describeRank(profile.primary)
    return rank and rank.ministryLabel ~= "" and rank.ministryLabel or nil
end

-- key: Config.Chat entry (Fine, Jail, JailRelease, JailServed). Every line of the entry is one
-- chat message that starts with Config.Chat.Tag (the officer's ministry).
function Chat.announce(key, vars, involved)
    local entry = Config.Chat and Config.Chat[key]
    if type(entry) ~= "table" or not entry.enabled then return end
    local safe = {}
    for k, v in pairs(vars or {}) do safe[k] = chatSafe(v) end
    safe.ministry = chatSafe(officerMinistry(vars and vars.officer_id) or Config.Chat.DefaultTag or L("menu_police"))
    local targets = -1
    if entry.audience == "officers" then
        targets = BoFaisaL.Officers.militarySources()
        for _, src in ipairs(involved or {}) do targets[#targets + 1] = src end
    elseif entry.audience == "involved" then
        targets = involved or {}
    end
    local tag = Utils.format(Config.Chat.Tag or "^3[{ministry}]", safe)
    for _, line in ipairs(entry.lines or { entry.template }) do
        if type(line) == "string" and line ~= "" then
            Chat.line(targets, (tag ~= "" and (tag .. " ") or "") .. Utils.format(line, safe))
        end
    end
end

