--[[
    BoFaisaL_Police — الجدول العسكري (military roster, iPad tab)

    Built from the ranks by itself (config/config.lua → Config.Government): one section for
    رئاسة الوزراء, one for each ministry, and each sector split by rank tier: its command
    (قيادة), its officers (ضباط) and its enlisted (أفراد) — see Gov.rankTier. Every officer
    appears in the section of his most senior rank, ordered by rank then by appointment date.

    Code of a row: the section letter + its place in the section (A-1, A-2...). The letters and
    any single officer's number can be changed from the table settings (permission "rosterManage");
    they are saved in bofaisal_police_meta for the whole server. A changed number keeps the section
    letter, so changing a letter changes every code of that section (A-15 → B-15).

    Config.MilitaryCode.Mode = "roster" makes this code the officer's military code too
    (Roster.codeOf / Roster.codeMap); "manual" keeps the military code the officer writes himself.
]]

local Roster = { settings = { prefixes = {}, codes = {} } }
BoFaisaL.Roster = Roster

local DB, P, Gov, Officers, Vacation, Logs, RPC = BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Officers, BoFaisaL.Vacation, BoFaisaL.Logs, BoFaisaL.RPC

local META_KEY = "roster"
local PREFIX_MAX, NUMBER_MAX = 6, 5
local LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
local TIER_ORDER = { "command", "officers", "enlisted" }

local function decode(raw)
    local ok, data = pcall(json.decode, raw or "")
    return ok and type(data) == "table" and data or {}
end

local function save()
    local encoded = json.encode(Roster.settings)
    DB.execute("INSERT INTO bofaisal_police_meta (k, v) VALUES (?, ?) ON DUPLICATE KEY UPDATE v = VALUES(v)", { META_KEY, encoded })
    return DB.scalar("SELECT v FROM bofaisal_police_meta WHERE k = ?", { META_KEY }) == encoded
end

-- Settings: { v = 2, prefixes = { [section id] = "P" }, codes = { ["user id"] = "15" } }
-- codes hold only the number; the letter always comes from the officer's section.
function Roster.load()
    local data = decode(DB.scalar("SELECT v FROM bofaisal_police_meta WHERE k = ?", { META_KEY }))
    Roster.settings = {
        v = 2,
        prefixes = type(data.prefixes) == "table" and data.prefixes or {},
        codes = type(data.codes) == "table" and data.codes or {},
    }
    -- Older saves kept the whole code ("A-15"): keep only its number.
    if data.v ~= 2 then
        for uid, code in pairs(Roster.settings.codes) do
            local number = type(code) == "string" and (code:match("^[^%-]*%-(.+)$") or code) or ""
            Roster.settings.codes[uid] = number ~= "" and number:sub(1, NUMBER_MAX) or nil
        end
        if next(Roster.settings.codes) or next(Roster.settings.prefixes) then save() end
    end
end

-- true = the officer's military code is his code in this table (Config.MilitaryCode.Mode).
function Roster.linked()
    return Config.MilitaryCode ~= nil and Config.MilitaryCode.Mode == "roster"
end

-- Sections in the order of the config: { id, label, ranks = { group... }, prefix, defaultPrefix }
function Roster.sections()
    local list = {}
    local function add(id, label, ranks)
        local index = #list + 1
        local default = LETTERS:sub(((index - 1) % #LETTERS) + 1, ((index - 1) % #LETTERS) + 1)
        local custom = Roster.settings.prefixes[id]
        list[index] = {
            id = id, label = label, ranks = ranks or {}, defaultPrefix = default,
            prefix = type(custom) == "string" and custom ~= "" and custom or default,
        }
    end
    if Gov.prime then add("prime", Gov.prime.label, Gov.prime.ranks) end
    local tierNames = (Config.Roster and Config.Roster.Tiers) or {}
    for _, m in ipairs(Gov.ministryList) do
        add("ministry:" .. m.key, m.label, m.ranks)
        for _, sectorId in ipairs(m.sectors) do
            local s = Gov.sectors[sectorId]
            -- One section per tier that has ranks in this sector (command, officers, enlisted).
            local byTier = {}
            for _, group in ipairs(s.ranks) do
                local tier = Gov.rankTier(Gov.ranks[group])
                byTier[tier] = byTier[tier] or {}
                table.insert(byTier[tier], group)
            end
            for _, tier in ipairs(TIER_ORDER) do
                if byTier[tier] then
                    add("sector:" .. sectorId .. ":" .. tier, s.label .. " — " .. (tierNames[tier] or tier), byTier[tier])
                end
            end
        end
    end
    return list
end

local function sectionOf(rank)
    if rank.level == "prime" then return "prime" end
    if rank.level == "ministry" then return "ministry:" .. rank.ministry end
    return "sector:" .. rank.sector .. ":" .. Gov.rankTier(rank)
end

-- Every officer: online officers, stored records and officers on vacation (in their saved rank).
local function officers()
    local seen, list = {}, {}
    local function add(uid, groups, name, appointed)
        if seen[uid] then return end
        local primary = Gov.resolve(groups).primary
        if not primary then return end
        seen[uid] = true
        list[#list + 1] = { user_id = uid, rank = primary, name = name, appointed = appointed or 0 }
    end
    local rows = DB.query("SELECT user_id, name, groups_json, created_at FROM bofaisal_police_officers WHERE active = 1")
    local byId = {}
    for _, row in ipairs(rows) do byId[tonumber(row.user_id)] = row end
    for uid in pairs(P.byUser) do
        local prof = Gov.cached(uid)
        if prof.isMilitary then
            local row = byId[uid]
            add(uid, Gov.militaryGroups(prof.groups), P.name(uid), row and tonumber(row.created_at))
        end
    end
    for uid, vac in pairs(Vacation.active) do
        local row = byId[uid]
        add(uid, decode(vac.original_groups), P.name(uid), row and tonumber(row.created_at))
    end
    for _, row in ipairs(rows) do
        local uid = tonumber(row.user_id)
        if uid then add(uid, Officers.decodeGroups(row.groups_json), row.name ~= "" and row.name or P.name(uid), tonumber(row.created_at)) end
    end
    return list
end

-- The table is built once and kept until something changes it: a rank (profileChanged — also
-- vacations and joins), an offline rank change made by the script (recruit, dismissal,
-- promotion → Officers.storeGroups / deactivate), a number or a section letter. Opening the
-- table never reads the database again by itself.
-- Offline officers whose rank was changed OUTSIDE the script (database, another script) are
-- updated by the light check below (Config.Roster.SyncOfflineMinutes) or when they join.
local built, codeCache, version = nil, nil, 0
local placed = {} -- [user id] = "rank group\nname" of every row of the kept table

function Roster.invalidate()
    built, codeCache = nil, nil
    version = version + 1
end

-- The table: sections with their rows { code, number, custom, rank, name, user_id, online, onDuty, vacation }.
function Roster.build()
    local startedAt = version
    local sections, index = Roster.sections(), {}
    for _, s in ipairs(sections) do
        s.rows = {}
        index[s.id] = s
    end
    for _, o in ipairs(officers()) do
        local s = index[sectionOf(o.rank)]
        if s then s.rows[#s.rows + 1] = o end
    end
    local out = {}
    for _, s in ipairs(sections) do
        table.sort(s.rows, function(a, b)
            if a.rank.order ~= b.rank.order then return a.rank.order < b.rank.order end
            if a.appointed ~= b.appointed then return a.appointed < b.appointed end
            return a.user_id < b.user_id
        end)
        local rows = {}
        for i, o in ipairs(s.rows) do
            local custom = Roster.settings.codes[tostring(o.user_id)]
            local hasCustom = type(custom) == "string" and custom ~= ""
            local number = hasCustom and custom or tostring(i)
            rows[i] = {
                code = s.prefix .. "-" .. number,
                number = number,
                custom = hasCustom,
                rank = Gov.rankLabel(o.rank.group),
                name = o.name,
                user_id = o.user_id,
                online = P.isOnline(o.user_id),
                onDuty = Officers.isOnDuty(o.user_id),
                vacation = Vacation.isOnVacation(o.user_id),
            }
        end
        out[#out + 1] = { id = s.id, label = s.label, prefix = s.prefix, defaultPrefix = s.defaultPrefix, rows = rows }
    end
    local map, where = {}, {}
    for _, s in ipairs(out) do
        for _, row in ipairs(s.rows) do map[row.user_id] = row.code end
    end
    for _, s in ipairs(sections) do
        for _, o in ipairs(s.rows) do where[o.user_id] = o.rank.group .. "\n" .. tostring(o.name) end
    end
    -- Kept only when nothing changed while it was read (else the next request builds again).
    if startedAt == version then built, codeCache, placed = out, map, where end
    return out
end

-- The kept table, with the live states (connected, on duty, on vacation) filled in now: they
-- change all the time but cost nothing to read.
function Roster.get()
    local sections = built or Roster.build()
    for _, s in ipairs(sections) do
        for _, row in ipairs(s.rows) do
            row.online = P.isOnline(row.user_id)
            row.onDuty = Officers.isOnDuty(row.user_id)
            row.vacation = Vacation.isOnVacation(row.user_id)
        end
    end
    return sections
end

-- { [user id] = "A-1" } for every officer in the table (the table is built only when it changed).
function Roster.codeMap()
    if codeCache then return codeCache end
    local map = {}
    for _, s in ipairs(Roster.build()) do
        for _, row in ipairs(s.rows) do map[row.user_id] = row.code end
    end
    return map
end

-- A rank change of a connected officer. Also raised when an officer joins (his rank is read for
-- the first time): when he sits in the kept table with the same rank and name, nothing changed.
BoFaisaL.on("profileChanged", function(user_id, profile)
    if not built then return end
    local primary
    local vac = Vacation.get(user_id)
    if vac then
        primary = Gov.resolve(decode(vac.original_groups)).primary -- on vacation: shown in his saved rank
    elseif profile and profile.isMilitary then
        primary = profile.primary
    end
    local now = primary and (primary.group .. "\n" .. tostring(P.name(user_id))) or nil
    if now ~= placed[user_id] then Roster.invalidate() end
end)

---------------------------------------------------------------------------
-- Offline officers changed outside the script (Config.Roster.SyncOfflineMinutes)
--   Reads only the groups of the saved vRP data (JSON_EXTRACT), 50 officers at a time with a
--   pause between them; MySQL / MariaDB without JSON_EXTRACT read the whole data instead.
---------------------------------------------------------------------------
local jsonExtract = nil -- true / false once tested

local function savedGroups(ids)
    local out = {}
    if jsonExtract == nil then
        jsonExtract = DB.scalar([[SELECT JSON_EXTRACT('{"a":1}', '$.a') AS v]]) ~= nil
    end
    local column = jsonExtract and "JSON_EXTRACT(dvalue, '$.groups')" or "dvalue"
    local rows = DB.query("SELECT user_id, " .. column .. " AS g FROM vrp_user_data WHERE dkey = 'vRP:datatable' AND user_id IN ("
        .. string.rep("?, ", #ids):sub(1, -3) .. ")", ids)
    for _, row in ipairs(rows) do
        -- Some drivers hand JSON results back already decoded.
        local ok, data = true, row.g
        if type(data) == "string" then ok, data = pcall(json.decode, data) end
        if ok and type(data) == "table" then
            local groups = jsonExtract and data or data.groups
            if type(groups) == "table" then out[tonumber(row.user_id)] = groups end
        end
    end
    return out
end

function Roster.syncOffline()
    local offline, stored = {}, {}
    for _, row in ipairs(Officers.activeRows()) do
        local uid = tonumber(row.user_id)
        if uid and not P.isOnline(uid) and not Vacation.isOnVacation(uid) then
            offline[#offline + 1] = uid
            stored[uid] = row.groups_json
        end
    end
    local changed = 0
    for first = 1, #offline, 50 do
        local chunk = {}
        for i = first, math.min(#offline, first + 49) do chunk[#chunk + 1] = offline[i] end
        for uid, groups in pairs(savedGroups(chunk)) do
            local current = Gov.militaryGroups(groups)
            if not P.isOnline(uid) and table.concat(current, "\n") ~= table.concat(Officers.decodeGroups(stored[uid]), "\n") then
                Officers.storeGroups(uid, groups)
                changed = changed + 1
            end
        end
        Citizen.Wait(250)
    end
    if changed > 0 then BoFaisaL.debug("permissions", "roster: %d offline officers changed outside the script", changed) end
end

Citizen.CreateThread(function()
    while not BoFaisaL.ready do Citizen.Wait(1000) end
    while true do
        local minutes = tonumber(Config.Roster and Config.Roster.SyncOfflineMinutes) or 0
        Citizen.Wait(math.max(1, minutes > 0 and minutes or 1) * 60000)
        if minutes > 0 and DB.ready then
            local ok, err = pcall(Roster.syncOffline)
            if not ok then BoFaisaL.error("roster sync failed: %s", tostring(err)) end
        end
    end
end)

function Roster.codeOf(user_id)
    return Roster.codeMap()[tonumber(user_id)] or ""
end

local function clean(text, max)
    if type(text) ~= "string" then return nil end
    local s = Utils.sanitize(text, max)
    return s
end

RPC.register("roster:list", { feature = "Roster", perm = "roster" }, function(ctx)
    return { sections = Roster.get(), manage = Gov.has(ctx.profile, "rosterManage") }
end)

-- One officer's number ("" = back to the automatic one). The section letter stays in front of it.
RPC.register("roster:setCode", { feature = "Roster", perm = "rosterManage", cooldown = 500 }, function(ctx, data)
    local uid = RPC.userId(data.user_id)
    local code = clean(data.code, NUMBER_MAX)
    if not uid or not code then return nil, L("err_invalid_request") end
    Roster.settings.codes[tostring(uid)] = code ~= "" and code or nil
    if not save() then return nil, L("err_internal") end
    Logs.add("affairs", "roster_code", { actor = ctx.user_id, target = uid, fields = { { L("roster_code"), code ~= "" and code or "-", true } } })
    return { sections = Roster.build(), manage = true }
end)

-- A section's letter ("" = back to the default one).
RPC.register("roster:setPrefix", { feature = "Roster", perm = "rosterManage", cooldown = 500 }, function(ctx, data)
    local prefix = clean(data.prefix, PREFIX_MAX)
    local id = type(data.section) == "string" and data.section or nil
    local known = false
    for _, s in ipairs(Roster.sections()) do if s.id == id then known = true end end
    if not known or not prefix then return nil, L("err_invalid_request") end
    Roster.settings.prefixes[id] = prefix ~= "" and prefix or nil
    if not save() then return nil, L("err_internal") end
    Logs.add("affairs", "roster_prefix", { actor = ctx.user_id, fields = { { L("roster_section"), id, true }, { L("roster_prefix"), prefix ~= "" and prefix or "-", true } } })
    return { sections = Roster.build(), manage = true }
end)
