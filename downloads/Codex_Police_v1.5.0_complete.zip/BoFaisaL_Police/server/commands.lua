--[[
    BoFaisaL_Police — chat commands for entries of the police menu (Config.Commands)

    The client registers each command (and its optional key); the server runs exactly what the
    entry in the police menu runs, so permissions, duty and the feature switches are the same.
]]

local Commands = {}
BoFaisaL.Commands = Commands

local RPC = BoFaisaL.RPC

-- id = { feature, menu key (Config.Menus switch, optional), action }
local function openMenu(src, menu) if menu then BoFaisaL.Menu.open(src, menu) end end

-- قائمة الشرطة: officers and officers on vacation (same as the main menu entry).
local function policeMenu(src)
    local user_id = BoFaisaL.Players.getUserId(src)
    if not user_id then return end
    if not BoFaisaL.Gov.getProfile(user_id, true).isMilitary and not BoFaisaL.Vacation.isOnVacation(user_id) then
        return BoFaisaL.notify(src, "err_no_permission", nil, "error")
    end
    openMenu(src, BoFaisaL.PoliceMenu.build(src))
end

-- Commands run on the client only (nothing to do here).
Commands.CLIENT = { StopSpectate = true }

Commands.ACTIONS = {
    Police         = { nil,              nil,                    policeMenu },
    Ipad           = { "Ipad",           "menu_ipad",            function(src) BoFaisaL.Ipad.open(src, "office") end },
    Clock          = { "Clock",          "menu_clock",           function(src) BoFaisaL.Ipad.toggleDuty(src) end },
    Jail           = { "Jail",           "menu_jail",            function(src) BoFaisaL.Jail.openMenu(src) end },
    Fines          = { "Fines",          "menu_fines",           function(src) BoFaisaL.Fines.openMenu(src) end },
    Badge          = { "Badge",          "menu_badge",           function(src) BoFaisaL.Badge.show(src) end },
    Barricades     = { "Barricades",     "menu_barricades",      function(src) openMenu(src, BoFaisaL.Barricades.menu(src)) end },
    Equipment      = { "SecurityTools",  "menu_equipment",       function(src) openMenu(src, BoFaisaL.Equipment.kitsMenu(src)) end },
    SecurityAlert  = { "SecurityTools",  "menu_security_alert",  function(src) openMenu(src, BoFaisaL.Alert.menu(src)) end },
    -- Config.Commands.Identity.everyone: every player may ask for an ID card, not only officers.
    Identity       = { "Field",          nil,                    function(src) BoFaisaL.Field.command(src, "identity", (Config.Commands.Identity or {}).everyone ~= false) end },
    Search         = { "Field",          nil,                    function(src) BoFaisaL.Field.command(src, "search") end },
    VehicleSearch  = { "Field",          nil,                    function(src) BoFaisaL.Field.command(src, "vehicleSearch") end },
    Cuff           = { "Field",          nil,                    function(src) BoFaisaL.Field.command(src, "cuff") end },
    Drag           = { "Field",          nil,                    function(src) BoFaisaL.Field.command(src, "drag") end },
    CitizenInquiry = { "CitizenInquiry", "menu_citizen_inquiry", function(src) BoFaisaL.Citizens.inquiryFlow(src) end },
    Wanted         = { "Wanted",         "menu_wanted",          function(src) BoFaisaL.Wanted.createFlow(src) end },
    FineInquiry    = { "Inquiries",      "inq_fines",            function(src) BoFaisaL.Fines.inquiryFlow(src) end },
    JailCheck      = { "Jail",           "inq_jail_check",       function(src) BoFaisaL.Jail.checkFlow(src) end },
    JailRelease    = { "Jail",           "inq_jail_release",     function(src) BoFaisaL.Jail.releaseFlow(src) end },
    Impound        = { "Impound",        "impound_action",       function(src) BoFaisaL.Impound.flow(src) end },
    Report         = { "CitizenReport",  nil,                    function(src) BoFaisaL.Reports.createFlow(src) end },
    Absher         = { "Absher",         nil,                    function(src) BoFaisaL.Absher.open(src) end },
}

RPC.register("cmd:run", { cooldown = 600 }, function(ctx, data)
    local id = type(data.id) == "string" and data.id or ""
    local def = Commands.ACTIONS[id]
    local c = Config.Commands and Config.Commands[id]
    if not def or type(c) ~= "table" or c.enabled == false then return nil, L("err_invalid_request") end
    if (def[1] and not BoFaisaL.feature(def[1])) or (def[2] and not MenuOn(def[2])) then return nil, L("err_feature_disabled") end
    -- The flows open menus / inputs and wait for the player: run them on their own.
    local src = ctx.source
    BoFaisaL.thread(def[3], src)
    return true
end)

-- Config check at start: wrong ids, invalid or repeated names are printed (nothing breaks).
Citizen.CreateThread(function()
    local _, problems = Utils.commandList(Config.Commands)
    for id, c in pairs(Config.Commands or {}) do
        if type(c) == "table" and c.enabled ~= false and not Commands.ACTIONS[id] and not Commands.CLIENT[id] then
            problems[#problems + 1] = ("Config.Commands.%s: unknown command (keep the names before \"=\" as they are)."):format(tostring(id))
        end
    end
    for _, p in ipairs(problems) do BoFaisaL.warn(p) end
end)
