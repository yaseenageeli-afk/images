--[[
    BoFaisaL_Police — security equipment (أخذ العتاد)
]]

local Equipment = { last = {} }
BoFaisaL.Equipment = Equipment

local P, Gov, Logs, Officers = BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers
local I = BoFaisaL.Integrations

-- Sector / rank restrictions of a kit.
local function allowedFor(profile, entry)
    if type(entry.sectors) == "table" and #entry.sectors > 0 then
        local ok = false
        for _, g in ipairs(profile.grants) do
            for _, s in ipairs(entry.sectors) do
                if g.sector == s or (g.level ~= "sector" and Gov.coversSector(g, s)) then ok = true end
            end
        end
        if not ok then return false end
    end
    if type(entry.ranks) == "table" and #entry.ranks > 0 then
        local set = Utils.toSet(entry.ranks)
        local ok = false
        for _, g in ipairs(profile.grants) do
            if set[g.group] then ok = true end
        end
        if not ok then return false end
    end
    return true
end
Equipment.allowedFor = allowedFor

local function gate(source, perm, dutyKey)
    local user_id = P.getUserId(source)
    if not user_id then return nil end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("SecurityTools") or not Gov.has(profile, perm) then
        BoFaisaL.notify(source, "err_no_permission", nil, "error")
        return nil
    end
    if not Officers.dutyOk(user_id, dutyKey) then
        BoFaisaL.notify(source, "err_not_on_duty", nil, "error")
        return nil
    end
    return user_id, profile
end

function Equipment.takeKit(source, kitId)
    local user_id, profile = gate(source, "equipment", "equipment")
    if not user_id then return end
    local kit
    for _, k in ipairs((Config.Equipment and Config.Equipment.Kits) or {}) do
        if k.id == kitId then kit = k end
    end
    if not kit or not allowedFor(profile, kit) then return BoFaisaL.notify(source, "err_no_permission", nil, "error") end
    local now = BoFaisaL.now()
    local cooldown = (Config.Equipment and Config.Equipment.Cooldown) or 120
    if Equipment.last[user_id] and now - Equipment.last[user_id] < cooldown then
        return BoFaisaL.notify(source, "equipment_cooldown", { seconds = cooldown - (now - Equipment.last[user_id]) }, "error")
    end
    Equipment.last[user_id] = now
    local weapons = {}
    for _, w in ipairs(kit.weapons or {}) do weapons[w.name:upper()] = { ammo = tonumber(w.ammo) or 0 } end
    if next(weapons) then I.Weapons.give(source, weapons) end
    for _, it in ipairs(kit.items or {}) do I.Inventory.give(user_id, it.item, tonumber(it.amount) or 1) end
    if (tonumber(kit.armour) or 0) > 0 then TriggerClientEvent("bofaisal_police:armour", source, tonumber(kit.armour)) end
    BoFaisaL.notify(source, "equipment_taken", { kit = kit.label }, "success")
    Logs.add("field", "equipment_take", { actor = user_id, fields = { { L("field_kit"), kit.label } } })
end

-- Weapon names handed out by any kit.
local function kitWeapons()
    local set = {}
    for _, k in ipairs((Config.Equipment and Config.Equipment.Kits) or {}) do
        for _, w in ipairs(k.weapons or {}) do set[w.name:upper()] = true end
    end
    return set
end

-- Takes back the weapons handed out by the kits (personal weapons stay). Returns true if any.
local function stripNow(source)
    local issued, keep, had = kitWeapons(), {}, false
    for name, data in pairs(I.Weapons.get(source) or {}) do
        if issued[name] then had = true else keep[name] = data end
    end
    if not had then return false end
    I.Weapons.clear(source)
    if next(keep) then I.Weapons.give(source, keep) end
    return true
end

-- Clock-out / dismissal: now when the officer is connected, otherwise on his next join
-- (queued in bofaisal_police_pending, applied by Officers.applyPending).
-- queue = true: the player is leaving right now (his client can't answer any more).
function Equipment.strip(user_id, reason, queue)
    user_id = tonumber(user_id)
    if not user_id then return end
    local src = not queue and P.getSource(user_id)
    if src then
        BoFaisaL.thread(function()
            if stripNow(src) then
                Logs.add("field", "equipment_return", { actor = user_id, fields = { { L("log_field_reason"), L("clock_reason_" .. (reason or "manual")) } } })
            end
        end)
    else
        BoFaisaL.DB.execute("DELETE FROM bofaisal_police_pending WHERE user_id = ? AND action = 'strip'", { user_id })
        BoFaisaL.Officers.queueGroup(user_id, "strip", "")
    end
end

-- Queued strip on join: a moment later, once vRP has given the saved weapons back.
function Equipment.stripOnJoin(user_id)
    SetTimeout(8000, function()
        local src = P.getSource(user_id)
        if src and not BoFaisaL.Officers.isOnDuty(user_id) then
            BoFaisaL.thread(function()
                stripNow(src)
            end)
        end
    end)
end

function Equipment.returnAll(source)
    local user_id = gate(source, "equipment", "equipment")
    if not user_id then return end
    if (Config.Equipment and Config.Equipment.ReturnMode) == "all" then
        I.Weapons.clear(source)
    else
        -- Personal weapons stay with the officer.
        local issued, keep = kitWeapons(), {}
        for name, data in pairs(I.Weapons.get(source)) do
            if not issued[name] then keep[name] = data end
        end
        I.Weapons.clear(source)
        if next(keep) then I.Weapons.give(source, keep) end
    end
    TriggerClientEvent("bofaisal_police:armour", source, 0)
    BoFaisaL.notify(source, "equipment_returned", nil, "info")
    Logs.add("field", "equipment_return", { actor = user_id })
end

function Equipment.kitsMenu(source, parent)
    local user_id, profile = gate(source, "equipment", "equipment")
    if not user_id then return nil end
    local items = {}
    for _, kit in ipairs((Config.Equipment and Config.Equipment.Kits) or {}) do
        if allowedFor(profile, kit) then
            local names = {}
            for _, w in ipairs(kit.weapons or {}) do names[#names + 1] = w.name:gsub("^WEAPON_", "") end
            items[#items + 1] = {
                label = kit.label,
                description = table.concat(names, " • "),
                action = function(src) Equipment.takeKit(src, kit.id) end,
            }
        end
    end
    if Config.Equipment and Config.Equipment.ReturnEnabled ~= false then
        items[#items + 1] = { label = L("equipment_return"), description = L("equipment_return_desc"), action = function(src) Equipment.returnAll(src) end }
    end
    return { title = L("menu_equipment"), items = items, parent = parent }
end
