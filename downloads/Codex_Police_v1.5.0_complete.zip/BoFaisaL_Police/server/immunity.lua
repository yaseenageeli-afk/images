--[[
    BoFaisaL_Police — immunity (الموانع)

    A vRP permission (Config.Immunity) put in a group of vrp/cfg/groups.lua protects its players:
        Jail    → can't be jailed
        Cuff    → can't be cuffed (taking cuffs off stays possible)
        Drag    → can't be dragged (letting go stays possible)
        Fine    → can't be fined
        Impound → their vehicles can't be impounded
    Online players are checked with vRP itself. An offline vehicle owner is checked from his saved
    groups (vRP user data "vRP:datatable") against vrp/cfg/groups.lua (Config.Framework.ReadGroupsConfig).
]]

local Immunity = {}
BoFaisaL.Immunity = Immunity

local P, F = BoFaisaL.Players, BoFaisaL.Framework

local function permission(kind)
    local p = Config.Immunity and Config.Immunity[kind]
    if type(p) ~= "string" or p == "" then return nil end -- false / empty = this immunity is off
    return p
end

-- Groups saved for a player who is not connected (nil when they can't be read).
local function offlineGroups(user_id)
    local raw = F.callAsync("getUData", 6000, user_id, "vRP:datatable")
    if type(raw) ~= "string" or raw == "" then return nil end
    local ok, data = pcall(json.decode, raw)
    if not ok or type(data) ~= "table" or type(data.groups) ~= "table" then return nil end
    return data.groups
end

-- Does one of these groups give the permission in vrp/cfg/groups.lua? Same rules as
-- vRP.hasPermission: "-perm" in any of the groups takes it away.
local function groupsGive(groups, perm)
    local cfg = F.groupsCfg
    if type(cfg) ~= "table" then return false end
    local defs = {}
    for k, v in pairs(groups) do
        local group = type(k) == "string" and k or v
        local def = type(group) == "string" and v ~= false and cfg[group]
        if type(def) == "table" then defs[#defs + 1] = def end
    end
    local found = false
    for _, def in ipairs(defs) do
        for key, p in pairs(def) do
            if key ~= "_config" then
                if p == "-" .. perm then return false end
                if p == perm then found = true end
            end
        end
    end
    return found
end

-- kind = "Jail" | "Cuff" | "Drag" | "Fine" | "Impound"
function Immunity.has(user_id, kind)
    user_id = tonumber(user_id)
    local perm = permission(kind)
    if not user_id or not perm then return false end
    if P.getSource(user_id) then return F.hasPermission(user_id, perm) end
    local groups = offlineGroups(user_id)
    return groups ~= nil and groupsGive(groups, perm)
end

-- Notifies the officer and returns true when the target is protected.
function Immunity.blocks(officerSrc, user_id, kind)
    if not Immunity.has(user_id, kind) then return false end
    BoFaisaL.notify(officerSrc, "immune_" .. kind:lower(), nil, "error")
    return true
end

---------------------------------------------------------------------------
-- Serving officers (Config.OfficerProtection): an officer who holds a military rank can't be
-- fined, jailed, reported or put on the wanted list. On vacation he is a normal citizen.
---------------------------------------------------------------------------
function Immunity.isServingOfficer(user_id)
    user_id = Utils.toUserId(user_id)
    if not user_id then return false end
    if BoFaisaL.Vacation and BoFaisaL.Vacation.isOnVacation(user_id) then return false end
    if P.isOnline(user_id) then return BoFaisaL.Gov.getProfile(user_id, true).isMilitary == true end
    local record = BoFaisaL.Officers and BoFaisaL.Officers.get(user_id)
    return record ~= nil and tonumber(record.active) == 1
end

-- kind = "Fines" | "Jail" | "Reports" | "Wanted". actorId: who does it (on himself with
-- Config.Targeting.AllowSelf, the protection does not apply).
function Immunity.officerProtected(user_id, kind, actorId)
    local c = Config.OfficerProtection
    if type(c) ~= "table" or c[kind] ~= true then return false end
    if actorId ~= nil and Utils.toUserId(actorId) == Utils.toUserId(user_id) and BoFaisaL.allowSelf() then return false end
    return Immunity.isServingOfficer(user_id)
end
