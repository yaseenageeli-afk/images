--[[
    BoFaisaL_Police — security alert (الاستنفار الأمني)

    CRITICAL RULE: players already inside the zone when the alert starts are NOT affected;
    players who enter after the start ARE affected. The occupants are captured on the server at
    activation time (server-side positions with OneSync) and each client receives its own
    exemption flag with the alert.
]]

local Alert = { active = {}, seq = 0 }
BoFaisaL.Alert = Alert

local P, Gov, Logs, Officers = BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers

local function cfg() return Config.SecurityAlert or {} end

-- The alert announcement only reaches players near the zone (radius + AnnounceDistance).
local function announce(a, message)
    if not cfg().AnnounceToCitizens then return end
    local reach = a.radius + (tonumber(cfg().AnnounceDistance) or 300.0)
    local payload = {
        kind = "alert", title = L("alert_broadcast_title"), message = message,
        duration = Config.Broadcast.Duration, style = Config.Broadcast.Style, sound = Config.Broadcast.Sound,
    }
    for _, p in ipairs(P.online()) do
        local c = P.coords(p.source)
        if c and Utils.dist2d(c, a.coords) <= reach then TriggerClientEvent("bofaisal_police:ui", p.source, "broadcast", payload) end
    end
end

local function publicAlert(a)
    return {
        id = a.id, label = a.label, coords = a.coords, radius = a.radius,
        startedAt = a.startedAt, by = a.byName,
        mapZone = cfg().MapZone, vehicle = cfg().VehicleSlowdown, player = cfg().PlayerSlowdown, weapons = cfg().WeaponBan,
        exemptOfficers = cfg().ExemptOfficers ~= false, exemptOnlyOnDuty = cfg().ExemptOnlyOnDuty ~= false,
        exemptionEndsOnExit = cfg().ExemptionEndsOnExit ~= false,
        interval = cfg().CheckInterval or 400,
    }
end

Alert.public = publicAlert

local function gate(source)
    local user_id = P.getUserId(source)
    if not user_id then return nil end
    local profile = Gov.getProfile(user_id, true)
    if not BoFaisaL.feature("SecurityTools") or not Gov.has(profile, "securityAlert") then
        BoFaisaL.notify(source, "err_no_permission", nil, "error")
        return nil
    end
    if not Officers.dutyOk(user_id, "securityAlert") then
        BoFaisaL.notify(source, "err_not_on_duty", nil, "error")
        return nil
    end
    return user_id
end

-- Each officer owns at most one alert.
function Alert.ownedBy(user_id)
    for id, a in pairs(Alert.active) do
        if a.by == user_id then return id, a end
    end
    return nil
end

-- The zone is always a circle centred on the officer who starts it.
function Alert.start(source)
    local user_id = gate(source)
    if not user_id then return end
    if Alert.ownedBy(user_id) then return BoFaisaL.notify(source, "alert_already_own", nil, "error") end
    if Utils.count(Alert.active) >= (cfg().MaxActive or 3) then return BoFaisaL.notify(source, "alert_max", nil, "error") end
    local coords = P.coords(source)
    if not coords then return BoFaisaL.notify(source, "err_internal", nil, "error") end
    local radius = tonumber(cfg().Radius) or 200.0
    Alert.seq = Alert.seq + 1
    local label = L("alert_label", { name = P.name(user_id) })
    local a = {
        id = Alert.seq, label = label, coords = coords, radius = radius,
        startedAt = BoFaisaL.now(), by = user_id, byName = P.name(user_id), exempt = {},
    }
    -- Capture the occupants at activation time.
    local serverSide = P.oneSync()
    if serverSide then
        for _, p in ipairs(P.online()) do
            local c = P.coords(p.source)
            if c and Utils.dist2d(c, coords) <= radius then a.exempt[p.source] = true end
        end
    end
    Alert.active[a.id] = a
    local payload = publicAlert(a)
    for _, p in ipairs(P.online()) do
        -- true = exempt, false = affected on entry, nil = client decides at receipt (no OneSync)
        local exempt = nil
        if serverSide then exempt = a.exempt[p.source] == true end
        TriggerClientEvent("bofaisal_police:alert:start", p.source, payload, exempt)
    end
    announce(a, L("alert_broadcast_start"))
    BoFaisaL.notify(source, "alert_started", { zone = label }, "success")
    Logs.add("security", "alert_start", { actor = user_id, fields = {
        { L("alert_zone"), label, true }, { L("alert_radius"), ("%dm"):format(math.floor(radius)), true },
        { L("alert_exempt"), Utils.count(a.exempt), true },
    } })
end

-- Ends an alert and tells everyone. actor = user_id credited in the log.
local function finish(id, a, actor)
    Alert.active[id] = nil
    TriggerClientEvent("bofaisal_police:alert:stop", -1, id)
    announce(a, L("alert_broadcast_stop"))
    Logs.add("security", "alert_stop", { actor = actor, fields = { { L("alert_zone"), a.label, true },
        { L("log_field_duration"), Utils.humanDuration(BoFaisaL.now() - a.startedAt), true } } })
end

-- The alert whose zone the player stands in (the nearest centre when zones overlap).
function Alert.at(source)
    local pos = P.coords(source)
    if not pos then return nil end
    local bestId, best, bestDist
    for id, a in pairs(Alert.active) do
        local d = Utils.dist2d(pos, a.coords)
        if d <= a.radius and (not bestDist or d < bestDist) then bestId, best, bestDist = id, a, d end
    end
    return bestId, best
end

-- Stops the officer's own alert. Without one: the alert he stands in, whoever started it.
function Alert.stop(source)
    local user_id = gate(source)
    if not user_id then return end
    local id, a = Alert.ownedBy(user_id)
    if not id then
        id, a = Alert.at(source)
        if not id then return BoFaisaL.notify(source, "alert_stop_outside", nil, "error") end
    end
    finish(id, a, user_id)
    BoFaisaL.notify(source, "alert_stopped", { zone = a.label }, "success")
    -- Someone else's alert: its owner is told who stopped it.
    local ownerSrc = a.by ~= user_id and P.getSource(a.by)
    if ownerSrc then BoFaisaL.notify(ownerSrc, "alert_stopped_by_other", { name = P.name(user_id), zone = a.label }, "info", 10) end
end

function Alert.menu(source, parent)
    local user_id = gate(source)
    if not user_id then return nil end
    local _, own = Alert.ownedBy(user_id)
    local stopDesc = own and L("alert_stop_desc", { since = Utils.humanDuration(BoFaisaL.now() - own.startedAt) }) or L("alert_stop_desc_none")
    return {
        title = L("menu_security_alert"),
        items = {
            { label = L("alert_start"), description = L("alert_start_desc", { radius = math.floor(tonumber(cfg().Radius) or 200) }), action = function(src) Alert.start(src) end },
            { label = L("alert_stop"), description = stopDesc, action = function(src) Alert.stop(src) end },
        },
        parent = parent,
    }
end

-- Late joiners: active alerts affect them (they were not inside at activation).
BoFaisaL.on("playerReady", function(user_id, source)
    local list = {}
    for _, a in pairs(Alert.active) do list[#list + 1] = publicAlert(a) end
    if #list > 0 then TriggerClientEvent("bofaisal_police:alert:sync", source, list) end
end)

-- An officer's alert ends when they leave, so no alert is left without an owner to stop it.
BoFaisaL.on("playerDropped", function(user_id, source)
    for id, a in pairs(Alert.active) do
        if a.by == user_id then
            finish(id, a, user_id)
        elseif source then
            a.exempt[source] = nil
        end
    end
end)
