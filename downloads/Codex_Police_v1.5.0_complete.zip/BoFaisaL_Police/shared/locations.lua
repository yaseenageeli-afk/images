--[[
    BoFaisaL_Police — locations edited from إدارة اللوحة

    The panel can override every place of config/coords.lua: fine payment points, impound
    centres, jail entry / exit / centre / radius / return point, jail tasks and the recall HQ.
    Overrides are stored in the database (server) and sent to every client. A section that was
    never edited keeps the value of config/coords.lua.

    ApplyLocations(loc) rebuilds the runtime Config from the ORIGINAL config values and then
    applies the overrides, so removing an override brings the config value back.
      loc = {
        finePoints = { { id, label, x, y, z, radius, style } },
        impounds   = { { id, label, x, y, z, radius, style } },
        jail       = { entry = { x, y, z, h }, exit = { x, y, z, h }, center = { x, y, z }, radius, returnPoint = { x, y, z } | false },
        jailTasks  = { { id, label, x, y, z, radius, type, difficulty, duration, reduction, cooldown, style } },
        recallHQ   = { x, y, z },
      }
]]

local original = nil

local function copy(t)
    if type(t) ~= "table" then return t end
    local out = {}
    for k, v in pairs(t) do out[k] = copy(v) end
    return out
end

local function vec(p)
    if type(p) ~= "table" or not tonumber(p.x) then return nil end
    return vector3(tonumber(p.x) + 0.0, tonumber(p.y) + 0.0, tonumber(p.z) + 0.0)
end

-- Remembers the values coming from config/coords.lua (first call only).
local function capture()
    if original then return end
    original = {
        finePoints = copy(Config.Fines.PaymentPoints or {}),
        impounds = copy(Config.Impound.Locations or {}),
        jail = {
            Entry = Config.Jail.Entry, EntryHeading = Config.Jail.EntryHeading,
            Exit = Config.Jail.Exit, ExitHeading = Config.Jail.ExitHeading,
            Center = Config.Jail.Center, Radius = Config.Jail.Radius, ReturnLocation = Config.Jail.ReturnLocation,
        },
        jailTasks = copy((Config.Jail.Tasks and Config.Jail.Tasks.List) or {}),
        recallHQ = Config.Recall and Config.Recall.HQ,
    }
end

-- Marker / blip style of new points: the style of the first point in config/coords.lua.
local function style(list, fallbackMarker, fallbackBlip)
    local first = list[1] or {}
    return copy(first.marker or fallbackMarker), copy(first.blip or fallbackBlip)
end

-- A shape of Config.MarkerStyles as a marker table (copy), or nil when unknown.
-- The "none" shape (type -1) gives { enabled = false }.
function MarkerStyle(id)
    if type(id) ~= "string" then return nil end
    for _, s in ipairs(Config.MarkerStyles or {}) do
        if s.id == id then
            if (tonumber(s.type) or -1) < 0 then return { enabled = false, style = id } end
            local m = copy(s)
            m.style = id
            m.enabled = true
            return m
        end
    end
    return nil
end

-- section = "finePoints" | "impounds" | "jailTasks": its default shape when a point has none.
local function markerFor(p, section, fallback)
    return MarkerStyle(p.style) or MarkerStyle(Config.MarkerStyleDefaults and Config.MarkerStyleDefaults[section]) or copy(fallback)
end

local function points(list, section, marker, blip)
    local out = {}
    for i, p in ipairs(list) do
        local coords = vec(p)
        if coords then
            out[#out + 1] = {
                id = p.id or ("point_" .. i), label = p.label or "", coords = coords,
                radius = tonumber(p.radius) or 2.0, style = p.style, marker = markerFor(p, section, marker), blip = copy(blip),
            }
        end
    end
    return out
end

function ApplyLocations(loc)
    capture()
    loc = type(loc) == "table" and loc or {}

    -- Fine payment points
    local fineMarker, fineBlip = style(original.finePoints,
        { enabled = true, type = 2, color = { 220, 38, 38, 210 }, scale = { 0.35, 0.35, 0.35 }, rotation = { 0.0, 180.0, 0.0 }, offsetZ = 0.35, bob = true, rotate = true, drawDistance = 15.0 },
        { enabled = true, sprite = 525, color = 1, scale = 0.8, label = "سداد المخالفات" })
    Config.Fines.PaymentPoints = loc.finePoints and points(loc.finePoints, "finePoints", fineMarker, fineBlip) or copy(original.finePoints)

    -- Impound centres
    local impMarker, impBlip = style(original.impounds,
        { enabled = true, type = 36, color = { 37, 99, 235, 190 }, scale = { 0.9, 0.9, 0.9 }, offsetZ = 0.6, rotate = true, drawDistance = 20.0 },
        { enabled = true, sprite = 524, color = 1, scale = 0.8, label = "حجز المركبات" })
    Config.Impound.Locations = loc.impounds and points(loc.impounds, "impounds", impMarker, impBlip) or copy(original.impounds)

    -- Jail places
    local o, j = original.jail, loc.jail or {}
    Config.Jail.Entry = vec(j.entry) or o.Entry
    Config.Jail.EntryHeading = (j.entry and tonumber(j.entry.h)) or o.EntryHeading
    Config.Jail.Exit = vec(j.exit) or o.Exit
    Config.Jail.ExitHeading = (j.exit and tonumber(j.exit.h)) or o.ExitHeading
    Config.Jail.Center = vec(j.center) or o.Center
    Config.Jail.Radius = tonumber(j.radius) or o.Radius
    if j.returnPoint == false then
        Config.Jail.ReturnLocation = nil
    else
        Config.Jail.ReturnLocation = vec(j.returnPoint) or o.ReturnLocation
    end

    -- Jail tasks
    Config.Jail.Tasks = Config.Jail.Tasks or {}
    if loc.jailTasks then
        local list = {}
        for i, t in ipairs(loc.jailTasks) do
            local coords = vec(t)
            if coords then
                list[#list + 1] = {
                    id = t.id or ("task_" .. i), label = t.label or "", coords = coords, radius = tonumber(t.radius) or 2.0,
                    type = t.type, difficulty = t.difficulty, duration = tonumber(t.duration) or 20,
                    reduction = tonumber(t.reduction) or 60, cooldown = tonumber(t.cooldown) or 120,
                    style = t.style, marker = markerFor(t, "jailTasks", Config.Jail.Tasks.Marker), ui = t.ui,
                }
            end
        end
        Config.Jail.Tasks.List = list
    else
        Config.Jail.Tasks.List = copy(original.jailTasks)
    end

    -- Recall HQ
    Config.Recall = Config.Recall or {}
    Config.Recall.HQ = vec(loc.recallHQ) or original.recallHQ
end
