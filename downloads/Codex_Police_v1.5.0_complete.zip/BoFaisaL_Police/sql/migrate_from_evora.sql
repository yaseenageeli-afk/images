-- Run once with BOTH resources stopped and a database backup.
-- Destination tables must NOT already exist. Renaming preserves all data.
RENAME TABLE
 `evora_police_players` TO `bofaisal_police_players`,
 `evora_police_officers` TO `bofaisal_police_officers`,
 `evora_police_attendance` TO `bofaisal_police_attendance`,
 `evora_police_vacations` TO `bofaisal_police_vacations`,
 `evora_police_pending` TO `bofaisal_police_pending`,
 `evora_police_reports` TO `bofaisal_police_reports`,
 `evora_police_wanted` TO `bofaisal_police_wanted`,
 `evora_police_fines` TO `bofaisal_police_fines`,
 `evora_police_jail` TO `bofaisal_police_jail`,
 `evora_police_jail_history` TO `bofaisal_police_jail_history`,
 `evora_police_impounds` TO `bofaisal_police_impounds`,
 `evora_police_logs` TO `bofaisal_police_logs`,
 `evora_police_meta` TO `bofaisal_police_meta`,
 `evora_police_mugshots` TO `bofaisal_police_mugshots`;
