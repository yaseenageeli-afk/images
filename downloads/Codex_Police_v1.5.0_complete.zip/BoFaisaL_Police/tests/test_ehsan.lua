local handlers,cases,donations,balances,online={},{},{},{[1]=1000,[2]=100},{[1]=10,[2]=20}
local adminUser=99
Config={Ehsan={Enabled=true,RequireApproval=true,MaxTarget=10000,MinDonation=1,MaxDonation=1000,CreateCooldownHours=24,AdminPermission='owner'}}
BoFaisaL={DB={ready=true,schema={}},RPC={},Players={},Framework={},Logs={add=function()end},now=function()return 100000 end,error=function()end}
local B=BoFaisaL;local DB=B.DB
function B.RPC.register(name,opts,fn) handlers[name]=fn end
function B.RPC.int(v,min,max) v=tonumber(v);if not v or v~=v or v%1~=0 or v<(min or -math.huge) or v>(max or math.huge) then return nil end;return v end
function B.RPC.text(v,max) return type(v)=='string' and #v>0 and v:sub(1,max) or nil end
function B.RPC.oneOf(v,list)for _,x in ipairs(list)do if x==v then return v end end end
function B.Players.getSource(uid)return online[uid]end
function B.Players.isOnline(uid)return online[uid]~=nil end
function B.Framework.call(method,uid)if method=='hasPermission' then return uid==adminUser end end
function B.Framework.getMoney(uid)return balances[uid] or 0 end
function B.Framework.getBankMoney(uid)return 0 end
local payMode='normal';local reentry
function B.Framework.pay(uid,amount)
 if payMode=='reentry' then reentry={handlers['ehsan:donate']({user_id=1,source=10,name='one'},{id=1,amount=20})} end
 balances[uid]=balances[uid]-amount
 if payMode=='timeout' then return false end
 return true
end
function B.Framework.giveMoney(uid,amount) balances[uid]=(balances[uid] or 0)+amount end
function DB.scalar(sql,p)
 if sql:find('COUNT') then local count=0;for _,d in pairs(donations)do if d.status=='prepared' or d.status=='deducted' or d.status=='credited' then count=count+1 end end;return count end
 local sum=0;for _,d in pairs(donations)do if d.case_id==p[1] and d.status=='paid' then sum=sum+d.amount end end;return sum
end
function DB.single(sql,p)
 if sql:find('WHERE id') then local r=cases[p[1]];if sql:find("status='active'") and r and r.status~='active' then return nil end;return r end
 for _,r in pairs(cases)do if r.user_id==p[1] and (r.status=='active' or r.status=='pending' or r.created_at>p[2]) then return r end end
end
function DB.query(sql,p)
 local rows={};for _,r in pairs(cases)do rows[#rows+1]=r end;return rows
end
function DB.insert(sql,p)
 if sql:find('ehsan_cases') then local id=#cases+1;cases[id]={id=id,user_id=p[1],name=p[2],reason=p[3],target=p[4],status=p[5],created_at=p[6]};return id end
 local id=#donations+1;donations[id]={id=id,case_id=p[1],donor_id=p[2],recipient_id=p[3],amount=p[4],status=p[5]};return id
end
function DB.execute(sql,p)
 if sql:find('ehsan_cases') then
  if sql:find("status='completed'") then cases[p[1]].status='completed';return 1 end
  if not cases[p[2]] or cases[p[2]].status~=p[3] then return 0 end
  cases[p[2]].status=p[1];return 1
 end
 local status=sql:match("SET status='(%w+)'");donations[p[1]].status=status;return 1
end
function RegisterCommand()end
assert(loadfile('server/ehsan.lua'))()
local one={user_id=1,source=10,name='one'};local two={user_id=2,source=20,name='two'};local boss={user_id=99,source=99,name='admin'}
local n=0
local function pass(label,condition)assert(condition,label);n=n+1 end
pass('create request',handlers['ehsan:create'](two,{amount=500,reason='debt',user_id=999,name='forged'})~=nil)
pass('identity derived from context',cases[1].user_id==2 and cases[1].name=='two')
pass('approval default pending',cases[1].status=='pending')
pass('one active case per citizen',handlers['ehsan:create'](two,{amount=200,reason='second'})==nil)
pass('cannot donate to pending',handlers['ehsan:donate'](one,{id=1,amount=10})==nil)
pass('non-admin cannot approve',handlers['ehsan:moderate'](one,{id=1,decision='approve'})==nil)
pass('admin can approve',handlers['ehsan:moderate'](boss,{id=1,decision='approve'})~=nil)
for _,amount in ipairs({0,-1,1.5,1001,math.huge})do pass('invalid amount '..tostring(amount),handlers['ehsan:donate'](one,{id=1,amount=amount})==nil)end
pass('self donation denied',handlers['ehsan:donate'](two,{id=1,amount=10})==nil)
online[2]=nil
pass('offline recipient denied',handlers['ehsan:donate'](one,{id=1,amount=10})==nil);online[2]=20
pass('target cap',handlers['ehsan:donate'](one,{id=1,amount=501})==nil)
balances[1]=1
pass('insufficient cash',handlers['ehsan:donate'](one,{id=1,amount=100})==nil);balances[1]=1000
payMode='reentry'
pass('normal donation',handlers['ehsan:donate'](one,{id=1,amount=100})~=nil)
pass('serializes concurrent donation',reentry[1]==nil)
pass('wallet amounts and persisted journal',balances[1]==900 and balances[2]==200 and donations[1].status=='paid')
pass('remaining cap after prior donation',handlers['ehsan:donate'](one,{id=1,amount=401})==nil)
payMode='timeout'
pass('ambiguous wallet mutation denied',handlers['ehsan:donate'](one,{id=1,amount=100})==nil)
pass('ambiguous operation retains journal',donations[2].status=='prepared')
local before=balances[1];payMode='normal'
pass('retry blocked until reconciliation',handlers['ehsan:donate'](one,{id=1,amount=100})==nil and balances[1]==before)
-- Simulate an administrator resolving the deducted-but-not-credited journal after inspecting wallet evidence.
donations[2].status='failed'
pass('completion donation',handlers['ehsan:donate'](one,{id=1,amount=400})~=nil)
pass('completed case',cases[1].status=='completed')
pass('completed case rejects donation',handlers['ehsan:donate'](one,{id=1,amount=1})==nil)
pass('no extra deductions on rejected requests',balances[1]==400 and balances[2]==600)
print('Ehsan mocked server checks passed: '..n)
