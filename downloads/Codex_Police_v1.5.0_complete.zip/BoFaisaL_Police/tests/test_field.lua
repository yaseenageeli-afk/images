-- Exercise the actual field module with the archive's legacy defaults and live rank grants.
dofile('config/config.lua');dofile('config/settings.lua');dofile('config/locale.lua')
function L(key)return Locale[key] or key end
local n=0;local function check(text,c)assert(c,text);n=n+1 end
local map={cuff='fieldCuff',seizeWeapons='fieldSeizeWeapons',drag='fieldDrag',search='fieldSearch',vehicleSearch='fieldVehicleSearch',putInVehicle='fieldPutInVehicle',pullOutVehicle='fieldPullOutVehicle',seizeContraband='fieldSeizeContraband',identity='fieldIdentity'}
local profile={perms={}};local duty=true;local notified,nearest,called=false,false,false
local B={DB={},Players={getUserId=function()return 1 end},Gov={FIELD_PERMS=map,getProfile=function()return profile end,has=function(p,k)return p.perms[k]==true end},Logs={},Officers={dutyOk=function()return duty end},Confirm={},Targets={nearest=function(_,fn)nearest=true;fn(20,2)end},RPC={register=function()end},Integrations={},feature=function()return true end,notify=function()notified=true end,on=function()end}
BoFaisaL=B;function GetGameTimer()return 10000 end
dofile('server/field.lua')
for name,perm in pairs(map)do profile.perms[perm]=true;check(name..' legacy permission mapped',B.Field.permOf(name)==perm)end
local menu=B.Field.menu(10,function()end);check('all nine configured actions appear',#menu.items==9)
profile.perms={fieldCuff=true};menu=B.Field.menu(10);check('only authorized action appears',#menu.items==1)
local actualRun=B.Field.run
B.Field.run=function(_,name,src,id)called=name=='cuff' and src==20 and id==2 end
menu.items[1].action(10);check('nearest player callback preserved',nearest and called)
duty=false;nearest=false;called=false;menu.items[1].action(10);check('off duty action refused',not nearest and not called)
profile.perms={};notified=false;check('unauthorized avoids empty back-only menu',B.Field.menu(10)==nil and notified)
Config.Field.Actions.cuff.permission='customCuff';profile.perms={fieldCuff=true};check('custom permission not bypassed',B.Field.menu(10)==nil)
profile.perms.customCuff=true;check('custom granted permission works',#B.Field.menu(10).items==1)
Config.Field.Actions.cuff.enabled=false;check('disabled action stays disabled',B.Field.menu(10)==nil)
-- Run the real handler too: permission, duty and proximity must pass before handcuff effects.
B.Field.run=actualRun;Config.Field.Actions.cuff.permission='police.em';Config.Field.Actions.cuff.enabled=true
profile.perms={fieldCuff=true};duty=true;local close=true;local cuffed=false
B.Targets.check=function()return close,'target_too_far' end;B.Targets.allowSelf=function()return false end
B.Players.name=function()return 'اختبار' end
B.Immunity={has=function()return false end};B.Integrations.Handcuff={toggle=function()cuffed=true;return true end}
B.Logs.add=function()end;function TriggerClientEvent()end
B.Field.last={};B.Field.run(10,'cuff',20,2);check('real authorized cuff executes',cuffed)
B.Field.last={};cuffed=false;close=false;B.Field.run(10,'cuff',20,2);check('distant target cannot be cuffed',not cuffed)
B.Field.last={};close=true;profile.perms={};B.Field.run(10,'cuff',20,2);check('real unauthorized cuff rejected',not cuffed)
print('Field permission and callback checks passed: '..n)
