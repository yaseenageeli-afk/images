-- Run from the resource directory with Lua 5.4: lua tests/test_database.lua
-- Models FiveM's empty-table-as-list export bridge; does not require a live SQL server.
local total = 0
local function check(label, condition)
    assert(condition, label)
    total = total + 1
end
for _, driverName in ipairs({ 'mysql-async', 'ghmattimysql', 'oxmysql' }) do
    local calls, errors = {}, {}
    local named = driverName ~= 'oxmysql'
    Config = { Database = { Driver = driverName, AutoCreateTables = true } }
    BoFaisaL = {
        error = function(...) errors[#errors+1] = {...} end,
        print = function() end,
        debug = function() end,
        thread = function(fn) fn() end,
    }
    function GetResourceState(name) return name == driverName and 'started' or 'stopped' end
    function SetTimeout() end
    promise = { new = function()
        return { resolve = function(self, value) self.result = value; self.done = true end }
    end }
    Citizen = { Await = function(p)
        assert(p.done, 'Mock driver callback was not invoked')
        return p.result
    end }
    local function record(kind, sql, params, cb)
        if named then
            -- FiveM sends {} as a List; mysql-async's C# export requires IDictionary.
            assert(next(params) ~= nil, 'List cannot be cast to IDictionary: empty named parameters')
            for k in pairs(params) do assert(type(k) == 'string', 'Named parameters must have string keys') end
        end
        calls[#calls+1] = { kind=kind, sql=sql, params=params }
        if kind == 'query' then
            cb(sql:find('COUNT') and {{c=1}} or {{value=7}})
        elseif kind == 'insert' then cb(99)
        else cb(1) end
    end
    exports = {
        ['mysql-async'] = {
            mysql_fetch_all = function(_, sql, p, cb) record('query', sql, p, cb) end,
            mysql_execute = function(_, sql, p, cb) record('execute', sql, p, cb) end,
            mysql_insert = function(_, sql, p, cb) record('insert', sql, p, cb) end,
        },
        ghmattimysql = { execute = function(_, sql, p, cb)
            if sql:find('^SELECT') then record('query', sql, p, cb)
            else record('execute', sql, p, function() cb({affectedRows=1, insertId=99}) end) end
        end },
        oxmysql = {
            query = function(_, sql, p, cb) record('query', sql, p, cb) end,
            update = function(_, sql, p, cb) record('execute', sql, p, cb) end,
            insert = function(_, sql, p, cb) record('insert', sql, p, cb) end,
        },
    }
    assert(loadfile(DATABASE_SOURCE or 'server/core/database.lua'))()
    local DB = BoFaisaL.DB
    check(driverName..': initialization', DB.init() == true)
    check(driverName..': bridge errors during schema creation', #errors == 0)
    local creates = 0
    for _, call in ipairs(calls) do if call.sql:find('CREATE TABLE') then creates=creates+1 end end
    check(driverName..': all base tables submitted', creates == #DB.schema)
    check(driverName..': execute without placeholders', DB.execute('UPDATE test SET amount=0') == 1)
    check(driverName..': select without placeholders', DB.scalar('SELECT 7') == 7)
    check(driverName..': insert without placeholders', DB.insert('INSERT INTO test (amount) VALUES (1)') == 99)
    local before = #calls
    DB.fire('DELETE FROM test WHERE amount=0', {})
    check(driverName..': fire without placeholders', #calls == before + 1)
    DB.execute('UPDATE test SET a=? WHERE id=?', {'text', 12})
    local c = calls[#calls]
    check(driverName..': ordinary placeholders', named and c.sql=='UPDATE test SET a=@p1 WHERE id=@p2' and c.params['@p1']=='text' and c.params['@p2']==12 or not named and c.params[1]=='text' and c.params[2]==12)
    DB.execute('UPDATE test SET a=?', { DB.NULL })
    c = calls[#calls]
    check(driverName..': NULL-only query still has dictionary', c.sql=='UPDATE test SET a=NULL' and (not named or next(c.params)~=nil))
    DB.execute('UPDATE test SET a=?,b=?,c=?', {true, false, 9007199254740992})
    c = calls[#calls]
    local p1,p2,p3 = named and c.params['@p1'] or c.params[1], named and c.params['@p2'] or c.params[2], named and c.params['@p3'] or c.params[3]
    check(driverName..': boolean and large integer conversion', p1==1 and p2==0 and p3=='9007199254740992')
    local q,p = DB.named('UPDATE test SET a=@amount', {amount=15})
    DB.execute(q,p)
    c=calls[#calls]
    check(driverName..': external named SQL helper', named and c.params['@p1']==15 or not named and c.params[1]==15)
    check(driverName..': no bridge errors in any path', #errors==0)
end
print('Database adapter mock checks passed: '..total)
