--[[
    BoFaisaL_Police — client core: RPC client, NUI bridge, focus stack, state, generic events.
    The client never decides anything sensitive: it renders UI and performs local effects.
]]

BoFaisaL = BoFaisaL or {}
BoFaisaL.state = { military = false, onDuty = false, vacation = false, jailed = false, permissions = {} }
BoFaisaL.ready = false

function BoFaisaL.debug(category, msg, ...)
    if not Config.Debug then return end
    local ok, text = pcall(string.format, msg, ...)
    print(("^6[BoFaisaL_Police:%s]^7 %s"):format(category, ok and text or msg))
end

-- Same rule as the server: a missing Config.Features entry means disabled.
function BoFaisaL.feature(name)
    local f = Config.Features and Config.Features[name]
    return f ~= nil and f.enabled ~= false
end

function BoFaisaL.hasPerm(perm)
    for _, p in ipairs(BoFaisaL.state.permissions or {}) do
        if p == perm then return true end
    end
    return false
end

---------------------------------------------------------------------------
-- RPC
---------------------------------------------------------------------------
local rpcSeq = 0
local pending = {}

-- Blocking (call from a thread). Returns ok, data | ok = false, errorMessage
function BoFaisaL.rpc(name, payload, timeoutMs)
    rpcSeq = rpcSeq + 1
    local id = rpcSeq
    local p = promise.new()
    pending[id] = p
    TriggerServerEvent("bofaisal_police:rpc", id, name, payload or {})
    SetTimeout(timeoutMs or 90000, function()
        if pending[id] then
            pending[id] = nil
            p:resolve({ ok = false, data = "timeout" })
        end
    end)
    local r = Citizen.Await(p)
    return r.ok, r.data
end

RegisterNetEvent("bofaisal_police:rpc:res", function(id, ok, data)
    local p = pending[id]
    if not p then return end
    pending[id] = nil
    p:resolve({ ok = ok == true, data = data })
end)

---------------------------------------------------------------------------
-- NUI bridge + focus stack
---------------------------------------------------------------------------
UI = UI or {}
local focusLayers = {}

-- Big ids travel as text (Utils.jsonSafe): the UI shows every digit.
function UI.send(action, data)
    SendNUIMessage({ action = action, data = Utils.jsonSafe(data) })
end

-- Several layers (iPad, dialog, panel, menu) can need focus at the same time.
function UI.focus(layer, state, cursor)
    if state then
        focusLayers[layer] = cursor ~= false
    else
        focusLayers[layer] = nil
    end
    local any, anyCursor = false, false
    for _, c in pairs(focusLayers) do
        any = true
        if c then anyCursor = true end
    end
    SetNuiFocus(any, anyCursor)
end

function UI.hasFocus(layer)
    if layer then return focusLayers[layer] ~= nil end
    return next(focusLayers) ~= nil
end

-- The script's own notification (NUI toast).
function UI.toast(message, kind, duration)
    UI.send("toast", { message = message, kind = kind or "info", duration = duration or 6 })
end

function UI.notify(message, kind, duration)
    UI.toast(message, kind, duration or (Config.UI and Config.UI.NotifySeconds) or 6)
end

RegisterNUICallback("ready", function(_, cb)
    UI.ready = true -- the page is loaded: messages sent from now on are received
    UI.send("init", {
        locale = LocaleUI,
        ui = Config.UI,
        portal = Config.Absher,
        confirm = { accept = Config.Confirm.AcceptLabel, reject = Config.Confirm.RejectLabel },
        broadcast = Config.Broadcast.Style,
        spectate = { key = Config.Spectate.StopKeyLabel },
        wanted = Config.Wanted.QuickOpen,
        ipad = { size = Config.Ipad.Size },
        jailHud = (Config.Jail and Config.Jail.Hud and Config.Jail.Hud.Style) or "digital", -- look of the jail counter
        infoCard = (Config.UI and Config.UI.InfoCardStyle) or "file", -- look of the inquiry cards
        toast = (Config.UI and Config.UI.NotifyStyle) or "gradient", -- look of the notifications
        wantedStyle = (Config.Wanted and Config.Wanted.AlertStyle) or "poster", -- look of the wanted alert
        confirmStyle = (Config.UI and Config.UI.ConfirmStyle) or "compact", -- look of the F5 / F6 confirmation
        vehicleSearch = (Config.UI and Config.UI.VehicleSearchStyle) or "list", -- look of the vehicle search window
        finesLook = (Config.UI and Config.UI.FinesStyle) or "cards", -- look of the fines window
        impoundLook = (Config.UI and Config.UI.ImpoundStyle) or "cards", -- look of the impounded vehicles window
        keyHint = (Config.UI and Config.UI.KeyHintStyle) or "glass", -- look of the key hints
        cardPage = { size = (Config.UI and Config.UI.CardPageSize) or 8, keys = Config.UI and Config.UI.CardPageKeys }, -- long lists on the cards
    })
    UI.send("state", BoFaisaL.state)
    if BoFaisaL.theme then UI.send("theme", BoFaisaL.theme) end
    cb({ ok = true })
end)

-- Server-wide UI theme (إدارة اللوحة): colours, transparency and notification positions.
RegisterNetEvent("bofaisal_police:theme", function(theme)
    BoFaisaL.theme = type(theme) == "table" and theme or {}
    UI.send("theme", BoFaisaL.theme)
end)

RegisterNUICallback("rpc", function(data, cb)
    if type(data) ~= "table" or type(data.name) ~= "string" then
        cb({ ok = false, data = "invalid" })
        return
    end
    Citizen.CreateThread(function()
        local ok, result = BoFaisaL.rpc(data.name, data.payload or {})
        cb({ ok = ok, data = Utils.jsonSafe(result) })
    end)
end)

RegisterNUICallback("close", function(data, cb)
    local layer = type(data) == "table" and data.layer or nil
    if layer then
        UI.focus(layer, false)
        TriggerEvent("bofaisal_police:client:closed", layer)
    end
    cb({ ok = true })
end)

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
RegisterNetEvent("bofaisal_police:state", function(state)
    if type(state) ~= "table" then return end
    BoFaisaL.state = state
    UI.send("state", state)
    TriggerEvent("bofaisal_police:client:state", state)
end)

---------------------------------------------------------------------------
-- Server → client requests (facts about this client only)
---------------------------------------------------------------------------
BoFaisaL.responders = BoFaisaL.responders or {}

BoFaisaL.responders.coords = function()
    local c = GetEntityCoords(PlayerPedId())
    return { x = c.x, y = c.y, z = c.z }
end

BoFaisaL.responders.nearbyPlayers = function(args)
    local radius = tonumber(args and args.radius) or 4.0
    local me = PlayerPedId()
    local origin = GetEntityCoords(me)
    local list = {}
    for _, player in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(player)
        if ped ~= me and DoesEntityExist(ped) then
            local d = Utils.dist(origin, GetEntityCoords(ped))
            if d <= radius then list[#list + 1] = { source = GetPlayerServerId(player), dist = d } end
        end
    end
    return list
end

local function vehicleInfo(veh, origin)
    return {
        plate = GetVehicleNumberPlateText(veh),
        model = GetEntityModel(veh),
        netId = NetworkGetEntityIsNetworked(veh) and NetworkGetNetworkIdFromEntity(veh) or nil,
        dist = Utils.dist(origin, GetEntityCoords(veh)),
    }
end

BoFaisaL.responders.nearestVehicle = function(args)
    local radius = tonumber(args and args.radius) or 5.0
    local origin = GetEntityCoords(PlayerPedId())
    local best, bestDist
    for _, veh in ipairs(GetGamePool("CVehicle")) do
        local d = Utils.dist(origin, GetEntityCoords(veh))
        if d <= radius and (not bestDist or d < bestDist) then best, bestDist = veh, d end
    end
    return best and vehicleInfo(best, origin) or nil
end

-- plates: one plate or a list of accepted spellings (garage prefixes).
local function plateMatches(veh, plates)
    local plate = Utils.normalizePlate(GetVehicleNumberPlateText(veh) or "")
    if plate == "" then return false end
    for _, p in ipairs(type(plates) == "table" and plates or { plates }) do
        if Utils.normalizePlate(tostring(p)) == plate then return true end
    end
    return false
end

BoFaisaL.responders.vehicleByPlate = function(args)
    local radius = tonumber(args and args.radius) or 8.0
    local plates = args and (args.plates or args.plate) or {}
    local model = tonumber(args and args.model) -- several vehicles can share a plate (vRP)
    local origin = GetEntityCoords(PlayerPedId())
    for _, veh in ipairs(GetGamePool("CVehicle")) do
        if plateMatches(veh, plates) and (not model or GetEntityModel(veh) == model)
            and Utils.dist(origin, GetEntityCoords(veh)) <= radius then
            return vehicleInfo(veh, origin)
        end
    end
    return nil
end

-- The game's name of a vehicle model ("ADDER"), when the garage doesn't know it.
BoFaisaL.responders.modelName = function(args)
    local model = tonumber(args and args.model)
    if not model or not IsModelInCdimage(model) then return nil end
    local name = GetDisplayNameFromVehicleModel(model)
    if type(name) ~= "string" or name == "" or name == "CARNOTFOUND" then return nil end
    return name
end

RegisterNetEvent("bofaisal_police:creq", function(id, name, args)
    local responder = BoFaisaL.responders[name]
    local value = nil
    if responder then
        local ok, result = pcall(responder, args)
        if ok then value = result end
    end
    TriggerServerEvent("bofaisal_police:cres", id, value)
end)

---------------------------------------------------------------------------
-- Generic effects requested by the server
---------------------------------------------------------------------------
local teleportSeq = 0

RegisterNetEvent("bofaisal_police:teleport", function(x, y, z, heading)
    -- Let go of any drag at once: the drag loop would attach the player back to the officer.
    if BoFaisaL.stopDrag then BoFaisaL.stopDrag() end
    teleportSeq = teleportSeq + 1
    local mine = teleportSeq
    local target = vector3(x + 0.0, y + 0.0, z + 0.0)
    local origin = GetEntityCoords(PlayerPedId())
    -- Always the CURRENT ped: putting clothes on (vRP) can replace the character at any moment.
    local function place()
        local ped = PlayerPedId()
        if IsEntityAttached(ped) then DetachEntity(ped, true, false) end -- attached = does not move
        if IsPedInAnyVehicle(ped, false) then ClearPedTasksImmediately(ped) end
        SetEntityCoords(ped, target.x, target.y, target.z, false, false, false, false)
        if heading then SetEntityHeading(ped, heading + 0.0) end
    end
    -- Left behind = still nearer to where he was than to where he was sent (walking away
    -- from the arrival point afterwards is not "left behind").
    local function leftBehind()
        local pos = GetEntityCoords(PlayerPedId())
        local d = #(pos - target)
        return d > 5.0 and #(pos - origin) < d
    end
    Citizen.CreateThread(function()
        DoScreenFadeOut(400)
        local waited = 0
        while not IsScreenFadedOut() and waited < 1000 do
            Citizen.Wait(10)
            waited = waited + 10
        end
        RequestCollisionAtCoord(target.x, target.y, target.z)
        place()
        -- Behind the black screen: make sure he really arrived (a new character or another
        -- script's drag would leave him where he was), placing him again if needed.
        local deadline, steady = GetGameTimer() + 4000, 0
        while GetGameTimer() < deadline and steady < 6 and mine == teleportSeq do
            Citizen.Wait(100)
            if leftBehind() then place() steady = 0 else steady = steady + 1 end
        end
        local timeout = GetGameTimer() + 3000
        while not HasCollisionLoadedAroundEntity(PlayerPedId()) and GetGameTimer() < timeout do
            Citizen.Wait(10)
        end
        DoScreenFadeIn(500)
        -- A few more seconds for a late change of character.
        local late = GetGameTimer() + 5000
        while GetGameTimer() < late and mine == teleportSeq do
            Citizen.Wait(250)
            if leftBehind() then place() end
        end
    end)
end)

RegisterNetEvent("bofaisal_police:waypoint", function(x, y)
    if x and y then
        SetNewWaypoint(x + 0.0, y + 0.0)
        UI.sound("Waypoint")
    end
end)

local function loadDict(dict)
    RequestAnimDict(dict)
    local timeout = GetGameTimer() + 3000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < timeout do Citizen.Wait(10) end
    return HasAnimDictLoaded(dict)
end
BoFaisaL.loadDict = loadDict

RegisterNetEvent("bofaisal_police:anim", function(dict, anim, duration)
    Citizen.CreateThread(function()
        if not loadDict(dict) then return end
        TaskPlayAnim(PlayerPedId(), dict, anim, 8.0, -8.0, duration or 1500, 48, 0, false, false, false)
        RemoveAnimDict(dict)
    end)
end)

RegisterNetEvent("bofaisal_police:armour", function(value)
    SetPedArmour(PlayerPedId(), math.max(0, math.min(100, tonumber(value) or 0)))
end)

RegisterNetEvent("bofaisal_police:vehicle:delete", function(netId, plates)
    if not netId or not NetworkDoesNetworkIdExist(netId) then return end
    local veh = NetworkGetEntityFromNetworkId(netId)
    -- Only the impounded vehicle itself: never another entity behind a stale or forged net id.
    if not DoesEntityExist(veh) or GetEntityType(veh) ~= 2 or not plateMatches(veh, plates) then return end
    Citizen.CreateThread(function()
        local timeout = GetGameTimer() + 2000
        NetworkRequestControlOfEntity(veh)
        while not NetworkHasControlOfEntity(veh) and GetGameTimer() < timeout do
            Citizen.Wait(10)
            NetworkRequestControlOfEntity(veh)
        end
        SetEntityAsMissionEntity(veh, true, true)
        DeleteVehicle(veh)
    end)
end)

---------------------------------------------------------------------------
-- Impounded vehicles (servers without OneSync): any of them spawned by this client is
-- deleted at once (Config.Impound.BlockSpawn). With OneSync the server does it.
---------------------------------------------------------------------------
local blockedVehicles = {}

RegisterNetEvent("bofaisal_police:impound:blocked", function(list)
    blockedVehicles = type(list) == "table" and list or {}
end)

Citizen.CreateThread(function()
    local me = PlayerId()
    while true do
        Citizen.Wait(#blockedVehicles > 0 and 750 or 3000)
        if #blockedVehicles > 0 then
            for _, veh in ipairs(GetGamePool("CVehicle")) do
                if NetworkGetEntityOwner(veh) == me then
                    local model = GetEntityModel(veh) % 4294967296
                    for _, b in ipairs(blockedVehicles) do
                        if (b.model == 0 or b.model == model) and plateMatches(veh, b.plates) then
                            SetEntityAsMissionEntity(veh, true, true)
                            DeleteVehicle(veh)
                            UI.toast(b.message, "error", 10)
                            break
                        end
                    end
                end
            end
        end
    end
end)

---------------------------------------------------------------------------
-- Session start (also after a client-side resource restart)
---------------------------------------------------------------------------
Citizen.CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Citizen.Wait(500) end
    for _ = 1, 60 do
        local ok = BoFaisaL.rpc("session:init", {}, 15000)
        if ok then
            BoFaisaL.ready = true
            break
        end
        Citizen.Wait(5000)
    end
end)

AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
end)
