--[[
    BoFaisaL_Police — client-side integration adapters.
    Used when an integration type is "builtin", "client_export" or when no server system exists.
]]

local function cfg(name) return (Config.Integrations and Config.Integrations[name]) or {} end

---------------------------------------------------------------------------
-- Notifications (the script's own notification)
---------------------------------------------------------------------------
RegisterNetEvent("bofaisal_police:notify", function(message, kind, duration)
    UI.toast(message, kind, duration)
end)

---------------------------------------------------------------------------
-- Handcuffs (builtin)
---------------------------------------------------------------------------
local cuffed = false
local cuffLoop = false -- the per-frame loop of the cuffs is running

-- The hands-behind-the-back pose (Config.Field.Actions.cuff.targetAnimation).
local function cuffPose()
    local c = Config.Field and Config.Field.Actions and Config.Field.Actions.cuff or {}
    return c.targetAnimation ~= false
end

local function applyCuffs(state)
    cuffed = state == true
    local ped = PlayerPedId()
    SetEnableHandcuffs(ped, cuffed)
    if cuffed then
        if cuffLoop then return end -- already cuffed (e.g. jailed while cuffed): one loop only
        cuffLoop = true
        Citizen.CreateThread(function()
            if cuffPose() and not IsPedInAnyVehicle(ped, false) and BoFaisaL.loadDict("mp_arresting") then
                TaskPlayAnim(ped, "mp_arresting", "idle", 8.0, -8.0, -1, 49, 0, false, false, false)
            end
            while cuffed do
                local p = PlayerPedId()
                DisableControlAction(0, 21, true)  -- sprint
                DisableControlAction(0, 22, true)  -- jump
                DisableControlAction(0, 24, true)  -- attack
                DisableControlAction(0, 25, true)  -- aim
                DisableControlAction(0, 140, true) -- melee
                DisableControlAction(0, 141, true)
                DisableControlAction(0, 142, true)
                DisableControlAction(0, 257, true)
                DisableControlAction(0, 263, true)
                DisableControlAction(0, 75, true)  -- leave vehicle
                DisablePlayerFiring(PlayerId(), true)
                if cuffPose() and not IsEntityPlayingAnim(p, "mp_arresting", "idle", 3) and not IsPedInAnyVehicle(p, false)
                    and not (BoFaisaL.jailTask and BoFaisaL.jailTask.active) then
                    TaskPlayAnim(p, "mp_arresting", "idle", 8.0, -8.0, -1, 49, 0, false, false, false)
                end
                Citizen.Wait(0)
            end
            cuffLoop = false
        end)
    else
        ClearPedSecondaryTask(ped)
        StopAnimTask(ped, "mp_arresting", "idle", 1.0)
    end
end

RegisterNetEvent("bofaisal_police:cuff:set", function(state) applyCuffs(state) end)
BoFaisaL.responders["cuff:get"] = function() return cuffed end

-- Seated in a vehicle the cuffed pose would stand the player up through the roof: it is
-- stopped there (whatever system plays it, vRP replays it every few seconds).
local function stopPoseInVehicle(ped)
    if IsPedInAnyVehicle(ped, false) and IsEntityPlayingAnim(ped, "mp_arresting", "idle", 3) then
        StopAnimTask(ped, "mp_arresting", "idle", 2.0)
    end
end

-- Cuffed by this script (any handcuff system): the pose is kept out of vehicles until uncuffed,
-- or until the player has been neither posed nor seated for a while (uncuffed elsewhere).
local cuffedHere, poseWatch = false, false
local function watchVehiclePose()
    if poseWatch then return end
    poseWatch = true
    Citizen.CreateThread(function()
        local idle = 0
        while cuffedHere and idle < 20 do
            local p = PlayerPedId()
            stopPoseInVehicle(p)
            if cuffed or IsEntityPlayingAnim(p, "mp_arresting", "idle", 3) or IsPedInAnyVehicle(p, false) then idle = 0 else idle = idle + 1 end
            Citizen.Wait(500)
        end
        cuffedHere, poseWatch = false, false
    end)
end

RegisterNetEvent("bofaisal_police:cuffstate", function(state)
    cuffedHere = state == true
    if state then watchVehiclePose() end
end)

---------------------------------------------------------------------------
-- Drag (builtin): the target attaches to the officer
---------------------------------------------------------------------------
local dragger = nil

-- Lets go of the player being dragged (a teleport, e.g. jail, must not be pulled back).
function BoFaisaL.stopDrag()
    if not dragger then return end
    dragger = nil
    DetachEntity(PlayerPedId(), true, false)
end

RegisterNetEvent("bofaisal_police:drag", function(officerSource)
    local ped = PlayerPedId()
    if dragger then
        dragger = nil
        DetachEntity(ped, true, false)
        return
    end
    -- Dragging himself (Config.Targeting.AllowSelf): nothing to follow, only the state
    -- (so "إدخال للمركبة" works on himself too).
    if officerSource == GetPlayerServerId(PlayerId()) then
        dragger = officerSource
        return
    end
    local officerPlayer = GetPlayerFromServerId(officerSource)
    if officerPlayer == -1 then return end
    dragger = officerSource
    -- 11816 passed as is (not GetPedBoneIndex): the player follows the officer's body upright.
    -- The pelvis bone index turned him on his side.
    local function attach(me, officerPed)
        AttachEntityToEntity(me, officerPed, 11816, 0.45, 0.45, 0.0, 0.0, 0.0, 0.0, false, false, false, false, 2, true)
    end
    -- Attached at once; the loop only keeps him attached (another script may detach him).
    attach(ped, GetPlayerPed(officerPlayer))
    Citizen.CreateThread(function()
        while dragger do
            Citizen.Wait(250)
            if not dragger then break end
            local officerPed = GetPlayerPed(GetPlayerFromServerId(dragger))
            local me = PlayerPedId()
            if not DoesEntityExist(officerPed) or IsPedInAnyVehicle(me, false) or IsPedDeadOrDying(me, true) then
                dragger = nil
                DetachEntity(me, true, false)
                break
            end
            if not IsEntityAttachedToEntity(me, officerPed) then attach(me, officerPed) end
        end
    end)
end)

---------------------------------------------------------------------------
-- Seats (builtin)
---------------------------------------------------------------------------
local function nearestVehicle(radius)
    local origin = GetEntityCoords(PlayerPedId())
    local best, bestDist
    for _, veh in ipairs(GetGamePool("CVehicle")) do
        local d = Utils.dist(origin, GetEntityCoords(veh))
        if d <= radius and (not bestDist or d < bestDist) then best, bestDist = veh, d end
    end
    return best
end

-- Seated on a free passenger seat (back seats first), never on a seat the model doesn't have.
RegisterNetEvent("bofaisal_police:seat:putIn", function(radius)
    local veh = nearestVehicle(tonumber(radius) or 6.0)
    if not veh then return end
    local ped = PlayerPedId()
    if dragger then
        dragger = nil
        DetachEntity(ped, true, false)
    end
    local passengers = GetVehicleModelNumberOfSeats(GetEntityModel(veh)) - 1
    for seat = passengers - 1, 0, -1 do
        if IsVehicleSeatFree(veh, seat) then
            Citizen.CreateThread(function()
                StopAnimTask(ped, "mp_arresting", "idle", 8.0)
                ClearPedTasksImmediately(ped)
                Citizen.Wait(0) -- one frame after the detach, or the seat is refused
                SetPedIntoVehicle(ped, veh, seat)
                Citizen.Wait(300)
                if not IsPedInVehicle(ped, veh, false) then TaskWarpPedIntoVehicle(ped, veh, seat) end
            end)
            return
        end
    end
end)

RegisterNetEvent("bofaisal_police:seat:pullOut", function()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
        TaskLeaveVehicle(ped, GetVehiclePedIsIn(ped, false), 16)
    end
end)

-- Ground height under the player (إدارة اللوحة: markers are placed on the ground, not at body height).
BoFaisaL.responders["panel:ground"] = function()
    local c = GetEntityCoords(PlayerPedId())
    local found, z = GetGroundZFor_3dCoord(c.x, c.y, c.z + 0.5, false)
    return { z = found and z or (c.z - 0.98) }
end

---------------------------------------------------------------------------
-- Clothing (builtin, jail clothing) — same format as vRP customization
---------------------------------------------------------------------------
BoFaisaL.responders["clothing:get"] = function()
    local ped = PlayerPedId()
    local custom = { modelhash = GetEntityModel(ped) }
    for i = 0, 11 do
        custom[i] = { GetPedDrawableVariation(ped, i), GetPedTextureVariation(ped, i), GetPedPaletteVariation(ped, i) }
    end
    for i = 0, 7 do
        custom["p" .. i] = { GetPedPropIndex(ped, i), math.max(GetPedPropTextureIndex(ped, i), 0) }
    end
    return custom
end

RegisterNetEvent("bofaisal_police:clothing:set", function(custom)
    if type(custom) ~= "table" then return end
    local ped = PlayerPedId()
    for key, value in pairs(custom) do
        if type(value) == "table" then
            local prop = type(key) == "string" and key:match("^p(%d+)$")
            if prop then
                if (tonumber(value[1]) or -1) < 0 then
                    ClearPedProp(ped, tonumber(prop))
                else
                    SetPedPropIndex(ped, tonumber(prop), tonumber(value[1]), tonumber(value[2]) or 0, true)
                end
            elseif tonumber(key) then
                SetPedComponentVariation(ped, tonumber(key), tonumber(value[1]) or 0, tonumber(value[2]) or 0, tonumber(value[3]) or 2)
            end
        end
    end
end)

---------------------------------------------------------------------------
-- Weapons (builtin)
---------------------------------------------------------------------------
local KNOWN_WEAPONS = {
    "WEAPON_KNIFE", "WEAPON_NIGHTSTICK", "WEAPON_HAMMER", "WEAPON_BAT", "WEAPON_CROWBAR", "WEAPON_FLASHLIGHT",
    "WEAPON_MACHETE", "WEAPON_SWITCHBLADE", "WEAPON_KNUCKLE", "WEAPON_PISTOL", "WEAPON_PISTOL_MK2",
    "WEAPON_COMBATPISTOL", "WEAPON_APPISTOL", "WEAPON_STUNGUN", "WEAPON_PISTOL50", "WEAPON_SNSPISTOL",
    "WEAPON_HEAVYPISTOL", "WEAPON_VINTAGEPISTOL", "WEAPON_REVOLVER", "WEAPON_MICROSMG", "WEAPON_SMG",
    "WEAPON_ASSAULTSMG", "WEAPON_COMBATPDW", "WEAPON_MACHINEPISTOL", "WEAPON_MINISMG", "WEAPON_PUMPSHOTGUN",
    "WEAPON_SAWNOFFSHOTGUN", "WEAPON_ASSAULTSHOTGUN", "WEAPON_BULLPUPSHOTGUN", "WEAPON_ASSAULTRIFLE",
    "WEAPON_CARBINERIFLE", "WEAPON_ADVANCEDRIFLE", "WEAPON_SPECIALCARBINE", "WEAPON_BULLPUPRIFLE",
    "WEAPON_COMPACTRIFLE", "WEAPON_MG", "WEAPON_COMBATMG", "WEAPON_GUSENBERG", "WEAPON_SNIPERRIFLE",
    "WEAPON_HEAVYSNIPER", "WEAPON_MARKSMANRIFLE", "WEAPON_GRENADE", "WEAPON_BZGAS", "WEAPON_MOLOTOV",
    "WEAPON_SMOKEGRENADE", "WEAPON_FLARE", "WEAPON_PETROLCAN", "WEAPON_FIREEXTINGUISHER",
}

BoFaisaL.responders["weapons:get"] = function()
    local ped = PlayerPedId()
    local out = {}
    for _, name in ipairs(KNOWN_WEAPONS) do
        local hash = GetHashKey(name)
        if HasPedGotWeapon(ped, hash, false) then out[name] = { ammo = GetAmmoInPedWeapon(ped, hash) } end
    end
    return out
end

RegisterNetEvent("bofaisal_police:weapons:clear", function()
    RemoveAllPedWeapons(PlayerPedId(), true)
end)

RegisterNetEvent("bofaisal_police:weapons:give", function(weapons)
    local ped = PlayerPedId()
    for name, data in pairs(weapons or {}) do
        GiveWeaponToPed(ped, GetHashKey(name), tonumber(type(data) == "table" and data.ammo) or 0, false, false)
    end
end)

---------------------------------------------------------------------------
-- Identity presentation (the target shows the card)
---------------------------------------------------------------------------
RegisterNetEvent("bofaisal_police:idcard:present", function()
    local a = Config.IdCard and Config.IdCard.Animation
    if not a then return end
    Citizen.CreateThread(function()
        if BoFaisaL.loadDict(a.dict) then
            TaskPlayAnim(PlayerPedId(), a.dict, a.name, 8.0, -8.0, a.duration or 1500, 48, 0, false, false, false)
            RemoveAnimDict(a.dict)
        end
    end)
end)
