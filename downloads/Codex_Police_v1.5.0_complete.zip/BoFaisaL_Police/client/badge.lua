--[[
    BoFaisaL_Police — badge animation: the officer holds out his badge (Config.Badge).
]]

local badgeProp = nil

local function removeProp()
    if badgeProp and DoesEntityExist(badgeProp) then
        DetachEntity(badgeProp, true, false)
        DeleteEntity(badgeProp)
    end
    badgeProp = nil
end

RegisterNetEvent("bofaisal_police:badge:anim", function()
    local c = Config.Badge or {}
    if c.Animation == false then return end
    Citizen.CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then return end
        local dict, anim = c.AnimDict or "paper_1_rcm_alt1-9", c.AnimName or "player_one_dual-9"
        if not BoFaisaL.loadDict(dict) then return end
        local p = c.Prop or {}
        if type(p.model) == "string" and p.model ~= "" then
            local hash = GetHashKey(p.model)
            if IsModelInCdimage(hash) then
                RequestModel(hash)
                local timeout = GetGameTimer() + 3000
                while not HasModelLoaded(hash) and GetGameTimer() < timeout do Citizen.Wait(10) end
                if HasModelLoaded(hash) then
                    removeProp()
                    local pos = GetEntityCoords(ped)
                    badgeProp = CreateObject(hash, pos.x, pos.y, pos.z + 0.2, true, true, false)
                    SetModelAsNoLongerNeeded(hash)
                    local o, r = p.offset or {}, p.rotation or {}
                    AttachEntityToEntity(badgeProp, ped, GetPedBoneIndex(ped, p.bone or 28422),
                        (o[1] or 0.0) + 0.0, (o[2] or 0.0) + 0.0, (o[3] or 0.0) + 0.0, (r[1] or 0.0) + 0.0, (r[2] or 0.0) + 0.0, (r[3] or 0.0) + 0.0,
                        true, true, false, true, 1, true)
                end
            end
        end
        local ms = math.floor((c.AnimSeconds or 3) * 1000)
        TaskPlayAnim(ped, dict, anim, 8.0, -8.0, ms, 49, 0, false, false, false)
        Citizen.Wait(ms)
        StopAnimTask(ped, dict, anim, 1.0)
        removeProp()
    end)
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then removeProp() end
end)
