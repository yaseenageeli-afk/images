--[[
    BoFaisaL_Police — barricade placement preview (client)

    A local, non-networked ghost is placed in front of the officer and then moved with keys
    (it does not follow him): arrows move, mouse wheel rotates, E places, BACKSPACE cancels.
    The server validates and creates the real object (OneSync). Without OneSync the client
    creates it and the server only tracks it.
]]

local placing = false

local function loadModel(hash)
    RequestModel(hash)
    local timeout = GetGameTimer() + 3000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Citizen.Wait(10) end
    return HasModelLoaded(hash)
end

-- Spike strips (الشوك): any barricade with spikes = true.
local function spikeOptions() return (Config.BarricadeOptions and Config.BarricadeOptions.Spikes) or {} end
local SPIKE_DICT = "p_ld_stinger_s"

-- The strip unfolds on the ground (idle = already spread, for the placement preview).
local function spreadSpike(entity, idle)
    if spikeOptions().Deploy == false or not BoFaisaL.loadDict(SPIKE_DICT) then return end
    PlayEntityAnim(entity, idle and "p_stinger_s_idle_deployed" or "p_stinger_s_deploy", SPIKE_DICT, 1000.0, false, true, false, 0.0, 0)
end

RegisterNetEvent("bofaisal_police:barricade:place", function(index, model, label, distance, serverSide)
    if placing then return end
    local hash = GetHashKey(model)
    if not IsModelInCdimage(hash) or not loadModel(hash) then
        UI.notify(model, "error")
        return
    end
    placing = true
    local entry = Config.Barricades and Config.Barricades[index]
    local spikes = type(entry) == "table" and entry.spikes == true
    Citizen.CreateThread(function()
        local ped = PlayerPedId()
        local origin = GetEntityCoords(ped)
        local ghost = CreateObject(hash, origin.x, origin.y, origin.z, false, false, false)
        SetEntityAlpha(ghost, 160, false)
        SetEntityCollision(ghost, false, false)
        FreezeEntityPosition(ghost, true)
        if spikes then spreadSpike(ghost, true) end
        -- The ghost does NOT follow the officer: it starts in front of him and is moved with keys.
        --   Arrows = move (relative to the camera) · SHIFT = faster · Mouse wheel = rotate
        --   E = place · BACKSPACE = cancel
        local fwd = GetEntityForwardVector(ped)
        local gx, gy, gz = origin.x + fwd.x * (distance or 2.2), origin.y + fwd.y * (distance or 2.2), origin.z
        local heading = GetEntityHeading(ped)
        local maxDist = math.max(1.5, ((Config.BarricadeOptions and Config.BarricadeOptions.MaxPlaceDistance) or 6.0) - 0.5)
        local confirmed = false
        UI.hint("E", label .. " — " .. LocaleUI.barricade_hint, "barricade")
        while placing do
            ped = PlayerPedId()
            -- Movement / weapon wheel / phone keys are used by the placement.
            for _, c in ipairs({ 14, 15, 16, 17, 27, 172, 173, 174, 175, 241, 242, 261, 262 }) do DisableControlAction(0, c, true) end
            local step = IsControlPressed(0, 21) and 0.12 or 0.04
            local camHeading = math.rad(GetGameplayCamRot(2).z)
            local fx, fy = -math.sin(camHeading), math.cos(camHeading) -- camera forward
            local rx, ry = fy, -fx                                     -- camera right
            if IsDisabledControlPressed(0, 172) then gx, gy = gx + fx * step, gy + fy * step end
            if IsDisabledControlPressed(0, 173) then gx, gy = gx - fx * step, gy - fy * step end
            if IsDisabledControlPressed(0, 175) then gx, gy = gx + rx * step, gy + ry * step end
            if IsDisabledControlPressed(0, 174) then gx, gy = gx - rx * step, gy - ry * step end
            if IsDisabledControlJustPressed(0, 241) or IsDisabledControlJustPressed(0, 261) then heading = heading + 7.5 end
            if IsDisabledControlJustPressed(0, 242) or IsDisabledControlJustPressed(0, 262) then heading = heading - 7.5 end
            -- Stay within the distance the server accepts.
            local pos = GetEntityCoords(ped)
            local dx, dy = gx - pos.x, gy - pos.y
            local d = math.sqrt(dx * dx + dy * dy)
            if d > maxDist then gx, gy = pos.x + dx / d * maxDist, pos.y + dy / d * maxDist end
            local found, groundZ = GetGroundZFor_3dCoord(gx, gy, pos.z + 2.0, false)
            gz = found and groundZ or pos.z
            SetEntityCoords(ghost, gx, gy, gz, false, false, false, false)
            PlaceObjectOnGroundProperly(ghost)
            SetEntityHeading(ghost, heading)
            if IsControlJustReleased(0, 38) then
                confirmed = true
                break
            end
            if IsDisabledControlJustReleased(0, 194) or IsControlJustReleased(0, 194) or IsControlJustReleased(0, 177) or IsPedInAnyVehicle(ped, false) then
                break
            end
            Citizen.Wait(0)
        end
        local final = GetEntityCoords(ghost)
        local heading = GetEntityHeading(ghost)
        DeleteEntity(ghost)
        UI.hideHint("barricade")
        placing = false
        if not confirmed then
            SetModelAsNoLongerNeeded(hash)
            return
        end
        -- The officer bends down and lays the spike strip on the ground.
        if spikes and spikeOptions().PlaceAnimation ~= false and BoFaisaL.loadDict("pickup_object") then
            TaskPlayAnim(ped, "pickup_object", "pickup_low", 8.0, -8.0, 1100, 0, 0, false, false, false)
            Citizen.Wait(750)
        end
        local payload = { index = index, x = final.x, y = final.y, z = final.z, heading = heading }
        local object
        if not serverSide then
            object = CreateObject(hash, final.x, final.y, final.z, true, true, false)
            SetEntityHeading(object, heading)
            PlaceObjectOnGroundProperly(object)
            FreezeEntityPosition(object, true)
            payload.netId = NetworkGetNetworkIdFromEntity(object)
        end
        SetModelAsNoLongerNeeded(hash)
        local ok, err = BoFaisaL.rpc("barricade:place", payload)
        if not ok then
            if object and DoesEntityExist(object) then DeleteEntity(object) end
            UI.notify(err, "error")
        else
            UI.sound("Barricade")
        end
    end)
end)

local barricadeModels = {}
for _, o in ipairs(Config.Barricades or {}) do
    if type(o) == "table" and type(o.model) == "string" then barricadeModels[GetHashKey(o.model)] = true end
end

-- Without OneSync the server asks every client to remove a tracked barricade. Net ids are
-- reported by the placing client, so only configured barricade props are ever deleted.
RegisterNetEvent("bofaisal_police:barricade:delete", function(netId)
    if not netId or not NetworkDoesNetworkIdExist(netId) then return end
    local object = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(object) or GetEntityType(object) ~= 3 or not barricadeModels[GetEntityModel(object)] then return end
    if NetworkHasControlOfEntity(object) then DeleteEntity(object) end
end)

---------------------------------------------------------------------------
-- Spike strips: every player sees them spread on the ground, and the tyres of a car driven over
-- one burst. Each driver checks his own car (a burst tyre is synced by the car's owner).
---------------------------------------------------------------------------
local spikeModels = {}
for _, o in ipairs(Config.Barricades or {}) do
    if type(o) == "table" and o.enabled ~= false and o.spikes == true and type(o.model) == "string" then spikeModels[GetHashKey(o.model)] = true end
end

if next(spikeModels) then
    local spread = {}  -- [entity] = true once its unfold animation was played here
    local nearby = {}  -- spike strips around the player

    -- The server sends the net ids of the spike strips (no scan of every object in the game).
    local spikeNet = {}
    RegisterNetEvent("bofaisal_police:spikes", function(ids)
        spikeNet = {}
        for _, id in ipairs(type(ids) == "table" and ids or {}) do spikeNet[#spikeNet + 1] = id end
    end)

    Citizen.CreateThread(function()
        while true do
            local list = {}
            if #spikeNet > 0 then
                local me = GetEntityCoords(PlayerPedId())
                for _, netId in ipairs(spikeNet) do
                    if NetworkDoesNetworkIdExist(netId) then
                        local obj = NetworkGetEntityFromNetworkId(netId)
                        if obj ~= 0 and DoesEntityExist(obj) and spikeModels[GetEntityModel(obj)] then
                            if not spread[obj] then
                                spread[obj] = true
                                spreadSpike(obj)
                            end
                            if #(GetEntityCoords(obj) - me) < 120.0 then list[#list + 1] = obj end
                        end
                    end
                end
            end
            for obj in pairs(spread) do
                if not DoesEntityExist(obj) then spread[obj] = nil end
            end
            nearby = list
            Citizen.Wait(#spikeNet > 0 and 1000 or 2000)
        end
    end)

    local WHEELS = { { "wheel_lf", 0 }, { "wheel_rf", 1 }, { "wheel_lm1", 2 }, { "wheel_rm1", 3 }, { "wheel_lr", 4 }, { "wheel_rr", 5 } }
    Citizen.CreateThread(function()
        while true do
            local wait = 500
            local ped = PlayerPedId()
            local veh = GetVehiclePedIsIn(ped, false)
            local opts = spikeOptions()
            if veh ~= 0 and #nearby > 0 and GetPedInVehicleSeat(veh, -1) == ped
                and not (opts.IgnoreEmergency and GetVehicleClass(veh) == 18) then
                local radius = opts.Radius or 1.8
                local vpos = GetEntityCoords(veh)
                local closest = math.huge
                for _, obj in ipairs(nearby) do
                    if DoesEntityExist(obj) then closest = math.min(closest, #(GetEntityCoords(obj) - vpos)) end
                end
                -- Checked every frame only when a spike strip is close.
                if closest < 30.0 then
                    wait = 0
                    for _, w in ipairs(WHEELS) do
                        local bone = GetEntityBoneIndexByName(veh, w[1])
                        if bone ~= -1 and not IsVehicleTyreBurst(veh, w[2], false) then
                            local p = GetWorldPositionOfEntityBone(veh, bone)
                            for _, obj in ipairs(nearby) do
                                if DoesEntityExist(obj) then
                                    local s = GetEntityCoords(obj)
                                    if math.abs(p.z - s.z) < 1.5 and #(vector2(p.x, p.y) - vector2(s.x, s.y)) < radius then
                                        SetVehicleTyreBurst(veh, w[2], false, 1000.0)
                                        break
                                    end
                                end
                            end
                        end
                    end
                elseif closest < 60.0 then
                    wait = 100
                end
            end
            Citizen.Wait(wait)
        end
    end)
end
