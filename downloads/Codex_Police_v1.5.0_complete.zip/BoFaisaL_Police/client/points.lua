--[[
    BoFaisaL_Police — interaction points: fine payment points (red arrow) and impound centres.
    A slow loop (250 / 750 ms) finds the points around the player and whether he stands on one;
    the frame loop only draws the markers of those few points (arguments prepared once).
    Stepping on a point opens its Builder Menu (server/points.lua), stepping off closes it.
]]

local points = {}
local blips = {}
local current = nil -- the point the player stands on
local nearby = {}   -- prepared markers of the points close enough to be drawn

local function blip(coords, b)
    if not b or b.enabled == false then return end
    local handle = AddBlipForCoord(coords.x, coords.y, coords.z)
    SetBlipSprite(handle, b.sprite or 1)
    SetBlipColour(handle, b.color or 0)
    SetBlipScale(handle, b.scale or 0.8)
    SetBlipAsShortRange(handle, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentSubstringPlayerName(b.label or "")
    EndTextCommandSetBlipName(handle)
    blips[#blips + 1] = handle
end

local function build()
    current = nil
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    blips = {}
    points = {}
    if BoFaisaL.feature("Fines") then
        for _, p in ipairs(Config.Fines.PaymentPoints or {}) do
            points[#points + 1] = { kind = "fines", coords = p.coords, radius = p.radius or 1.5, marker = p.marker }
            blip(p.coords, p.blip)
        end
    end
    if BoFaisaL.feature("Impound") then
        for _, loc in ipairs(Config.Impound.Locations or {}) do
            points[#points + 1] = { kind = "impound", coords = loc.coords, radius = loc.radius or 3.0, marker = loc.marker }
            blip(loc.coords, loc.blip)
        end
    end
    -- Worked out once per point (not every frame).
    for _, p in ipairs(points) do
        p.draw = UI.prepareMarker(p.marker, p.coords)
        p.drawDistance = UI.markerDistance(p.marker, 15.0)
    end
    nearby = {}
end

-- Frame loop: draws the nearby markers only, nothing else.
Citizen.CreateThread(function()
    while true do
        local list = nearby
        if #list > 0 then
            for i = 1, #list do UI.drawPrepared(list[i]) end
            Citizen.Wait(0)
        else
            Citizen.Wait(250)
        end
    end
end)

-- Slow loop: which points are around, and is the player standing on one.
Citizen.CreateThread(function()
    build()
    while true do
        local sleep = 750
        if #points > 0 then
            local pos = GetEntityCoords(PlayerPedId())
            local inside, list = nil, {}
            for _, p in ipairs(points) do
                -- Horizontal distance: points sit on the ground, the player's position is at body height.
                local d = Utils.dist2d(pos, p.coords)
                if math.abs(pos.z - p.coords.z) < 4.0 then
                    if d < p.drawDistance then
                        sleep = 250
                        if p.draw then list[#list + 1] = p.draw end
                    end
                    if d <= p.radius then inside = p end
                end
            end
            nearby = list
            -- Like vRP areas: stepping on a point opens its menu, stepping off closes it.
            if inside ~= current then
                if current then
                    local left = current
                    Citizen.CreateThread(function() BoFaisaL.rpc("points:leave", { kind = left.kind }) end)
                end
                current = inside
                if inside then
                    local entered = inside
                    Citizen.CreateThread(function()
                        local ok, err = BoFaisaL.rpc("points:enter", { kind = entered.kind })
                        if not ok and err then UI.notify(err, "error") end
                    end)
                end
            end
        end
        Citizen.Wait(sleep)
    end
end)

-- Locations changed from إدارة اللوحة: the server sends the overrides to everyone.
RegisterNetEvent("bofaisal_police:locations", function(loc)
    ApplyLocations(loc)
    build()
end)

AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, b in ipairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end end
end)
