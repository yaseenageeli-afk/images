--[[
    BoFaisaL_Police — client UI glue: broadcasts, toasts, panels, ID card, dialogs, builtin menu,
    key hints, progress / skill checks and the wanted quick-open.
]]

---------------------------------------------------------------------------
-- Generic server → UI events
---------------------------------------------------------------------------
local handlers = {}

-- Game sound from Config.Sounds (each entry { name, set } or false; Enabled = false mutes them all).
local DEFAULT_SOUNDS = {
    Confirm = { "Menu_Accept", "Phone_SoundSet_Default" },
    Accept = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },
    Reject = { "BACK", "HUD_FRONTEND_DEFAULT_SOUNDSET" },
    IdCard = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },
    Waypoint = { "WAYPOINT_SET", "HUD_FRONTEND_DEFAULT_SOUNDSET" },
    Escape = { "CHECKPOINT_MISSED", "HUD_MINI_GAME_SOUNDSET" },
    Barricade = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },
}
function UI.sound(key)
    local s = type(Config.Sounds) == "table" and Config.Sounds or {}
    if s.Enabled == false then return end
    local entry = s[key]
    if entry == nil then entry = DEFAULT_SOUNDS[key] end
    if type(entry) == "table" and entry[1] then PlaySoundFrontend(-1, entry[1], entry[2], true) end
end

function handlers.broadcast(data)
    UI.send("broadcast", data)
    local sound = data.sound or (Config.Broadcast and Config.Broadcast.Sound)
    if sound and sound.enabled then PlaySoundFrontend(-1, sound.name, sound.set, true) end
end

function handlers.panel(data)
    UI.send("panel:open", data)
    UI.focus("panel", true, true)
end

function handlers.idcard(data)
    UI.send("idcard:show", data)
    UI.sound("IdCard")
end

function handlers.toast(data)
    UI.send("toast", data)
end

-- Inquiry results shown as a card on the left (no focus, disappears by itself).
function handlers.infocard(data)
    UI.send("infocard", data)
end

-- An officer's badge card (إظهار الشارة).
function handlers.badge(data)
    UI.send("badge:show", data)
end

---------------------------------------------------------------------------
-- F5 closes the info cards (inquiry, search, ID card, badge) before their time is up,
-- one per press, oldest first. While a confirmation is open F5 answers it instead.
---------------------------------------------------------------------------
local cardsShown = 0
local skipLoop = false

-- Long lists on a card are split in pages (Config.UI.CardPageSize): these keys turn them.
local function pageKeys()
    local k = Config.UI and Config.UI.CardPageKeys
    if type(k) ~= "table" then return nil end
    return tonumber(k.next), tonumber(k.prev)
end

local function watchSkipKey()
    if skipLoop then return end
    skipLoop = true
    Citizen.CreateThread(function()
        local skip = Config.UI and Config.UI.SkipKey
        local nextKey, prevKey = pageKeys()
        while cardsShown > 0 do
            if not UI.hasFocus() then
                if skip ~= false and not (BoFaisaL.confirmPending and BoFaisaL.confirmPending())
                    and IsControlJustReleased(0, tonumber(skip) or 166) then
                    UI.send("cards:skip", {})
                end
                if nextKey and IsControlJustReleased(0, nextKey) then UI.send("cards:page", { dir = 1 }) end
                if prevKey and IsControlJustReleased(0, prevKey) then UI.send("cards:page", { dir = -1 }) end
            end
            Citizen.Wait(0)
        end
        skipLoop = false
    end)
end

RegisterNUICallback("cardsShown", function(data, cb)
    cardsShown = tonumber(data and data.count) or 0
    if cardsShown > 0 and ((Config.UI and Config.UI.SkipKey ~= false) or pageKeys()) then watchSkipKey() end
    cb({ ok = true })
end)

RegisterNetEvent("bofaisal_police:ui", function(action, data)
    local fn = handlers[action]
    if fn then fn(data or {}) end
end)

---------------------------------------------------------------------------
-- Builtin popup (Config.Integrations.Popup.type = "builtin")
---------------------------------------------------------------------------
RegisterNetEvent("bofaisal_police:dialog:open", function(id, title, fields)
    UI.send("dialog:open", { id = id, title = title, fields = fields })
    UI.focus("dialog", true, true)
end)

RegisterNetEvent("bofaisal_police:dialog:close", function(id)
    UI.send("dialog:close", { id = id })
    UI.focus("dialog", false)
end)

RegisterNUICallback("dialogSubmit", function(data, cb)
    UI.focus("dialog", false)
    Citizen.CreateThread(function()
        BoFaisaL.rpc("dialog:submit", { id = data.id, values = data.values })
    end)
    cb({ ok = true })
end)

RegisterNUICallback("dialogCancel", function(data, cb)
    UI.focus("dialog", false)
    Citizen.CreateThread(function() BoFaisaL.rpc("dialog:cancel", { id = data.id }) end)
    cb({ ok = true })
end)

---------------------------------------------------------------------------
-- Builtin menu (Config.Integrations.BuilderMenu.type = "builtin")
---------------------------------------------------------------------------
RegisterNetEvent("bofaisal_police:menu:open", function(token, menu)
    UI.send("menu:open", { token = token, title = menu.title, subtitle = menu.subtitle, items = menu.items, back = menu.back })
    UI.focus("menu", true, true)
end)

RegisterNetEvent("bofaisal_police:menu:close", function()
    UI.send("menu:close", {})
    UI.focus("menu", false)
end)

RegisterNUICallback("menuSelect", function(data, cb)
    UI.focus("menu", false)
    Citizen.CreateThread(function() BoFaisaL.rpc("menu:select", { token = data.token, index = data.index }) end)
    cb({ ok = true })
end)

RegisterNUICallback("menuBack", function(data, cb)
    UI.focus("menu", false)
    Citizen.CreateThread(function() BoFaisaL.rpc("menu:back", { token = data.token }) end)
    cb({ ok = true })
end)

RegisterNUICallback("menuClose", function(data, cb)
    UI.focus("menu", false)
    Citizen.CreateThread(function() BoFaisaL.rpc("menu:close", {}) end)
    cb({ ok = true })
end)

do
    local menuCfg = Config.Integrations and Config.Integrations.BuilderMenu or {}
    if menuCfg.type == "builtin" and menuCfg.builtin and menuCfg.builtin.command then
        RegisterCommand(menuCfg.builtin.command, function()
            Citizen.CreateThread(function()
                local ok, err = BoFaisaL.rpc("menu:main", {})
                if not ok and err then UI.notify(err, "error") end
            end)
        end, false)
        if menuCfg.builtin.key then
            RegisterKeyMapping(menuCfg.builtin.command, "BoFaisaL_Police", "keyboard", menuCfg.builtin.key)
        end
    end
end

---------------------------------------------------------------------------
-- Panels (inquiries, search results, payments)
---------------------------------------------------------------------------
RegisterNUICallback("panelAction", function(data, cb)
    Citizen.CreateThread(function()
        local action = type(data) == "table" and data.action or ""
        local ok, result
        if action == "finesPay" then
            ok, result = BoFaisaL.rpc("fines:pay", { ids = data.ids, all = data.all == true, remote = data.remote == true })
        elseif action == "impoundPay" then
            ok, result = BoFaisaL.rpc("impound:pay", { id = data.id, remote = data.remote == true })
        elseif action == "ehsan" then
            ok, result = BoFaisaL.rpc("ehsan:" .. tostring(data.operation or "list"), data)
        elseif action == "absher" then
            ok, result = BoFaisaL.rpc("absher:view", { view = data.view })
        elseif action == "vehicleSeize" then
            ok, result = BoFaisaL.rpc("field:vehicleSeize", { token = data.token })
        else
            ok, result = false, "invalid"
        end
        cb({ ok = ok, data = Utils.jsonSafe(result) })
    end)
end)

AddEventHandler("bofaisal_police:client:closed", function(layer)
    if layer == "panel" then UI.send("panel:close", {}) end
end)

---------------------------------------------------------------------------
-- Key hints (Arabic text rendered by the NUI, never by GTA text natives)
---------------------------------------------------------------------------
local hintOwner, hintId = nil, nil

-- owner: "points" | "jail" | "barricade" ... a hint can only be hidden by its owner.
function UI.hint(key, text, owner)
    owner = owner or "default"
    local id = key .. text
    if hintOwner == owner and hintId == id then return end
    hintOwner, hintId = owner, id
    if Config.UI.Hints ~= false then UI.send("hint", { key = key, text = text }) end
end

function UI.hideHint(owner)
    owner = owner or "default"
    if hintOwner == owner then
        hintOwner, hintId = nil, nil
        UI.send("hint:hide", {})
    end
    if UI.worldHintOwner == owner then
        UI.worldHintOwner, UI.worldHintPos = nil, nil
        UI.send("worldhint:hide", {})
    end
end

-- Draws a point shape (Config.MarkerStyles / a marker table) at coords. Call every frame.
function UI.drawMarker(m, coords)
    if not m or m.enabled == false or (tonumber(m.type) or 0) < 0 then return end
    local col = m.color or { 37, 99, 235, 190 }
    local sc = m.scale or { 0.4, 0.4, 0.4 }
    local rot = m.rotation or { 0.0, 0.0, 0.0 }
    DrawMarker(m.type or 2, coords.x, coords.y, coords.z + (m.offsetZ or 0.0), 0.0, 0.0, 0.0,
        rot[1] + 0.0, rot[2] + 0.0, rot[3] + 0.0, sc[1] + 0.0, sc[2] + 0.0, sc[3] + 0.0, col[1], col[2], col[3], col[4] or 200,
        m.bob == true, m.faceCamera == true, 2, m.rotate == true, nil, nil, false)
end

-- The DrawMarker arguments of a marker at a place, worked out once (nil = nothing to draw).
-- UI.drawPrepared(args) then draws it every frame without building anything.
function UI.prepareMarker(m, coords)
    if not m or m.enabled == false or (tonumber(m.type) or 0) < 0 or not coords then return nil end
    local col = m.color or { 37, 99, 235, 190 }
    local sc = m.scale or { 0.4, 0.4, 0.4 }
    local rot = m.rotation or { 0.0, 0.0, 0.0 }
    return {
        m.type or 2, coords.x + 0.0, coords.y + 0.0, coords.z + (m.offsetZ or 0.0),
        rot[1] + 0.0, rot[2] + 0.0, rot[3] + 0.0, sc[1] + 0.0, sc[2] + 0.0, sc[3] + 0.0,
        col[1], col[2], col[3], col[4] or 200, m.bob == true, m.faceCamera == true, m.rotate == true,
    }
end

function UI.drawPrepared(a)
    DrawMarker(a[1], a[2], a[3], a[4], 0.0, 0.0, 0.0, a[5], a[6], a[7], a[8], a[9], a[10],
        a[11], a[12], a[13], a[14], a[15], a[16], 2, a[17], nil, nil, false)
end

-- How far markers are drawn: the shape's own distance, never more than Config.UI.MarkerDistance.
function UI.markerDistance(m, fallback)
    local own = (m and tonumber(m.drawDistance)) or fallback or 15.0
    local cap = tonumber(Config.UI and Config.UI.MarkerDistance)
    if cap and cap > 0 then return math.min(own, cap) end
    return own
end

-- Height of the text just above a shape (a little over its top).
function UI.markerTop(m)
    if not m or m.enabled == false or (tonumber(m.type) or 0) < 0 then return 0.9 end
    local top = (m.offsetZ or 0.0) + ((m.scale and m.scale[3]) or 0.4) * 0.5
    return math.max(top + 0.3, 0.55)
end

-- Hint floating above a point in the world (markers). Call it every frame while near:
-- the screen position is only sent to the UI when it actually moves.
function UI.worldHint(key, text, owner, coords, height)
    if Config.UI.Hints == false then return end
    owner = owner or "default"
    local onScreen, x, y = GetScreenCoordFromWorldCoord(coords.x, coords.y, coords.z + (height or 1.0))
    if not onScreen then
        if UI.worldHintOwner == owner then UI.hideHint(owner) end
        return
    end
    local last = UI.worldHintPos
    local id = key .. text
    if UI.worldHintOwner == owner and last and last.id == id and math.abs(last.x - x) < 0.0015 and math.abs(last.y - y) < 0.0015 then return end
    UI.worldHintOwner = owner
    UI.worldHintPos = { x = x, y = y, id = id }
    UI.send("worldhint", { key = key, text = text, x = x, y = y })
end

---------------------------------------------------------------------------
-- Progress bar + skill checks (jail tasks)
---------------------------------------------------------------------------
local skill = nil

-- action: "skillcheck:start" (the round check) | "task:check" (the check inside the task HUD).
local function runCheck(action, difficulty)
    local p = promise.new()
    skill = p
    UI.send(action, {
        checks = difficulty.checks or 1, speed = difficulty.speed or 1.0, zone = difficulty.zone or 0.2, key = "E",
    })
    UI.focus("skillcheck", true, false)
    -- The NUI gives up after 6 s; this only covers a NUI that never answers.
    SetTimeout(10000, function()
        if skill == p then
            skill = nil
            p:resolve({ success = false })
        end
    end)
    local r = Citizen.Await(p)
    UI.focus("skillcheck", false)
    return r.success == true
end

function UI.skillCheck(difficulty) return runCheck("skillcheck:start", difficulty) end

-- Jail task on screen: style = "corners" | "segments" (إدارة اللوحة). Progress + the check under it.
function UI.taskStart(style, label, seconds) UI.send("task:start", { style = style, label = label, duration = seconds }) end
function UI.taskCheck(difficulty) return runCheck("task:check", difficulty) end
function UI.taskStop() UI.send("task:stop", {}) end

RegisterNUICallback("skillcheck", function(data, cb)
    if skill then
        local p = skill
        skill = nil
        p:resolve({ success = data and data.success == true })
    end
    cb({ ok = true })
end)

function UI.progress(label, seconds)
    UI.send("progress:start", { label = label, duration = seconds })
end

function UI.stopProgress()
    UI.send("progress:stop", {})
end

---------------------------------------------------------------------------
-- Wanted alert with quick open (click-free: press the configured key)
---------------------------------------------------------------------------
local quickUntil = 0

RegisterNetEvent("bofaisal_police:wanted:alert", function(alert)
    UI.send("wanted:alert", alert)
    local q = alert and alert.quickOpen
    if not q or not q.enabled then return end
    local wasActive = GetGameTimer() < quickUntil
    quickUntil = GetGameTimer() + (q.seconds or 10) * 1000
    if wasActive then return end
    Citizen.CreateThread(function()
        while GetGameTimer() < quickUntil do
            if IsControlJustReleased(0, q.key or 47) and not UI.hasFocus() then
                quickUntil = 0
                UI.send("wanted:alertHide", {})
                BoFaisaL.openIpad(alert.tab or "wanted") -- the reports alert opens البلاغات
                break
            end
            Citizen.Wait(0)
        end
        UI.send("wanted:alertHide", {})
    end)
end)
