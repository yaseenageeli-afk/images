--[[
    BoFaisaL_Police — character photo (client)

    Takes a headshot of the player's own character with the game (ped headshot), the UI turns
    it into a small image (canvas → data URL) and it is uploaded to the server with a latent
    event. Done a little after joining / spawning and every Config.Mugshot.RefreshMinutes.
    Also forwards the photos the UI asks for (wanted posters, reports, ID card).
]]

local function cfg() return Config.Mugshot or {} end

local waiters, seq = {}, 0
local lastSent = nil
local lastLook = nil -- appearance of the last photo sent (model, clothes, props, hair)
local lastAt = 0     -- when it was taken (a new one every Config.Mugshot.MaxAgeMinutes, for face-only edits)

-- Short signature of how the character looks: no new photo while it stays the same.
local function lookSignature(ped)
    local parts = { GetEntityModel(ped), GetPedHairColor(ped), GetPedHairHighlightColor(ped) }
    for c = 0, 11 do
        parts[#parts + 1] = GetPedDrawableVariation(ped, c) .. "." .. GetPedTextureVariation(ped, c)
    end
    for p = 0, 7 do
        parts[#parts + 1] = GetPedPropIndex(ped, p) .. "." .. GetPedPropTextureIndex(ped, p)
    end
    return table.concat(parts, ",")
end

-- Asks the UI to turn a headshot texture into a data URL.
local function encode(txd)
    seq = seq + 1
    local id = seq
    local p = promise.new()
    waiters[id] = p
    UI.send("mugshot:encode", { id = id, txd = txd })
    SetTimeout(6000, function()
        if waiters[id] then
            waiters[id] = nil
            p:resolve(nil)
        end
    end)
    return Citizen.Await(p)
end

RegisterNUICallback("mugshotEncoded", function(data, cb)
    local p = type(data) == "table" and waiters[data.id]
    if p then
        waiters[data.id] = nil
        p:resolve(type(data.data) == "string" and data.data or nil)
    end
    cb({ ok = true })
end)

local busy = false
local function capture()
    if busy or cfg().Enabled == false then return end
    busy = true
    local ped = PlayerPedId()
    local look = DoesEntityExist(ped) and lookSignature(ped) or nil
    local maxAge = math.max(1, tonumber(cfg().MaxAgeMinutes) or 60) * 60000
    if look and look == lastLook and GetGameTimer() - lastAt < maxAge then busy = false return end -- same look: up to date
    if DoesEntityExist(ped) and not IsEntityDead(ped) then
        local handle = RegisterPedheadshotTransparent(ped)
        local timeout = GetGameTimer() + 6000
        while not (IsPedheadshotReady(handle) and IsPedheadshotValid(handle)) and GetGameTimer() < timeout do
            Citizen.Wait(50)
        end
        if IsPedheadshotReady(handle) and IsPedheadshotValid(handle) then
            local data = encode(GetPedheadshotTxdString(handle))
            if data then lastLook, lastAt = look, GetGameTimer() end
            if data and data ~= lastSent then
                lastSent = data
                TriggerLatentServerEvent("bofaisal_police:mugshot:upload", 30000, data)
            end
        end
        UnregisterPedheadshot(handle)
    end
    busy = false
end

-- After joining (the character needs a moment to get its clothes), then every few minutes.
Citizen.CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) do Citizen.Wait(1000) end
    Citizen.Wait((cfg().FirstDelay or 25) * 1000)
    while true do
        capture()
        Citizen.Wait(math.max(2, cfg().RefreshMinutes or 10) * 60000)
    end
end)

AddEventHandler("playerSpawned", function()
    SetTimeout((cfg().FirstDelay or 25) * 1000, function() Citizen.CreateThread(capture) end)
end)

-- Photos asked by the UI → server; photos from the server → UI.
RegisterNUICallback("mugshots", function(data, cb)
    if type(data) == "table" and type(data.ids) == "table" and #data.ids > 0 then
        TriggerServerEvent("bofaisal_police:mugshot:request", data.ids)
    end
    cb({ ok = true })
end)

RegisterNetEvent("bofaisal_police:mugshot:data", function(id, at, image)
    UI.send("mugshot", { id = id, at = at, data = image or false })
end)
