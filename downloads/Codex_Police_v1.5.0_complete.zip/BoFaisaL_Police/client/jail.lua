--[[
    BoFaisaL_Police — jail client: HUD timer (display only), perimeter report, task points.
    The remaining time is authoritative on the server; this only mirrors it.
]]

local jail = nil
local blips = {}
local menuTask = nil -- the task point the player stands on (its Builder Menu is open)
BoFaisaL.jailTask = { active = false }

local function clearBlips()
    for _, b in ipairs(blips) do
        if DoesBlipExist(b) then RemoveBlip(b) end
    end
    blips = {}
end

local function taskBlips(tasks)
    clearBlips()
    local bcfg = Config.Jail.Tasks and Config.Jail.Tasks.Blip
    if not bcfg or not bcfg.enabled then return end
    for _, t in ipairs(tasks or {}) do
        local b = AddBlipForCoord(t.coords.x, t.coords.y, t.coords.z)
        SetBlipSprite(b, bcfg.sprite or 566)
        SetBlipColour(b, bcfg.color or 27)
        SetBlipScale(b, bcfg.scale or 0.6)
        SetBlipAsShortRange(b, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName(t.label)
        EndTextCommandSetBlipName(b)
        blips[#blips + 1] = b
    end
end

local taskProp = nil -- the object in the prisoner's hand during a task (the broom)

local function removeTaskProp()
    if taskProp and DoesEntityExist(taskProp) then
        DetachEntity(taskProp, true, false)
        DeleteEntity(taskProp)
    end
    taskProp = nil
end

-- Object in the hand (Config.Jail.Tasks.Types[type].prop): seen by everyone around.
local function attachTaskProp(ped, prop)
    if type(prop) ~= "table" or type(prop.model) ~= "string" then return end
    local hash = GetHashKey(prop.model)
    if not IsModelInCdimage(hash) then return end
    RequestModel(hash)
    local timeout = GetGameTimer() + 3000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Citizen.Wait(10) end
    if not HasModelLoaded(hash) then return end
    local pos = GetEntityCoords(ped)
    removeTaskProp()
    taskProp = CreateObject(hash, pos.x, pos.y, pos.z + 0.2, true, true, false)
    SetModelAsNoLongerNeeded(hash)
    local o, r = prop.offset or {}, prop.rotation or {}
    AttachEntityToEntity(taskProp, ped, GetPedBoneIndex(ped, prop.bone or 28422),
        (o[1] or 0.0) + 0.0, (o[2] or 0.0) + 0.0, (o[3] or 0.0) + 0.0, (r[1] or 0.0) + 0.0, (r[2] or 0.0) + 0.0, (r[3] or 0.0) + 0.0,
        true, true, false, true, 1, true)
end

local function playTaskAnim(anim)
    local ped = PlayerPedId()
    if anim.scenario then
        TaskStartScenarioInPlace(ped, anim.scenario, 0, true)
    elseif anim.dict and anim.name and BoFaisaL.loadDict(anim.dict) then
        -- Flag 1 = loops for the whole task.
        TaskPlayAnim(ped, anim.dict, anim.name, 8.0, -8.0, -1, 1, 0, false, false, false)
    end
    attachTaskProp(ped, anim.prop)
end

local function runTask(task)
    if BoFaisaL.jailTask.active then return end
    BoFaisaL.jailTask.active = true
    local ok, info = BoFaisaL.rpc("jail:taskStart", { id = task.id })
    if not ok then
        UI.notify(info, "error")
        BoFaisaL.jailTask.active = false
        menuTask = nil -- still on the point: its menu opens again
        return
    end
    playTaskAnim(info.anim or {})
    -- "classic" = the older progress bar and round check; otherwise the task HUD.
    local classic = info.ui == "classic"
    if classic then UI.progress(info.label, info.duration) else UI.taskStart(info.ui or "corners", info.label, info.duration) end
    local checks = (info.difficulty and info.difficulty.checks) or 1
    local startedAt = GetGameTimer()
    local duration = (info.duration or 10) * 1000
    local success = true
    local nextCheck = 1
    while GetGameTimer() - startedAt < duration do
        local ped = PlayerPedId()
        if Utils.dist(GetEntityCoords(ped), task.coords) > (task.radius or 2.0) + 0.75 or IsPedDeadOrDying(ped, true) then
            success = false
            break
        end
        local progress = (GetGameTimer() - startedAt) / duration
        if nextCheck <= checks and progress >= nextCheck / (checks + 1) then
            nextCheck = nextCheck + 1
            local passed
            if classic then passed = UI.skillCheck(info.difficulty or {}) else passed = UI.taskCheck(info.difficulty or {}) end
            if not passed then
                success = false
                break
            end
        end
        Citizen.Wait(100)
    end
    if classic then UI.stopProgress() else UI.taskStop() end
    ClearPedTasks(PlayerPedId())
    removeTaskProp()
    if success then
        local ok2, res = BoFaisaL.rpc("jail:taskComplete", { id = task.id, success = true })
        if not ok2 then
            UI.notify(res, "error")
        elseif res.capped then
            UI.notify(LocaleUI.jail_task_capped, "info")
        elseif (res.reduced or 0) > 0 then
            UI.notify(Utils.format(LocaleUI.jail_task_reduced, { time = Utils.mmss(res.reduced) }), "success")
        end
    else
        BoFaisaL.rpc("jail:taskComplete", { id = task.id, success = false })
        UI.notify(LocaleUI.jail_task_failed, "error")
    end
    BoFaisaL.jailTask.active = false
    menuTask = nil -- still on the point: its menu opens again
end

-- "بدء المهمة" in the task point's menu.
RegisterNetEvent("bofaisal_police:jail:runTask", function(id)
    if not jail or BoFaisaL.jailTask.active then return end
    for _, t in ipairs(jail.tasks or {}) do
        if t.id == id then
            Citizen.CreateThread(function() runTask(t) end)
            return
        end
    end
end)

-- Prepared markers of the task points close enough to be drawn.
local nearTasks = {}

-- Number of the current sentence: released and jailed again within a second, the loops of the
-- previous sentence see a new number and stop (never two copies running).
local session = 0

-- Two loops, like the fine / impound points:
--   frame loop → only draws the nearby task markers (arguments prepared once)
--   slow loop  → perimeter report (useful without OneSync; the server re-validates), which tasks
--                are near and which one the player stands on
local function loop()
    local mine = session
    Citizen.CreateThread(function()
        while jail and mine == session do
            local list = nearTasks
            if #list > 0 then
                for i = 1, #list do UI.drawPrepared(list[i]) end
                Citizen.Wait(0)
            else
                Citizen.Wait(250)
            end
        end
    end)
    Citizen.CreateThread(function()
        local lastReport = 0
        while jail and mine == session do
            local sleep = 750
            local ped = PlayerPedId()
            local pos = GetEntityCoords(ped)
            if jail.escape and jail.center and Utils.dist2d(pos, jail.center) > (jail.radius or 150) then
                if GetGameTimer() - lastReport > 3000 then
                    lastReport = GetGameTimer()
                    Citizen.CreateThread(function() BoFaisaL.rpc("jail:escaped", {}) end)
                end
            end
            local inside, list = nil, {}
            for _, t in ipairs(jail.tasks or {}) do
                local d = Utils.dist(pos, t.coords)
                if d < 20.0 then
                    sleep = 250
                    -- Shape chosen in إدارة اللوحة (or Config.Jail.Tasks.Marker). No text above it.
                    -- Worked out once per task (a new state from the server brings new tasks).
                    if t.draw == nil then t.draw = UI.prepareMarker(t.marker or Config.Jail.Tasks.Marker, t.coords) or false end
                    if t.draw then list[#list + 1] = t.draw end
                    -- Horizontal distance: the point sits on the ground, the player's position is at body height.
                    if Utils.dist2d(pos, t.coords) <= (t.radius or 2.0) and math.abs(pos.z - t.coords.z) < 3.0 then inside = t end
                end
            end
            nearTasks = list
            -- Like the fine / impound points: stepping on a task opens its menu, stepping off closes it.
            if not BoFaisaL.jailTask.active and (inside and inside.id) ~= (menuTask and menuTask.id) then
                if menuTask then
                    local left = menuTask.id
                    Citizen.CreateThread(function() BoFaisaL.rpc("jail:taskLeave", { id = left }) end)
                end
                menuTask = inside
                if inside then
                    local id = inside.id
                    Citizen.CreateThread(function()
                        local ok, err = BoFaisaL.rpc("jail:taskMenu", { id = id })
                        if not ok and err then UI.notify(err, "error") end
                    end)
                end
            end
            Citizen.Wait(sleep)
        end
        if mine == session then
            nearTasks = {}
            UI.hideHint("jail")
        end
    end)
end

-- Config.Jail.BlockWeapons: no weapon in hand and no attacks while jailed.
local UNARMED = GetHashKey("WEAPON_UNARMED")
local WEAPON_CONTROLS = { 24, 25, 37, 45, 47, 58, 140, 141, 142, 143, 257, 263, 264 }

local function blockWeapons()
    if Config.Jail.BlockWeapons == false then return end
    local mine = session
    Citizen.CreateThread(function()
        while jail and mine == session do
            local ped = PlayerPedId()
            if GetSelectedPedWeapon(ped) ~= UNARMED then SetCurrentPedWeapon(ped, UNARMED, true) end
            for _, c in ipairs(WEAPON_CONTROLS) do DisableControlAction(0, c, true) end
            DisablePlayerFiring(PlayerId(), true)
            Citizen.Wait(0)
        end
    end)
end

RegisterNetEvent("bofaisal_police:jail:start", function(state)
    if type(state) ~= "table" then return end
    local wasJailed = jail ~= nil
    jail = state
    if state.hud ~= false then UI.send("jail:show", state) end
    taskBlips(state.tasks)
    if not wasJailed then
        session = session + 1
        loop()
        blockWeapons()
    end
end)

RegisterNetEvent("bofaisal_police:jail:sync", function(remaining)
    if not jail then return end
    jail.remaining = remaining
    UI.send("jail:sync", { remaining = remaining })
end)

RegisterNetEvent("bofaisal_police:jail:escape", function(message, added)
    UI.send("jail:escape", { message = message, added = added })
    UI.sound("Escape")
end)

RegisterNetEvent("bofaisal_police:jail:end", function()
    jail = nil
    if menuTask then
        menuTask = nil
        Citizen.CreateThread(function() BoFaisaL.rpc("jail:taskLeave", {}) end)
    end
    clearBlips()
    UI.send("jail:hide", {})
    UI.hideHint("jail")
end)

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then
        clearBlips()
        removeTaskProp()
    end
end)
