--[[
    BoFaisaL_Police — chat commands for entries of the police menu (Config.Commands)
    Each command (and its optional key) asks the server to open the same thing as the menu entry.
]]

-- Commands that run here on the client (no server action).
local LOCAL = {
    StopSpectate = function() TriggerEvent("bofaisal_police:client:stopSpectate") end,
}

local suggested = {} -- chat suggestions added here, removed when the resource stops

Citizen.CreateThread(function()
    local list = Utils.commandList(Config.Commands)
    for _, c in ipairs(list) do
        local id = c.id
        suggested[#suggested + 1] = "/" .. c.name
        RegisterCommand(c.name, function()
            if LOCAL[id] then return LOCAL[id]() end
            Citizen.CreateThread(function()
                local ok, err = BoFaisaL.rpc("cmd:run", { id = id })
                if not ok and err then UI.notify(err, "error") end
            end)
        end, false)
        if c.key then RegisterKeyMapping(c.name, "BoFaisaL_Police — " .. c.label, "keyboard", c.key) end
        TriggerEvent("chat:addSuggestion", "/" .. c.name, c.label)
    end
end)

-- A renamed command must not stay in the chat suggestions after a restart (the command itself
-- is removed by FiveM with the resource).
AddEventHandler("onResourceStop", function(resource)
    if resource ~= GetCurrentResourceName() then return end
    for _, name in ipairs(suggested) do TriggerEvent("chat:removeSuggestion", name) end
end)
