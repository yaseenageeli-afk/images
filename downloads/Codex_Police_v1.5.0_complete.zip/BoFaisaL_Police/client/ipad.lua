--[[
    BoFaisaL_Police — القائمة العسكرية (police iPad) controller.
    Opening is decided by the server (Ipad.open); every tab loads its data through RPC.
]]

local open = false
local prop = nil

local function startTabletAnim()
    local c = Config.Ipad or {}
    if not c.Animation then return end
    Citizen.CreateThread(function()
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then return end
        if not BoFaisaL.loadDict(c.AnimDict) then return end
        local hash = GetHashKey(c.Prop or "prop_cs_tablet")
        RequestModel(hash)
        local timeout = GetGameTimer() + 2000
        while not HasModelLoaded(hash) and GetGameTimer() < timeout do Citizen.Wait(10) end
        if not open then return end
        local coords = GetEntityCoords(ped)
        prop = CreateObject(hash, coords.x, coords.y, coords.z + 0.2, true, true, false)
        AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 28422), -0.05, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
        SetModelAsNoLongerNeeded(hash)
        TaskPlayAnim(ped, c.AnimDict, c.AnimName, 3.0, 3.0, -1, 49, 0, false, false, false)
    end)
end

local function stopTabletAnim()
    local c = Config.Ipad or {}
    if prop and DoesEntityExist(prop) then
        DetachEntity(prop, true, false)
        DeleteEntity(prop)
    end
    prop = nil
    if c.AnimDict then StopAnimTask(PlayerPedId(), c.AnimDict, c.AnimName, 1.0) end
end

local shown = false   -- the UI confirmed it opened the iPad
local attempt = 0

function BoFaisaL.openIpad(tab)
    if open and shown then
        UI.send("ipad:tab", { tab = tab or "office" })
        return
    end
    -- Opens at once. If the UI does not confirm (message lost), the command is sent again;
    -- only if that fails too is the mouse given back, so the screen never stays locked.
    open, shown = true, false
    attempt = attempt + 1
    local mine = attempt
    UI.send("ipad:open", { tab = tab or "office" })
    UI.focus("ipad", true, true)
    startTabletAnim()
    SetTimeout(2500, function()
        if not (open and not shown and attempt == mine) then return end
        UI.send("ipad:open", { tab = tab or "office" })
        SetTimeout(3000, function()
            if open and not shown and attempt == mine then
                open = false
                UI.focus("ipad", false)
                stopTabletAnim()
            end
        end)
    end)
end

-- The UI received the open command.
RegisterNUICallback("ipadShown", function(_, cb)
    shown = true
    cb({ ok = true })
end)

function BoFaisaL.closeIpad()
    if not open then return end
    open, shown = false, false
    UI.send("ipad:close", {})
    UI.focus("ipad", false)
    stopTabletAnim()
end

RegisterNetEvent("bofaisal_police:ipad:open", function(tab)
    BoFaisaL.openIpad(tab)
end)

RegisterNetEvent("bofaisal_police:ipad:push", function(kind, data)
    UI.send("ipad:push", { type = kind, data = data })
end)

AddEventHandler("bofaisal_police:client:closed", function(layer)
    if layer == "ipad" and open then
        open, shown = false, false
        stopTabletAnim()
    end
end)

-- Monitoring from the iPad closes the tablet first (spectate takes the camera).
AddEventHandler("bofaisal_police:client:spectateStarting", function()
    BoFaisaL.closeIpad()
end)

do
    local c = Config.Ipad or {}
    if c.Command then
        RegisterCommand(c.Command, function()
            Citizen.CreateThread(function()
                local ok, err = BoFaisaL.rpc("ipad:bootstrap", {})
                if ok then BoFaisaL.openIpad("office") elseif err then UI.notify(err, "error") end
            end)
        end, false)
        if c.Key then RegisterKeyMapping(c.Command, "BoFaisaL_Police — القائمة العسكرية", "keyboard", c.Key) end
    end
end

AddEventHandler("onResourceStop", function(resource)
    if resource == GetCurrentResourceName() then stopTabletAnim() end
end)
