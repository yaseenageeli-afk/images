/* BoFaisaL_Police — server-wide theme (إدارة اللوحة): colours, transparency, sizes and the place of
   every on-screen element, plus the drag & move layout editor. A saved position is the box of the
   element's sample in the editor (x / y = top-left corner, w / h = size, in % of the screen) and
   its size s (1 = normal). */
(function () {
  const E = window.BoFaisaL;
  const h = E.h;
  const $ = (id) => document.getElementById(id);
  E.theme = {};
  E.appliedTheme = {};

  // An empty Lua table reaches the browser as an ARRAY ([]). Values added to an array are dropped
  // when it is sent back, so theme data must always be a plain object.
  const obj = (v) => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});
  E.plainObject = obj;

  /* --------------------------------------------------------------- Colours */
  const hexToRgb = (hex) => {
    const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(String(hex || ''));
    return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : null;
  };
  const mix = (rgb, to, t) => rgb.map((c, i) => Math.round(c + (to[i] - c) * t));
  const rgba = (rgb, a) => 'rgba(' + rgb.join(', ') + ', ' + a + ')';
  const hex = (rgb) => '#' + rgb.map((c) => c.toString(16).padStart(2, '0')).join('');
  E.hexToRgb = hexToRgb;

  /* ------------------------------------------------------------- Positions */
  // Element that holds each movable part of the screen (broadcast cards are placed one by one).
  const TARGETS = {
    toasts: 'toasts', infocards: 'infocards', confirm: 'confirm', wanted: 'wanted-alert', alert: 'alert-status',
    jail: 'jail-hud', idcard: 'idcard-layer', progress: 'progress', hint: 'hint', badge: 'badge-layer',
  };
  const STACKS = { toasts: true, infocards: true };
  const SIZE_MIN = 0.5, SIZE_MAX = 1.8, SIZE_STEP = 0.05;
  const sizeOf = (pos) => { const s = Number(pos && pos.s); return s >= SIZE_MIN && s <= SIZE_MAX ? s : 1; };
  const rnd = (n) => Math.round(n * 100) / 100;

  // The real element is often bigger or smaller than its sample, so one edge stays where it was
  // put: the one nearest the side of the screen it sits on (left / middle / right thirds).
  // The confirmation box always keeps its base and grows upwards; stacks grow away from their edge.
  function anchors(key, pos) {
    const third = (c) => (c < 100 / 3 ? 0 : c > 200 / 3 ? 2 : 1);
    const cx = pos.x + pos.w / 2, cy = pos.y + pos.h / 2;
    return {
      x: ['left', 'center', 'right'][third(cx)],
      y: key === 'confirm' ? 'bottom' : STACKS[key] ? (cy > 50 ? 'bottom' : 'top') : ['top', 'middle', 'bottom'][third(cy)],
    };
  }

  // Puts an element at a saved box (no size change). Without w / h: top-left corner only.
  function position(el, pos, key) {
    const s = { left: '', top: '', right: '', bottom: '', transform: '', alignItems: '' };
    if (pos && pos.w !== undefined && pos.h !== undefined) {
      const a = anchors(key, pos);
      const move = [];
      Object.assign(s, { left: 'auto', top: 'auto', right: 'auto', bottom: 'auto' });
      if (a.x === 'left') s.left = pos.x + '%';
      else if (a.x === 'right') s.right = Math.max(0, 100 - pos.x - pos.w) + '%';
      else { s.left = pos.x + pos.w / 2 + '%'; move.push('translateX(-50%)'); }
      if (a.y === 'top') s.top = pos.y + '%';
      else if (a.y === 'bottom') s.bottom = Math.max(0, 100 - pos.y - pos.h) + '%';
      else { s.top = pos.y + pos.h / 2 + '%'; move.push('translateY(-50%)'); }
      s.transform = move.join(' ') || 'none';
      // Stacked notifications line up on the same side (the page is RTL: flex-start = right).
      if (STACKS[key]) s.alignItems = a.x === 'left' ? 'flex-end' : a.x === 'right' ? 'flex-start' : 'center';
    } else if (pos) {
      Object.assign(s, { left: pos.x + '%', top: pos.y + '%', right: 'auto', bottom: 'auto', transform: 'none' });
    }
    Object.assign(el.style, s);
  }

  // Older saves have only the top-left corner: the sample is measured to know its box.
  function withBox(key, pos) {
    if (!pos || (pos.w !== undefined && pos.h !== undefined)) return pos;
    const probe = h('div', { class: 'le-probe' }, sample(key));
    probe.firstChild.style.zoom = sizeOf(pos);
    document.body.appendChild(probe);
    const r = probe.firstChild.getBoundingClientRect();
    probe.remove();
    return Object.assign({}, pos, { w: (r.width / window.innerWidth) * 100, h: (r.height / window.innerHeight) * 100 });
  }

  // Place + size of a real element. zoom (not transform: scale) keeps the text sharp; it is set on
  // what the element shows (--z in app.css), a broadcast card is zoomed itself.
  function place(el, pos, key) {
    if (!el) return;
    pos = withBox(key, pos);
    position(el, pos, key);
    if (key === 'broadcasts') el.style.zoom = pos ? String(sizeOf(pos)) : '';
    else el.style.setProperty('--z', String(pos ? sizeOf(pos) : 1));
  }
  E.placeAt = place;

  // A box saved near the edge of the screen could push a bigger real element out of it: pull it
  // back in. Runs whenever an element is shown or its content changes.
  function keepOnScreen(el) {
    if (!el || el.classList.contains('hidden')) return;
    const r = el.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
    if (!r.width || !r.height) return;
    const dx = r.left < 0 ? -r.left : r.right > vw ? vw - r.right : 0;
    const dy = r.top < 0 ? -r.top : r.bottom > vh ? vh - r.bottom : 0;
    if (!dx && !dy) return;
    Object.assign(el.style, { left: ((r.left + dx) / vw) * 100 + '%', top: ((r.top + dy) / vh) * 100 + '%', right: 'auto', bottom: 'auto', transform: 'none' });
  }
  const refit = (key, el) => {
    const pos = obj(E.appliedTheme.positions)[key];
    if (!pos) return;
    place(el, pos, key);
    keepOnScreen(el);
  };
  document.addEventListener('DOMContentLoaded', () => {
    Object.keys(TARGETS).forEach((key) => {
      const el = $(TARGETS[key]);
      if (el) new MutationObserver(() => refit(key, el)).observe(el, { childList: true, attributes: true, attributeFilter: ['class'] });
    });
    const bc = $('broadcasts');
    if (bc) new MutationObserver(() => bc.querySelectorAll('.broadcast').forEach((card) => refit('broadcasts', card))).observe(bc, { childList: true });
  });

  E.applyTheme = function (t) {
    t = obj(t);
    E.appliedTheme = t;
    const root = document.documentElement.style;
    const accent = hexToRgb(t.accent) || hexToRgb((E.cfg.ui && E.cfg.ui.Accent) || '#2563eb');
    const light = mix(accent, [255, 255, 255], 0.35);
    root.setProperty('--accent', hex(accent));
    root.setProperty('--accent-2', hex(light));
    root.setProperty('--accent-3', hex(mix(accent, [0, 0, 0], 0.35)));
    root.setProperty('--accent-soft', rgba(accent, 0.14));
    root.setProperty('--accent-line', rgba(light, 0.30));
    root.setProperty('--accent-glow', rgba(accent, 0.16));
    // Colour / transparency of the notification (right side) only.
    const note = hexToRgb(t.noteColor) || [38, 50, 70];
    const alpha = t.noteAlpha !== undefined && t.noteAlpha !== null ? Number(t.noteAlpha) : 0.8;
    root.setProperty('--toast-bg', rgba(note, alpha));
    root.setProperty('--toast-line', rgba(mix(note, [255, 255, 255], 0.45), 0.22));
    // Transparency of the inquiry cards (left side), set on its own.
    const info = Number(t.infoAlpha);
    if (info >= 0.3 && info <= 1) root.setProperty('--info-alpha', String(info));
    else root.removeProperty('--info-alpha'); // each look keeps its own default
    // Size of the windows (search results, forms, dialogs).
    const sheet = Number(t.sheetScale);
    root.setProperty('--sheet-z', String(sheet >= 0.6 && sheet <= 1.6 ? sheet : 1));
    const positions = obj(t.positions);
    Object.keys(TARGETS).forEach((key) => place($(TARGETS[key]), positions[key], key));
    // Broadcast cards already on screen follow too.
    if (positions.broadcasts) document.querySelectorAll('#broadcasts .broadcast').forEach((card) => place(card, positions.broadcasts, 'broadcasts'));
    E.emit('theme:applied', t); // the iPad re-fits its size
  };

  E.on('theme', (t) => {
    E.theme = obj(t);
    E.theme.positions = obj(E.theme.positions);
    E.applyTheme(E.theme);
  });

  /* --------------------------------------------------------- Layout editor */
  const LABELS = {
    toasts: 'le_toasts', infocards: 'le_infocards', broadcasts: 'le_broadcasts', confirm: 'le_confirm',
    wanted: 'le_wanted', alert: 'le_alert', jail: 'le_jail', idcard: 'le_idcard', progress: 'le_progress',
    hint: 'le_keyhint', badge: 'le_badge',
  };

  // Elements with several looks: theme key, the looks (first = default) and their label keys.
  // The look can be switched from the editor too.
  const LOOKS = {
    toasts: { key: 'toast', cfg: 'toast', list: ['gradient', 'ring', 'classic'], label: 'toast_style_' },
    infocards: { key: 'infoCard', cfg: 'infoCard', list: ['file', 'classic'], label: 'info_card_' },
    confirm: { key: 'confirm', cfg: 'confirmStyle', list: ['compact', 'classic'], label: 'confirm_style_' },
    wanted: { key: 'wanted', cfg: 'wantedStyle', list: ['poster', 'classic'], label: 'wanted_style_' },
    jail: { key: 'jailHud', cfg: 'jailHud', list: ['digital', 'split', 'minimal', 'strip'], label: 'jail_hud_' },
    hint: { key: 'keyHint', cfg: 'keyHint', list: ['glass', 'pill', 'bar', 'keycap'], label: 'key_hint_' },
  };
  const lookOf = (key) => {
    const l = LOOKS[key];
    if (!l) return null;
    const v = (E.appliedTheme && E.appliedTheme[l.key]) || E.cfg[l.cfg];
    return l.list.indexOf(v) >= 0 ? v : l.list[0];
  };

  // A sample of every element, built like the real one (same classes, same parts) so sizes match.
  // look = the look to show (else the one chosen in الواجهة).
  function sample(key, look) {
    const t = (k, f) => E.t(k, null, f);
    look = look || lookOf(key);
    switch (key) {
      case 'toasts': { // the real notification (layers.js) in the look chosen in الواجهة
        const el = E.toastEl({ kind: 'success', message: t('le_sample_toast', 'إشعار تجريبي'), duration: 5 }, look);
        el.classList.add('in');
        return el;
      }
      case 'infocards': { // the real card (layers.js) in the look chosen in الواجهة
        const card = E.infoCardEl({ title: t('le_infocards', 'بطاقة الاستعلام'), file: 12, stamp: { text: t('card_stamp_clean', 'سليم'), tone: 'ok' },
          rows: [[t('card_name', 'الاسم'), 'Ahmed'], [t('id_label', 'رقم الهوية'), 12], [t('card_status', 'الحالة'), t('online', 'متصل'), 'ok'], [t('card_job', 'الوظيفة'), '—']],
          sections: [{ title: t('card_last_fines', 'آخر المخالفات'), records: [[t('le_sample_reason', 'السبب'), '$5,000', '09/30 19:58']] }] }, look);
        card.classList.add('in');
        return card;
      }
      case 'broadcasts': return h('div', { class: 'broadcast in', style: { width: ((E.cfg.broadcast && E.cfg.broadcast.width) || '560px'), position: 'relative', left: 'auto', transform: 'none', '--bc': 'var(--accent)', '--bc-line': 'var(--accent-line)' } },
        h('div', { class: 'bc-head' }, h('div', { class: 'bc-title' }, t('le_broadcasts', 'التعميم'))),
        h('div', { class: 'bc-body' }, t('le_sample_broadcast', 'نص التعميم يظهر هنا')));
      case 'confirm': // the real confirmation (layers.js) in the look chosen in الواجهة
        return E.confirmEl({ title: t('le_confirm', 'التأكيد'), message: t('le_sample_confirm', 'تأكيد الإجراء'), timeout: 30 }, look).el;
      case 'wanted': // the real alert (layers.js) in the look chosen in الواجهة
        return E.wantedEl({ name: 'Ahmed', user_id: 12, reason: t('le_sample_reason', 'السبب'), quickOpen: E.cfg.wanted || {} }, look);
      case 'alert': return h('div', { class: 'alert-chip' }, h('span', null, t('alert_zone_chip', 'منطقة استنفار أمني')));
      case 'jail': {
        // The real counter (layers.js) in the look chosen in الواجهة.
        const card = E.jailCard(look, t('le_jail', 'عداد السجن'), t('le_sample_reason', 'السبب'));
        card.update(1079, 1800);
        return card.el;
      }
      case 'idcard': {
        const row = (label, value, cls) => h('div', { class: 'idc-field ' + (cls || '') }, h('span', null, label), h('b', null, value));
        return h('div', { class: 'idcard in' }, h('div', { class: 'idc-pattern' }),
          h('div', { class: 'idc-top' }, h('div', { class: 'idc-titles' }, h('div', { class: 'idc-country' }, ''), h('div', { class: 'idc-title' }, t('le_idcard', 'الهوية')))),
          h('div', { class: 'idc-body' }, h('div', { class: 'idc-photo' }, E.mugshot(0, 0, 'idc')),
            h('div', { class: 'idc-fields' }, row(t('idcard_name', 'الاسم'), 'Ahmed'), row(t('idcard_id', 'رقم الهوية'), E.digits(12), 'mono'), row(t('idcard_job', 'الوظيفة'), '—'))),
          h('div', { class: 'idc-bottom' },
            h('div', { class: 'idc-code' }, Array.from({ length: 28 }, (_, i) => h('i', { style: { width: ((i * 7) % 3 + 1) + 'px' } }))),
            h('div', { class: 'idc-num mono' }, E.digits('1000095028'))));
      }
      case 'progress': { // the jail task on screen (layers.js)
        const card = E.taskCard('corners', t('le_progress', 'شريط التقدم'));
        card.progress(0.6);
        return card.el;
      }
      case 'hint': return E.keyHintEl('E', t('le_keyhint', 'تلميح الزر'), look);
      case 'badge': // the real badge card (layers.js)
        return E.badgeEl({ country: 'المملكة العربية السعودية', title: t('le_badge', 'الهوية العسكرية'), ministry: t('le_badge', 'الهوية العسكرية'), number: 1,
          name: 'Ahmed', rank: '—', sector: '—', issued: Math.floor(Date.now() / 1000), user_id: 0, fields: {} });
      default: return h('div');
    }
  }

  // Where each element sits when no position is saved (mirrors app.css): top-left corner, in %.
  function defaultPos(key, w, hgt) {
    const vw = window.innerWidth, vh = window.innerHeight;
    const cx = ((vw - w) / 2 / vw) * 100;
    const mid = ((vh - hgt) / 2 / vh) * 100;
    const top = parseFloat((E.cfg.broadcast && E.cfg.broadcast.top) || '26');
    return {
      toasts: { x: ((vw - 22 - w) / vw) * 100, y: 30 },
      infocards: { x: (22 / vw) * 100, y: 28 },
      broadcasts: { x: cx, y: top },
      confirm: { x: cx, y: ((vh * 0.87 - hgt) / vh) * 100 },
      wanted: { x: (24 / vw) * 100, y: 22 },
      alert: { x: cx, y: 12 },
      jail: { x: cx, y: 3.5 },
      idcard: { x: ((vw * 0.96 - w) / vw) * 100, y: mid },
      progress: { x: cx, y: ((vh * 0.88 - hgt) / vh) * 100 },
      hint: { x: cx, y: ((vh * 0.93 - hgt) / vh) * 100 },
      badge: { x: cx, y: 18 },
    }[key];
  }

  // Which elements the editor shows: saved in the theme (إدارة اللوحة) like everything else, so it
  // is the same for every admin. Never saved = all of them.
  function loadShown(list) {
    if (Array.isArray(list)) return list.filter((k) => LABELS[k]);
    return Object.keys(LABELS);
  }
  const SNAP = 10; // px: an element's middle this close to the screen's middle snaps onto it

  // Opens the editor. onSave(positions, looks, shown) when "حفظ" is pressed (looks = { themeKey: look }
  // of the elements whose look was switched here, shown = the elements picked in "العناصر");
  // onClose() whenever it closes. shownList = the saved pick (theme.editorShown).
  E.openLayoutEditor = function (positions, onSave, onClose, shownList) {
    const layer = $('layout-editor');
    E.clear(layer);
    const current = JSON.parse(JSON.stringify(obj(positions)));
    const items = {}, samples = {}, sizes = {}, looks = {}, tags = {};
    const changedLooks = {};
    const shown = new Set(loadShown(shownList));
    let selected = null;
    const finish = () => { E.popEsc('layout'); layer.classList.add('hidden'); E.clear(layer); if (onClose) onClose(); };
    const isShown = (key) => shown.has(key);

    // Box of an item on screen, in % of the screen (what is saved), with its size.
    const measure = (key) => {
      const r = items[key].getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
      return { x: rnd((r.left / vw) * 100), y: rnd((r.top / vh) * 100), w: rnd((r.width / vw) * 100), h: rnd((r.height / vh) * 100), s: sizes[key] };
    };
    const putDefault = (key) => { const el = items[key]; position(el, defaultPos(key, el.offsetWidth, el.offsetHeight), key); };
    const keepInside = (key) => {
      const el = items[key], r = el.getBoundingClientRect(), vw = window.innerWidth, vh = window.innerHeight;
      const x = Math.max(0, Math.min(vw - r.width, r.left)), y = Math.max(0, Math.min(vh - r.height, r.top));
      if (Math.abs(x - r.left) > 0.5 || Math.abs(y - r.top) > 0.5) position(el, { x: (x / vw) * 100, y: (y / vh) * 100 }, key);
    };

    // Centre lines of the screen, shown while an element is dragged (bright when it sits on them).
    const guideV = h('div', { class: 'le-guide v' }), guideH = h('div', { class: 'le-guide h' });
    layer.appendChild(guideV);
    layer.appendChild(guideH);
    layer.appendChild(h('div', { class: 'le-top-hint' }, E.t('le_hint')));

    const tagText = (key) => E.t(LABELS[key]) + (LOOKS[key] ? ' · ' + E.t(LOOKS[key].label + looks[key]) : '');
    Object.keys(LABELS).forEach((key) => {
      looks[key] = lookOf(key);
      const smp = sample(key, looks[key]);
      sizes[key] = sizeOf(current[key]);
      smp.style.zoom = String(sizes[key]);
      const tag = h('span', { class: 'le-tag' }, tagText(key));
      const item = h('div', { class: 'le-item' + (isShown(key) ? '' : ' le-off'), dataset: { key } }, tag, smp);
      layer.appendChild(item);
      items[key] = item;
      samples[key] = smp;
      tags[key] = tag;
    });
    layer.classList.remove('hidden');

    // Initial places (after layout so sizes are known).
    requestAnimationFrame(() => {
      Object.keys(items).forEach((key) => {
        if (!isShown(key)) return;
        if (current[key]) position(items[key], current[key], key); else putDefault(key);
      });
    });

    /* Size of the selected element: + / − buttons or the mouse wheel over it. */
    const sizeName = h('b', { class: 'le-size-name' }, E.t('le_pick'));
    const sizeValue = h('b', { class: 'mono le-size-val' }, '—');
    const minus = h('button', { class: 'btn le-sq', disabled: true, onclick: () => resize(selected, -SIZE_STEP) }, '−');
    const plus = h('button', { class: 'btn le-sq', disabled: true, onclick: () => resize(selected, SIZE_STEP) }, '+');
    /* Look of the selected element: one button switches to the next look. */
    const lookBtn = h('button', { class: 'btn le-look', disabled: true, onclick: () => switchLook(selected) }, E.icon('reset', 15), h('span', null, E.t('le_look_switch')));
    const showSize = () => {
      sizeName.textContent = selected ? E.t(LABELS[selected]) : E.t('le_pick');
      sizeValue.textContent = selected ? E.digits(Math.round(sizes[selected] * 100)) + '%' : '—';
      minus.disabled = plus.disabled = !selected;
      lookBtn.disabled = !(selected && LOOKS[selected]);
      lookBtn.lastChild.textContent = selected && LOOKS[selected] ? E.t('le_look') + ': ' + E.t(LOOKS[selected].label + looks[selected]) : E.t('le_look_switch');
    };
    function switchLook(key) {
      const l = key && LOOKS[key];
      if (!l) return;
      const next = l.list[(l.list.indexOf(looks[key]) + 1) % l.list.length];
      // The new sample keeps the edge that stays in place, like the real element.
      const before = measure(key);
      const smp = sample(key, next);
      smp.style.zoom = String(sizes[key]);
      items[key].replaceChild(smp, samples[key]);
      samples[key] = smp;
      looks[key] = next;
      changedLooks[l.key] = next;
      tags[key].textContent = tagText(key);
      position(items[key], before, key);
      keepInside(key);
      if (current[key]) current[key] = measure(key);
      showSize();
    }
    const select = (key) => {
      if (key && !isShown(key)) key = null;
      if (selected && items[selected]) items[selected].classList.remove('selected');
      selected = key;
      if (key) items[key].classList.add('selected');
      showSize();
    };
    function resize(key, delta) {
      if (!key) return;
      const next = rnd(Math.min(SIZE_MAX, Math.max(SIZE_MIN, sizes[key] + delta)));
      if (next === sizes[key]) return;
      // Grows / shrinks from the edge that stays in place, like the real element.
      const before = measure(key);
      sizes[key] = next;
      samples[key].style.zoom = String(next);
      position(items[key], before, key);
      keepInside(key);
      current[key] = measure(key);
      showSize();
    }

    // Drag & move with the mouse (the bottom bar can be moved too, when it covers something).
    let drag = null;
    layer.onmousedown = (ev) => {
      const bar = ev.target.closest('.le-bar');
      if (bar && ev.target.closest('button, .le-pick')) return;
      const item = bar || ev.target.closest('.le-item');
      if (!item) { select(null); return; }
      ev.preventDefault();
      const rect = item.getBoundingClientRect();
      const vw = window.innerWidth, vh = window.innerHeight;
      // Held by its top-left corner while it moves.
      Object.assign(item.style, { left: (rect.left / vw) * 100 + '%', top: (rect.top / vh) * 100 + '%', right: 'auto', bottom: 'auto', transform: 'none' });
      drag = { item, bar: !!bar, dx: ev.clientX - rect.left, dy: ev.clientY - rect.top, w: rect.width, h: rect.height };
      if (!bar) { select(item.dataset.key); item.classList.add('dragging'); layer.classList.add('le-dragging'); }
    };
    layer.onmousemove = (ev) => {
      if (!drag) return;
      const vw = window.innerWidth, vh = window.innerHeight;
      let x = Math.max(0, Math.min(vw - drag.item.offsetWidth, ev.clientX - drag.dx));
      let y = Math.max(0, Math.min(vh - drag.item.offsetHeight, ev.clientY - drag.dy));
      if (!drag.bar) {
        // Snaps onto the centre lines of the screen (middle of the element on the middle of the screen).
        const onV = Math.abs(x + drag.w / 2 - vw / 2) <= SNAP, onH = Math.abs(y + drag.h / 2 - vh / 2) <= SNAP;
        if (onV) x = vw / 2 - drag.w / 2;
        if (onH) y = vh / 2 - drag.h / 2;
        guideV.classList.toggle('hit', onV);
        guideH.classList.toggle('hit', onH);
      }
      drag.item.style.left = (x / vw) * 100 + '%';
      drag.item.style.top = (y / vh) * 100 + '%';
    };
    layer.onmouseup = () => {
      if (!drag) return;
      if (!drag.bar) {
        const key = drag.item.dataset.key;
        current[key] = measure(key);
        drag.item.classList.remove('dragging');
        layer.classList.remove('le-dragging');
        guideV.classList.remove('hit');
        guideH.classList.remove('hit');
      }
      drag = null;
    };
    layer.onwheel = (ev) => {
      const item = ev.target.closest('.le-item');
      if (!item) return;
      ev.preventDefault();
      select(item.dataset.key);
      resize(item.dataset.key, ev.deltaY < 0 ? SIZE_STEP : -SIZE_STEP);
    };

    /* Which elements are shown: one, several or all. Hidden ones keep their saved place. */
    const pickCount = h('b', { class: 'mono' });
    const chips = {};
    const showCount = () => { pickCount.textContent = E.digits(shown.size) + '/' + E.digits(Object.keys(LABELS).length); };
    const setShown = (key, on) => {
      if (on) shown.add(key); else shown.delete(key);
      items[key].classList.toggle('le-off', !on);
      chips[key].classList.toggle('on', on);
      if (on) {
        // Placed again when it comes back (its sample may have been hidden while the editor opened).
        requestAnimationFrame(() => { if (current[key]) position(items[key], current[key], key); else putDefault(key); keepInside(key); });
      } else if (selected === key) select(null);
    };
    const afterPick = () => showCount();
    Object.keys(LABELS).forEach((key) => {
      chips[key] = h('button', { class: 'le-chip' + (isShown(key) ? ' on' : ''), onclick: () => { setShown(key, !isShown(key)); afterPick(); } },
        h('i'), E.t(LABELS[key]));
    });
    const pickPanel = h('div', { class: 'le-pick hidden' },
      h('div', { class: 'le-pick-head' },
        h('b', null, E.t('le_shown')),
        h('button', { class: 'btn le-mini', onclick: () => { Object.keys(LABELS).forEach((k) => setShown(k, true)); afterPick(); } }, E.t('le_all')),
        h('button', { class: 'btn le-mini', onclick: () => { Object.keys(LABELS).forEach((k) => setShown(k, false)); afterPick(); } }, E.t('le_none'))),
      h('div', { class: 'le-chips' }, Object.keys(LABELS).map((k) => chips[k])));
    const pickBtn = h('button', { class: 'btn', onclick: () => pickPanel.classList.toggle('hidden') }, E.icon('grid', 15), h('span', null, E.t('le_elements')), pickCount);
    showCount();

    const bar = h('div', { class: 'le-bar' },
      pickPanel,
      pickBtn,
      h('div', { class: 'le-size' }, h('span', null, E.t('le_size')), sizeName, minus, sizeValue, plus, lookBtn),
      h('button', { class: 'btn', onclick: () => {
        // Back to the default place and size: the elements on screen only.
        Object.keys(items).forEach((key) => {
          if (!isShown(key)) return;
          delete current[key];
          sizes[key] = 1;
          samples[key].style.zoom = '1';
          putDefault(key);
        });
        showSize();
      } }, E.t('le_defaults')),
      h('button', { class: 'btn btn-primary', onclick: () => {
        // Every element on screen that was moved, resized or saved before is stored with its full box
        // (hidden ones keep what they had).
        Object.keys(current).forEach((key) => { if (items[key] && isShown(key)) current[key] = measure(key); });
        onSave(JSON.parse(JSON.stringify(current)), Object.assign({}, changedLooks), Object.keys(LABELS).filter((k) => shown.has(k)));
        finish();
      } }, E.t('save')),
      h('button', { class: 'btn btn-ghost', onclick: finish }, E.t('cancel')));
    layer.appendChild(bar);
    E.pushEsc('layout', finish);
  };
})();
