/* Codex Police — القائمة العسكرية (police iPad). Every action goes through the server (E.rpc). */
(function () {
  const E = window.BoFaisaL;
  const h = E.h;
  // Like el.append(...) but skips null / false (the native one prints "null").
  const put = (el, ...kids) => E.append(el, kids);
  const root = document.getElementById('ipad-layer');
  const S = { boot: null, tab: 'office', timers: [], open: false, offset: 0, sub: null, recall: null, recallView: null };

  const now = () => Date.now() / 1000 + S.offset;
  const every = (ms, fn) => { const id = setInterval(fn, ms); S.timers.push(id); return id; };
  const clearTimers = () => { S.timers.forEach(clearInterval); S.timers = []; };
  const perm = (p) => !!(S.boot && S.boot.perms && S.boot.perms[p]);
  const empty = (text, icon) => h('div', { class: 'empty' }, E.icon(icon || 'info', 30), h('div', null, text || E.t('none')));
  const loading = () => h('div', { class: 'loading' }, h('span', { class: 'spinner' }), E.t('loading'));
  const confirmHint = () => E.t('confirm_on_screen', { key: (E.cfg.confirm && E.cfg.confirm.accept) || 'F5' });

  const TABS = [
    { id: 'office', icon: 'office', label: 'tab_office', perm: 'office' },
        { id: 'reports', icon: 'report', label: 'tab_reports', perm: 'reports', feature: 'reports' },
    { id: 'online', icon: 'users', label: 'tab_online', perm: 'online' },
    { id: 'wanted', icon: 'target', label: 'tab_wanted', perm: 'wantedList', feature: 'wanted' },
    { id: 'roster', icon: 'grid', label: 'tab_roster', perm: 'roster', feature: 'roster' },
    { id: 'affairs', icon: 'shield', label: 'tab_affairs', perm: 'affairs', feature: 'affairs' },
    { id: 'protocols', icon: 'report', title: 'البروتوكولات العسكرية' },
    { id: 'appearance', icon: 'edit', title: 'مظهر التابلت' },
    { id: 'panel', icon: 'edit', label: 'tab_panel', admin: true },
  ];

  const tabTitle = t => t.title || E.t(t.label);

  function visibleTabs() {
    if (!S.boot) return [];
    if (S.boot.me.vacation) return TABS.filter((t) => ['office','protocols','appearance'].includes(t.id));
    return TABS.filter((t) => (t.admin ? S.boot.panelAdmin === true : (!t.perm || perm(t.perm)) && (!t.feature || S.boot.features[t.feature])));
  }

  // Navigation preferences are local, partitioned by character. They grant no permissions.
  const descriptions = { office: 'حضورك وإنجازاتك', reports: 'البلاغات ومتابعتها', online: 'الزملاء المتواجدون',
    wanted: 'المطلوبون والتعاميم', roster: 'الرتب والأكواد', affairs: 'إجراءات الأفراد', panel: 'إدارة السيرفر', protocols: 'مرجع الاتصال الميداني', appearance: 'إعداداتك الشخصية' };
  const symbols = { office: '◈', reports: '◉', online: '◌', wanted: '⌖', roster: '▦', affairs: '◇', panel: '⚙' };
  let favorites = [], recent = [], launcherOpen = false;
  const preferenceKey = () => 'codex:tabs:' + String(S.boot.me.user_id);
  function loadFavorites() {
    favorites = [];
    try { const saved = JSON.parse(localStorage.getItem(preferenceKey()) || '[]');
      if (Array.isArray(saved)) favorites = [...new Set(saved.filter(id => TABS.some(t => t.id === id)))].slice(0, 7);
    } catch (_) { /* Storage can be unavailable in embedded browsers. */ }
    recent = [];
  }
  function drawShortcuts() {
    const area = E.$('.cx-shortcuts', root); if (!area) return;
    const allowed = visibleTabs(); E.clear(area);
    put(area, h('span', {class:'cx-shortcut-caption'}, 'وصولك السريع'));
    const ids = [...new Set([...favorites, ...recent])].filter(id => allowed.some(t => t.id === id)).slice(0,4);
    if (!ids.length) put(area,h('small',null,'ثبّت أقسامك من النجمة بجانب عنوان الصفحة'));
    ids.forEach(id => { const tab = allowed.find(t => t.id === id);
      put(area,h('button',{class:'cx-shortcut'+(id===S.tab?' selected':''),onclick:()=>go(id)},
        E.icon(tab.icon,14),tabTitle(tab),h('small',null,favorites.includes(id)?'★':'الأخيرة'))); });
    const star = E.$('.cx-pin',root); if (star) { const pinned=favorites.includes(S.tab);
      star.textContent=pinned?'★':'☆'; star.setAttribute('aria-pressed',String(pinned));
      star.title=pinned?'إزالة القسم من المفضلة':'تثبيت القسم في المفضلة'; }
  }
  function toggleFavorite() {
    favorites = favorites.includes(S.tab) ? favorites.filter(id=>id!==S.tab) : [...favorites,S.tab];
    try { localStorage.setItem(preferenceKey(),JSON.stringify(favorites)); } catch (_) {}
    drawShortcuts();
  }
  function hideLauncher() {
    if (!launcherOpen) return; launcherOpen=false;
    E.$('.cx-launcher',root)?.classList.add('hidden');E.popEsc('codex-launcher');
    E.$('.cx-search-open',root)?.focus();
  }
  function showLauncher() {
    if (!S.open || launcherOpen || modalEl) return;
    launcherOpen=true;const overlay=E.$('.cx-launcher',root);overlay.classList.remove('hidden');
    const input=E.$('.cx-launcher-input',root);input.value='';
    const results=E.$('.cx-launcher-results',root);
    const draw=()=>{const query=input.value.trim();const tabs=visibleTabs().filter(t=>(tabTitle(t)+' '+descriptions[t.id]).includes(query));
      E.clear(results);tabs.forEach(t=>put(results,h('button',{class:'cx-launcher-option',onclick:()=>{hideLauncher();go(t.id);}},
        E.icon(t.icon,22),h('span',null,h('b',null,tabTitle(t)),h('small',null,descriptions[t.id])))));
      if(!tabs.length)put(results,empty('لا يوجد قسم مطابق'));
    };
    input.oninput=draw;input.onkeydown=ev=>{if(ev.key==='Enter'){const first=E.$('.cx-launcher-option',results);if(first){ev.preventDefault();first.click();}}};
    overlay.onkeydown=ev=>{if(ev.key!=='Tab')return;
      const items=[...overlay.querySelectorAll('button,input')].filter(el=>!el.disabled);
      const first=items[0],last=items[items.length-1];
      if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus();}
      else if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus();}
    };
    draw();E.pushEsc('codex-launcher',hideLauncher);input.focus();
  }
  window.addEventListener('keydown',ev=>{if(S.open&&(ev.ctrlKey||ev.metaKey)&&ev.key.toLowerCase()==='k'){ev.preventDefault();showLauncher();}});

  // Personal presentation never writes the server theme or changes permissions.
  const defaultPersonal = () => ({ size: 0, accent: '#a2b6d2', layout: 'top', density: 'comfortable', contrast: false });
  let personal = defaultPersonal();
  const personalKey = () => 'codex:appearance:' + String(S.boot.me.user_id);
  const protocolKey = () => 'codex:protocol-image:' + String(S.boot.me.user_id);
  function validatePersonal(value) {
    const v=value&&typeof value==='object'?value:{};const size=Number(v.size);
    return {size:size>=.45&&size<=.9?size:0,accent:/^#[0-9a-f]{6}$/i.test(v.accent||'')?v.accent:'#a2b6d2',
      layout:v.layout==='side'?'side':'top',density:v.density==='compact'?'compact':'comfortable',contrast:v.contrast===true};
  }
  function loadPersonal() {
    personal=defaultPersonal();try{personal=validatePersonal(JSON.parse(localStorage.getItem(personalKey())||'{}'));}catch(_){}
  }
  function applyPersonal() {
    const tablet=E.$('.ipad',root);if(!tablet)return;
    tablet.classList.toggle('cx-layout-side',personal.layout==='side');
    tablet.classList.toggle('cx-compact',personal.density==='compact');
    tablet.classList.toggle('cx-high-contrast',personal.contrast);
    tablet.style.setProperty('--cx-user-accent',personal.accent);fit();
  }
  function savePersonal() {
    try{localStorage.setItem(personalKey(),JSON.stringify(personal));E.toast('تم حفظ مظهر التابلت لهذه الشخصية','success');}
    catch(_){E.toast('تم تطبيق المظهر لهذه الجلسة؛ تعذر الحفظ على الجهاز','warning');}
  }
  function viewAppearance(view) {
    setTitle('مظهر التابلت','إعدادات شخصية على جهازك • لا تغيّر مظهر اللاعبين الآخرين');
    const size=h('input',{type:'range',min:45,max:90,step:1,value:Math.round((personal.size||Number(E.cfg.ipad?.size)||.6)*100)});
    const output=h('span',{class:'mono'},size.value+'%');
    size.oninput=()=>{personal.size=Number(size.value)/100;output.textContent=size.value+'%';applyPersonal();};
    const color=h('input',{type:'color',value:personal.accent,oninput:ev=>{personal.accent=ev.target.value;applyPersonal();},'aria-label':'لون تمييز التابلت'});
    const select=(label,options,value,change)=>{const input=h('select',{'aria-label':label,onchange:ev=>change(ev.target.value)},options.map(([id,text])=>h('option',{value:id},text)));input.value=value;return h('label',{class:'field'},h('span',null,label),input);};
    const contrast=h('input',{type:'checkbox',checked:personal.contrast,onchange:ev=>{personal.contrast=ev.target.checked;applyPersonal();}});
    put(view,h('div',{class:'card cx-personal-card'},h('div',{class:'card-head'},E.icon('edit',20),'على ذوقك'),
      h('p',{class:'muted'},'جرّب المظهر مباشرة، ثم اضغط حفظ. المفضلة والمظهر منفصلان لكل شخصية.'),
      h('label',{class:'field'},h('span',null,'حجم التابلت'),h('div',{class:'range-row'},size,output)),
      h('label',{class:'field'},h('span',null,'لون التمييز'),color),
      select('مكان التنقل',[['top','شريط علوي'],['side','قائمة جانبية']],personal.layout,value=>{personal.layout=value;applyPersonal();}),
      select('تباعد العناصر',[['comfortable','مريح'],['compact','مضغوط']],personal.density,value=>{personal.density=value;applyPersonal();}),
      h('label',{class:'cx-check'},contrast,h('span',null,'تباين أعلى للقراءة')),
      h('div',{class:'actions'},h('button',{class:'btn btn-primary',onclick:savePersonal},E.icon('check',16),'حفظ مظهري'),
        h('button',{class:'btn btn-ghost',onclick:()=>{personal=defaultPersonal();applyPersonal();savePersonal();go('appearance',true);}},'استعادة الافتراضي'))));
  }
  function viewProtocols(view) {
    setTitle('البروتوكولات العسكرية','مرجع ميداني • تكبير الصورة دون مغادرة التابلت');
    let zoom=100;
    const message=h('div',{class:'empty'},'تعذر تحميل صورة البروتوكولات. تحقق من رابط Config.Ipad.ProtocolsImage واتصالك، أو اختر صورة من جهازك.');
    const image=h('img',{class:'cx-protocol-image',alt:'صورة البروتوكولات العسكرية',draggable:false,onload:()=>message.classList.add('hidden'),onerror:()=>{image.classList.add('hidden');message.classList.remove('hidden');}});
    let saved='';try{saved=localStorage.getItem(protocolKey())||'';}catch(_){}
    const safeData=value=>/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value)&&value.length<3000000;
    const configured=S.boot.protocolsImage||'assets/protocols.png';
    let asset='assets/protocols.png';
    if(typeof configured==='string') {
      if(/^assets\/[a-zA-Z0-9_./-]+\.(png|jpg|jpeg|webp)$/.test(configured)&&!configured.includes('..')) asset=configured;
      else { try { const url=new URL(configured); if(url.protocol==='https:'&&!url.username&&!url.password) asset=url.href; } catch(_){} }
    }
    image.referrerPolicy='no-referrer';
    image.src=safeData(saved)?saved:asset;
    const label=h('span',{class:'mono'},'100%');
    const scale=delta=>{zoom=Math.max(50,Math.min(250,zoom+delta));image.style.width=zoom+'%';label.textContent=zoom+'%';};
    const file=h('input',{type:'file',accept:'image/png,image/jpeg,image/webp','aria-label':'اختيار صورة البروتوكولات',onchange:ev=>{
      const selected=ev.target.files[0];if(!selected)return;
      if(!['image/png','image/jpeg','image/webp'].includes(selected.type)||selected.size>2000000){E.toast('اختر صورة PNG أو JPG أو WebP بحجم أقل من 2 ميغابايت','error');return;}
      const reader=new FileReader();reader.onload=()=>{if(!S.open||S.tab!=='protocols')return;
        if(!safeData(String(reader.result))){E.toast('تعذر قراءة الصورة','error');return;}
        image.classList.remove('hidden');image.src=reader.result;scale(100-zoom);
        try{localStorage.setItem(protocolKey(),reader.result);E.toast('تم حفظ الصورة لهذه الشخصية على جهازك','success');}
        catch(_){E.toast('الصورة متاحة لهذه الجلسة؛ تعذر الحفظ على الجهاز','warning');}
      };reader.readAsDataURL(selected);
    }});
    put(view,h('div',{class:'card'},h('div',{class:'actions wrap'},
      h('button',{class:'btn btn-ghost',title:'تكبير الصورة',onclick:()=>scale(25)},E.icon('plus',16)),label,
      h('button',{class:'btn btn-ghost',title:'تصغير الصورة',onclick:()=>scale(-25)},E.icon('minus',16)),
      h('button',{class:'btn btn-ghost',onclick:()=>scale(100-zoom)},'حجم أصلي'),file,
      h('button',{class:'btn btn-ghost',onclick:()=>{try{localStorage.removeItem(protocolKey());}catch(_){}image.classList.remove('hidden');image.src=asset;scale(100-zoom);}},'صورة السيرفر')),
      h('p',{class:'muted'},'اختيار صورة من جهازك يغيّر مرجعك المحلي فقط. صورة السيرفر يحددها مسؤول السيرفر.'),
      h('div',{class:'cx-protocol-canvas'},message,image)));
  }

  /* ---------------------------------------------------------------- Shell */
  function fit() {
    const scaler = E.$('.ipad-scaler', root);
    if (!scaler) return;
    // Share of the screen width the iPad takes (kept inside the screen height): إدارة اللوحة first,
    // then Config.Ipad.Size.
    const size = Math.min(Math.max(Number(E.appliedTheme && E.appliedTheme.ipadSize) || Number(E.cfg.ipad && E.cfg.ipad.size) || 0.6, 0.3), 0.95);
    const personalSize = personal.size || size;
    const s = Math.min((window.innerWidth * personalSize) / 1280, (window.innerHeight * Math.min(personalSize + 0.1, 0.93)) / 800);
    // zoom (not transform: scale) keeps the text sharp at any size.
    scaler.style.zoom = s.toFixed(3);
  }
  window.addEventListener('resize', fit);
  E.on('theme:applied', fit);

  function renderShell() {
    const me = S.boot.me;
    launcherOpen = false;
    const nav = h('nav', { class: 'nav' }, visibleTabs().map((t) =>
      h('button', { class: 'nav-item' + (t.id === S.tab ? ' active' : ''), dataset: { tab: t.id }, onclick: () => go(t.id) },
        h('span', { class: 'nav-ico cx-symbol cx-symbol-'+t.id }, E.icon(t.icon,20)), h('span', { class: 'nav-label' }, tabTitle(t), h('small', {class:'cx-nav-description'},descriptions[t.id])),
        h('span', { class: 'nav-badge hidden', dataset: { badge: t.id } }))));
    const dutyDot = h('span', { class: 'duty-dot' + (S.boot.office.onDuty ? ' on' : '') });
    const clockEl = h('span', { class: 'sb-time mono' });
    const tickClock = () => { const d = new Date(); clockEl.textContent = E.digits(String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0')); };
    tickClock();
    const shell = h('div', { class: 'ipad-backdrop' },
      h('div', { class: 'ipad-scaler' },
        h('div', { class: 'ipad' },
          h('div', { class: 'ipad-cam' }),
          h('div', { class: 'screen' },
            h('div', { class: 'statusbar' }, clockEl, h('span', { class: 'sb-net' }, (E.cfg.ui && E.cfg.ui.ServerName) || E.t('status_bar_net')),
              h('span', { class: 'sb-bat' }, h('i'), E.digits('92%'))),
            h('div', { class: 'screen-body' },
              h('aside', { class: 'sidebar' },
                h('div',{class:'bf-military-brand'},h('b',null,'Codex'),h('small',null,'مركز القيادة • COMMAND')),
                nav,
                h('div', { class: 'me-card' }, E.avatar(me.name, me.avatar, 42),
                  h('div', { class: 'me-info' }, h('div', { class: 'me-name' }, me.name, dutyDot), h('div', { class: 'me-rank' }, me.vacation ? E.t('office_vacation') : (me.rank || '—')),h('small',{class:'cx-credit'},'حقوق التطوير Codex')))),
              h('main', { class: 'main' },
                h('header', { class: 'topbar' },
                  h('div', null, h('div', { class: 'page-title' }), h('div', { class: 'page-sub' })),
                  h('div', { class: 'top-actions' },
                    h('span', { class: 'top-extra' }),
                    h('button',{class:'icon-btn cx-search-open',title:'البحث عن قسم — Ctrl+K',onclick:showLauncher},E.icon('search',18)),
                    h('button',{class:'icon-btn cx-pin',title:'تثبيت القسم في المفضلة','aria-pressed':'false',onclick:toggleFavorite},'☆'),
                    h('button', { class: 'icon-btn', title: E.t('refresh'), onclick: () => go(S.tab, true) }, E.icon('refresh', 18)),
                    h('button', { class: 'icon-btn close', title: E.t('close'), onclick: close }, E.icon('x', 18)))),
                h('div',{class:'cx-shortcuts'}),
                h('section', { class: 'view' })))))),
      h('div', {class:'cx-launcher hidden',onclick:ev=>{if(ev.target===ev.currentTarget)hideLauncher();}},
        h('div',{class:'cx-launcher-box',role:'dialog','aria-modal':'true','aria-label':'البحث عن أقسام المركز'},
          h('div',{class:'cx-launcher-head'},h('b',null,'انتقل مباشرة'),h('button',{class:'icon-btn',title:'إغلاق البحث',onclick:hideLauncher},E.icon('x',16))),
          h('input',{class:'cx-launcher-input',placeholder:'ابحث عن قسم…','aria-label':'ابحث عن قسم'}),
          h('div',{class:'cx-launcher-results'}),h('small',null,'Enter للانتقال • Esc للعودة • Ctrl+K للبحث'))),
      h('div', { class: 'modal-host' }));
    E.clear(root).appendChild(shell);
    clearInterval(S.clockTimer);
    S.clockTimer = setInterval(tickClock, 15000);
    applyPersonal();
    fit();
  }

  function setTitle(title, sub) {
    E.$('.page-title', root).textContent = title;
    E.$('.page-sub', root).textContent = sub || (me() ? (me().sectorLabel || me().ministryLabel || '') : '');
  }
  const me = () => S.boot && S.boot.me;

  async function open(tab) {
    E.post('ipadShown', {}); // tells the client the command arrived (else it frees the mouse)
    if (!S.open) {
      S.open = true;
      E.clear(root).appendChild(h('div', { class: 'ipad-backdrop' }, h('div', { class: 'ipad-boot' }, h('span', { class: 'boot-ico' }, E.icon('shield', 64)), h('div', { class: 'boot-bar' }, h('i')))));
      root.classList.remove('hidden');
      requestAnimationFrame(() => root.classList.add('in'));
      E.pushEsc('ipad', close);
    }
    const r = await E.rpc('ipad:bootstrap');
    if (!r.ok) {
      E.toast(r.data || E.t('open_ipad_error'), 'error');
      close();
      return;
    }
    S.boot = r.data;
    loadFavorites();
    loadPersonal();
    S.offset = r.data.now - Date.now() / 1000;
    const tabs = visibleTabs();
    if (!tabs.length) { // no page this rank may see
      E.toast(E.t('ipad_no_tabs'), 'error');
      close();
      return;
    }
    S.tab = tabs.some((t) => t.id === tab) ? tab : tabs[0].id;
    try {
      renderShell();
      go(S.tab);
    } catch (err) {
      // Never leave a frozen screen: close with a message.
      console.error('[BoFaisaL] iPad', err);
      E.toast(E.t('open_ipad_error'), 'error');
      close();
    }
  }

  function close() {
    if (!S.open) return;
    hideLauncher();
    S.open = false;
    if (S.panelDirty) { S.panelDirty = false; E.applyTheme(E.theme); }
    clearTimers();
    clearInterval(S.clockTimer);
    closeModal();
    root.classList.remove('in');
    E.popEsc('ipad');
    setTimeout(() => { if (!S.open) { root.classList.add('hidden'); E.clear(root); } }, 250);
    E.post('close', { layer: 'ipad' });
  }

  function go(tab, force) {
    if (!S.boot) return;
    // Unsaved preview from إدارة اللوحة: back to the saved look.
    if (S.panelDirty) { S.panelDirty = false; E.applyTheme(E.theme); }
    if (!visibleTabs().some((t) => t.id === tab)) tab = (visibleTabs()[0] || { id: 'office' }).id;
    if (S.tab === tab && !force && S.sub) S.sub = null;
    S.tab = tab;
    recent = [tab,...recent.filter(id=>id!==tab)].slice(0,4);
    drawShortcuts();
    clearTimers();
    S.recallView = null;
    const extra = E.$('.top-extra', root);
    if (extra) E.clear(extra);
    root.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    const view = E.clear(E.$('.view', root));
    view.classList.remove('enter');
    void view.offsetWidth;
    view.classList.add('enter');
    ({ office: viewOffice, online: viewOnline, reports: viewReports, wanted: viewWanted, affairs: viewAffairs, roster: viewRoster, protocols: viewProtocols, appearance: viewAppearance, panel: viewPanel })[tab](view);
  }

  /* ---------------------------------------------------------------- Modal */
  let modalEl = null;
  let modalOnClose = null;
  function closeModal() {
    if (modalEl) { modalEl.remove(); modalEl = null; E.popEsc('ipad-modal'); }
    const fn = modalOnClose;
    modalOnClose = null;
    if (fn && S.open) fn();
  }
  function modal(opts) {
    closeModal();
    modalOnClose = opts.onClose || null;
    const host = E.$('.modal-host', root);
    modalEl = h('div', { class: 'modal-backdrop', onclick: (ev) => { if (ev.target === modalEl) closeModal(); } },
      h('div', { class: 'modal' + (opts.wide ? ' wide' : '') },
        h('div', { class: 'modal-head' }, h('div', { class: 'modal-title' }, opts.icon ? E.icon(opts.icon, 18) : null, opts.title),
          h('button', { class: 'icon-btn', onclick: closeModal }, E.icon('x', 16))),
        h('div', { class: 'modal-body' }, opts.body),
        opts.actions ? h('div', { class: 'modal-actions' }, opts.actions) : null));
    host.appendChild(modalEl);
    E.pushEsc('ipad-modal', closeModal);
    const first = modalEl.querySelector('input, textarea');
    if (first) setTimeout(() => first.focus(), 30);
    return modalEl;
  }

  // Runs an action and shows the result. Actions needing F5 wait on the server.
  async function act(button, name, payload, successText) {
    if (button) { button.disabled = true; button.classList.add('busy'); }
    const r = await E.rpc(name, payload);
    if (button) { button.disabled = false; button.classList.remove('busy'); }
    if (r.ok) { if (successText) E.toast(successText, 'success'); }
    else E.toast(r.data || E.t('no_data'), 'error');
    return r;
  }

  /* =============================================================== مكتبي */
  function statCard(icon, label, valueEl, accent) {
    return h('div', { class: 'stat' + (accent ? ' accent' : '') }, h('div', { class: 'stat-ico' }, E.icon(icon, 20)),
      h('div', { class: 'stat-label' }, label), h('div', { class: 'stat-value mono' }, valueEl));
  }

  async function viewOffice(view) {
    setTitle(E.t('tab_office'));
    const b = S.boot;
    let o = b.office;
    const fresh = await E.rpc('ipad:office');
    if (S.tab !== 'office') return;
    if (fresh.ok) { o = fresh.data; S.offset = o.now - Date.now() / 1000; b.office = o; }
    const m = b.me;
    const sessionEl = h('span', null, E.clock(o.session));
    const totalEl = h('span', null, E.hours(o.attendance));
    const base = { at: now(), session: o.session, total: o.attendance };
    if (o.onDuty) every(1000, () => {
      const extra = now() - base.at;
      sessionEl.textContent = E.clock(base.session + extra);
      totalEl.textContent = E.hours(base.total + extra);
    });

    const dutyBtn = h('button', { class: 'btn btn-lg ' + (o.onDuty ? 'btn-danger' : 'btn-primary'), onclick: async () => {
      const r = await act(dutyBtn, 'office:clock', {});
      if (r.ok) { b.office.onDuty = r.data.onDuty; go('office', true); const dot = E.$('.duty-dot', root); if (dot) dot.classList.toggle('on', r.data.onDuty); }
    } }, E.icon('power', 18), o.onDuty ? E.t('office_clock_out') : E.t('office_clock_in'));

    const hero = h('div', { class: 'hero' },
      h('div', { class: 'hero-glow' }),
      E.avatar(m.name, m.avatar, 76),
      h('div', { class: 'hero-info' },
        h('div', { class: 'hero-hello' }, E.t('office_welcome') + '،'),
        h('div', { class: 'hero-name' }, m.name),
        h('div', { class: 'hero-tags' },
          h('span', { class: 'chip mono' }, E.t('id_label') + ' ' + E.digits(m.user_id)),
          m.rank ? h('span', { class: 'chip accent' }, E.icon('star', 13), m.rank) : null,
          m.sectorLabel ? h('span', { class: 'chip' }, m.sectorLabel) : null,
          m.ministryLabel ? h('span', { class: 'chip' }, m.ministryLabel) : null)),
      h('div', { class: 'hero-duty' },
        h('div', { class: 'duty-state ' + (o.onDuty ? 'on' : 'off') }, h('i'), o.onDuty ? E.t('on_duty') : E.t('off_duty')),
        b.features.clock && perm('clock') && !m.vacation ? dutyBtn : null));

    const stats = h('div', { class: 'stats' },
      statCard('fine', E.t('office_fines'), E.digits(o.finesIssued), true),
      statCard('clock', E.t('office_session'), sessionEl),
      statCard('hourglass', E.t('office_total'), totalEl),
      statCard('jail', E.t('office_jails'), E.digits(o.jailsIssued)));

    // Military code (codeLinked: it is the code in الجدول العسكري, changed from there only)
    const codeValue = h('span', { class: 'code-value mono' }, o.code || '—');
    const codeCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, E.icon('radio', 18), h('span', null, E.t('office_code'))),
      h('div', { class: 'code-row' }, codeValue,
        !b.codeLinked && perm('militaryCode') ? h('button', { class: 'btn btn-ghost', onclick: () => {
          const input = h('input', { type: 'text', maxlength: b.codeMax || 12, value: o.code || '', placeholder: E.t('office_code_placeholder') });
          const save = h('button', { class: 'btn btn-primary', onclick: async () => {
            const r = await act(save, 'office:setCode', { code: input.value }, E.t('code_saved'));
            if (r.ok) { o.code = r.data.code; codeValue.textContent = r.data.code || '—'; closeModal(); }
          } }, E.icon('check', 16), E.t('save'));
          modal({ title: E.t('office_code_edit'), icon: 'radio', body: h('label', { class: 'field' }, h('span', null, E.t('office_code')), input), actions: [save] });
        } }, E.icon('edit', 16), E.t('office_code_edit')) : null));

    // Vacation
    const vac = o.vacation || {};
    const vacLeft = () => Math.max(0, Math.ceil(((vac.endsAt || 0) - now()) / 60));
    const vacLeftEl = h('span', null, E.digits(vacLeft()));
    if (vac.active) every(1000, () => { vacLeftEl.textContent = E.digits(vacLeft()); });
    const vacBody = vac.active
      ? h('div', { class: 'vac-active' },
          h('div', { class: 'muted' }, E.t('office_vacation_remaining')),
          h('div', { class: 'vac-balance mono' }, vacLeftEl, h('small', null, ' ' + E.t('minutes'))),
          h('div', { class: 'muted small' }, E.t('office_vacation_active') + ' ' + E.date(vac.endsAt)),
          h('button', { class: 'btn btn-danger', onclick: async (ev) => { const r = await act(ev.currentTarget, 'vacation:break', {}); if (r.ok) setTimeout(() => open('office'), 400); } },
            E.icon('power', 16), E.t('office_vacation_break')))
      : h('div', { class: 'vac-idle' },
          h('div', null, h('div', { class: 'muted' }, E.t('office_vacation_balance')), h('div', { class: 'vac-balance mono' }, E.digits(o.vacationBalance), h('small', null, ' ' + E.t('minutes')))),
          b.features.vacation && perm('vacation') && o.vacationBalance > 0 ? h('button', { class: 'btn btn-primary', onclick: () => vacationModal(o) }, E.icon('sun', 16), E.t('office_vacation_request')) : null);
    const vacCard = h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('sun', 18), h('span', null, E.t('office_vacation'))), vacBody);

    // Service activity
    const actRow = (icon, label, value) => h('div', { class: 'activity-row' },
      h('span', { class: 'activity-ico' }, E.icon(icon, 16)), h('span', { class: 'grow muted' }, label), h('b', { class: 'mono' }, value));
    const activityCard = h('div', { class: 'card' },
      h('div', { class: 'card-head' }, E.icon('chart', 18), h('span', null, E.t('office_activity'))),
      h('div', { class: 'activity' },
        actRow('report', E.t('office_reports'), E.digits(o.reportsHandled || 0)),
        actRow('car', E.t('office_impounds'), E.digits(o.impoundsIssued || 0)),
        actRow('clock', E.t('office_last_in'), E.date(o.lastClockIn)),
        actRow('power', E.t('office_last_out'), E.date(o.lastClockOut))));

    // My points and my place among all officers, with how points are earned.
    const st = o.standing || {};
    const pointsCard = st.total ? h('div', { class: 'card points-card' },
      h('div', { class: 'pc-row' },
        h('div', { class: 'pc-box' }, h('div', { class: 'pc-ico' }, E.icon('trophy', 24)),
          h('div', null, h('div', { class: 'stat-label' }, E.t('office_points')), h('div', { class: 'pc-value mono' }, E.digits(st.points || 0)))),
        h('div', { class: 'pc-box' }, h('div', { class: 'pc-ico' }, E.icon('chart', 24)),
          h('div', null, h('div', { class: 'stat-label' }, E.t('office_rank')),
            h('div', { class: 'pc-value mono' }, st.position ? '#' + E.digits(st.position) : '—'),
            h('div', { class: 'muted small' }, E.t('office_rank_of', { total: E.digits(st.total) }, 'من {total} عسكري')))))) : null;

    // The vacation card only for ranks with the "vacation" permission (or an officer on vacation, to break it).
    const showVac = vac.active || (b.features.vacation && perm('vacation'));
    put(E.clear(view), hero, stats, pointsCard, showVac ? h('div', { class: 'grid-2' }, codeCard, vacCard) : codeCard, activityCard);
  }

  // The vacation uses the whole balance; no duration to choose.
  function vacationModal(o) {
    const send = h('button', { class: 'btn btn-primary', onclick: async () => {
      const r = await act(send, 'vacation:request', {});
      if (r.ok) { closeModal(); setTimeout(() => open('office'), 400); }
    } }, E.icon('check', 16), E.t('office_vacation_request'));
    modal({
      title: E.t('vacation_request_title'), icon: 'sun',
      body: h('div', { class: 'stack' },
        h('div', { class: 'callout' }, E.icon('info', 16), E.t('office_vacation_balance') + ': ' + E.digits(o.vacationBalance) + ' ' + E.t('minutes'))),
      actions: [send],
    });
  }

  /* ============================================================= المتصلين */
  async function viewOnline(view) {
    setTitle(E.t('tab_online'));
    E.clear(view).appendChild(loading());
    const r = await E.rpc('ipad:online');
    if (S.tab !== 'online') return;
    if (!r.ok) return E.clear(view).appendChild(empty(r.data));
    S.offset = r.data.now - Date.now() / 1000;
    const list = r.data.list || [];
    // Two filters: sector (all / one sector) and duty (all connected / on duty only).
    let sector = '';
    let dutyOnly = false;
    const sectors = Array.from(new Set(list.map((o) => o.sectorLabel).filter(Boolean)));
    const counter = h('div', { class: 'count-pill' }, E.icon('users', 16), h('span'));
    const tableBody = h('div', { class: 'table-body' });
    const draw = () => {
      E.clear(tableBody);
      const rows = list.filter((o) => (!sector || o.sectorLabel === sector) && (!dutyOnly || o.onDuty));
      counter.lastChild.textContent = E.digits(rows.length);
      if (!rows.length) return tableBody.appendChild(empty(E.t('online_empty'), 'users'));
      rows.forEach((o) => {
        tableBody.appendChild(h('div', { class: 'trow' },
          h('div', { class: 'tcell name' }, E.avatar(o.name, o.avatar, 34), h('div', null, h('b', null, o.name), h('div', { class: 'muted small' }, o.rank))),
          h('div', { class: 'tcell mono' }, E.digits(o.user_id)),
          h('div', { class: 'tcell' }, h('span', { class: 'chip' }, o.sectorLabel || '—')),
          h('div', { class: 'tcell' }, h('span', { class: 'badge ' + (o.onDuty ? 'ok' : 'off') }, o.onDuty ? E.t('on_duty') : E.t('off_duty'))),
          h('div', { class: 'tcell' }, o.code ? h('span', { class: 'code-pill mono' }, o.code) : h('span', { class: 'muted' }, '—'))));
      });
    };
    const chipGroup = (items, onPick) => {
      const box = h('div', { class: 'chips' });
      items.forEach(([label, value], i) => box.appendChild(h('button', { class: 'chip-btn' + (i === 0 ? ' active' : ''), onclick: (ev) => {
        box.querySelectorAll('.chip-btn').forEach((b) => b.classList.remove('active'));
        ev.currentTarget.classList.add('active');
        onPick(value);
        draw();
      } }, label)));
      return box;
    };
    const sectorFilter = chipGroup([[E.t('all_sectors'), '']].concat(sectors.map((s) => [s, s])), (v) => { sector = v; });
    const dutyFilter = chipGroup([[E.t('filter_all'), false], [E.t('filter_on_duty'), true]], (v) => { dutyOnly = v; });
    put(E.clear(view), 
      h('div', { class: 'toolbar' }, counter, h('div', { class: 'filters' }, dutyFilter, sectorFilter)),
      h('div', { class: 'table online' },
        h('div', { class: 'thead' }, ['col_name', 'col_id', 'col_sector', 'col_status', 'col_code'].map((k) => h('div', { class: 'tcell' }, E.t(k)))),
        tableBody));
    draw();
  }

  /* ============================================================== البلاغات */
  // Open reports only. A report disappears after it is finished or when it expires.
  async function viewReports(view) {
    setTitle(E.t('tab_reports'));
    E.clear(view).appendChild(loading());
    const r = await E.rpc('reports:list');
    if (S.tab !== 'reports') return;
    if (!r.ok) return E.clear(view).appendChild(empty(r.data));
    S.offset = r.data.now - Date.now() / 1000;
    const items = r.data.list || [];
    if (!items.length) {
      E.clear(view).appendChild(h('div', { class: 'center-empty' }, E.icon('report', 44), h('div', null, E.t('reports_empty'))));
      setBadge('reports', 0);
      return;
    }
    const list = h('div', { class: 'report-list' });
    items.forEach((rep) => list.appendChild(reportCard(rep, r.data.me, view)));
    put(E.clear(view), list);
    setBadge('reports', items.filter((x) => x.status === 'new').length);
  }

  function reportCard(rep, meId, view) {
    const mine = rep.assigned && rep.assigned.id === meId;
    const actions = [];
    const run = (btn, name) => act(btn, name, { id: rep.id }).then((res) => { if (res.ok) viewReports(view); });
    if (rep.status === 'new') {
      const b = h('button', { class: 'btn btn-primary', onclick: () => run(b, 'reports:claim') }, E.icon('check', 16), E.t('report_claim'));
      actions.push(b);
    }
    if (mine && rep.status === 'claimed') {
      const b = h('button', { class: 'btn btn-success', onclick: () => run(b, 'reports:finish') }, E.icon('lock', 16), E.t('report_finish'));
      actions.push(b);
    }
    if (rep.hasLocation) {
      const w = h('button', { class: 'btn btn-ghost', onclick: () => act(w, 'reports:waypoint', { id: rep.id }) }, E.icon('pin', 16), E.t('report_waypoint'));
      actions.push(w);
    }
    const expires = h('span', { class: 'muted small mono' });
    const tick = () => { expires.textContent = E.t('report_expires') + ' ' + E.mmss(Math.max(0, rep.expiresAt - now())); };
    tick();
    every(1000, tick);
    const t = rep.target;
    // Photo of the reported player across the top, details under it.
    return h('div', { class: 'report st-' + rep.status },
      h('div', { class: 'report-photo' },
        E.mugshot(t.id, t.mugshotAt, 'wide'),
        h('div', { class: 'report-head' },
          h('span', { class: 'report-id mono' }, '#' + E.digits(rep.id)),
          h('span', { class: 'badge st-' + rep.status }, E.t('status_' + rep.status))),
        h('span', { class: 'chip poster-state ' + (t.online ? 'ok' : '') }, t.online ? E.t('online') : E.t('offline'))),
      h('div', { class: 'report-body' },
        h('div', { class: 'rt-row' }, h('span', null, E.t('card_name') + ':'), h('b', null, t.name)),
        h('div', { class: 'rt-row' }, h('span', null, E.t('id_label') + ':'), h('b', { class: 'mono' }, E.digits(t.id))),
        h('div', { class: 'rt-row' }, h('span', null, E.t('report_reason') + ':'), h('b', null, rep.reason)),
        h('div', { class: 'rt-row muted small' }, expires),
        h('div', { class: 'report-foot' },
          h('span', { class: 'muted small' }, E.t('report_reporter') + ': ' + rep.reporter.name + (rep.assigned ? ' • ' + E.t('report_assigned') + ': ' + rep.assigned.name : '')),
          h('div', { class: 'report-actions' }, actions))));
  }

  function setBadge(tab, n) {
    const el = root.querySelector('[data-badge="' + tab + '"]');
    if (!el) return;
    el.textContent = E.digits(n);
    el.classList.toggle('hidden', !n);
  }

  /* ========================================================= مطلوبين الدولة */
  async function viewWanted(view) {
    setTitle(E.t('tab_wanted'));
    // "+" next to refresh: only ranks with the wantedAdd permission.
    const extra = E.$('.top-extra', root);
    if (extra) {
      E.clear(extra);
      if (perm('wantedAdd')) extra.appendChild(h('button', { class: 'icon-btn', title: E.t('wanted_add'), onclick: () => wantedAddModal(view) }, E.icon('plus', 18)));
    }
    E.clear(view).appendChild(loading());
    const r = await E.rpc('wanted:list');
    if (S.tab !== 'wanted') return;
    if (!r.ok) return E.clear(view).appendChild(empty(r.data));
    const list = r.data || [];
    if (!list.length) {
      E.clear(view).appendChild(h('div', { class: 'wanted-empty' }, h('div', { class: 'we-ring' }, E.icon('shield', 44)), h('div', { class: 'we-text' }, E.t('wanted_none'))));
      return;
    }
    const grid = h('div', { class: 'wanted-grid' }, list.map((w) => wantedPoster(w, view)));
    put(E.clear(view), h('div', { class: 'toolbar' }, h('div', { class: 'count-pill danger' }, E.icon('target', 16), E.t('wanted_count', { count: E.digits(list.length) }))), grid);
  }

  function wantedPoster(w, view) {
    const remove = perm('wantedClear') ? h('button', { class: 'btn btn-ghost small', onclick: async () => { const res = await act(remove, 'wanted:clear', { id: w.id }); if (res.ok) viewWanted(view); } }, E.icon('trash', 14), E.t('wanted_remove')) : null;
    // Character photo across the whole top of the card, every detail under it.
    return h('div', { class: 'poster' },
      h('div', { class: 'poster-photo' },
        E.mugshot(w.target.id, w.target.mugshotAt, 'wide'),
        h('div', { class: 'poster-band' }, E.icon('target', 14), E.t('wanted_title')),
        h('span', { class: 'chip poster-state ' + (w.target.online ? 'ok' : '') }, w.target.online ? E.t('online') : E.t('offline'))),
      h('div', { class: 'poster-body' },
        h('div', { class: 'poster-name' }, w.target.name),
        h('div', { class: 'poster-id mono' }, E.t('id_label') + ' ' + E.digits(w.target.id)),
        h('div', { class: 'poster-rows' },
          h('div', { class: 'kv' }, h('span', null, E.t('wanted_job')), h('b', null, w.job)),
          h('div', { class: 'kv' }, h('span', null, E.t('wanted_by')), h('b', null, w.createdBy.name + ' | ' + E.t('id_label') + ' ' + E.digits(w.createdBy.id))),
          h('div', { class: 'kv' }, h('span', null, E.t('wanted_date')), h('b', { class: 'mono' }, E.date(w.createdAt)))),
        h('div', { class: 'poster-reason' }, h('span', { class: 'muted small' }, E.t('wanted_reason')), h('div', null, w.reason)),
        remove));
  }

  function wantedAddModal(view) {
    const id = h('input', { type: 'number', placeholder: E.t('wanted_add_id') });
    const reason = h('textarea', { rows: 3, maxlength: 250, placeholder: E.t('wanted_add_reason') });
    const result = h('div');
    const send = h('button', { class: 'btn btn-primary', onclick: async () => {
      if (!/^-?\d+$/.test(id.value.trim()) || !reason.value.trim()) return;
      const r = await act(send, 'wanted:add', { id: id.value.trim(), reason: reason.value }, E.t('wanted_added'));
      // After adding: show the card (photo + connected or not).
      if (r.ok && r.data && r.data.target) { E.clear(result).appendChild(wantedPoster(r.data, view)); id.value = ''; reason.value = ''; }
    } }, E.icon('plus', 16), E.t('wanted_add'));
    modal({
      title: E.t('wanted_add'), icon: 'target', wide: true,
      body: h('div', { class: 'stack' },
        h('label', { class: 'field' }, h('span', null, E.t('wanted_add_id')), id),
        h('label', { class: 'field' }, h('span', null, E.t('wanted_add_reason')), reason),
        result),
      actions: [send],
      onClose: () => viewWanted(view),
    });
  }

  /* ================================================================ الشؤون */
  const TILE_ICON = {
    recruit: 'recruit', dismiss: 'userMinus', promote: 'star', demote: 'minus', broadcastOfficers: 'megaphone', broadcastCitizens: 'megaphone', recall: 'recall', monitor: 'eye',
    vacationBalance: 'sun', vacationBreak: 'sun', officerInquiry: 'userSearch', resetAttendance: 'clock', resetFines: 'fine', resetData: 'reset', statistics: 'trophy',
  };

  async function viewAffairs(view) {
    setTitle(E.t('tab_affairs'));
    S.recallView = null;
    E.clear(view).appendChild(loading());
    const r = await E.rpc('affairs:overview');
    if (S.tab !== 'affairs') return;
    if (!r.ok) return E.clear(view).appendChild(empty(r.data));
    S.affairs = r.data;
    const st = r.data.stats;
    const strip = h('div', { class: 'kpis' },
      [['users', 'affairs_officers', st.officers], ['radio', 'affairs_online', st.online], ['power', 'affairs_on_duty', st.onDuty],
        ['report', 'affairs_reports', st.reports], ['target', 'affairs_wanted', st.wanted], ['jail', 'affairs_prisoners', st.prisoners]]
        .map(([icon, key, v]) => h('div', { class: 'kpi' }, E.icon(icon, 18), h('div', { class: 'kpi-v mono' }, E.digits(v)), h('div', { class: 'kpi-l' }, E.t(key)))));
    const scope = h('div', { class: 'scope' }, h('span', { class: 'muted' }, E.icon('shield', 14), E.t('affairs_scope') + ':'),
      (r.data.scope || []).map((s) => h('span', { class: 'chip accent' }, s)));
    const tiles = h('div', { class: 'tiles' }, (r.data.tiles || []).map((id) =>
      h('button', { class: 'tile', onclick: () => openAffair(view, id) },
        h('div', { class: 'tile-ico' }, E.icon(TILE_ICON[id] || 'grid', 24)),
        h('div', { class: 'tile-label' }, E.t('tile_' + id)),
        h('span', { class: 'tile-go' }, E.icon('chevronLeft', 16)))));
    put(E.clear(view), strip, scope, tiles);
  }

  function subView(view, title, icon, body) {
    setTitle(E.t('tab_affairs'), title);
    put(E.clear(view), 
      h('div', { class: 'sub-head' },
        h('button', { class: 'btn btn-ghost', onclick: () => viewAffairs(view) }, E.icon('chevronRight', 16), E.t('back')),
        h('div', { class: 'sub-title' }, E.icon(icon, 20), title)),
      body);
  }

  // Officer list with id search. onSelect(officer)
  function officerPicker(permName, onSelect, opts) {
    opts = opts || {};
    const list = h('div', { class: 'picker-list' }, loading());
    let selected = null;
    const load = async (query) => {
      const r = await E.rpc('affairs:officers', { perm: permName, query: query || '', onlineOnly: opts.onlineOnly === true });
      E.clear(list);
      if (!r.ok) return list.appendChild(empty(r.data));
      if (!r.data.length) return list.appendChild(empty(E.t('no_officers'), 'users'));
      r.data.forEach((o) => {
        const row = h('button', { class: 'picker-row', onclick: () => {
          list.querySelectorAll('.picker-row').forEach((x) => x.classList.remove('active'));
          row.classList.add('active');
          selected = o;
          onSelect(o);
        } },
          E.avatar(o.name, o.avatar, 36),
          h('div', { class: 'grow' }, h('b', null, o.name), h('div', { class: 'muted small' }, (o.rank || '') + (o.sectorLabel ? ' • ' + o.sectorLabel : ''))),
          h('span', { class: 'mono small' }, E.t('id_label') + ' ' + E.digits(o.user_id)),
          o.vacation ? h('span', { class: 'badge warn' }, E.t('office_vacation')) : null,
          o.online ? h('span', { class: 'badge ' + (o.onDuty ? 'ok' : 'off') }, o.onDuty ? E.t('on_duty') : E.t('off_duty')) : h('span', { class: 'badge off' }, E.t('offline')));
        list.appendChild(row);
      });
    };
    let t = null;
    const search = h('input', { class: 'search', type: 'number', placeholder: E.t('search_by_id'), oninput: () => { clearTimeout(t); t = setTimeout(() => load(search.value), 300); } });
    load('');
    // opts.search === false: the list only (the id is typed in its own form next to it).
    const box = opts.search === false ? null : h('div', { class: 'search-box' }, E.icon('search', 16), search);
    return { el: h('div', { class: 'picker' }, box, list), get: () => selected, reload: () => load(search.value) };
  }

  // A single "رقم الهوية" field + button (no list). onSubmit(id, button)
  function idForm(buttonLabel, buttonIcon, onSubmit, extraField) {
    const id = h('input', { type: 'number', placeholder: E.t('enter_id') });
    // Any whole number is an id (0 and negatives too). Sent as text so no digit is lost.
    const valid = () => /^-?\d+$/.test(id.value.trim());
    const btn = h('button', { class: 'btn btn-primary btn-lg', onclick: () => {
      if (valid()) onSubmit(id.value.trim(), btn);
      else E.toast(E.t('err_unknown_id', null, 'رقم الهوية غير صحيح.'), 'error');
    } }, E.icon(buttonIcon, 18), buttonLabel);
    id.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') btn.click(); });
    return h('div', { class: 'id-form' }, h('label', { class: 'field' }, h('span', null, E.t('enter_id')), id), extraField || null, btn);
  }

  function openAffair(view, id) {
    const title = E.t('tile_' + id);
    const icon = TILE_ICON[id] || 'grid';
    const handlers = {
      recruit: () => affRecruit(view, title, icon, 'recruit'),
      dismiss: () => affRecruit(view, title, icon, 'dismiss'),
      promote: () => affRank(view, title, icon, 'up'),
      demote: () => affRank(view, title, icon, 'down'),
      vacationBreak: () => affVacationBreak(view, title, icon),
      broadcastOfficers: () => affBroadcast(view, title, icon, 'officers'),
      broadcastCitizens: () => affBroadcast(view, title, icon, 'citizens'),
      recall: () => affRecall(view, title, icon),
      monitor: () => affMonitor(view, title, icon),
      vacationBalance: () => affVacation(view, title, icon),
      officerInquiry: () => affInquiry(view, title, icon),
      resetAttendance: () => affReset(view, title, icon, 'attendance', 'resetAttendance'),
      resetFines: () => affReset(view, title, icon, 'fines', 'resetFines'),
      resetData: () => affReset(view, title, icon, 'data', 'resetData'),
      statistics: () => affTop(view, title, icon),
    };
    if (handlers[id]) handlers[id]();
  }

  function affRecruit(view, title, icon, only) {
    const pane = h('div', { class: 'pane' });
    const tabs = h('div', { class: 'segmented' });
    const showRecruit = () => {
      E.clear(pane);
      let player = null;
      let rank = null;
      const players = h('div', { class: 'picker-list' });
      const ranksBox = h('div', { class: 'rank-groups' }, empty(E.t('recruit_pick_player'), 'userPlus'));
      const submit = h('button', { class: 'btn btn-primary btn-lg', disabled: true, onclick: async () => {
        const r = await act(submit, 'affairs:recruit', { user_id: player.user_id, rank: rank.group }, E.t('recruit_done'));
        if (r.ok) showRecruit();
      } }, E.icon('userPlus', 18), E.t('recruit'));
      const refresh = () => { submit.disabled = !(player && rank); };
      const loadRanks = async () => {
        const r = await E.rpc('affairs:ranks');
        E.clear(ranksBox);
        if (!r.ok || !r.data.length) return ranksBox.appendChild(empty(r.ok ? E.t('no_data') : r.data));
        r.data.forEach((g) => ranksBox.appendChild(h('div', { class: 'rank-group' }, h('div', { class: 'rank-group-title' }, g.label),
          h('div', { class: 'chips' }, g.ranks.map((rk) => {
            const c = h('button', { class: 'chip-btn', onclick: () => { ranksBox.querySelectorAll('.chip-btn').forEach((x) => x.classList.remove('active')); c.classList.add('active'); rank = rk; refresh(); } }, rk.label);
            return c;
          })))));
      };
      const loadPlayers = async (q) => {
        const r = await E.rpc('affairs:players', { query: q || '' });
        E.clear(players);
        if (!r.ok) return players.appendChild(empty(r.data));
        if (!r.data.length) return players.appendChild(empty(q ? E.t('err_unknown_id', null, E.t('no_data')) : E.t('recruit_nearby_empty'), 'users'));
        r.data.forEach((p) => {
          const row = h('button', { class: 'picker-row', onclick: () => { players.querySelectorAll('.picker-row').forEach((x) => x.classList.remove('active')); row.classList.add('active'); player = p; refresh(); if (!ranksBox.dataset.loaded) { ranksBox.dataset.loaded = '1'; loadRanks(); } } },
            E.avatar(p.name, p.avatar, 34), h('div', { class: 'grow' }, h('b', null, p.name), h('div', { class: 'muted small' }, p.rank ? p.rank + (p.sectorLabel ? ' • ' + p.sectorLabel : '') : '—')),
            h('span', { class: 'mono small' }, E.t('id_label') + ' ' + E.digits(p.user_id)));
          players.appendChild(row);
        });
      };
      let t = null;
      const search = h('input', { class: 'search', type: 'number', placeholder: E.t('recruit_search'), oninput: () => { clearTimeout(t); t = setTimeout(() => loadPlayers(search.value), 300); } });
      loadPlayers('');
      pane.appendChild(h('div', { class: 'split' },
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('users', 18), E.t('recruit_pick_player')), h('div', { class: 'muted small' }, E.t('recruit_nearby')), h('div', { class: 'search-box' }, E.icon('search', 16), search), players),
        h('div', { class: 'card sticky' }, h('div', { class: 'card-head' }, E.icon('star', 18), E.t('recruit_pick_rank')), ranksBox, h('div', { class: 'card-foot' }, submit))));
    };
    const showDismiss = () => {
      E.clear(pane);
      const info = h('div', { class: 'detail-box' }, empty(E.t('select_officer'), 'userMinus'));
      const picker = officerPicker('dismiss', (o) => {
        const btn = h('button', { class: 'btn btn-danger btn-lg', onclick: async () => {
          E.toast(confirmHint(), 'info', 4);
          const r = await act(btn, 'affairs:dismiss', { user_id: o.user_id }, E.t('dismiss_done'));
          if (r.ok) { picker.reload(); E.clear(info).appendChild(empty(E.t('select_officer'), 'userMinus')); }
        } }, E.icon('userMinus', 18), E.t('dismiss'));
        put(E.clear(info), officerSummary(o), btn);
      });
      pane.appendChild(h('div', { class: 'split' }, h('div', { class: 'card' }, picker.el), h('div', { class: 'card' }, info)));
    };
    // Recruit and dismiss are separate tiles (each with its own permission).
    const fn = only === 'dismiss' ? (perm('dismiss') ? showDismiss : null) : (perm('recruit') ? showRecruit : null);
    subView(view, title, icon, h('div', { class: 'stack' }, pane));
    if (fn) fn();
  }

  function officerSummary(o) {
    return h('div', { class: 'officer-summary' }, E.avatar(o.name, o.avatar, 60),
      h('div', null, h('div', { class: 'hero-name small' }, o.name),
        h('div', { class: 'hero-tags' }, h('span', { class: 'chip mono' }, E.t('id_label') + ' ' + E.digits(o.user_id)),
          o.rank ? h('span', { class: 'chip accent' }, o.rank) : null, o.sectorLabel ? h('span', { class: 'chip' }, o.sectorLabel) : null,
          h('span', { class: 'chip ' + (o.online ? 'ok' : '') }, o.online ? E.t('online') : E.t('offline')))));
  }

  function affBroadcast(view, title, icon, audience) {
    const max = (S.affairs && S.affairs.broadcastMax) || 300;
    const counter = h('span', { class: 'mono muted small' }, E.digits('0/' + max));
    const text = h('textarea', { rows: 6, maxlength: max, placeholder: E.t('broadcast_placeholder'), oninput: () => { counter.textContent = E.digits(text.value.length + '/' + max); } });
    const send = h('button', { class: 'btn btn-primary btn-lg', onclick: async () => {
      if (!text.value.trim()) return;
      const r = await act(send, 'affairs:broadcast', { audience, message: text.value }, E.t('broadcast_sent'));
      if (r.ok) { text.value = ''; counter.textContent = E.digits('0/' + max); }
    } }, E.icon('send', 18), E.t('send'));
    subView(view, title, icon, h('div', { class: 'card broadcast-compose' + (audience === 'citizens' ? ' citizens' : '') },
      h('div', { class: 'compose-preview' }, E.icon('megaphone', 22), h('b', null, audience === 'officers' ? E.t('tile_broadcastOfficers') : E.t('tile_broadcastCitizens'))),
      text, h('div', { class: 'card-foot' }, counter, send)));
  }

  function renderRecall(box, snap) {
    E.clear(box);
    const c = snap.counts || {};
    box.appendChild(h('div', { class: 'kpis small' },
      [['recall_pending', c.pending, ''], ['recall_accepted', c.accepted, 'ok'], ['recall_rejected', c.rejected, 'bad'], ['recall_timeout', c.timeout, 'warn']]
        .map(([k, v, cls]) => h('div', { class: 'kpi ' + cls }, h('div', { class: 'kpi-v mono' }, E.digits(v || 0)), h('div', { class: 'kpi-l' }, E.t(k))))));
    box.appendChild(h('div', { class: 'picker-list' }, (snap.results || []).map((r) => h('div', { class: 'picker-row static' },
      E.avatar(r.name, null, 32), h('div', { class: 'grow' }, h('b', null, r.name), h('div', { class: 'muted small' }, r.rank || '')),
      h('span', { class: 'mono small' }, E.t('id_label') + ' ' + E.digits(r.user_id)),
      h('span', { class: 'badge ' + ({ accepted: 'ok', rejected: 'bad', timeout: 'warn' }[r.status] || '') }, E.t('recall_' + r.status))))));
  }

  function affRecall(view, title, icon) {
    const msg = h('input', { type: 'text', maxlength: 200, placeholder: E.t('recall_message') });
    const results = h('div', { class: 'stack' });
    const start = h('button', { class: 'btn btn-primary btn-lg', onclick: async () => {
      const r = await act(start, 'affairs:recall', { message: msg.value });
      if (r.ok) { S.recallView = results; renderRecall(results, r.data); }
    } }, E.icon('recall', 18), E.t('recall_start'));
    subView(view, title, icon, h('div', { class: 'stack' },
      h('div', { class: 'card narrow' }, h('label', { class: 'field' }, h('span', null, E.t('recall_message')), msg), start),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('users', 18), E.t('recall_results')), results)));
  }

  // Monitor any officer: type the id, or pick from every connected officer.
  function affMonitor(view, title, icon) {
    const start = async (userId) => {
      const r = await E.rpc('affairs:monitor', { user_id: userId });
      if (r.ok) close(); else E.toast(r.data, 'error');
    };
    const picker = officerPicker('monitor', (o) => start(o.user_id), { onlineOnly: true, search: false });
    subView(view, title, icon, h('div', { class: 'split' },
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('eye', 18), E.t('monitor_start')), idForm(E.t('monitor_start'), 'eye', (id) => start(id))),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('users', 18), E.t('monitor_list')), picker.el)));
  }

  // Promotion / demotion: officer id → his rank, and one step up or down in the same sector.
  function affRank(view, title, icon, dir) {
    const box = h('div', { class: 'rank-box' });
    const load = async (id) => {
      E.clear(box).appendChild(loading());
      const r = await E.rpc('affairs:rankInfo', { user_id: id });
      E.clear(box);
      if (!r.ok) return box.appendChild(empty(r.data));
      const d = r.data;
      const kv = (label, value) => h('div', { class: 'kv' }, h('span', null, label), h('b', null, value));
      // One button per direction; at the top / bottom of the sector a short note instead.
      const step = (dir) => {
        const next = dir === 'up' ? d.up : d.down;
        if (!next) return h('div', { class: 'muted small' }, E.t(dir === 'up' ? 'rank_top' : 'rank_bottom'));
        const allowed = (dir === 'up' ? d.canUp : d.canDown) && !d.vacation;
        const btn = h('button', { class: 'btn btn-lg ' + (dir === 'up' ? 'btn-primary' : 'btn-danger'), disabled: !allowed, onclick: async () => {
          const res = await act(btn, 'affairs:rank', { user_id: d.user_id, direction: dir }, E.t(dir === 'up' ? 'rank_promoted' : 'rank_demoted'));
          if (res.ok) load(d.user_id);
        } }, E.icon(dir === 'up' ? 'plus' : 'minus', 18), E.t(dir === 'up' ? 'rank_promote' : 'rank_demote') + ' ← ' + next);
        return btn;
      };
      put(box, h('div', { class: 'card' },
        h('div', { class: 'card-head' }, E.icon('star', 18), d.name + ' | ' + E.t('id_label') + ' ' + E.digits(d.user_id)),
        kv(E.t('rank_current'), d.rank),
        kv(E.t('rank_sector'), d.sector || '—'),
        kv(E.t('card_status', null, 'الحالة'), d.online ? E.t('online') : E.t('offline')),
        d.vacation ? h('div', { class: 'callout' }, E.icon('sun', 16), E.t('rank_on_vacation')) : null,
        h('div', { class: 'actions wrap' }, step(dir === 'down' ? 'down' : 'up'))));
    };
    const form = idForm(E.t('show'), 'search', (id) => load(id));
    subView(view, title, icon, h('div', { class: 'stack' },
      h('div', { class: 'card narrow' }, form), box));
  }

  // Break an officer's vacation: officer id → his rank comes back.
  function affVacationBreak(view, title, icon) {
    const form = idForm(E.t('tile_vacationBreak'), 'sun', async (id, btn) => {
      await act(btn, 'affairs:vacationBreak', { user_id: id }, E.t('action_done'));
    });
    subView(view, title, icon, h('div', { class: 'card narrow' }, form));
  }

  // Vacation balance: officer id + minutes. Online or not, any officer.
  function affVacation(view, title, icon) {
    const minutes = h('input', { type: 'number', min: 1, max: (S.affairs && S.affairs.vacationMax) || 600, value: 60 });
    const form = idForm(E.t('tile_vacationBalance'), 'plus', async (id, btn) => {
      const r = await act(btn, 'affairs:vacationBalance', { user_id: id, minutes: Number(minutes.value) }, E.t('vacation_added'));
      if (r.ok) E.toast(E.t('office_vacation_balance') + ': ' + E.digits(r.data.balance) + ' ' + E.t('minutes'), 'info');
    }, h('label', { class: 'field' }, h('span', null, E.t('vacation_minutes')), minutes));
    subView(view, title, icon, h('div', { class: 'card narrow' }, form));
  }

  async function officerDetails(box, userId) {
    E.clear(box).appendChild(loading());
    const r = await E.rpc('affairs:officer', { user_id: userId });
    E.clear(box);
    if (!r.ok) return box.appendChild(empty(r.data));
    const d = r.data;
    const kv = (label, value) => h('div', { class: 'kv' }, h('span', null, label), h('b', { class: 'mono' }, value));
    const actions = [];
    const push = (ok, label, iconName, cls, fn) => { if (ok) { const b = h('button', { class: 'btn ' + (cls || ''), onclick: () => fn(b) }, E.icon(iconName, 16), label); actions.push(b); } };
    push(d.actions.monitor, E.t('tile_monitor'), 'eye', '', async () => { const res = await E.rpc('affairs:monitor', { user_id: d.user_id }); if (res.ok) close(); else E.toast(res.data, 'error'); });
    push(d.actions.resetAttendance, E.t('tile_resetAttendance'), 'clock', '', async (b) => { const res = await act(b, 'affairs:reset', { user_id: d.user_id, kind: 'attendance' }, E.t('reset_done')); if (res.ok) officerDetails(box, userId); });
    push(d.actions.resetFines, E.t('tile_resetFines'), 'fine', '', async (b) => { const res = await act(b, 'affairs:reset', { user_id: d.user_id, kind: 'fines' }, E.t('reset_done')); if (res.ok) officerDetails(box, userId); });
    push(d.actions.resetData, E.t('tile_resetData'), 'reset', '', async (b) => { const res = await act(b, 'affairs:reset', { user_id: d.user_id, kind: 'data' }, E.t('reset_done')); if (res.ok) officerDetails(box, userId); });
    push(d.actions.vacationBreak, E.t('office_vacation_break'), 'sun', '', async (b) => { const res = await act(b, 'affairs:vacationBreak', { user_id: d.user_id }, E.t('action_done')); if (res.ok) officerDetails(box, userId); });
    push(d.actions.dismiss, E.t('dismiss'), 'userMinus', 'btn-danger', async (b) => { E.toast(confirmHint(), 'info', 4); const res = await act(b, 'affairs:dismiss', { user_id: d.user_id }, E.t('dismiss_done')); if (res.ok) officerDetails(box, userId); });
    put(box, 
      officerSummary(d),
      h('div', { class: 'kv-grid' },
        kv(E.t('officer_attendance'), E.hours(d.attendance)),
        kv(E.t('officer_session'), E.clock(d.session)),
        kv(E.t('officer_fines'), E.digits(d.fines)),
        kv(E.t('officer_jails'), E.digits(d.jails)),
        kv(E.t('officer_reports'), E.digits(d.reports)),
        kv(E.t('officer_impounds'), E.digits(d.impounds)),
        kv(E.t('officer_vacation_balance'), E.digits(d.vacationBalance) + ' ' + E.t('minutes')),
        kv(E.t('officer_vacation_status'), d.vacation.active ? E.t('officer_vacation_active') + ' ' + E.date(d.vacation.endsAt) : E.t('officer_vacation_none')),
        kv(E.t('office_code'), d.code || '—'),
        kv(E.t('officer_ministry'), d.ministryLabel || '—'),
        kv(E.t('officer_last_in'), E.date(d.lastClockIn)),
        kv(E.t('officer_last_out'), E.date(d.lastClockOut))),
      actions.length ? h('div', { class: 'actions wrap' }, actions) : null);
  }

  // Officer inquiry: type the id, the details show below. Online or not, any officer.
  function affInquiry(view, title, icon) {
    const box = h('div', { class: 'detail-box' });
    subView(view, title, icon, h('div', { class: 'stack' },
      h('div', { class: 'card narrow' }, idForm(E.t('inquiry_go'), 'userSearch', (id) => officerDetails(box, id))),
      h('div', { class: 'card' }, box)));
  }

  // Resets: type the officer id, the summary and the reset button show below.
  function affReset(view, title, icon, kind) {
    const info = h('div', { class: 'detail-box' });
    const lookup = async (id, lookBtn) => {
      if (lookBtn) { lookBtn.disabled = true; }
      const r = await E.rpc('affairs:lookup', { user_id: id });
      if (lookBtn) { lookBtn.disabled = false; }
      E.clear(info);
      if (!r.ok) return info.appendChild(empty(r.data));
      const btn = h('button', { class: 'btn btn-danger btn-lg', onclick: async () => {
        E.toast(confirmHint(), 'info', 4);
        await act(btn, 'affairs:reset', { user_id: id, kind }, E.t('reset_done'));
      } }, E.icon('reset', 18), title);
      put(info, officerSummary(r.data),
        btn);
    };
    subView(view, title, icon, h('div', { class: 'stack' },
      h('div', { class: 'card narrow' }, idForm(E.t('show'), 'search', lookup)),
      h('div', { class: 'card' }, info)));
  }

  async function affTop(view, title, icon) {
    const box = h('div', { class: 'stack' }, loading());
    const send = h('button', { class: 'btn btn-primary', onclick: () => act(send, 'affairs:topWebhook', {}, E.t('top_sent')) }, E.icon('send', 16), E.t('top_send'));
    subView(view, title, icon, h('div', { class: 'card' }, h('div', { class: 'card-head between' }, h('span', null, E.icon('trophy', 18), E.t('top_title')), send), box));
    const r = await E.rpc('affairs:top');
    E.clear(box);
    if (!r.ok) return box.appendChild(empty(r.data));
    if (!r.data.length) return box.appendChild(empty(E.t('no_data'), 'trophy'));
    box.appendChild(h('div', { class: 'table top' },
      h('div', { class: 'thead' }, ['col_rank_pos', 'col_name', 'col_id', 'col_sector', 'col_score'].map((k) => h('div', { class: 'tcell' }, E.t(k)))),
      h('div', { class: 'table-body' }, r.data.map((o) => h('div', { class: 'trow' + (o.position <= 3 ? ' podium p' + o.position : '') },
        h('div', { class: 'tcell' }, h('span', { class: 'medal mono' }, E.digits(o.position))),
        h('div', { class: 'tcell name' }, E.avatar(o.name, o.avatar, 30), h('div', null, h('b', null, o.name), h('div', { class: 'muted small' }, o.rank))),
        h('div', { class: 'tcell mono' }, E.digits(o.user_id)),
        h('div', { class: 'tcell' }, h('span', { class: 'chip' }, o.sectorLabel || '—')),
        h('div', { class: 'tcell mono accent-text' }, E.digits(o.points)))))));
  }

  /* ======================================================== الجدول العسكري */
  // Sections built from the ranks (رئاسة الوزراء, each ministry, each sector). Code = the section
  // letter + the place in the section (A-1), or a custom number (A-15). With "rosterManage": click
  // a code to change its number (the letter stays), and "إعدادات الجدول" changes each section letter.
  async function viewRoster(view) {
    setTitle(E.t('tab_roster'));
    E.clear(view).appendChild(loading());
    const r = await E.rpc('roster:list');
    if (S.tab !== 'roster') return;
    if (!r.ok) return E.clear(view).appendChild(empty(r.data));
    renderRoster(view, r.data, false);
  }

  function renderRoster(view, data, settings) {
    if (S.tab !== 'roster') return;
    const sections = data.sections || [];
    const redraw = (res) => { if (res.ok) renderRoster(view, res.data, settings); };
    const switchBtn = data.manage ? h('button', { class: 'btn' + (settings ? '' : ' btn-primary'), onclick: () => renderRoster(view, data, !settings) },
      E.icon(settings ? 'chevronRight' : 'edit', 16), E.t(settings ? 'roster_back' : 'roster_settings')) : null;
    const toolbar = h('div', { class: 'toolbar' },
      h('div', { class: 'muted small' }, data.manage ? E.t(settings ? 'roster_settings_hint' : 'roster_edit_hint') : ''), switchBtn);

    if (settings) {
      // One line per section: its name, the letter (empty = the default letter) and "حفظ".
      const list = h('div', { class: 'card roster-settings' }, sections.map((s) => {
        const input = h('input', { type: 'text', maxlength: 6, value: s.prefix !== s.defaultPrefix ? s.prefix : '', placeholder: s.defaultPrefix, class: 'mono' });
        const save = h('button', { class: 'btn btn-primary', onclick: async () => {
          redraw(await act(save, 'roster:setPrefix', { section: s.id, prefix: input.value.trim() }, E.t('roster_saved')));
        } }, E.icon('check', 16), E.t('save'));
        input.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') save.click(); });
        return h('div', { class: 'roster-set-row' }, h('b', { class: 'grow' }, s.label), h('span', { class: 'muted small mono' }, s.prefix + '-1'), input, save);
      }));
      setTitle(E.t('tab_roster'), E.t('roster_settings'));
      return put(E.clear(view), toolbar, list);
    }

    // The code cell: a button to edit its number when allowed (the section letter stays in front).
    const codeCell = (row, prefix) => {
      const cell = h('div', { class: 'tcell rs-code' });
      const label = h('span', { class: 'code-pill mono' + (row.custom ? ' custom' : ''), title: row.custom ? E.t('roster_custom') : '' }, row.code);
      if (!data.manage) return put(cell, label);
      const edit = () => {
        const input = h('input', { type: 'text', maxlength: 5, value: row.custom ? row.number : '', placeholder: row.number, class: 'mono rs-input' });
        let done = false;
        const commit = async () => {
          if (done) return;
          done = true;
          let value = input.value.trim();
          if (value.toUpperCase().startsWith((prefix + '-').toUpperCase())) value = value.slice(prefix.length + 1).trim();
          if (value === (row.custom ? row.number : '')) return renderRoster(view, data, false);
          redraw(await act(null, 'roster:setCode', { user_id: row.user_id, code: value }, E.t('roster_saved')));
        };
        input.addEventListener('keydown', (ev) => {
          if (ev.key === 'Enter') commit();
          else if (ev.key === 'Escape') { ev.stopPropagation(); done = true; renderRoster(view, data, false); }
        });
        input.addEventListener('blur', commit);
        put(E.clear(cell), h('span', { class: 'rs-edit-box' }, h('span', { class: 'mono muted' }, prefix + '-'), input));
        input.focus();
        input.select();
      };
      return put(cell, h('button', { class: 'rs-edit', onclick: edit }, label));
    };

    const table = h('div', { class: 'table roster' },
      h('div', { class: 'thead' }, ['roster_col_name', 'roster_col_rank', 'roster_col_code'].map((k) => h('div', { class: 'tcell' }, E.t(k)))),
      h('div', { class: 'table-body' }, sections.map((s) => [
        h('div', { class: 'rs-section' }, h('span', null, s.label), h('span', { class: 'chip mono' }, s.prefix)),
        s.rows.length ? s.rows.map((row) => h('div', { class: 'trow' },
          h('div', { class: 'tcell rs-name' }, h('span', { class: 'rs-dot' + (row.onDuty ? ' on' : row.online ? ' online' : '') }), h('b', null, row.name),
            row.vacation ? h('span', { class: 'badge warn' }, E.t('office_vacation')) : null),
          h('div', { class: 'tcell rs-rank' }, row.rank),
          codeCell(row, s.prefix))) : h('div', { class: 'rs-empty muted small' }, E.t('roster_empty')),
      ])));
    put(E.clear(view), toolbar, table);
  }

  /* ============================================================ إدارة اللوحة */
  // Server-wide look: colours, transparency and the position of every notification.
  const ACCENTS = ['#2563eb', '#1d4ed8', '#0ea5e9', '#0d9488', '#16a34a', '#64748b', '#7c3aed', '#dc2626'];
  const NOTES = ['#263246', '#1e293b', '#111827', '#334155', '#1f2a3a', '#0f172a'];

  // إدارة اللوحة: two sections, the look and the places.
  function viewPanel(view, section) {
    setTitle(E.t('tab_panel'));
    section = section || S.panelSection || 'look';
    S.panelSection = section;
    const tabs = h('div', { class: 'segmented' },
      [['look', 'panel_look', 'edit'], ['places', 'panel_places', 'pin']].map(([id, key, icon]) =>
        h('button', { class: 'seg' + (id === section ? ' active' : ''), onclick: () => { if (S.panelDirty) { S.panelDirty = false; E.applyTheme(E.theme); } viewPanel(view, id); } }, E.icon(icon, 16), E.t(key))));
    const box = h('div', { class: 'stack' });
    put(E.clear(view), tabs, box);
    (section === 'places' ? panelPlaces : panelLook)(box, view);
  }

  // ---------------------------------------------------------------- Saving
  // Saves one at a time (the server rejects calls that are too close together).
  let saveChain = Promise.resolve();
  function queueSave(name, payload) {
    const run = saveChain.then(() => E.rpc(name, payload)).then((r) => new Promise((res) => setTimeout(() => res(r), 220)));
    saveChain = run.catch(() => {});
    return run;
  }
  // Status label: "جاري الحفظ..." → "محفوظ" (or the error).
  function saveStatus() {
    const el = h('span', { class: 'save-status' });
    return {
      el,
      saving: () => { el.className = 'save-status saving'; el.textContent = E.t('panel_saving'); },
      saved: () => { el.className = 'save-status ok'; el.textContent = E.t('panel_saved_short'); },
      dirty: () => { el.className = 'save-status saving'; el.textContent = E.t('panel_unsaved'); },
      failed: (msg) => { el.className = 'save-status bad'; el.textContent = E.t('panel_save_error'); if (msg) E.toast(msg, 'error'); },
    };
  }
  // Dropdown built in HTML (the browser's own <select> list may not open inside the game).
  function dropdown(options, value, onChange) {
    const current = () => options.find((o) => o.id === value) || options[0] || { label: '—' };
    const dot = (o) => (o && o.color ? h('i', { class: 'dd-dot', style: { background: 'rgba(' + o.color.slice(0, 3).join(',') + ',1)' } }) : null);
    const label = h('span', { class: 'dd-label' });
    const list = h('div', { class: 'dd-list hidden' });
    const box = h('div', { class: 'dd' }, h('button', { class: 'dd-btn', type: 'button', onclick: (ev) => {
      ev.stopPropagation();
      document.querySelectorAll('.dd-list').forEach((l) => { if (l !== list) l.classList.add('hidden'); });
      list.classList.toggle('hidden');
    } }, label, E.icon('chevronLeft', 14)), list);
    const draw = () => {
      E.clear(label).append(...[dot(current()), current().label].filter(Boolean));
      E.clear(list);
      options.forEach((o) => list.appendChild(h('button', { class: 'dd-item' + (o.id === value ? ' active' : ''), type: 'button', onclick: (ev) => {
        ev.stopPropagation();
        value = o.id;
        list.classList.add('hidden');
        draw();
        onChange(o.id);
      } }, dot(o), o.label)));
    };
    draw();
    return box;
  }
  document.addEventListener('click', () => document.querySelectorAll('.dd-list').forEach((l) => l.classList.add('hidden')));

  // Colour: ready colours + a "#rrggbb" field (the Windows colour dialog does not open in game).
  function colorField(value, swatches, onChange) {
    const row = h('div', { class: 'swatches' });
    const input = h('input', { type: 'text', class: 'hex-input mono', maxlength: 7, value });
    const preview = h('i', { class: 'hex-preview', style: { background: value } });
    const set = (c, fromInput) => {
      value = c;
      preview.style.background = c;
      if (!fromInput) input.value = c;
      row.querySelectorAll('.swatch').forEach((s) => s.classList.toggle('active', s.dataset.c === c));
      onChange(c);
    };
    swatches.forEach((c) => row.appendChild(h('button', { class: 'swatch', type: 'button', dataset: { c }, style: { background: c }, onclick: () => set(c) })));
    input.addEventListener('input', () => { const v = input.value.trim(); if (/^#[0-9a-fA-F]{6}$/.test(v)) set(v.toLowerCase(), true); });
    row.querySelectorAll('.swatch').forEach((s) => s.classList.toggle('active', s.dataset.c === value));
    return h('div', { class: 'stack tight' }, row, h('div', { class: 'color-row' }, preview, input));
  }

  // A sample inquiry card (the look buttons show it).
  const SAMPLE_CARD = () => ({
    title: E.t('le_infocards'), fileTitle: E.t('le_infocards'), file: 12, duration: 6,
    stamp: { text: E.t('info_card_sample_stamp'), tone: 'ok' },
    rows: [[E.t('card_name', null, 'الاسم'), 'Ahmed'], [E.t('id_label', null, 'رقم الهوية'), 12],
      [E.t('card_status', null, 'الحالة'), E.t('info_card_sample_online'), 'ok'], [E.t('card_job', null, 'الوظيفة'), '—']],
    sections: [{ title: E.t('info_card_sample_fines'), records: [[E.t('le_sample_reason'), '$5,000', '09/30 19:58']] }],
  });

  async function panelLook(view, pageView) {
    E.clear(view).appendChild(loading());
    const r = await E.rpc('panel:get');
    if (S.tab !== 'panel') return;
    if (!r.ok) return put(E.clear(view), empty(r.data));
    // Plain objects only: an empty theme arrives as [] and would be sent back empty.
    const draft = Object.assign({}, JSON.parse(JSON.stringify(E.plainObject(r.data.theme))));
    draft.positions = Object.assign({}, E.plainObject(draft.positions));
    draft.accent = draft.accent || (E.cfg.ui && E.cfg.ui.Accent) || '#2563eb';
    draft.noteColor = draft.noteColor || '#263246';
    draft.noteAlpha = draft.noteAlpha !== undefined ? draft.noteAlpha : 0.8;
    const status = saveStatus();
    status.saved();

    // Changes preview at once; "حفظ" writes them to the database.
    const persist = async (btn) => {
      status.saving();
      if (btn) { btn.disabled = true; btn.classList.add('busy'); }
      const res = await queueSave('panel:save', { theme: draft });
      if (btn) { btn.disabled = false; btn.classList.remove('busy'); }
      if (res.ok) { S.panelDirty = false; status.saved(); E.toast(E.t('panel_saved'), 'success'); } else status.failed(res.data);
      return res.ok;
    };
    const change = () => { S.panelDirty = true; E.applyTheme(draft); status.dirty(); };

    const alphaValue = h('b', { class: 'mono' }, Math.round(draft.noteAlpha * 100) + '%');
    const alpha = h('input', { type: 'range', min: 30, max: 100, value: Math.round(draft.noteAlpha * 100), oninput: () => {
      draft.noteAlpha = Number(alpha.value) / 100;
      alphaValue.textContent = alpha.value + '%';
      change();
    } });

    // Sizes: the iPad (share of the screen) and the windows (search results, forms, dialogs).
    const pct = (v) => E.digits(Math.round(v)) + '%';
    const ipadNow = Math.round((Number(draft.ipadSize) || Number(E.cfg.ipad && E.cfg.ipad.size) || 0.6) * 100);
    const ipadValue = h('b', { class: 'mono' }, pct(ipadNow));
    const ipadRange = h('input', { type: 'range', min: 30, max: 95, value: ipadNow,
      oninput: () => { ipadValue.textContent = pct(ipadRange.value); },
      // Applied when the slider is let go: the iPad itself changes size.
      onchange: () => { draft.ipadSize = Number(ipadRange.value) / 100; change(); } });
    const sheetNow = Math.round((Number(draft.sheetScale) || 1) * 100);
    const sheetValue = h('b', { class: 'mono' }, pct(sheetNow));
    const sheetRange = h('input', { type: 'range', min: 60, max: 160, step: 5, value: sheetNow, oninput: () => {
      draft.sheetScale = Number(sheetRange.value) / 100;
      sheetValue.textContent = pct(sheetRange.value);
      change();
    } });

    // Look of the jail counter (all players).
    const JAIL_HUDS = ['digital', 'split', 'minimal', 'strip'];
    const jailBtns = JAIL_HUDS.map((id) => h('button', { class: 'btn', dataset: { hud: id }, onclick: () => {
      draft.jailHud = id;
      jailBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.hud === id));
      change();
    } }, E.t('jail_hud_' + id)));
    jailBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.hud === (draft.jailHud || E.cfg.jailHud || 'digital')));
    // Look of the inquiry cards (all players).
    const infoBtns = ['file', 'classic'].map((id) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
      draft.infoCard = id;
      infoBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
      change();
      E.emit('infocard', SAMPLE_CARD()); // shows how it looks
    } }, E.t('info_card_' + id)));
    infoBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.infoCard || E.cfg.infoCard || 'file')));
    // Transparency of the inquiry cards (left side), separate from the notification.
    const infoNow = Math.round((Number(draft.infoAlpha) || 1) * 100);
    const infoValue = h('b', { class: 'mono' }, pct(infoNow));
    const infoRange = h('input', { type: 'range', min: 30, max: 100, step: 5, value: infoNow, oninput: () => {
      draft.infoAlpha = Number(infoRange.value) / 100;
      infoValue.textContent = pct(infoRange.value);
      change();
    }, onchange: () => E.emit('infocard', SAMPLE_CARD()) });
    // Look of the notifications (all players).
    const toastBtns = ['gradient', 'ring', 'classic'].map((id) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
      draft.toast = id;
      toastBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
      change();
      E.toast(E.t('le_sample_toast'), 'success', 5); // shows how it looks
    } }, E.t('toast_style_' + id)));
    toastBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.toast || E.cfg.toast || 'gradient')));
    // Look of the wanted alert (all players).
    const wantedBtns = ['poster', 'classic'].map((id) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
      draft.wanted = id;
      wantedBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
      change();
      E.emit('wanted:alert', { name: 'Ahmed', user_id: 12, reason: E.t('le_sample_reason'), quickOpen: Object.assign({}, E.cfg.wanted || {}, { seconds: 5 }) });
    } }, E.t('wanted_style_' + id)));
    wantedBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.wanted || E.cfg.wantedStyle || 'poster')));
    // Look of the F5 / F6 confirmation (all players). The preview is only shown, nothing is answered.
    const confirmBtns = ['compact', 'classic'].map((id) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
      draft.confirm = id;
      confirmBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
      change();
    } }, E.t('confirm_style_' + id)));
    confirmBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.confirm || E.cfg.confirmStyle || 'compact')));
    // Look of the vehicle search window (all players).
    const vehicleBtns = ['list', 'classic'].map((id) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
      draft.vehicleSearch = id;
      vehicleBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
      change();
    } }, E.t('vehicle_style_' + id)));
    vehicleBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.vehicleSearch || E.cfg.vehicleSearch || 'list')));
    // Look of the fines window and of the impounded vehicles window (points and منصة أبشر).
    const lookBtns = (key, cfgKey, list, labels) => {
      const btns = list.map((id, i) => h('button', { class: 'btn', dataset: { look: id }, onclick: () => {
        draft[key] = id;
        btns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === id));
        change();
      } }, E.t(labels[i])));
      btns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft[key] || E.cfg[cfgKey] || list[0])));
      return btns;
    };
    const finesBtns = lookBtns('finesLook', 'finesLook', ['cards', 'classic'], ['look_cards', 'look_classic']);
    const HINT_LOOKS = ['glass', 'pill', 'bar', 'keycap'];
    const hintBtns = lookBtns('keyHint', 'keyHint', HINT_LOOKS, HINT_LOOKS.map((id) => 'key_hint_' + id));
    // Shows how the hint looks for a few seconds.
    hintBtns.forEach((b) => b.addEventListener('click', () => {
      E.emit('hint', { key: 'E', text: E.t('le_keyhint') });
      clearTimeout(S.hintPreview);
      S.hintPreview = setTimeout(() => E.emit('hint:hide'), 3000);
    }));
    const impoundBtns = lookBtns('impoundLook', 'impoundLook', ['cards', 'classic'], ['look_car_cards', 'look_classic']);

    // The look buttons follow a look switched from the layout editor.
    const syncLookBtns = () => {
      jailBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.hud === (draft.jailHud || E.cfg.jailHud || 'digital')));
      infoBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.infoCard || E.cfg.infoCard || 'file')));
      toastBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.toast || E.cfg.toast || 'gradient')));
      wantedBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.wanted || E.cfg.wantedStyle || 'poster')));
      confirmBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.confirm || E.cfg.confirmStyle || 'compact')));
      hintBtns.forEach((b) => b.classList.toggle('btn-primary', b.dataset.look === (draft.keyHint || E.cfg.keyHint || 'glass')));
    };

    const saveBtn = h('button', { class: 'btn btn-primary btn-lg', onclick: () => persist(saveBtn) }, E.icon('check', 18), E.t('save'));
    const reset = h('button', { class: 'btn', onclick: async () => {
      const res = await act(reset, 'panel:reset', {}, E.t('panel_reset_done'));
      if (res.ok) { S.panelDirty = false; viewPanel(pageView, 'look'); }
    } }, E.icon('reset', 16), E.t('panel_reset'));
    const test = h('button', { class: 'btn btn-ghost', onclick: () => {
      E.toast(E.t('le_sample_toast'), 'info', 5);
      E.emit('infocard', { title: E.t('le_infocards'), rows: [[E.t('card_name'), 'Ahmed'], [E.t('id_label'), 12]], duration: 5 });
    } }, E.icon('bolt', 16), E.t('panel_test'));
    const layout = h('button', { class: 'btn btn-primary', onclick: () => {
      // The iPad hides while the notifications are moved; "حفظ" in the editor saves them.
      root.classList.add('hidden');
      E.openLayoutEditor(draft.positions, (positions, looks, shown) => {
        draft.positions = Object.assign({}, positions);
        Object.assign(draft, looks || {});
        draft.editorShown = shown; // which elements the editor shows, the same for every admin
        E.applyTheme(draft);
        syncLookBtns();
        persist();
      }, () => root.classList.remove('hidden'), draft.editorShown);
    } }, E.icon('grid', 16), E.t('panel_layout'));

    put(E.clear(view),
      h('div', { class: 'toolbar' }, h('div'), status.el),
      h('div', { class: 'panel-grid' },
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('star', 18), E.t('panel_accent')), colorField(draft.accent, ACCENTS, (c) => { draft.accent = c; change(); })),
        h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('info', 18), E.t('panel_note')), colorField(draft.noteColor, NOTES, (c) => { draft.noteColor = c; change(); }),
          h('div', { class: 'field' }, h('span', null, E.t('panel_alpha')), h('div', { class: 'range-row' }, alpha, alphaValue)))),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('grid', 18), E.t('panel_positions')), h('div', { class: 'actions wrap' }, layout, test)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('grid', 18), E.t('panel_sizes')),
        h('div', { class: 'field' }, h('span', null, E.t('panel_ipad_size')), h('div', { class: 'range-row' }, ipadRange, ipadValue)),
        h('div', { class: 'field' }, h('span', null, E.t('panel_sheet_size')), h('div', { class: 'range-row' }, sheetRange, sheetValue))),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('jail', 18), E.t('panel_jail_hud')), h('div', { class: 'actions wrap' }, jailBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('car', 18), E.t('panel_vehicle_style')), h('div', { class: 'actions wrap' }, vehicleBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('cash', 18), E.t('panel_fines_look')), h('div', { class: 'actions wrap' }, finesBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('impound', 18), E.t('panel_impound_look')), h('div', { class: 'actions wrap' }, impoundBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('check', 18), E.t('panel_confirm_style')), h('div', { class: 'actions wrap' }, confirmBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('grid', 18), E.t('panel_key_hint')), h('div', { class: 'actions wrap' }, hintBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('siren', 18), E.t('panel_wanted_style')), h('div', { class: 'actions wrap' }, wantedBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('bolt', 18), E.t('panel_toast_style')), h('div', { class: 'actions wrap' }, toastBtns)),
      h('div', { class: 'card' }, h('div', { class: 'card-head' }, E.icon('info', 18), E.t('panel_info_card')), h('div', { class: 'actions wrap' }, infoBtns),
        h('div', { class: 'field' }, h('span', null, E.t('panel_info_alpha')), h('div', { class: 'range-row' }, infoRange, infoValue))),
      h('div', { class: 'actions' }, saveBtn, reset));
  }

  /* ---------------------------------------------------- النقاط والأماكن */
  // Every place of config/coords.lua, edited in game. Each section is saved with its "حفظ" button.
  async function panelPlaces(view) {
    E.clear(view).appendChild(loading());
    const r = await E.rpc('panel:locations');
    if (S.tab !== 'panel') return;
    if (!r.ok) return put(E.clear(view), empty(r.data));
    renderPlaces(view, r.data);
  }

  function renderPlaces(view, data) {
    const fmt = (p) => (p ? E.digits(Number(p.x).toFixed(1) + ', ' + Number(p.y).toFixed(1) + ', ' + Number(p.z).toFixed(1)) : '—');
    const here = async (btn) => {
      const res = await act(btn, 'panel:here', {});
      return res.ok ? res.data : null;
    };
    const gotoBtn = (getPoint) => {
      const b = h('button', { class: 'btn small btn-ghost', onclick: () => { const p = getPoint(); if (p) act(b, 'panel:goto', p); } }, E.icon('pin', 14), E.t('places_goto'));
      return b;
    };
    const styles = data.markerStyles || [];
    const styleDefaults = data.styleDefaults || {};

    // One card per section: changes are marked "not saved" until "حفظ" is pressed.
    const section = (name, icon, key, getValue) => {
      const status = saveStatus();
      status.saved();
      const badge = h('span', { class: 'badge ' + (data.edited[name] ? 'ok' : 'off') }, data.edited[name] ? E.t('places_from_panel') : E.t('places_from_config'));
      const saveBtn = h('button', { class: 'btn btn-primary small', onclick: async () => {
        status.saving();
        saveBtn.disabled = true;
        const res = await queueSave('panel:locations:save', { section: name, value: getValue() });
        saveBtn.disabled = false;
        if (res.ok) {
          status.saved();
          badge.className = 'badge ok';
          badge.textContent = E.t('places_from_panel');
          E.toast(E.t('places_saved'), 'success');
        } else status.failed(res.data);
      } }, E.icon('check', 14), E.t('save'));
      const resetBtn = h('button', { class: 'btn btn-ghost small', onclick: async () => {
        const res = await act(resetBtn, 'panel:locations:save', { section: name, reset: true }, E.t('places_reset_done'));
        if (res.ok) renderPlaces(view, res.data);
      } }, E.icon('reset', 14), E.t('places_reset'));
      const head = h('div', { class: 'card-head between' }, h('span', null, E.icon(icon, 18), E.t(key)), h('span', { class: 'head-right' }, status.el, badge, saveBtn, resetBtn));
      const dirty = () => status.dirty();
      return { head, save: dirty, saveNow: dirty };
    };

    const numInput = (value, onChange, opts) => h('input', Object.assign({ type: 'number', value: value, oninput: (ev) => onChange(Number(ev.target.value)) }, opts || {}));
    const textInput = (value, onChange) => h('input', { type: 'text', value: value || '', maxlength: 60, oninput: (ev) => onChange(ev.target.value) });
    const hereBtn = (onPoint) => {
      const b = h('button', { class: 'btn small', onclick: async () => { const c = await here(b); if (c) onPoint(c); } }, E.icon('pin', 14), E.t('places_here'));
      return b;
    };
    const styleField = (value, onChange) => h('label', { class: 'field' }, h('span', null, E.t('places_style')), dropdown(styles, value, onChange));

    // Lists of points (fine payment points, impound centres). Markers use the ground height.
    const pointList = (name, icon, key, items) => {
      const list = items.map((p) => Object.assign({}, p));
      list.forEach((p) => { if (!p.style) p.style = styleDefaults[name]; });
      const sec = section(name, icon, key, () => list);
      const rows = h('div', { class: 'place-list' });
      const draw = () => {
        E.clear(rows);
        if (!list.length) rows.appendChild(empty(E.t('places_none'), icon));
        list.forEach((p, i) => {
          const coords = h('span', { class: 'mono small muted' }, fmt(p));
          rows.appendChild(h('div', { class: 'place-row' },
            h('label', { class: 'field grow' }, h('span', null, E.t('places_name')), textInput(p.label, (v) => { p.label = v; sec.save(); })),
            styleField(p.style, (v) => { p.style = v; sec.saveNow(); }),
            h('label', { class: 'field small-field' }, h('span', null, E.t('places_radius')), numInput(p.radius, (v) => { p.radius = v; sec.save(); }, { step: 0.5, min: 0.5 })),
            h('div', { class: 'place-coords' }, coords, h('div', { class: 'actions' },
              hereBtn((c) => { Object.assign(p, { x: c.x, y: c.y, z: c.gz }); coords.textContent = fmt(p); sec.saveNow(); }),
              gotoBtn(() => p),
              h('button', { class: 'btn small btn-ghost', onclick: () => { list.splice(i, 1); draw(); sec.saveNow(); } }, E.icon('trash', 14), E.t('places_delete'))))));
        });
      };
      draw();
      const add = h('button', { class: 'btn', onclick: async () => {
        const c = await here(add);
        if (c) {
          list.push({ label: '', x: c.x, y: c.y, z: c.gz, radius: name === 'impounds' ? 3.0 : 1.5, style: styleDefaults[name] });
          draw();
          sec.saveNow();
        }
      } }, E.icon('plus', 16), E.t('places_add_here'));
      return h('div', { class: 'card' }, sec.head, rows, h('div', { class: 'actions' }, add));
    };

    // One point (players are placed there: body height, with the heading they face).
    const singlePoint = (labelKey, getPoint, withHeading, onSet, extra) => {
      const text = () => fmt(getPoint()) + (withHeading && getPoint() ? ' • ' + E.digits(Math.round(getPoint().h || 0)) + '°' : '');
      const coords = h('span', { class: 'mono small muted' }, text());
      return h('div', { class: 'place-row' },
        h('div', { class: 'grow' }, h('b', null, E.t(labelKey)), h('div', null, coords)),
        extra || null,
        h('div', { class: 'actions' }, hereBtn((c) => { onSet(c); coords.textContent = text(); }), gotoBtn(getPoint)));
    };

    // Jail places.
    const j = JSON.parse(JSON.stringify(data.jail || {}));
    const jailSec = section('jail', 'jail', 'places_jail', () => j);
    const returnRow = () => singlePoint('places_jail_return', () => j.returnPoint || null, false,
      (c) => { j.returnPoint = { x: c.x, y: c.y, z: c.z }; jailSec.saveNow(); },
      h('button', { class: 'btn small btn-ghost', onclick: (ev) => { j.returnPoint = false; ev.currentTarget.closest('.place-row').replaceWith(returnRow()); jailSec.saveNow(); } }, E.icon('x', 14), E.t('places_jail_return_clear')));
    const jailCard = h('div', { class: 'card' }, jailSec.head,
      h('div', { class: 'place-list' },
        singlePoint('places_jail_entry', () => j.entry, true, (c) => { j.entry = { x: c.x, y: c.y, z: c.z, h: c.h }; jailSec.saveNow(); }),
        singlePoint('places_jail_exit', () => j.exit, true, (c) => { j.exit = { x: c.x, y: c.y, z: c.z, h: c.h }; jailSec.saveNow(); }),
        singlePoint('places_jail_center', () => j.center, false, (c) => { j.center = { x: c.x, y: c.y, z: c.z }; jailSec.saveNow(); },
          h('label', { class: 'field small-field' }, h('span', null, E.t('places_jail_radius')), numInput(j.radius, (v) => { j.radius = v; jailSec.save(); }, { step: 5, min: 10 }))),
        returnRow()));

    // Jail tasks.
    const tasks = (data.jailTasks || []).map((t) => Object.assign({}, t));
    tasks.forEach((t) => { if (!t.style) t.style = styleDefaults.jailTasks; });
    const taskSec = section('jailTasks', 'hourglass', 'places_tasks', () => tasks);
    const taskRows = h('div', { class: 'place-list' });
    const typeOptions = data.taskTypes || [];
    const diffOptions = (data.difficulties || []).map((d) => ({ id: d, label: E.t('difficulty_' + d, null, d) }));
    const uiOptions = data.taskUis || []; // look of the task on screen
    const drawTasks = () => {
      E.clear(taskRows);
      if (!tasks.length) taskRows.appendChild(empty(E.t('places_none'), 'jail'));
      tasks.forEach((t, i) => {
        const coords = h('span', { class: 'mono small muted' }, fmt(t));
        taskRows.appendChild(h('div', { class: 'place-row task' },
          h('div', { class: 'task-fields' },
            h('label', { class: 'field grow' }, h('span', null, E.t('places_name')), textInput(t.label, (v) => { t.label = v; taskSec.save(); })),
            h('label', { class: 'field' }, h('span', null, E.t('places_task_type')), dropdown(typeOptions, t.type, (v) => { t.type = v; taskSec.saveNow(); })),
            h('label', { class: 'field' }, h('span', null, E.t('places_task_difficulty')), dropdown(diffOptions, t.difficulty, (v) => { t.difficulty = v; taskSec.saveNow(); })),
            h('label', { class: 'field' }, h('span', null, E.t('places_task_ui')), dropdown(uiOptions, t.ui, (v) => { t.ui = v; taskSec.saveNow(); })),
            styleField(t.style, (v) => { t.style = v; taskSec.saveNow(); }),
            h('label', { class: 'field small-field' }, h('span', null, E.t('places_task_duration')), numInput(t.duration, (v) => { t.duration = v; taskSec.save(); }, { min: 5 })),
            h('label', { class: 'field small-field' }, h('span', null, E.t('places_task_reduction')), numInput(t.reduction, (v) => { t.reduction = v; taskSec.save(); }, { min: 0 })),
            h('label', { class: 'field small-field' }, h('span', null, E.t('places_task_cooldown')), numInput(t.cooldown, (v) => { t.cooldown = v; taskSec.save(); }, { min: 0 })),
            h('label', { class: 'field small-field' }, h('span', null, E.t('places_radius')), numInput(t.radius, (v) => { t.radius = v; taskSec.save(); }, { step: 0.5, min: 0.5 }))),
          h('div', { class: 'place-coords' }, coords, h('div', { class: 'actions' },
            hereBtn((c) => { Object.assign(t, { x: c.x, y: c.y, z: c.gz }); coords.textContent = fmt(t); taskSec.saveNow(); }),
            gotoBtn(() => t),
            h('button', { class: 'btn small btn-ghost', onclick: () => { tasks.splice(i, 1); drawTasks(); taskSec.saveNow(); } }, E.icon('trash', 14), E.t('places_delete'))))));
      });
    };
    drawTasks();
    const addTask = h('button', { class: 'btn', onclick: async () => {
      const c = await here(addTask);
      if (c) {
        tasks.push({ label: '', x: c.x, y: c.y, z: c.gz, radius: 2.0, type: (typeOptions[0] || {}).id, difficulty: diffOptions[0] ? diffOptions[0].id : 'easy',
          duration: 20, reduction: 60, cooldown: 120, style: styleDefaults.jailTasks, ui: (uiOptions[0] || {}).id });
        drawTasks();
        taskSec.saveNow();
      }
    } }, E.icon('plus', 16), E.t('places_add_here'));
    const tasksCard = h('div', { class: 'card' }, taskSec.head, taskRows, h('div', { class: 'actions' }, addTask));

    // Recall HQ.
    let hq = data.recallHQ ? Object.assign({}, data.recallHQ) : null;
    const hqSec = section('recallHQ', 'recall', 'places_hq', () => hq);
    const hqCard = h('div', { class: 'card' }, hqSec.head,
      h('div', { class: 'place-list' }, singlePoint('places_hq_point', () => hq, false, (c) => { hq = { x: c.x, y: c.y, z: c.z }; hqSec.saveNow(); })));

    put(E.clear(view),
      pointList('finePoints', 'cash', 'places_fines', data.finePoints || []),
      pointList('impounds', 'impound', 'places_impounds', data.impounds || []),
      jailCard, tasksCard, hqCard);
  }

  /* ------------------------------------------------------------- Events */
  E.on('ipad:open', (d) => open(d.tab));
  E.on('ipad:tab', (d) => { if (S.open) go(d.tab); });
  E.on('ipad:close', () => close());
  E.on('ipad:push', (d) => {
    if (!S.open) return;
    if (d.type === 'recall' && S.recallView) renderRecall(S.recallView, d.data);
    if (d.type === 'reports') {
      if (S.tab === 'reports') viewReports(E.$('.view', root));
      else { const el = root.querySelector('[data-badge="reports"]'); if (el) { el.classList.remove('hidden'); el.textContent = '•'; } }
    }
  });
})();
