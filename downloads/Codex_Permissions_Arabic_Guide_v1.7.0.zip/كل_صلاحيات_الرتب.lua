-- مرجع: الأسماء التالية لقوائم Config.Permissions، وليست برمشنات groups.lua.
return {

    -- التابلت والمعلومات العسكرية
    "ipad", -- فتح التابلت العسكري
    "office", -- فتح صفحة المكتب ولوحة المناوبة
    "online", -- عرض العسكريين المتصلين
    "wantedList", -- عرض صفحة المطلوبين داخل التابلت
    "badge", -- إظهار الهوية العسكرية
    "clock", -- تسجيل الدخول والخروج العسكري
    "vacation", -- خدمة الإجازات الشخصية
    "militaryCode", -- خدمة الكود العسكري

    -- البلاغات والمطلوبون والاستعلام
    "reports", -- الوصول للبلاغات
    "wanted", -- فتح خدمات المطلوبين
    "wantedAdd", -- إضافة مطلوب
    "wantedClear", -- إزالة مطلوب
    "citizenInquiry", -- الاستعلام عن مواطن

    -- المخالفات
    "fines", -- تحرير المخالفات
    "fineInquiry", -- الاستعلام عن المخالفات

    -- السجن
    "jail", -- سجن شخص
    "jailCheck", -- الاستعلام عن سجين
    "jailModify", -- تعديل مدة السجن
    "jailMonitor", -- مراقبة سجين
    "jailRelease", -- فك السجن

    -- المهام الميدانية
    "fieldCuff", -- الكلبشة وفكها
    "fieldDrag", -- سحب الشخص
    "fieldSearch", -- تفتيش الشخص
    "fieldVehicleSearch", -- تفتيش المركبة
    "fieldPutInVehicle", -- إدخال الشخص للمركبة
    "fieldPullOutVehicle", -- إخراج الشخص من المركبة
    "fieldSeizeWeapons", -- مصادرة الأسلحة
    "fieldSeizeContraband", -- مصادرة الممنوعات
    "fieldIdentity", -- طلب هوية الشخص

    -- العتاد والاستنفار والحواجز
    "equipment", -- استلام العتاد
    "securityAlert", -- الاستنفار الأمني
    "barricades", -- استخدام الحواجز
    "barricadesAdmin", -- إدارة الحواجز وإزالة حواجز الآخرين

    -- حجز المركبات
    "impound", -- حجز مركبة
    "impoundInquiry", -- الاستعلام عن مركبة محجوزة
    "impoundRelease", -- فك حجز مركبة

    -- شؤون العسكريين
    "affairs", -- فتح قسم الشؤون
    "recruit", -- توظيف عسكري
    "dismiss", -- فصل عسكري
    "promote", -- ترقية عسكري
    "demote", -- تنزيل رتبة عسكري
    "recall", -- استدعاء العسكريين: سحب العساكر
    "monitor", -- مراقبة عسكري
    "officerInquiry", -- الاستعلام عن عسكري
    "vacationBalance", -- إضافة رصيد إجازة لعسكري
    "vacationBreak", -- إنهاء إجازة عسكري

    -- التعاميم
    "broadcastOfficers", -- تعميم للعسكريين
    "broadcastCitizens", -- تعميم للمواطنين

    -- التصفير والإحصاءات
    "resetAttendance", -- تصفير حضور عسكري
    "resetFines", -- تصفير مخالفات عسكري
    "resetData", -- تصفير بيانات عسكري حسب الإعدادات
    "statistics", -- الإحصاءات والتوب

    -- الجدول العسكري
    "roster", -- عرض الجدول العسكري
    "rosterManage", -- إدارة أكواد العسكريين وبادئات الجدول
}
