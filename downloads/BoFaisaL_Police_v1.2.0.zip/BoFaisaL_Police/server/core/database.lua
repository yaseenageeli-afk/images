--[[
    BoFaisaL_Police — database layer

    Drivers: oxmysql, mysql-async, ghmattimysql, or custom functions (Config.Database.Custom).
    All SQL uses positional "?" parameters; named-parameter drivers are converted automatically.
    Every call below blocks the calling thread (always call from a thread / event handler).
    Player id columns are BIGINT. Every player id is valid (zero and negatives too), so "no player"
    is NULL: pass DB.id(value) for those columns (a nil value becomes NULL). Other columns use
    NOT NULL defaults (0 / '').
]]

local DB = { ready = false, driver = nil }
BoFaisaL.DB = DB

-- Parameter written as SQL NULL.
DB.NULL = setmetatable({}, { __tostring = function() return "NULL" end })

-- A player id for a column where "no player" is allowed: nil → NULL.
function DB.id(value)
    if value == nil then return DB.NULL end
    return value
end

local TIMEOUT = 15000

DB.schema = {
    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_players` (
        `user_id` BIGINT NOT NULL,
        `name` VARCHAR(64) NOT NULL DEFAULT '',
        `avatar` VARCHAR(255) NOT NULL DEFAULT '',
        `avatar_at` INT NOT NULL DEFAULT 0,
        `last_seen` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_officers` (
        `user_id` BIGINT NOT NULL,
        `name` VARCHAR(64) NOT NULL DEFAULT '',
        `rank_group` VARCHAR(64) NOT NULL DEFAULT '',
        `sector` VARCHAR(96) NOT NULL DEFAULT '',
        `ministry` VARCHAR(64) NOT NULL DEFAULT '',
        `groups_json` TEXT NULL,
        `military_code` VARCHAR(32) NOT NULL DEFAULT '',
        `attendance_total` INT NOT NULL DEFAULT 0,
        `fines_issued` INT NOT NULL DEFAULT 0,
        `jails_issued` INT NOT NULL DEFAULT 0,
        `reports_handled` INT NOT NULL DEFAULT 0,
        `impounds_issued` INT NOT NULL DEFAULT 0,
        `vacation_balance` INT NOT NULL DEFAULT 0,
        `on_duty` TINYINT NOT NULL DEFAULT 0,
        `duty_started_at` INT NOT NULL DEFAULT 0,
        `duty_last_seen` INT NOT NULL DEFAULT 0,
        `last_clock_in` INT NOT NULL DEFAULT 0,
        `last_clock_out` INT NOT NULL DEFAULT 0,
        `active` TINYINT NOT NULL DEFAULT 1,
        `created_at` INT NOT NULL DEFAULT 0,
        `updated_at` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`user_id`),
        KEY `idx_sector` (`sector`),
        KEY `idx_active` (`active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_attendance` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT NOT NULL,
        `sector` VARCHAR(96) NOT NULL DEFAULT '',
        `clock_in` INT NOT NULL,
        `clock_out` INT NOT NULL,
        `duration` INT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_vacations` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT NOT NULL,
        `days` INT NOT NULL,
        `start_at` INT NOT NULL,
        `end_at` INT NOT NULL,
        `original_groups` TEXT NOT NULL,
        `inactive_group` VARCHAR(64) NOT NULL DEFAULT '',
        `status` VARCHAR(16) NOT NULL DEFAULT 'active',
        `restored` TINYINT NOT NULL DEFAULT 0,
        `ended_at` INT NOT NULL DEFAULT 0,
        `ended_by` BIGINT NULL DEFAULT NULL,
        `paused_at` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        KEY `idx_user_status` (`user_id`, `status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_pending` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT NOT NULL,
        `action` VARCHAR(16) NOT NULL,
        `group_name` VARCHAR(64) NOT NULL,
        `created_at` INT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_reports` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `reporter_id` BIGINT NOT NULL,
        `reporter_name` VARCHAR(64) NOT NULL DEFAULT '',
        `target_id` BIGINT NOT NULL,
        `target_name` VARCHAR(64) NOT NULL DEFAULT '',
        `reason` VARCHAR(255) NOT NULL DEFAULT '',
        `status` VARCHAR(16) NOT NULL DEFAULT 'new',
        `assigned_id` BIGINT NULL DEFAULT NULL,
        `assigned_name` VARCHAR(64) NOT NULL DEFAULT '',
        `pos_x` FLOAT NOT NULL DEFAULT 0,
        `pos_y` FLOAT NOT NULL DEFAULT 0,
        `pos_z` FLOAT NOT NULL DEFAULT 0,
        `created_at` INT NOT NULL,
        `updated_at` INT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_status` (`status`),
        KEY `idx_reporter` (`reporter_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_wanted` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `target_id` BIGINT NOT NULL,
        `target_name` VARCHAR(64) NOT NULL DEFAULT '',
        `target_job` VARCHAR(64) NOT NULL DEFAULT '',
        `reason` VARCHAR(255) NOT NULL DEFAULT '',
        `created_by_id` BIGINT NOT NULL,
        `created_by_name` VARCHAR(64) NOT NULL DEFAULT '',
        `created_at` INT NOT NULL,
        `active` TINYINT NOT NULL DEFAULT 1,
        `cleared_by_id` BIGINT NULL DEFAULT NULL,
        `cleared_by_name` VARCHAR(64) NOT NULL DEFAULT '',
        `cleared_at` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        KEY `idx_target_active` (`target_id`, `active`),
        KEY `idx_active` (`active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_fines` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `target_id` BIGINT NOT NULL,
        `target_name` VARCHAR(64) NOT NULL DEFAULT '',
        `officer_id` BIGINT NOT NULL,
        `officer_name` VARCHAR(64) NOT NULL DEFAULT '',
        `category` VARCHAR(32) NOT NULL,
        `category_label` VARCHAR(64) NOT NULL DEFAULT '',
        `fine_id` VARCHAR(64) NOT NULL,
        `label` VARCHAR(128) NOT NULL,
        `amount` INT NOT NULL,
        `status` VARCHAR(16) NOT NULL DEFAULT 'unpaid',
        `created_at` INT NOT NULL,
        `paid_at` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`id`),
        KEY `idx_target_status` (`target_id`, `status`),
        KEY `idx_officer` (`officer_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_jail` (
        `user_id` BIGINT NOT NULL,
        `name` VARCHAR(64) NOT NULL DEFAULT '',
        `officer_id` BIGINT NULL DEFAULT NULL,
        `officer_name` VARCHAR(64) NOT NULL DEFAULT '',
        `reason_id` VARCHAR(64) NOT NULL DEFAULT '',
        `reason_label` VARCHAR(128) NOT NULL DEFAULT '',
        `total_seconds` INT NOT NULL,
        `remaining_seconds` INT NOT NULL,
        `added_seconds` INT NOT NULL DEFAULT 0,
        `reduced_seconds` INT NOT NULL DEFAULT 0,
        `started_at` INT NOT NULL,
        `updated_at` INT NOT NULL,
        `clothing` MEDIUMTEXT NULL,
        `was_cuffed` TINYINT NOT NULL DEFAULT 0,
        PRIMARY KEY (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_jail_history` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `user_id` BIGINT NOT NULL,
        `name` VARCHAR(64) NOT NULL DEFAULT '',
        `officer_id` BIGINT NULL DEFAULT NULL,
        `officer_name` VARCHAR(64) NOT NULL DEFAULT '',
        `reason_label` VARCHAR(128) NOT NULL DEFAULT '',
        `total_seconds` INT NOT NULL DEFAULT 0,
        `started_at` INT NOT NULL DEFAULT 0,
        `ended_at` INT NOT NULL DEFAULT 0,
        `end_type` VARCHAR(16) NOT NULL DEFAULT '',
        `released_by_id` BIGINT NULL DEFAULT NULL,
        `released_by_name` VARCHAR(64) NOT NULL DEFAULT '',
        `release_reason` VARCHAR(255) NOT NULL DEFAULT '',
        PRIMARY KEY (`id`),
        KEY `idx_user` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_impounds` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `plate` VARCHAR(16) NOT NULL,
        `model` VARCHAR(64) NOT NULL DEFAULT '',
        `owner_id` BIGINT NOT NULL,
        `owner_name` VARCHAR(64) NOT NULL DEFAULT '',
        `officer_id` BIGINT NOT NULL,
        `officer_name` VARCHAR(64) NOT NULL DEFAULT '',
        `location_id` VARCHAR(32) NOT NULL,
        `reason` VARCHAR(128) NOT NULL,
        `fee` INT NOT NULL DEFAULT 0,
        `model_hash` BIGINT NOT NULL DEFAULT 0,
        `status` VARCHAR(16) NOT NULL DEFAULT 'impounded',
        `created_at` INT NOT NULL,
        `released_at` INT NOT NULL DEFAULT 0,
        `release_type` VARCHAR(16) NOT NULL DEFAULT '',
        `released_by_id` BIGINT NULL DEFAULT NULL,
        `released_by_name` VARCHAR(64) NOT NULL DEFAULT '',
        PRIMARY KEY (`id`),
        KEY `idx_plate_status` (`plate`, `status`),
        KEY `idx_owner_status` (`owner_id`, `status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_logs` (
        `id` INT NOT NULL AUTO_INCREMENT,
        `category` VARCHAR(32) NOT NULL,
        `action` VARCHAR(64) NOT NULL,
        `actor_id` BIGINT NULL DEFAULT NULL,
        `actor_name` VARCHAR(64) NOT NULL DEFAULT '',
        `target_id` BIGINT NULL DEFAULT NULL,
        `target_name` VARCHAR(64) NOT NULL DEFAULT '',
        `details` TEXT NULL,
        `created_at` INT NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_category` (`category`),
        KEY `idx_actor` (`actor_id`),
        KEY `idx_target` (`target_id`),
        KEY `idx_created` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    -- Last character photo of each player (headshot taken by his own client).
    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_mugshots` (
        `user_id` BIGINT NOT NULL,
        `image` MEDIUMTEXT NULL,
        `updated_at` INT NOT NULL DEFAULT 0,
        PRIMARY KEY (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],

    -- Small key / value store (e.g. the last weekly vacation reset).
    [[CREATE TABLE IF NOT EXISTS `bofaisal_police_meta` (
        `k` VARCHAR(64) NOT NULL,
        `v` MEDIUMTEXT NULL,
        PRIMARY KEY (`k`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4]],
}

---------------------------------------------------------------------------
-- Drivers
---------------------------------------------------------------------------
local function toNamed(sql, params)
    local i = 0
    local named = {}
    local out = sql:gsub("%?", function()
        i = i + 1
        named["@p" .. i] = params[i]
        return "@p" .. i
    end)
    return out, named
end

local drivers = {}

drivers.oxmysql = {
    resource = "oxmysql",
    query = function(sql, params, cb) exports.oxmysql:query(sql, params, cb) end,
    execute = function(sql, params, cb) exports.oxmysql:update(sql, params, cb) end,
    insert = function(sql, params, cb) exports.oxmysql:insert(sql, params, cb) end,
}

drivers["mysql-async"] = {
    resource = "mysql-async",
    named = true,
    query = function(sql, params, cb) exports["mysql-async"]:mysql_fetch_all(sql, params, cb) end,
    execute = function(sql, params, cb) exports["mysql-async"]:mysql_execute(sql, params, cb) end,
    insert = function(sql, params, cb) exports["mysql-async"]:mysql_insert(sql, params, cb) end,
}

drivers.ghmattimysql = {
    resource = "ghmattimysql",
    named = true,
    query = function(sql, params, cb) exports.ghmattimysql:execute(sql, params, cb) end,
    execute = function(sql, params, cb)
        exports.ghmattimysql:execute(sql, params, function(r)
            cb(type(r) == "table" and (r.affectedRows or r.changedRows) or r)
        end)
    end,
    insert = function(sql, params, cb)
        exports.ghmattimysql:execute(sql, params, function(r)
            cb(type(r) == "table" and r.insertId or r)
        end)
    end,
}

local function customDriver()
    local c = Config.Database and Config.Database.Custom
    if type(c) ~= "table" or type(c.query) ~= "function" then return nil end
    return {
        resource = nil,
        query = c.query,
        execute = c.execute or c.query,
        insert = c.insert or c.query,
    }
end

local function pickDriver()
    local wanted = Config.Database and Config.Database.Driver or "auto"
    if wanted == "custom" then return customDriver(), "custom" end
    if wanted ~= "auto" then
        local d = drivers[wanted]
        if d and GetResourceState(d.resource) == "started" then return d, wanted end
        return nil, wanted
    end
    for _, name in ipairs({ "oxmysql", "mysql-async", "ghmattimysql" }) do
        if GetResourceState(name) == "started" then return drivers[name], name end
    end
    local c = customDriver()
    if c then return c, "custom" end
    return nil, "auto"
end

---------------------------------------------------------------------------
-- Core call
---------------------------------------------------------------------------
-- Whole numbers past 2^53 lose digits in the JavaScript database drivers: they travel as text.
local JS_SAFE = 9007199254740991

local function prepare(sql, params)
    params = params or {}
    local list, i = {}, 0
    -- DB.NULL is written straight into the statement; every other value stays a parameter.
    local out = sql:gsub("%?", function()
        i = i + 1
        local v = params[i]
        if v == DB.NULL then return "NULL" end
        if v == nil then
            BoFaisaL.error("SQL parameter %d is nil in: %s", i, sql:sub(1, 120))
            v = ""
        elseif type(v) == "boolean" then
            v = v and 1 or 0
        elseif math.type(v) == "integer" and (v > JS_SAFE or v < -JS_SAFE) then
            v = tostring(v)
        end
        list[#list + 1] = v
        return "?"
    end)
    if DB.driver.named then return toNamed(out, list) end
    return out, list
end

-- DB.watch(table, fn): fn runs after every write (execute / insert) to that table, so a module can
-- keep its rows in memory and drop them the moment they change.
local watchers = {}
function DB.watch(tableName, fn)
    watchers[#watchers + 1] = { name = tableName, fn = fn }
end

local function written(sql)
    for i = 1, #watchers do
        if sql:find(watchers[i].name, 1, true) then
            local ok, err = pcall(watchers[i].fn)
            if not ok then BoFaisaL.error("database watcher failed: %s", tostring(err)) end
        end
    end
end

local function run(kind, sql, params)
    if not DB.ready then return nil end
    local q, p = prepare(sql, params)
    local promiseObj = promise.new()
    local finished = false
    local ok, err = pcall(DB.driver[kind], q, p, function(result)
        if finished then return end
        finished = true
        promiseObj:resolve({ value = result })
    end)
    if not ok then
        BoFaisaL.error("database %s failed: %s", kind, tostring(err))
        return nil
    end
    SetTimeout(TIMEOUT, function()
        if finished then return end
        finished = true
        BoFaisaL.error("database %s timed out: %s", kind, sql:sub(1, 120))
        promiseObj:resolve({})
    end)
    local r = Citizen.Await(promiseObj)
    -- After the write has finished: a read made meanwhile can never keep the old rows.
    if kind ~= "query" and #watchers > 0 then written(sql) end
    if Config.Debug then
        BoFaisaL.debug("database", "%s → %s", (sql:sub(1, 90):gsub("%s+", " ")),
            type(r.value) == "table" and ("rows:" .. #r.value) or tostring(r.value))
    end
    return r.value
end

function DB.query(sql, params)
    local rows = run("query", sql, params)
    if type(rows) ~= "table" then return {} end
    return rows
end

function DB.single(sql, params)
    local rows = DB.query(sql, params)
    return rows[1]
end

function DB.scalar(sql, params)
    local row = DB.single(sql, params)
    if not row then return nil end
    for _, v in pairs(row) do return v end
    return nil
end

function DB.execute(sql, params)
    local r = run("execute", sql, params)
    if type(r) == "table" then r = r.affectedRows end
    return tonumber(r) or 0
end

function DB.insert(sql, params)
    local r = run("insert", sql, params)
    if type(r) == "table" then r = r.insertId end
    return tonumber(r)
end

-- Dispatches a statement to the driver without waiting for the answer (resource stop).
function DB.fire(sql, params)
    if not DB.ready then return end
    local q, p = prepare(sql, params)
    pcall(DB.driver.execute, q, p, function() end)
end

function DB.executeAsync(sql, params)
    BoFaisaL.thread(function() DB.execute(sql, params) end)
end

-- Converts "@name" placeholders (server-owner SQL hooks) into positional parameters.
function DB.named(sql, map)
    local list = {}
    local out = sql:gsub("@([%a_][%w_]*)", function(name)
        local v = map[name]
        if v == nil then v = "" end
        list[#list + 1] = v
        return "?"
    end)
    return out, list
end

---------------------------------------------------------------------------
-- Upgrade: player id columns INT → BIGINT, and "no player" 0 → NULL (0 is a real id).
---------------------------------------------------------------------------
-- table, column, "none" allowed, name column (an old 0 with an empty name meant "no player")
local ID_COLUMNS = {
    { "bofaisal_police_players", "user_id" },
    { "bofaisal_police_officers", "user_id" },
    { "bofaisal_police_attendance", "user_id" },
    { "bofaisal_police_vacations", "user_id" },
    { "bofaisal_police_vacations", "ended_by", true },
    { "bofaisal_police_pending", "user_id" },
    { "bofaisal_police_reports", "reporter_id" },
    { "bofaisal_police_reports", "target_id" },
    { "bofaisal_police_reports", "assigned_id", true, "assigned_name" },
    { "bofaisal_police_wanted", "target_id" },
    { "bofaisal_police_wanted", "created_by_id" },
    { "bofaisal_police_wanted", "cleared_by_id", true, "cleared_by_name" },
    { "bofaisal_police_fines", "target_id" },
    { "bofaisal_police_fines", "officer_id" },
    { "bofaisal_police_jail", "user_id" },
    { "bofaisal_police_jail", "officer_id", true, "officer_name" },
    { "bofaisal_police_jail_history", "user_id" },
    { "bofaisal_police_jail_history", "officer_id", true, "officer_name" },
    { "bofaisal_police_jail_history", "released_by_id", true, "released_by_name" },
    { "bofaisal_police_impounds", "owner_id" },
    { "bofaisal_police_impounds", "officer_id" },
    { "bofaisal_police_impounds", "released_by_id", true, "released_by_name" },
    { "bofaisal_police_logs", "actor_id", true, "actor_name" },
    { "bofaisal_police_logs", "target_id", true, "target_name" },
    { "bofaisal_police_mugshots", "user_id" },
}

local function upgradeIdColumns()
    local current = {}
    for _, row in ipairs(DB.query("SELECT TABLE_NAME AS t, COLUMN_NAME AS c, DATA_TYPE AS d, IS_NULLABLE AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE 'bofaisal_police_%'")) do
        current[tostring(row.t) .. "." .. tostring(row.c)] = { type = tostring(row.d):lower(), nullable = row.n == "YES" }
    end
    local changes, order, cleared = {}, {}, {}
    for _, c in ipairs(ID_COLUMNS) do
        local now = current[c[1] .. "." .. c[2]]
        if now and (now.type ~= "bigint" or now.nullable ~= (c[3] == true)) then
            if not changes[c[1]] then changes[c[1]] = {} order[#order + 1] = c[1] end
            table.insert(changes[c[1]], ("MODIFY `%s` %s"):format(c[2], c[3] and "BIGINT NULL DEFAULT NULL" or "BIGINT NOT NULL"))
            if c[3] and not now.nullable then cleared[#cleared + 1] = c end
        end
    end
    for _, tableName in ipairs(order) do
        run("execute", ("ALTER TABLE `%s` %s"):format(tableName, table.concat(changes[tableName], ", ")), {})
    end
    for _, c in ipairs(cleared) do
        local nameCheck = c[4] and (" AND `%s` = ''"):format(c[4]) or ""
        run("execute", ("UPDATE `%s` SET `%s` = NULL WHERE `%s` = 0%s"):format(c[1], c[2], c[2], nameCheck), {})
    end
    if #order > 0 then BoFaisaL.print("Database: player id columns upgraded (%d tables).", #order) end
end

function DB.init()
    local driver, name = pickDriver()
    if not driver then
        DB.ready = false
        BoFaisaL.error("Database unavailable (driver '%s'). Start oxmysql, mysql-async or ghmattimysql.", tostring(name))
        return false
    end
    DB.driver = driver
    DB.driverName = name
    DB.ready = true
    if not (Config.Database and Config.Database.AutoCreateTables == false) then
        for _, statement in ipairs(DB.schema) do
            run("execute", statement, {})
        end
        -- Upgrades: bofaisal_police_meta.v was VARCHAR(255), too short for the panel theme / locations.
        run("execute", "ALTER TABLE `bofaisal_police_meta` MODIFY `v` MEDIUMTEXT NULL", {})
        -- Upgrade: vacations pause while the officer is offline (paused_at).
        local hasPaused = tonumber(DB.scalar("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'bofaisal_police_vacations' AND COLUMN_NAME = 'paused_at'"))
        if hasPaused == 0 then run("execute", "ALTER TABLE `bofaisal_police_vacations` ADD COLUMN `paused_at` INT NOT NULL DEFAULT 0", {}) end
        -- Upgrade: index on the logs date (old logs are removed by Config.Database.LogsKeepDays).
        local hasLogIdx = tonumber(DB.scalar("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'bofaisal_police_logs' AND INDEX_NAME = 'idx_created'"))
        if hasLogIdx == 0 then run("execute", "ALTER TABLE `bofaisal_police_logs` ADD KEY `idx_created` (`created_at`)", {}) end
        -- Upgrade: model hash of an impounded vehicle (blocks it from leaving any garage).
        local hasHash = tonumber(DB.scalar("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'bofaisal_police_impounds' AND COLUMN_NAME = 'model_hash'"))
        if hasHash == 0 then run("execute", "ALTER TABLE `bofaisal_police_impounds` ADD COLUMN `model_hash` BIGINT NOT NULL DEFAULT 0 AFTER `fee`", {}) end
        upgradeIdColumns()
    end
    BoFaisaL.print("Database ready (%s).", name)
    return true
end
