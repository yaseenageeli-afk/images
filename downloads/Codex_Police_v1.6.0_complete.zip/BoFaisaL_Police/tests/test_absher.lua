local handlers,captured={},{ };Config={Absher={Title='أبشر',RemotePay=true,RemoteRelease=true}}
function L(k)return k end
BoFaisaL={RPC={register=function(name,opts,fn)handlers[name]=fn end},
 DB={single=function(sql,args)captured[#captured+1]=args;return {count=2,total=750}end,query=function(sql,args)captured[#captured+1]=args;return {}end},
 Players={name=function(uid)return 'User '..uid end},Framework={getMoney=function()return 100 end,getBankMoney=function()return 200 end},
 Integrations={Garage={ownerVehicles=function(uid)captured[#captured+1]={uid};return {'a','b','c'}end}},
 Gov={getProfile=function()return {}end,summary=function()return {military=false,rank='',sectorLabel='',ministryLabel=''}end},
 Impound={ownerView=function(uid)captured[#captured+1]={uid};return {list={{id=1}}}end},Wanted={getActive=function()return nil end},
 Jail={status=function(uid)captured[#captured+1]={uid};return {jailed=false}end},
 Fines={payView=function(uid)captured[#captured+1]={uid};return {list={{id=1}}}end},feature=function()return true end}
assert(loadfile('server/absher.lua'))()
local ctx={user_id=1,source=10,name='User 1'};local n=0;local function check(label,c)assert(c,label);n=n+1 end
local profile=handlers['absher:view'](ctx,{view='profile',user_id=999})
check('profile uses authenticated identity',profile.data.user_id==1 and profile.data.name=='User 1')
check('actual owned vehicle count',profile.data.ownedVehiclesCount==3)
check('not jailed is zero',profile.data.activeSentencesCount==0)
local fines=handlers['absher:view'](ctx,{view='fines',user_id=999});check('readonly fines browsing',fines.data.readonly==true)
check('fine payment route unchanged',handlers['absher:view'](ctx,{view='finesPay'}).data.readonly==false)
Config.Absher.RemotePay=false;check('remote payment disable respected',handlers['absher:view'](ctx,{view='finesPay'}).data.readonly==true)
check('impound browsing remains readonly',handlers['absher:view'](ctx,{view='impound'}).data.readonly==true)
Config.Absher.RemoteRelease=false;check('remote release disable respected',handlers['absher:view'](ctx,{view='impoundPay'}).data.readonly==true)
check('police profile does not grant a rank',handlers['absher:view'](ctx,{view='policeProfile'}).data.military==false)
check('own sentencing records supported',handlers['absher:view'](ctx,{view='records',user_id=999}).kind=='absherRecords')
for _,args in ipairs(captured)do for _,uid in ipairs(args)do check('server identity scoped data',uid==1)end end
check('unknown view rejected',handlers['absher:view'](ctx,{view='admin'})==nil)
print('Absher identity and payment checks passed: '..n)
