-- Cameras render the game through the tablet's transparent viewport. No player teleport.
local cam,session,originalYaw,originalPitch,lease
local requested=false
local function stop()
 requested=false
 local active=cam~=nil
 if cam then RenderScriptCams(false,false,0,true,true);DestroyCam(cam,false)end
 cam,session=nil,nil
 if active then ClearFocus();ClearTimecycleModifier();UI.send('ipad:push',{type='cameraStopped',data={}})end
end
BoFaisaL.stopSecurityCamera=stop
RegisterNetEvent('bofaisal_police:camera:start',function(data)
 if not requested or not BoFaisaL.isIpadOpen() then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=data.token})end);return end
 stop();requested=true;session=data;originalYaw=data.rotation.z;originalPitch=data.rotation.x;lease=GetGameTimer()+25000
 cam=CreateCam('DEFAULT_SCRIPTED_CAMERA',true)
 SetCamCoord(cam,data.coords.x,data.coords.y,data.coords.z);SetCamRot(cam,data.rotation.x,data.rotation.y,data.rotation.z,2);SetCamFov(cam,65.0)
 SetFocusPosAndVel(data.coords.x,data.coords.y,data.coords.z,0.0,0.0,0.0)
 SetCamActive(cam,true);RenderScriptCams(true,false,0,true,true);SetTimecycleModifier('scanline_cam_cheap')
end)
RegisterNetEvent('bofaisal_police:camera:stop',stop)
RegisterNetEvent('bofaisal_police:camera:lease',function()if cam then lease=GetGameTimer()+25000 end end)
RegisterNUICallback('cameraPrepare',function(_,cb)requested=true;cb({ok=true})end)
RegisterNUICallback('cameraStop',function(_,cb)
 local token=session and session.token;stop();cb({ok=true});
 if token then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=token})end)end
end)
RegisterNUICallback('cameraControl',function(data,cb)
 if not cam or not session or not session.canRotate then cb({ok=false});return end
 local step=({left=-5,right=5,up=5,down=-5})[data.direction]
 if not step then cb({ok=false});return end
 local r=GetCamRot(cam,2)
 local pitch=math.max(-80,math.min(15,r.x+((data.direction=='up' or data.direction=='down')and step or 0)))
 local yaw=math.max(originalYaw-65,math.min(originalYaw+65,r.z+((data.direction=='left' or data.direction=='right')and step or 0)))
 SetCamRot(cam,pitch,r.y,yaw,2);cb({ok=true})
end)
RegisterNetEvent('bofaisal_police:pose',function(command)
 -- Fixed commands only. Never execute arbitrary strings received from the UI.
 if command=='e poG83' or command=='e poG82' or command=='e poG84' then
  BoFaisaL.closeIpad();UI.focus('menu',false);ExecuteCommand(command)
 end
end)
AddEventHandler('bofaisal_police:client:closed',function(layer)if layer=='ipad'then stop()end end)
AddEventHandler('onResourceStop',function(name)if name==GetCurrentResourceName()then stop()end end)
CreateThread(function()while true do
 Wait(cam and 100 or 1000)
 if cam and (GetGameTimer()>lease or IsEntityDead(PlayerPedId()))then
  local token=session and session.token;stop();if token then CreateThread(function()BoFaisaL.rpc('extras:cameras:stop',{token=token})end)end
 end
end end)
