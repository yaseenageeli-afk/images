-- Codex presentation only. Does not change ranks, permissions, money or duty rules.
local menus = Config.Menus or {}
if menus.Main and menus.Main.Police then
    menus.Main.Police.label = "القائمة العسكرية"
    menus.Main.Police.description = "فتح القائمة العسكرية"
end
if menus.Main and menus.Main.Absher then menus.Main.Absher.label = "أبشر" end
if menus.Main then
    menus.Main.Ehsan = menus.Main.Ehsan or { enabled = true, label = "إحسان", description = "حالات المساندة والتبرعات" }
end
local police = menus.Police or {}
local labels = {
    Ipad = "القائمة العسكرية", CitizenInquiry = "استعلام عن مواطن", Wanted = "تعميم بلاغ",
    Fines = "المخالفات", Jail = "السجن", Badge = "إظهار الهوية العسكرية",
    Field = "خيارات الميدان", SecurityTools = "الأدوات الأمنية", Inquiries = "استعلامات",
    Impound = "حجز المركبات", Barricades = "الحواجز",
}
for key,label in pairs(labels) do if police[key] then police[key].label = label end end
if police.Clock then
    police.Clock.label = "تسجيل الدخول / تسجيل الخروج"
    police.Clock.labelIn = "تسجيل الدخول"
    police.Clock.labelOut = "تسجيل الخروج"
end
if police.Ipad and police.Ipad.tabs then
    local labels = { Office = "مكتبي", Online = "المتصلين", Reports = "البلاغات",
        Wanted = "مطلوبين الدولة", Affairs = "الشؤون", Roster = "الجدول العسكري" }
    for key,label in pairs(labels) do
        if police.Ipad.tabs[key] then police.Ipad.tabs[key].label = label end
    end
end
-- Restore only labels changed in previous Codex builds; retain other custom text.
local renamed = {
    ["القيادة الأمنية"] = "الشرطة", ["مركز القيادة"] = "القائمة العسكرية",
    ["ملف الخدمة"] = "مكتبي", ["القوة المتاحة"] = "المتصلين", ["غرفة العمليات"] = "البلاغات",
    ["قائمة التعقب"] = "مطلوبين الدولة", ["إدارة الأفراد"] = "الشؤون", ["سجل التشكيلات"] = "الجدول العسكري",
    ["الإجراءات الميدانية"] = "خيارات الميدان", ["مستودع التجهيز"] = "العتاد", ["نطاق الحماية"] = "الاستنفار الأمني",
    ["الضبط المروري"] = "المخالفات", ["إدارة التوقيف"] = "السجن", ["السجل المدني"] = "استعلام عن مواطن",
    ["نشرة التعقب"] = "تعميم بلاغ", ["إبراز الشارة"] = "إظهار الهوية العسكرية",
    ["بدء المناوبة"] = "تسجيل الدخول", ["إنهاء المناوبة"] = "تسجيل الخروج",
    ["تقييد / تحرير"] = "كلبشة / فك الكلبشة", ["مصادرة التسليح"] = "استيلاء على الأسلحة",
    ["مرافقة المقيد"] = "سحب", ["الفحص الأمني"] = "تفتيش", ["التحقق من الهوية"] = "طلب الهوية",
    ["ضم إلى الخدمة"] = "توظيف", ["رفع الدرجة"] = "ترقية", ["إنهاء الخدمة"] = "فصل", ["لوحة التميّز"] = "توب 10",
}
for _,texts in ipairs({ Locale or {}, LocaleUI or {} }) do
    for key,value in pairs(texts) do if renamed[value] then texts[key] = renamed[value] end end
end
local function restore(t)
    if type(t) ~= "table" then return end
    for key,value in pairs(t) do
        if type(value) == "table" then restore(value)
        elseif key == "label" and renamed[value] then t[key] = renamed[value] end
    end
end
restore(police)
if Config.UI then Config.UI.Brand = "Codex"; Config.UI.Accent = "#929baa" end
-- New defaults for the civilian screen; existing Appearance overrides are retained.
if Config.Absher then Config.Absher.Appearance = Config.Absher.Appearance or {
    Accent = "#18b981", Background = "#080f0d", Card = "#141c17", Width = 1280, Height = 88 } end
