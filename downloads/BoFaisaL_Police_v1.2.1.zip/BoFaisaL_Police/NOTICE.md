# Attribution
Base: Evora_Police 1.1.0, author as supplied: Made By LR.
Custom interface, naming changes and Ehsan module: BoFaisaL.
Original authorship is preserved here and in fxmanifest.lua. No license grant was found for the base script; these changes do not transfer ownership of it. Font license remains in web/assets/fonts/OFL.txt.
