--[[
    BoFaisaL_Police — config assembly

    Builds the runtime Config from the user-facing files:
        config/config.lua    Config.Menus, Config.Lists, Config.Government
        config/coords.lua    Config.Coords
        config/settings.lua  every system's settings
    Menu labels are written into Locale / LocaleUI, menu switches become Config.Features,
    and each rank's `role` is added to Config.Roles[role].ranks.
]]

-- The notifications (config/notifications.lua) are texts like the others.
for key, text in pairs(Config.Notifications or {}) do
    if type(text) == "string" and Locale then Locale[key] = text end
end

local Menus = Config.Menus or {}
local Lists = Config.Lists or {}
local Coords = Config.Coords or {}
local IS_SERVER = IsDuplicityVersion()

local function on(entry)
    return type(entry) == "table" and entry.enabled ~= false
end

local function setText(key, value, ui)
    if type(value) ~= "string" then return end
    if Locale then Locale[key] = value end
    if ui and LocaleUI then LocaleUI[key] = value end
end

-- label → key, description → descKey (defaults to key .. "_desc")
local function applyEntry(entry, key, descKey)
    if type(entry) ~= "table" then return end
    setText(key, entry.label)
    setText(descKey or (key .. "_desc"), entry.description)
end

---------------------------------------------------------------------------
-- Menus: labels, sub-menu switches and features
---------------------------------------------------------------------------
MenuDisabled = {}

-- True unless the sub-menu entry registered under this locale key is disabled.
function MenuOn(key)
    return not MenuDisabled[key]
end

local function subEntry(entry, key, descKey)
    applyEntry(entry, key, descKey)
    if type(entry) == "table" and entry.enabled == false then MenuDisabled[key] = true end
end

local main = Menus.Main or {}
local police = Menus.Police or {}
local ipad = police.Ipad or {}
local tabs = ipad.tabs or {}

applyEntry(main.Police, "menu_police")
applyEntry(main.Report, "menu_report")
applyEntry(main.Absher, "menu_absher")

applyEntry(ipad, "menu_ipad")
setText("tab_office", tabs.Office and tabs.Office.label, true)
setText("tab_online", tabs.Online and tabs.Online.label, true)
setText("tab_reports", tabs.Reports and tabs.Reports.label, true)
setText("tab_wanted", tabs.Wanted and tabs.Wanted.label, true)
setText("tab_affairs", tabs.Affairs and tabs.Affairs.label, true)
setText("tab_roster", tabs.Roster and tabs.Roster.label, true)

if police.Clock then
    applyEntry(police.Clock, "menu_clock")
    setText("menu_clock_in", police.Clock.labelIn)
    setText("menu_clock_out", police.Clock.labelOut)
end
applyEntry(police.CitizenInquiry, "menu_citizen_inquiry")
applyEntry(police.Wanted, "menu_wanted")
applyEntry(police.Fines, "menu_fines")
applyEntry(police.Jail, "menu_jail")
applyEntry(police.Badge, "menu_badge")
applyEntry(police.Field, "menu_field")
applyEntry(police.SecurityTools, "menu_security_tools")
applyEntry(police.Inquiries, "menu_inquiries")
applyEntry(police.Impound, "menu_impound")
applyEntry(police.Barricades, "menu_barricades")
applyEntry(police.Vacation, "menu_vacation_break")

local security = (police.SecurityTools and police.SecurityTools.items) or {}
subEntry(security.Equipment, "menu_equipment")
subEntry(security.SecurityAlert, "menu_security_alert")

local inquiries = (police.Inquiries and police.Inquiries.items) or {}
subEntry(inquiries.Fines, "inq_fines")
subEntry(inquiries.JailCheck, "inq_jail_check")
subEntry(inquiries.JailModify, "inq_jail_modify")
subEntry(inquiries.JailMonitor, "inq_jail_monitor")
subEntry(inquiries.JailRelease, "inq_jail_release")
subEntry(inquiries.Impound, "inq_impound")
-- Titles of the prisoner lists opened from the inquiries menu
setText("menu_jail_modify", inquiries.JailModify and inquiries.JailModify.label)
setText("menu_jail_monitor", inquiries.JailMonitor and inquiries.JailMonitor.label)
setText("menu_jail_release", inquiries.JailRelease and inquiries.JailRelease.label)

local impound = (police.Impound and police.Impound.items) or {}
subEntry(impound.Impound, "impound_action")
subEntry(impound.Inquiry, "impound_inquiry_title", "impound_inquiry_desc")
subEntry(impound.Release, "impound_release_title", "impound_release_desc")

local barricades = (police.Barricades and police.Barricades.items) or {}
subEntry(barricades.Spawn, "barricade_spawn")
subEntry(barricades.Remove, "barricade_remove")
subEntry(barricades.RemoveAll, "barricade_remove_all")

Config.Features = {
    Ipad           = { enabled = on(ipad) },
    Clock          = { enabled = on(police.Clock) },
    CitizenInquiry = { enabled = on(police.CitizenInquiry) },
    Wanted         = { enabled = on(police.Wanted) },
    Fines          = { enabled = on(police.Fines) },
    Jail           = { enabled = on(police.Jail) },
    Badge          = { enabled = on(police.Badge) },
    Field          = { enabled = on(police.Field) },
    SecurityTools  = { enabled = on(police.SecurityTools) },
    Inquiries      = { enabled = on(police.Inquiries) },
    Impound        = { enabled = on(police.Impound) },
    Barricades     = { enabled = on(police.Barricades) },
    CitizenReport  = { enabled = on(main.Report) },
    Absher         = { enabled = on(main.Absher) },
    Vacation       = { enabled = on(police.Vacation) },
    Affairs        = { enabled = on(tabs.Affairs) },
    Roster         = { enabled = on(tabs.Roster) },
    Reports        = { enabled = on(tabs.Reports) },
}

-- Field actions: name / description / switch come from the menu config
Config.Field = Config.Field or {}
Config.Field.Actions = Config.Field.Actions or {}
for name, item in pairs((police.Field and police.Field.items) or {}) do
    setText("field_" .. name, item.label)
    setText("field_desc_" .. name, item.description)
    local action = Config.Field.Actions[name] or {}
    action.enabled = on(item)
    Config.Field.Actions[name] = action
end

---------------------------------------------------------------------------
-- Lists and coordinates
---------------------------------------------------------------------------
Config.Barricades = Lists.Barricades or {}
Config.Contraband = Lists.Contraband or {}

Config.Equipment = Config.Equipment or {}
Config.Equipment.Kits = Lists.Equipment or {}

Config.Fines = Config.Fines or {}
Config.Fines.Categories = Lists.Fines or {}
Config.Fines.PaymentPoints = Coords.FinePayment or {}

Config.Jail = Config.Jail or {}
Config.Jail.Reasons = Lists.JailReasons or {}
for key, value in pairs(Coords.Jail or {}) do Config.Jail[key] = value end
Config.Jail.Tasks = Config.Jail.Tasks or {}
Config.Jail.Tasks.List = Coords.JailTasks or {}

Config.Impound = Config.Impound or {}
Config.Impound.Reasons = Lists.ImpoundReasons or {}
Config.Impound.Locations = Coords.Impound or {}

Config.Recall = Config.Recall or {}
Config.Recall.HQ = Coords.RecallHQ

---------------------------------------------------------------------------
-- Ranks → permissions
--   Config.Permissions["group"] = { "ipad", "fines", ... }  (or { ipad = true, ... })
--   Each rank becomes its own role internally.
---------------------------------------------------------------------------
Config.Roles = Config.Roles or {}

for group, perms in pairs(Config.Permissions or {}) do
    local role = { ranks = { group }, permissions = {} }
    for k, v in pairs(type(perms) == "table" and perms or {}) do
        if type(k) == "number" then role.permissions[v] = true else role.permissions[k] = v end
    end
    Config.Roles["rank:" .. group] = role
end

local function assignRoles(ranks, where)
    for _, entry in ipairs(ranks or {}) do
        if type(entry) == "table" and entry.role then
            local role = Config.Roles[entry.role]
            if type(role) == "table" then
                role.ranks = role.ranks or {}
                role.ranks[#role.ranks + 1] = entry.group
            elseif IS_SERVER then
                print(("^3[BoFaisaL_Police] Rank '%s' (%s) uses unknown role '%s'. Check config/settings.lua (Config.Roles).^0")
                    :format(tostring(entry.group), where, tostring(entry.role)))
            end
        end
    end
end

local gov = Config.Government or {}
if gov.PrimeMinistry then assignRoles(gov.PrimeMinistry.ranks, gov.PrimeMinistry.label or "PrimeMinistry") end
for mKey, ministry in pairs(gov.Ministries or {}) do
    assignRoles(ministry.ranks, mKey)
    for sKey, sector in pairs(ministry.sectors or {}) do
        assignRoles(sector.ranks, mKey .. "." .. sKey)
    end
end
