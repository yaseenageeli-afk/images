--[[
    BoFaisaL_Police — field options (خيارات الميدان)

    Every action: permission + duty + server-side proximity + optional F5/F6 confirmation
    (Config.Field.Actions[x].confirm) + optional "target must be cuffed".
]]

local Field = { last = {}, vehicleSessions = {} }
BoFaisaL.Field = Field

local DB, P, Gov, Logs, Officers, Confirm, Targets, RPC =
    BoFaisaL.DB, BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.Logs, BoFaisaL.Officers, BoFaisaL.Confirm, BoFaisaL.Targets, BoFaisaL.RPC
local I = BoFaisaL.Integrations

local ORDER = { "cuff", "seizeWeapons", "drag", "search", "vehicleSearch", "putInVehicle", "pullOutVehicle", "seizeContraband", "identity" }

local function actionCfg(name)
    return (Config.Field and Config.Field.Actions and Config.Field.Actions[name]) or {}
end
-- Permission of an action: Config.Field.Actions[name].permission, else its own (fieldCuff, ...).
local function permOf(name)
    local p = actionCfg(name).permission
    if type(p) ~= "string" or p == "" or p == "field" then p = Gov.FIELD_PERMS[name] or "field" end
    return p
end
Field.permOf = permOf

local function contrabandList()
    local list = {}
    for _, entry in ipairs(Config.Contraband or {}) do
        if type(entry) == "string" then
            list[#list + 1] = { item = entry }
        elseif type(entry) == "table" and entry.item then
            list[#list + 1] = { item = entry.item, label = entry.label }
        end
    end
    return list
end
Field.contrabandList = contrabandList

local function isContraband(item)
    for _, c in ipairs(contrabandList()) do
        if c.item == item then return true end
    end
    return false
end

-- Common gate for every field action. Returns officer id or nil (after notifying).
-- public = true: the ID request command, open to every player (no permission / duty).
local function allowed(source, name, public)
    local user_id = P.getUserId(source)
    if not user_id then return nil end
    local a = actionCfg(name)
    if not BoFaisaL.feature("Field") or a.enabled == false then
        BoFaisaL.notify(source, "err_feature_disabled", nil, "error")
        return nil
    end
    if not public then
        local profile = Gov.getProfile(user_id, true)
        if not Gov.has(profile, permOf(name)) then
            BoFaisaL.notify(source, "err_no_permission", nil, "error")
            return nil
        end
        if not Officers.dutyOk(user_id, "field") then
            BoFaisaL.notify(source, "err_not_on_duty", nil, "error")
            return nil
        end
    end
    local now = GetGameTimer()
    if Field.last[user_id] and now - Field.last[user_id] < ((Config.Field and Config.Field.Cooldown) or 1500) then
        BoFaisaL.notify(source, "err_cooldown", nil, "error")
        return nil
    end
    Field.last[user_id] = now
    return user_id
end

-- Validates the target and runs the optional cuff requirement + confirmation.
local function prepareTarget(source, officerId, name, targetSrc, targetId, public)
    local ok, err = Targets.check(source, targetSrc, targetId)
    if not ok then BoFaisaL.notify(source, err, nil, "error") return false end
    if targetId == officerId and not Targets.allowSelf() then BoFaisaL.notify(source, "target_self", nil, "error") return false end
    local a = actionCfg(name)
    if a.requireCuffed and not I.Handcuff.isCuffed(targetSrc) then
        BoFaisaL.notify(source, "field_requires_cuffed", nil, "error")
        return false
    end
    if a.confirm then
        local responder = a.confirm == "self" and source or targetSrc
        BoFaisaL.notify(source, "confirm_waiting", { name = P.name(targetId) }, "info")
        -- The citizen only sees the request ("طلب هوية"), not who asks.
        local accepted, reason = Confirm.ask(responder, {
            title = a.confirm == "self" and L("field_" .. name)
                or ((Locale["confirm_target_" .. name] and L("confirm_target_" .. name)) or L("confirm_field_target", { action = L("field_" .. name) })),
            message = a.confirm == "self" and L("confirm_field_self", { action = L("field_" .. name), name = P.name(targetId), id = targetId }) or nil,
            icon = name,
        })
        if not accepted then BoFaisaL.notify(source, Confirm.failMessage(reason, a.confirm == "self"), nil, "error") return false end
        -- The officer may have been demoted or clocked out during the wait.
        if not public then
            if not Gov.has(Gov.getProfile(officerId, true), permOf(name)) then
                BoFaisaL.notify(source, "err_no_permission", nil, "error") return false
            end
            if not Officers.dutyOk(officerId, "field") then BoFaisaL.notify(source, "err_not_on_duty", nil, "error") return false end
        end
        ok, err = Targets.check(source, targetSrc, targetId, Targets.radius() + 2.0)
        if not ok then BoFaisaL.notify(source, err, nil, "error") return false end
    end
    return true
end

local function playOfficerAnim(source, dict, anim, duration)
    TriggerClientEvent("bofaisal_police:anim", source, dict, anim, duration or 1500)
end

---------------------------------------------------------------------------
-- Actions on a player
---------------------------------------------------------------------------
local handlers = {}

function handlers.cuff(source, officerId, targetSrc, targetId)
    -- A prisoner stays cuffed (Config.Jail.Handcuff.Enforce): the cuffs are not taken off at all.
    if BoFaisaL.Jail and BoFaisaL.Jail.keepsCuffs(targetId) and I.Handcuff.isCuffed(targetSrc) then
        return BoFaisaL.notify(source, "jail_keep_cuffed", nil, "error")
    end
    local cuffed = I.Handcuff.toggle(targetSrc)
    local c = actionCfg("cuff")
    local officerAnim = c.officerAnimation
    if officerAnim == nil then officerAnim = c.animation end -- older configs
    if officerAnim ~= false then playOfficerAnim(source, "mp_arresting", "a_uncuff", 2500) end
    BoFaisaL.notify(source, cuffed and "field_cuffed_officer" or "field_uncuffed_officer", { name = P.name(targetId) }, "success")
    BoFaisaL.notify(targetSrc, cuffed and "field_cuffed_target" or "field_uncuffed_target", nil, "info")
    Logs.add("field", cuffed and "cuff" or "uncuff", { actor = officerId, target = targetId })
end

function handlers.seizeWeapons(source, officerId, targetSrc, targetId)
    local weapons = I.Weapons.get(targetSrc)
    local names = {}
    for name, data in pairs(weapons) do names[#names + 1] = ("%s (%d)"):format(name, tonumber(data.ammo) or 0) end
    if #names == 0 then return BoFaisaL.notify(source, "field_no_weapons", nil, "info") end
    table.sort(names)
    I.Weapons.clear(targetSrc)
    if actionCfg("seizeWeapons").giveToOfficer then
        -- vRP keeps weapons client-side (the list comes from the target's game): only weapons of
        -- Config.Field.GiveWeapons are handed over, with a capped amount of ammo.
        local maxAmmo = actionCfg("seizeWeapons").maxAmmo or 250
        local allowed = {}
        for _, w in ipairs((Config.Field and Config.Field.GiveWeapons) or {}) do
            if type(w) == "string" then allowed[w:upper()] = true end
        end
        for name, data in pairs(weapons) do
            if allowed[name] and name:match("^WEAPON_[%w_]+$") and #name <= 48 then
                I.Inventory.give(officerId, "wbody|" .. name, 1)
                local ammo = math.min(math.max(0, math.floor(tonumber(data.ammo) or 0)), maxAmmo)
                if ammo > 0 then I.Inventory.give(officerId, "wammo|" .. name, ammo) end
            end
        end
    end
    BoFaisaL.notify(source, "field_weapons_seized_officer", { count = #names }, "success")
    BoFaisaL.notify(targetSrc, "field_weapons_seized_target", nil, "warning")
    Logs.add("field", "seize_weapons", { actor = officerId, target = targetId, fields = { { L("log_field_weapons"), table.concat(names, "\n") } } })
end

-- Field.dragging[targetSrc] = officer source currently dragging that player (toggle).
Field.dragging = Field.dragging or {}

function handlers.drag(source, officerId, targetSrc, targetId)
    I.Drag.toggle(source, targetSrc)
    if Field.dragging[targetSrc] == source then Field.dragging[targetSrc] = nil else Field.dragging[targetSrc] = source end
    Logs.add("field", "drag", { actor = officerId, target = targetId })
end

function handlers.search(source, officerId, targetSrc, targetId)
    local a = actionCfg("search")
    local items = I.Inventory.getItems(targetId, targetSrc)
    for _, it in ipairs(items) do it.contraband = isContraband(it.item) end
    local weapons = {}
    if a.showWeapons ~= false then
        for name, data in pairs(I.Weapons.get(targetSrc)) do weapons[#weapons + 1] = { name = name, ammo = tonumber(data.ammo) or 0 } end
        table.sort(weapons, function(x, y) return x.name < y.name end)
    end
    local money = a.showMoney ~= false and BoFaisaL.Framework.available and BoFaisaL.Framework.getMoney(targetId) or nil
    -- Shown as an info card (left side), like the other inquiries.
    local itemLines, weaponLines = {}, {}
    for _, it in ipairs(items) do
        itemLines[#itemLines + 1] = ("%s × %d"):format(it.label or it.item, tonumber(it.amount) or 0)
            .. (it.contraband and (" — " .. L("search_contraband_tag")) or "")
    end
    for _, w in ipairs(weapons) do
        weaponLines[#weaponLines + 1] = ("%s (%d)"):format((w.name:gsub("^WEAPON_", "")), w.ammo)
    end
    local rows = { { L("card_name"), P.name(targetId) }, { L("card_id"), targetId } }
    if money then rows[#rows + 1] = { L("card_money"), "$" .. Utils.money(money) } end
    local sections = { { title = L("card_items"), lines = itemLines, empty = L("card_none") } }
    if a.showWeapons ~= false then sections[#sections + 1] = { title = L("card_weapons"), lines = weaponLines, empty = L("card_none") } end
    BoFaisaL.infoCard(source, {
        title = L("field_search"), file = targetId, rows = rows, sections = sections,
        duration = (Config.UI and Config.UI.CitizenCardSeconds) or 20,
    })
    BoFaisaL.notify(targetSrc, "field_searched_target", nil, "info")
    Logs.add("field", "search", { actor = officerId, target = targetId, fields = { { L("log_field_items"), #items, true }, { L("log_field_weapons"), #weapons, true } } })
end

function handlers.putInVehicle(source, officerId, targetSrc, targetId)
    if actionCfg("putInVehicle").requireDrag ~= false and Field.dragging[targetSrc] ~= source then
        return BoFaisaL.notify(source, "field_requires_drag", nil, "error")
    end
    -- The drag ends when the player is seated.
    if Field.dragging[targetSrc] == source then
        I.Drag.toggle(source, targetSrc)
        Field.dragging[targetSrc] = nil
    end
    I.Seats.putIn(targetSrc, source, actionCfg("putInVehicle").radius or 6.0)
    Logs.add("field", "put_in_vehicle", { actor = officerId, target = targetId })
end

function handlers.pullOutVehicle(source, officerId, targetSrc, targetId)
    I.Seats.pullOut(targetSrc, source)
    Logs.add("field", "pull_out_vehicle", { actor = officerId, target = targetId })
end

function handlers.seizeContraband(source, officerId, targetSrc, targetId)
    local seized = {}
    for _, c in ipairs(contrabandList()) do
        local amount = I.Inventory.getAmount(targetId, c.item)
        if amount > 0 and I.Inventory.remove(targetId, c.item, amount) then
            seized[#seized + 1] = { item = c.item, label = c.label or I.Inventory.label(c.item), amount = amount }
            if actionCfg("seizeContraband").giveToOfficer then I.Inventory.give(officerId, c.item, amount) end
        end
    end
    if #seized == 0 then return BoFaisaL.notify(source, "field_no_contraband", nil, "info") end
    local lines = {}
    for _, s in ipairs(seized) do lines[#lines + 1] = ("%s (%s) × %d"):format(s.label, s.item, s.amount) end
    BoFaisaL.notify(source, "field_contraband_seized_officer", { count = #seized }, "success")
    BoFaisaL.notify(targetSrc, "field_contraband_seized_target", nil, "warning")
    Logs.add("field", "seize_contraband", { actor = officerId, target = targetId, fields = { { L("log_field_items"), table.concat(lines, "\n") } } })
end

function handlers.identity(source, officerId, targetSrc, targetId)
    -- The national ID card: no military rank on it (that is the badge, إظهار الهوية العسكرية).
    TriggerClientEvent("bofaisal_police:idcard:present", targetSrc)
    BoFaisaL.ui(source, "idcard", {
        name = P.name(targetId),
        user_id = targetId,
        mugshotAt = BoFaisaL.Mugshots.stamp(targetId), -- character photo (not the Discord picture)
        job = I.Job.get(targetId, true),
        title = Config.IdCard and Config.IdCard.Title,
        country = Config.IdCard and Config.IdCard.Country,
        duration = Config.IdCard and Config.IdCard.Duration or 10,
    })
    Logs.add("field", "identity", { actor = officerId, target = targetId })
end

-- public = true: only for "identity" from the ID request command (every player may use it).
function Field.run(source, name, targetSrc, targetId, public)
    public = public == true and name == "identity"
    local officerId = allowed(source, name, public)
    if not officerId then return end
    -- الموانع (Config.Immunity): an immune player can't be cuffed or dragged. Taking the cuffs off
    -- or letting go stays possible.
    local immunity = ({ cuff = "Cuff", drag = "Drag" })[name]
    if immunity and BoFaisaL.Immunity.has(targetId, immunity) then
        local releasing = (name == "cuff" and I.Handcuff.isCuffed(targetSrc)) or (name == "drag" and Field.dragging[targetSrc] == source)
        if not releasing then return BoFaisaL.notify(source, "immune_" .. name, nil, "error") end
    end
    if not prepareTarget(source, officerId, name, targetSrc, targetId, public) then return end
    local handler = handlers[name]
    if handler then handler(source, officerId, targetSrc, targetId) end
end

---------------------------------------------------------------------------
-- Vehicle search (تفتيش مركبة)
---------------------------------------------------------------------------
-- Nearest vehicle to the officer: { entity, netId, plate, model(hash) } using server-side entities.
function Field.nearestVehicle(source, radius)
    local origin = P.coords(source)
    if not origin then return nil end
    if P.oneSync() and GetAllVehicles then
        local best, bestDist
        for _, veh in ipairs(GetAllVehicles()) do
            if DoesEntityExist(veh) then
                local d = Utils.dist(origin, GetEntityCoords(veh))
                if d <= radius and (not bestDist or d < bestDist) then best, bestDist = veh, d end
            end
        end
        if not best then return nil end
        return {
            entity = best,
            netId = NetworkGetNetworkIdFromEntity(best),
            plate = Utils.normalizePlate(GetVehicleNumberPlateText(best) or ""),
            model = GetEntityModel(best),
            dist = bestDist,
        }
    end
    local v = BoFaisaL.clientRequest(source, "nearestVehicle", { radius = radius }, 4000)
    if type(v) ~= "table" or not v.plate then return nil end
    return { entity = nil, netId = tonumber(v.netId), plate = Utils.normalizePlate(v.plate), model = tonumber(v.model), dist = tonumber(v.dist) or radius }
end

function Field.vehicleSearch(source)
    local officerId = allowed(source, "vehicleSearch")
    if not officerId then return end
    local radius = actionCfg("vehicleSearch").radius or 5.0
    local veh = Field.nearestVehicle(source, radius)
    if not veh or veh.plate == "" then return BoFaisaL.notify(source, "field_no_vehicle", nil, "error") end
    local owner = I.Garage.findByPlate(veh.plate)
    if not owner then return BoFaisaL.notify(source, "field_vehicle_unowned", { plate = veh.plate }, "error") end
    local model = owner.model or I.Garage.modelFromHash(owner.owner, veh.model)
    local vehicle = { plate = veh.plate, owner = owner.owner, model = model }
    if not I.VehicleInventory.supported(vehicle) then return BoFaisaL.notify(source, "field_vehicle_inventory_unavailable", nil, "error") end
    local items = I.VehicleInventory.getItems(vehicle)
    local hasContraband = false
    for _, it in ipairs(items) do
        it.contraband = isContraband(it.item)
        if it.contraband then hasContraband = true end
    end
    local token = ("%d-%d"):format(officerId, GetGameTimer())
    Field.vehicleSessions[officerId] = { token = token, vehicle = vehicle, netId = veh.netId, expires = GetGameTimer() + 120000 }
    BoFaisaL.ui(source, "panel", {
        kind = "vehicle", title = L("field_vehicleSearch"),
        data = {
            plate = veh.plate, model = model or "", owner = { id = owner.owner, name = P.name(owner.owner) },
            items = items, token = token,
            canSeize = hasContraband and actionCfg("vehicleSearch").allowSeizeContraband ~= false,
        },
    })
    Logs.add("field", "vehicle_search", { actor = officerId, target = owner.owner, targetLabel = L("log_field_owner"),
        fields = { { L("field_plate"), veh.plate, true }, { L("field_model"), model or "-", true }, { L("log_field_items"), #items, true } } })
end

RPC.register("field:vehicleSeize", { feature = "Field", perm = Gov.FIELD_PERMS.vehicleSearch, duty = "field", cooldown = 2000 }, function(ctx, data)
    local session = Field.vehicleSessions[ctx.user_id]
    Field.vehicleSessions[ctx.user_id] = nil
    if not session or session.token ~= data.token or GetGameTimer() > session.expires then return nil, L("err_confirm_expired") end
    if actionCfg("vehicleSearch").allowSeizeContraband == false then return nil, L("err_feature_disabled") end
    if not Gov.has(ctx.profile, permOf("vehicleSearch"))
        or not Gov.has(ctx.profile, permOf("seizeContraband")) then
        return nil, L("err_no_permission")
    end
    -- The officer must still be next to the same vehicle.
    local veh = Field.nearestVehicle(ctx.source, (actionCfg("vehicleSearch").radius or 5.0) + 2.0)
    if not veh or veh.plate ~= session.vehicle.plate then return nil, L("field_no_vehicle") end
    local seized = {}
    for _, it in ipairs(I.VehicleInventory.getItems(session.vehicle)) do
        if isContraband(it.item) and I.VehicleInventory.remove(session.vehicle, it.item, it.amount) then
            seized[#seized + 1] = ("%s (%s) × %d"):format(it.label, it.item, it.amount)
            if actionCfg("seizeContraband").giveToOfficer then I.Inventory.give(ctx.user_id, it.item, it.amount) end
        end
    end
    if #seized == 0 then return nil, L("field_no_contraband") end
    Logs.add("field", "seize_vehicle_contraband", {
        actor = ctx.user_id, target = session.vehicle.owner, targetLabel = L("log_field_owner"),
        fields = { { L("field_plate"), session.vehicle.plate, true }, { L("log_field_items"), table.concat(seized, "\n") } },
    })
    return { seized = #seized, items = I.VehicleInventory.getItems(session.vehicle) }
end)

---------------------------------------------------------------------------
-- Menu
---------------------------------------------------------------------------
-- Same as pressing the action in "خيارات الميدان" (used by the chat commands): the closest
-- player, or the vehicle for "تفتيش مركبة".
function Field.command(source, name, public)
    if name == "vehicleSearch" then return Field.vehicleSearch(source) end
    public = public == true and name == "identity"
    if not allowed(source, name, public) then return end
    Field.last[P.getUserId(source)] = nil -- the real action is rate limited after the target is found
    Targets.nearest(source, function(targetSrc, targetId)
        Field.run(source, name, targetSrc, targetId, public)
    end)
end

function Field.menu(source, parent)
    local items = {}
    local profile = Gov.getProfile(P.getUserId(source), true)
    for _, name in ipairs(ORDER) do
        local a = actionCfg(name)
        -- Only the actions this rank may use.
        if a.enabled ~= false and Gov.has(profile, permOf(name)) then
            items[#items + 1] = {
                label = L("field_" .. name),
                description = L("field_desc_" .. name),
                action = function(src)
                    if name == "vehicleSearch" then return Field.vehicleSearch(src) end
                    if not allowed(src, name) then return end
                    Field.last[P.getUserId(src)] = nil -- the real action is rate limited after the target is found
                    Targets.nearest(src, function(targetSrc, targetId)
                        Field.run(src, name, targetSrc, targetId)
                    end)
                end,
            }
        end
    end
    return { title = L("menu_field"), items = items, parent = parent }
end

BoFaisaL.on("playerDropped", function(user_id, source)
    Field.vehicleSessions[user_id] = nil
    Field.last[user_id] = nil
    if source then
        for target, officer in pairs(Field.dragging) do
            if target == source or officer == source then Field.dragging[target] = nil end
        end
    end
end)
