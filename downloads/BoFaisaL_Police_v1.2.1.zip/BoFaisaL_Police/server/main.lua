--[[
    BoFaisaL_Police — start-up sequence, player lifecycle and exports.
]]

local P, Gov, DB, F = BoFaisaL.Players, BoFaisaL.Gov, BoFaisaL.DB, BoFaisaL.Framework

local dropped = {}

local function ready(user_id, source, restored)
    user_id, source = tonumber(user_id), tonumber(source)
    if not user_id or not source or not GetPlayerName(source) then return end
    dropped[source] = nil
    P.attach(user_id, source)
    P.remember(user_id, source)
    BoFaisaL.debug("groups", "player ready %d (source %d)%s", user_id, source, restored and " [restored]" or "")
    BoFaisaL.emit("playerReady", user_id, source, restored == true)
end

local function drop(user_id, source)
    user_id, source = tonumber(user_id), tonumber(source)
    if source then
        if dropped[source] then return end
        dropped[source] = true
        SetTimeout(10000, function() dropped[source] = nil end)
    end
    if user_id then BoFaisaL.emit("playerDropped", user_id, source) end
    -- Per-connection state exists even for players that never finished loading.
    if source then
        BoFaisaL.Confirm.cancelFor(source)
        BoFaisaL.Integrations.Popup.cancelFor(source)
        BoFaisaL.Spectate.onDropped(source)
        BoFaisaL.Menu.forget(source)
        BoFaisaL.RPC.forget(source)
    end
    if user_id then
        Gov.forget(user_id)
        P.detach(user_id, source)
    end
end

---------------------------------------------------------------------------
-- vRP lifecycle
---------------------------------------------------------------------------
AddEventHandler("vRP:playerJoin", function(user_id, source)
    if tonumber(user_id) and tonumber(source) then P.attach(user_id, source) end
end)

AddEventHandler("vRP:playerSpawn", function(user_id, source, first_spawn)
    if not BoFaisaL.ready then return end
    if first_spawn then
        ready(user_id, source, false)
    else
        BoFaisaL.emit("playerRespawn", tonumber(user_id), tonumber(source))
    end
end)

AddEventHandler("vRP:playerLeave", function(user_id, source)
    drop(user_id, source)
end)

AddEventHandler("playerDropped", function()
    local src = source
    drop(P.bySource[src], src)
end)

-- Group changes made anywhere (vRP admin menu, other scripts) refresh the profile.
local pendingRefresh = {}
local function refreshLater(user_id)
    user_id = tonumber(user_id)
    if not user_id or pendingRefresh[user_id] then return end
    pendingRefresh[user_id] = true
    SetTimeout(300, function()
        pendingRefresh[user_id] = nil
        if P.isOnline(user_id) then
            BoFaisaL.thread(function() Gov.getProfile(user_id, true) end)
        end
    end)
end
AddEventHandler("vRP:playerJoinGroup", function(user_id) refreshLater(user_id) end)
AddEventHandler("vRP:playerLeaveGroup", function(user_id) refreshLater(user_id) end)

-- Periodic safety net for group changes that raise no event (Config.Framework.GroupRefreshSeconds).
-- Spread over the interval (one player at a time) so a full server never reads every player's
-- groups in the same tick.
Citizen.CreateThread(function()
    while true do
        local started = GetGameTimer()
        local every = math.max(10, tonumber(Config.Framework and Config.Framework.GroupRefreshSeconds) or 60) * 1000
        if BoFaisaL.ready then
            local list = {}
            for uid in pairs(P.byUser) do list[#list + 1] = uid end
            local gap = math.min(1000, math.floor(every * 0.85 / math.max(1, #list)))
            for _, uid in ipairs(list) do
                if P.byUser[uid] then Gov.getProfile(uid, true) end
                Citizen.Wait(gap)
            end
        end
        Citizen.Wait(math.max(1000, every - (GetGameTimer() - started)))
    end
end)

-- Old logs are removed (Config.Database.LogsKeepDays) at start and every 6 hours.
Citizen.CreateThread(function()
    while not BoFaisaL.ready do Citizen.Wait(1000) end
    while true do
        local days = tonumber(Config.Database and Config.Database.LogsKeepDays) or 0
        if days > 0 and DB.ready then
            DB.execute("DELETE FROM bofaisal_police_logs WHERE created_at < ?", { BoFaisaL.now() - days * 86400 })
        end
        Citizen.Wait(6 * 3600 * 1000)
    end
end)

---------------------------------------------------------------------------
-- Client session (client resource restarts ask for their state again)
---------------------------------------------------------------------------
BoFaisaL.RPC.register("session:init", {}, function(ctx)
    BoFaisaL.Officers.pushState(ctx.user_id)
    local jail = BoFaisaL.Jail.active[ctx.user_id]
    if jail and not jail.pendingRelease then
        TriggerClientEvent("bofaisal_police:jail:start", ctx.source, BoFaisaL.Jail.clientState(jail))
    end
    local alerts = {}
    for _, a in pairs(BoFaisaL.Alert.active) do alerts[#alerts + 1] = BoFaisaL.Alert.public(a) end
    if #alerts > 0 then TriggerClientEvent("bofaisal_police:alert:sync", ctx.source, alerts) end
    return { user_id = ctx.user_id }
end)

---------------------------------------------------------------------------
-- Start-up
---------------------------------------------------------------------------
-- ─── STARTUP BANNER ──────────────────────────────────────
print([[

^6    ███████╗██╗   ██╗ ██████╗ ██████╗  █████╗
^6    ██╔════╝██║   ██║██╔═══██╗██╔══██╗██╔══██╗
^6    █████╗  ██║   ██║██║   ██║██████╔╝███████║
^6    ██╔══╝  ╚██╗ ██╔╝██║   ██║██╔══██╗██╔══██║
^6    ███████╗ ╚████╔╝ ╚██████╔╝██║  ██║██║  ██║
^6    ╚══════╝  ╚═══╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝^7     — Made by LR
^2              Thanks for the purchase^7
]])

Citizen.CreateThread(function()
    if BoFaisaL.blocked then
        BoFaisaL.error("The resource folder must be named ^3%s^7 (current name: ^3%s^7).", BoFaisaL.requiredName, BoFaisaL.resource)
        BoFaisaL.error("Rename it back to ^3%s^7 and restart. The script will not run.", BoFaisaL.requiredName)
        Citizen.Wait(500)
        StopResource(BoFaisaL.resource)
        return
    end
    math.randomseed(os.time())
    BoFaisaL.print("BoFaisaL_Police v%s", BoFaisaL.version)
    F.init()
    DB.init()
    Gov.build()
    Gov.validateGroups()
    BoFaisaL.Integrations.checkAll()
    if DB.ready then
        BoFaisaL.Vacation.load()
        BoFaisaL.Jail.load()
        BoFaisaL.Impound.load()
        BoFaisaL.Panel.load()
        BoFaisaL.Roster.load()
        BoFaisaL.Mugshots.load()
    end
    if F.available then
        for uid, src in pairs(F.getUsers()) do
            if GetPlayerName(src) then P.attach(uid, src) end
        end
    end
    if DB.ready then BoFaisaL.Officers.recoverSessions() end
    BoFaisaL.PoliceMenu.register()
    BoFaisaL.ready = true
    for uid, src in pairs(P.byUser) do
        BoFaisaL.thread(ready, uid, src, true)
    end
    BoFaisaL.print("ready — %d ministries, %d sectors, %d ranks, %d players attached.",
        #Gov.ministryList, #Gov.sectorList, #Gov.rankList, Utils.count(P.byUser))
end)

---------------------------------------------------------------------------
-- Exports
---------------------------------------------------------------------------
exports("IsOnDuty", function(user_id) return BoFaisaL.Officers.isOnDuty(user_id) end)
exports("IsJailed", function(user_id) return BoFaisaL.Jail.isJailed(user_id) end)
exports("IsOnVacation", function(user_id) return BoFaisaL.Vacation.isOnVacation(user_id) end)
exports("GetOfficerProfile", function(user_id)
    local summary = Gov.summary(Gov.cached(user_id))
    summary.onDuty = BoFaisaL.Officers.isOnDuty(user_id)
    return summary
end)
exports("HasPermission", function(user_id, perm) return Gov.has(Gov.cached(user_id), perm) end)
