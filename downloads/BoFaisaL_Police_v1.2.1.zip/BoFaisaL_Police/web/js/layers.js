/* BoFaisaL_Police — overlay layers (everything except the iPad). */
(function () {
  const E = window.BoFaisaL;
  const h = E.h;
  const $ = (id) => document.getElementById(id);
  const show = (el) => { el.classList.remove('hidden'); };
  const hide = (el) => { el.classList.add('hidden'); };

  /* =============================================================== Broadcasts */
  function hexToRgb(hex) {
    const m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(String(hex || '').trim());
    return m ? parseInt(m[1], 16) + ',' + parseInt(m[2], 16) + ',' + parseInt(m[3], 16) : '139,92,246';
  }
  const bcQueue = [];
  let bcBusy = false;
  function nextBroadcast() {
    const d = bcQueue.shift();
    if (!d) { bcBusy = false; return; }
    bcBusy = true;
    const style = d.style || {};
    const accent = d.kind === 'citizens' ? style.citizenAccent || '#3b82f6' : d.kind === 'alert' ? '#ef4444' : (E.theme && E.theme.accent) || style.officerAccent || '#2563eb';
    const duration = Math.max(3, d.duration || 12);
    const rgb = hexToRgb(accent);
    const card = h('div', { class: 'broadcast anim-' + (style.animation || 'slide'), style: { top: style.top || '26%', width: style.width || '560px' } },
      h('div', { class: 'bc-glow' }),
      h('div', { class: 'bc-head' }, h('div', { class: 'bc-title' }, d.title || '')),
      h('div', { class: 'bc-body' }, d.message || ''),
      d.sender ? h('div', { class: 'bc-foot' }, d.sender) : null,
      h('div', { class: 'bc-progress' }, h('i', { style: { animationDuration: duration + 's' } })));
    // Position saved in إدارة اللوحة.
    const bcPos = E.theme && E.theme.positions && E.theme.positions.broadcasts;
    if (bcPos) E.placeAt(card, bcPos, 'broadcasts');
    card.style.setProperty('--bc', accent);
    card.style.setProperty('--bc-line', 'rgba(' + rgb + ',.45)');
    card.style.setProperty('--bc-glow', 'rgba(' + rgb + ',.22)');
    $('broadcasts').appendChild(card);
    requestAnimationFrame(() => card.classList.add('in'));
    setTimeout(() => {
      card.classList.remove('in');
      card.classList.add('out');
      setTimeout(() => { card.remove(); nextBroadcast(); }, 450);
    }, duration * 1000);
  }
  E.on('broadcast', (d) => { bcQueue.push(d); if (!bcBusy) nextBroadcast(); });

  /* =================================================================== Toasts */
  // Right side. Two looks, chosen in إدارة اللوحة (الواجهة):
  //   "gradient" = the colour of the kind fades into the card, icon + title + message, time bar (default)
  //   "ring"     = the time runs out as a ring around the icon, title + message
  //   "classic"  = the dark card with a coloured edge
  const TOAST_ICONS = { success: 'check', error: 'x', warning: 'alert', info: 'info' };
  const TOAST_STYLES = ['gradient', 'ring', 'classic'];
  function toastStyle() {
    const s = (E.appliedTheme && E.appliedTheme.toast) || E.cfg.toast || 'gradient';
    return TOAST_STYLES.indexOf(s) >= 0 ? s : 'gradient';
  }
  function toastEl(d, style) {
    const kind = TOAST_ICONS[d.kind] ? d.kind : 'info';
    const seconds = Math.max(2, d.duration || 5);
    const bar = h('i', { class: 'toast-bar', style: { animationDuration: seconds + 's' } });
    const look = style || toastStyle();
    if (look === 'classic') {
      return h('div', { class: 'toast kind-' + kind }, h('div', { class: 'toast-msg' }, d.message || ''), bar);
    }
    const title = d.title || E.t('toast_' + kind, null, { success: 'نجاح', error: 'خطأ', warning: 'تنبيه', info: 'معلومة' }[kind]);
    const glyph = kind === 'info' ? h('b', { class: 'tg-letter' }, 'i') : E.icon(TOAST_ICONS[kind], 14, 2.6);
    if (look === 'ring') {
      // The ring (svg, constant markup) empties over the notification's lifetime.
      return h('div', { class: 'toast tr kind-' + kind },
        h('span', { class: 'tr-ring' },
          h('span', { class: 'tr-svg', html: '<svg viewBox="0 0 36 36"><circle class="tr-track" cx="18" cy="18" r="15"/><circle class="tr-prog" cx="18" cy="18" r="15" style="animation-duration:' + Number(seconds) + 's"/></svg>' }),
          h('span', { class: 'tr-glyph' }, glyph)),
        h('div', { class: 'tg-body' }, h('div', { class: 'tg-title' }, title), h('div', { class: 'toast-msg' }, d.message || '')));
    }
    // The info icon already has its own circle: a plain "i" inside ours instead.
    return h('div', { class: 'toast tg kind-' + kind },
      h('span', { class: 'tg-ico' }, glyph),
      h('div', { class: 'tg-body' }, h('div', { class: 'tg-title' }, title), h('div', { class: 'toast-msg' }, d.message || '')),
      bar);
  }
  E.toastEl = toastEl;
  E.on('toast', (d) => {
    const seconds = Math.max(2, d.duration || 5);
    const t = toastEl(Object.assign({}, d, { duration: seconds }));
    $('toasts').appendChild(t);
    requestAnimationFrame(() => t.classList.add('in'));
    setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 350); }, seconds * 1000);
    while ($('toasts').children.length > 5) $('toasts').firstChild.remove();
  });

  /* =============================================================== Info cards */
  // Inquiry results on the left. Two looks, chosen in إدارة اللوحة (الواجهة):
  //   "file"    = a police file (paper, stamp, two columns, aligned records) — the default
  //   "classic" = the dark card with "label: value" rows
  // card = { title, fileTitle, file (number on the file), stamp = { text, tone = "ok" | "bad" },
  //          rows = { { label, value, tone } }, lines = { "..." },
  //          sections = { { title, lines = { "..." } | records = { { a, b, c } }, empty } } }
  const INFO_STYLES = ['file', 'classic'];
  function infoStyle() {
    const s = (E.appliedTheme && E.appliedTheme.infoCard) || E.cfg.infoCard || 'file';
    return INFO_STYLES.indexOf(s) >= 0 ? s : 'file';
  }
  const shown = (v) => E.digits(v === undefined || v === null || v === '' ? '—' : v);

  // Long sections (the weapons of a search...) show a page at a time: ‹ 1/3 ›, turned with the
  // page keys (Config.UI.CardPageKeys) or by clicking the arrows.
  function pageSize() { return Math.max(3, Number(E.cfg.cardPage && E.cfg.cardPage.size) || 8); }
  function paged(list, render) {
    const size = pageSize();
    if (list.length <= size) return render(list);
    const pages = Math.ceil(list.length / size);
    const box = h('div', { class: 'ic-pages' });
    const keys = (E.cfg.cardPage && E.cfg.cardPage.keys) || {};
    const label = h('span', { class: 'mono' });
    let page = 0;
    const draw = () => {
      E.clear(box).append(...[].concat(render(list.slice(page * size, page * size + size))));
      label.textContent = E.digits((page + 1) + '/' + pages);
    };
    const turn = (dir) => { page = (page + dir + pages) % pages; draw(); };
    const pager = h('div', { class: 'ic-pager' },
      h('button', { class: 'ic-arrow', onclick: () => turn(-1) }, keys.prevLabel ? h('kbd', null, keys.prevLabel) : '‹'),
      label,
      h('button', { class: 'ic-arrow', onclick: () => turn(1) }, keys.nextLabel ? h('kbd', null, keys.nextLabel) : '›'));
    const wrap = h('div', { class: 'ic-paged' }, box, pager);
    wrap.turnPage = turn;
    draw();
    return wrap;
  }
  // Section entries as text (classic look): records are joined with " — ".
  const entryText = (e) => (Array.isArray(e) ? e.filter((x) => x !== undefined && x !== null && x !== '').join(' — ') : e);

  function classicCard(d) {
    const lines = (list) => list.map((l) => h('div', { class: 'ic-line' }, E.digits(entryText(l))));
    return h('div', { class: 'infocard' },
      d.title ? h('div', { class: 'ic-title' }, d.title) : null,
      (d.rows || []).map((r) => h('div', { class: 'ic-row' }, h('span', null, r[0] + ':'), h('b', null, shown(r[1])))),
      (d.lines && d.lines.length) ? h('div', { class: 'ic-lines' }, lines(d.lines)) : null,
      (d.sections || []).map((s) => {
        const list = s.records || s.lines || [];
        return h('div', { class: 'ic-lines' }, h('div', { class: 'ic-sub' }, s.title),
          list.length ? paged(list, lines) : h('div', { class: 'ic-none' }, s.empty || '—'));
      }));
  }

  function fileCard(d) {
    const tone = (t) => (t === 'ok' || t === 'bad' ? ' ' + t : '');
    const entries = (list) => list.map((e) => (Array.isArray(e)
      ? h('div', { class: 'if-rec' }, h('span', null, shown(e[0])), h('span', null, e[1] !== undefined ? shown(e[1]) : ''), h('span', { class: 'if-date' }, e[2] !== undefined ? E.digits(e[2]) : ''))
      : h('div', { class: 'if-line' }, E.digits(e))));
    const section = (title, list, empty) => [
      title ? h('div', { class: 'if-sec' }, title) : null,
      list.length ? paged(list, entries) : h('div', { class: 'if-none' }, empty || '—'),
    ];
    const no = d.file !== undefined && d.file !== null ? 'NO. ' + String(d.file).padStart(6, '0') : null;
    return h('div', { class: 'infocard if-file' },
      h('i', { class: 'if-tape' }),
      h('div', { class: 'if-head' },
        h('div', null, h('div', { class: 'if-title' }, d.fileTitle || d.title || ''), no ? h('div', { class: 'if-no' }, no) : null),
        d.stamp ? h('div', { class: 'if-stamp' + tone(d.stamp.tone) }, d.stamp.text) : null),
      (d.rows && d.rows.length) ? h('div', { class: 'if-grid' }, d.rows.map((r) =>
        h('div', null, h('div', { class: 'if-k' }, r[0]), h('div', { class: 'if-v' + tone(r[2]) }, shown(r[1]))))) : null,
      (d.lines && d.lines.length) ? section(null, d.lines) : null,
      (d.sections || []).map((s) => section(s.title, s.records || s.lines || [], s.empty)));
  }

  // Fine receipt (وصل مخالفة): a small paper slip with a torn bottom edge, whatever the look.
  function receiptCard(d) {
    const tone = d.stamp && (d.stamp.tone === 'ok' || d.stamp.tone === 'bad') ? ' ' + d.stamp.tone : '';
    return h('div', { class: 'infocard rc-card' },
      h('div', { class: 'rc-head' }, h('div', { class: 'rc-title' }, d.title || ''),
        d.file !== undefined ? h('div', { class: 'rc-no' }, 'NO. ' + String(d.file).padStart(6, '0')) : null),
      h('div', { class: 'rc-rows' }, (d.rows || []).map((r) => h('div', { class: 'rc-row' }, h('span', null, r[0]), h('b', null, shown(r[1]))))),
      h('div', { class: 'rc-total' }, h('span', null, E.t('receipt_amount')), h('b', null, d.amount || '')),
      d.stamp ? h('div', { class: 'rc-stamp' + tone }, d.stamp.text) : null,
      d.note ? h('div', { class: 'rc-note' }, d.note) : null);
  }

  function infoCardEl(d, style) {
    const card = d.receipt ? receiptCard(d) : (style || infoStyle()) === 'classic' ? classicCard(d) : fileCard(d);
    if (d.duration) {
      card.dataset.seconds = d.duration;
      card.appendChild(h('i', { class: 'ic-bar', style: { animationDuration: d.duration + 's' } }));
    }
    return card;
  }
  E.infoCardEl = infoCardEl;

  // A card leaves after its time; turning a page gives it a few more seconds to read.
  function expireCard(card, seconds) {
    clearTimeout(card.expireTimer);
    card.expireTimer = setTimeout(() => { card.classList.remove('in'); setTimeout(() => card.remove(), 350); }, seconds * 1000);
    const bar = card.querySelector('.ic-bar');
    if (bar) { bar.style.animation = 'none'; void bar.offsetWidth; bar.style.animation = ''; bar.style.animationDuration = seconds + 's'; }
  }
  E.on('infocard', (d) => {
    const seconds = Math.max(3, d.duration || 12);
    const card = infoCardEl(Object.assign({}, d, { duration: seconds }));
    $('infocards').appendChild(card);
    requestAnimationFrame(() => card.classList.add('in'));
    expireCard(card, seconds);
    while ($('infocards').children.length > 3) $('infocards').firstChild.remove();
  });
  // Page keys: the newest card with pages turns them.
  E.on('cards:page', (d) => {
    const cards = Array.from($('infocards').children).reverse();
    for (const card of cards) {
      const lists = card.querySelectorAll('.ic-paged');
      if (!lists.length) continue;
      lists.forEach((l) => l.turnPage(d.dir < 0 ? -1 : 1));
      expireCard(card, Math.max(8, Number(card.dataset.seconds) || 8));
      return;
    }
  });

  /* ============================================================ Confirmation */
  let confirmId = null;
  let confirmTimer = null;
  function answer(accepted) {
    if (!confirmId) return;
    const id = confirmId;
    confirmId = null;
    hide($('confirm'));
    E.post('confirmAnswer', { id, accepted });
  }
  // Two looks, chosen in إدارة اللوحة (الواجهة): "compact" (small and centred: request, details
  // in one line, F5 / F6, a thin time line — the default) and "classic" (the big card with a ring).
  function confirmStyle() {
    const s = (E.appliedTheme && E.appliedTheme.confirm) || E.cfg.confirmStyle || 'compact';
    return s === 'classic' ? 'classic' : 'compact';
  }
  // { el, tick(left, total) }
  function confirmEl(d, style) {
    const total = Math.max(1, d.timeout || 30);
    const accept = h('button', { class: 'btn btn-accept', onclick: () => answer(true) }, h('kbd', null, d.accept || 'F5'), E.t('confirm_hint_accept'));
    const reject = h('button', { class: 'btn btn-reject', onclick: () => answer(false) }, h('kbd', null, d.reject || 'F6'), E.t('confirm_hint_reject'));
    const details = (d.details && d.details.length) ? d.details : null;
    if ((style || confirmStyle()) === 'classic') {
      const ring = h('div', { class: 'cf-ring', style: { '--p': 1 } }, h('span', { class: 'cf-ring-num' }, E.digits(total)));
      return {
        el: h('div', { class: 'confirm-card' },
          h('div', { class: 'cf-head' }, h('div', { class: 'cf-title' }, d.title || ''), ring),
          d.message ? h('div', { class: 'cf-msg' }, d.message) : null,
          details ? h('div', { class: 'cf-details' }, details.map((r) => h('div', { class: 'cf-row' }, h('span', null, r[0]), h('b', null, r[1])))) : null,
          h('div', { class: 'cf-actions' }, accept, reject)),
        tick: (left) => { ring.style.setProperty('--p', left / total); ring.firstChild.textContent = E.digits(Math.ceil(left)); },
      };
    }
    accept.className = 'cfc-key ok';
    reject.className = 'cfc-key no';
    const bar = h('i', { class: 'cfc-bar' });
    return {
      el: h('div', { class: 'confirm-card cf-compact' },
        h('div', { class: 'cfc-title' }, d.title || ''),
        d.message ? h('div', { class: 'cfc-msg' }, d.message) : null,
        // Each value keeps its own direction (bdi): "$5,000" stays "$5,000".
        details ? h('div', { class: 'cfc-details' }, details.map((r, i) => [i ? h('span', { class: 'cfc-sep' }, '•') : null, r[0] + ': ', h('bdi', null, r[1])])) : null,
        h('div', { class: 'cfc-keys' }, accept, reject),
        bar),
      tick: (left) => { bar.style.transform = 'scaleX(' + Math.max(0, left / total).toFixed(3) + ')'; },
    };
  }
  E.confirmEl = confirmEl;

  E.on('confirm:show', (d) => {
    confirmId = d.id;
    const root = E.clear($('confirm'));
    const total = Math.max(1, d.timeout || 30);
    const view = confirmEl(d);
    root.appendChild(view.el);
    show(root);
    clearInterval(confirmTimer);
    const started = Date.now();
    confirmTimer = setInterval(() => {
      const left = Math.max(0, total - (Date.now() - started) / 1000);
      view.tick(left, total);
      if (left <= 0) clearInterval(confirmTimer);
    }, 200);
  });
  E.on('confirm:hide', () => { confirmId = null; clearInterval(confirmTimer); hide($('confirm')); });
  E.on('key', (ev) => {
    if (!confirmId) return;
    if (ev.key === 'F5') { ev.preventDefault(); answer(true); }
    else if (ev.key === 'F6') { ev.preventDefault(); answer(false); }
  });
  window.addEventListener('keydown', (ev) => { if (ev.key === 'F5' || ev.key === 'F6') ev.preventDefault(); }, true);

  /* ==================================================================== Hints */
  // Four looks (kh-<look>), chosen in إدارة اللوحة → الواجهة: "glass" (default), "pill", "bar",
  // "keycap". look = one look for a preview (the layout editor).
  const HINT_LOOKS = ['glass', 'pill', 'bar', 'keycap'];
  E.keyHintLook = () => {
    const s = (E.appliedTheme && E.appliedTheme.keyHint) || E.cfg.keyHint;
    return HINT_LOOKS.indexOf(s) >= 0 ? s : 'glass';
  };
  E.keyHintEl = (key, text, look) => h('div', { class: 'hint-pill kh-' + (look || E.keyHintLook()) },
    h('kbd', null, key || 'E'), h('span', null, text || ''));
  // The look was changed: the hints on screen change too.
  E.on('theme:applied', () => {
    document.querySelectorAll('#hint .hint-pill, #spectate .hint-pill').forEach((el) => {
      el.className = el.className.replace(/\bkh-\w+/g, '').trim() + ' kh-' + E.keyHintLook();
    });
  });
  E.on('hint', (d) => {
    const root = E.clear($('hint'));
    root.appendChild(E.keyHintEl(d.key, d.text));
    show(root);
  });
  E.on('hint:hide', () => hide($('hint')));

  // Floating above a marker: x / y are screen fractions (0 - 1) sent by the client.
  let worldHintId = null;
  E.on('worldhint', (d) => {
    const root = $('worldhint');
    const id = (d.key || 'E') + (d.text || '');
    if (worldHintId !== id) {
      worldHintId = id;
      E.clear(root).appendChild(h('div', { class: 'hint-pill' }, h('kbd', null, d.key || 'E'), h('span', null, d.text || '')));
    }
    root.style.left = (d.x * 100).toFixed(2) + '%';
    root.style.top = (d.y * 100).toFixed(2) + '%';
    show(root);
  });
  E.on('worldhint:hide', () => { worldHintId = null; hide($('worldhint')); });

  /* ================================================================= Jail HUD */
  // Four looks, chosen in إدارة اللوحة (الواجهة): "digital" (each digit in its own cell, the
  // default), "split" (time block + jail / reason), "minimal" (the time and a line, no box) and
  // "strip" (the older wide strip).
  const JAIL_STYLES = ['digital', 'split', 'minimal', 'strip'];
  function jailStyle() {
    const s = (E.appliedTheme && E.appliedTheme.jailHud) || (jail && jail.style) || E.cfg.jailHud || 'digital';
    return JAIL_STYLES.indexOf(s) >= 0 ? s : 'digital';
  }
  // A counter: { el, update(remaining, total) }.
  function jailCard(style, name, reason) {
    const card = { style };
    if (style === 'strip') {
      const time = h('div', { class: 'jh-time mono' });
      const bar = h('i');
      card.el = h('div', { class: 'jail-card jh-strip' },
        h('div', { class: 'jh-side' }, h('span', { class: 'jh-dot' }),
          h('div', null, h('div', { class: 'jh-title' }, E.t('jail_hud_title')), h('div', { class: 'jh-name' }, name || ''))),
        reason ? h('div', { class: 'jh-reason' }, h('span', null, E.t('jail_hud_reason')), h('b', null, reason)) : null,
        h('div', { class: 'jh-clock' }, h('div', { class: 'jh-label' }, E.t('jail_hud_remaining')), time),
        h('div', { class: 'jh-bar' }, bar));
      card.update = (r, total) => {
        time.textContent = E.mmss(r);
        bar.style.width = (total > 0 ? Math.max(0, Math.min(1, r / total)) * 100 : 0).toFixed(1) + '%';
      };
    } else if (style === 'split') {
      const time = h('div', { class: 'mono jh-time' });
      card.el = h('div', { class: 'jail-card jh-split' },
        h('div', { class: 'jh-left' }, h('div', { class: 'jh-label' }, E.t('jail_hud_left')), time),
        h('div', { class: 'jh-right' }, h('div', { class: 'jh-name' }, name || ''),
          reason ? h('div', { class: 'jh-reason' }, E.t('jail_hud_reason') + ': ' + reason) : null));
      card.update = (r) => { time.textContent = E.mmss(r); };
    } else if (style === 'minimal') {
      const time = h('div', { class: 'mono jh-time' });
      const bar = h('i');
      card.el = h('div', { class: 'jail-card jh-minimal' },
        h('div', { class: 'jh-sub' }, [name, reason].filter(Boolean).join(' • ')),
        time, h('div', { class: 'jh-bar' }, bar));
      card.update = (r, total) => {
        time.textContent = E.mmss(r);
        bar.style.width = (total > 0 ? Math.max(0, Math.min(1, r / total)) * 100 : 0).toFixed(1) + '%';
      };
    } else {
      const digits = h('div', { class: 'jh-digits' });
      card.el = h('div', { class: 'jail-card jh-digital' }, digits,
        h('div', { class: 'jh-sub' }, [name, reason].filter(Boolean).join(' — ')));
      let last = '';
      card.update = (r) => {
        const text = E.mmss(r);
        if (text === last) return;
        last = text;
        E.clear(digits);
        for (const ch of text) digits.appendChild(ch === ':' ? h('span', { class: 'jh-colon' }, ':') : h('span', { class: 'jh-cell mono' }, ch));
      };
    }
    return card;
  }
  E.jailCard = jailCard;

  let jail = null;
  let jailTick = null;
  let jailView = null;
  function renderJail() { if (jail && jailView) jailView.update(jail.remaining, jail.total); }
  function drawJail() {
    if (!jail) return;
    jailView = jailCard(jailStyle(), jail.name, jail.reason);
    E.clear($('jail-hud')).appendChild(jailView.el);
    renderJail();
  }
  E.on('jail:show', (d) => {
    jail = { remaining: d.remaining, total: d.total, name: d.name, reason: d.reason, style: d.style };
    drawJail();
    show($('jail-hud'));
    clearInterval(jailTick);
    jailTick = setInterval(() => { if (jail && jail.remaining > 0) { jail.remaining -= 1; renderJail(); } }, 1000);
  });
  // The look was changed in إدارة اللوحة: the counter on screen changes too.
  E.on('theme:applied', () => { if (jail && jailView && jailView.style !== jailStyle()) drawJail(); });
  E.on('jail:sync', (d) => { if (jail) { jail.remaining = d.remaining; renderJail(); } });
  E.on('jail:escape', (d) => {
    const root = $('jail-hud');
    root.classList.remove('flash');
    void root.offsetWidth;
    root.classList.add('flash');
    if (d.message) E.toast(d.message, 'error', 7);
  });
  E.on('jail:hide', () => { jail = null; jailView = null; clearInterval(jailTick); hide($('jail-hud')); });

  /* ============================================================ Badge (الشارة) */
  // Light green card: country + ministry on top, fields on the right, the character photo on
  // the left, a barcode and the signature line at the bottom (texts from Config.Badge).
  function badgeEl(d) {
    const f = d.fields || {};
    const no = String(d.number || 0).padStart(4, '0');
    const row = (show, label, value, mono) => (show === false ? null
      : h('div', { class: 'bdg-row' }, h('span', null, label), h('b', { class: mono ? 'mono' : null }, value)));
    const bars = Array.from({ length: 22 }, (_, i) => h('i', { style: { width: ((i * 7 + (d.number || 1)) % 3 + 1) + 'px' } }));
    return h('div', { class: 'badge-card' },
      h('div', { class: 'bdg-head' },
        h('div', null, h('b', null, d.country || ''), h('div', null, d.ministry || '')),
        h('div', { class: 'bdg-type' }, d.title || '', h('div', { class: 'mono' }, E.digits(no)))),
      h('div', { class: 'bdg-rule' }),
      h('div', { class: 'bdg-body' },
        h('div', { class: 'bdg-fields' },
          row(f.number, E.t('badge_number'), E.digits(no), true),
          row(f.name, E.t('badge_name'), d.name || ''),
          row(f.rank, E.t('badge_rank'), d.rank || '—'),
          row(f.sector, E.t('badge_sector'), d.sector || '—'),
          row(f.issued, E.t('badge_issued'), d.issued ? E.date(d.issued).slice(0, 10) : '—', true)),
        h('div', { class: 'bdg-photo' }, E.mugshot(d.user_id, d.mugshotAt, 'bdg'))),
      h('div', { class: 'bdg-bars' }, bars),
      h('div', { class: 'bdg-foot' }, h('span', null, E.t('badge_signature')), h('span', null, E.t('badge_issuer', { ministry: d.ministry || '' }))));
  }
  E.badgeEl = badgeEl;

  let badgeTimer = null;
  E.on('badge:show', (d) => {
    const root = E.clear($('badge-layer'));
    root.appendChild(badgeEl(d));
    show(root);
    clearTimeout(badgeTimer);
    badgeTimer = setTimeout(() => hide(root), Math.max(2, d.seconds || 8) * 1000);
  });

  /* ================================================================== ID card */
  // A small number made from the id's digits (ids can be 0, negative or sent as text).
  function idSeed(id) {
    let n = 7;
    for (const ch of String(id === undefined || id === null ? '' : id)) n = (n * 31 + ch.charCodeAt(0)) % 1000003;
    return n;
  }
  let idTimer = null;
  E.on('idcard:show', (d) => {
    const root = E.clear($('idcard-layer'));
    const row = (label, value, cls) => h('div', { class: 'idc-field ' + (cls || '') }, h('span', null, label), h('b', null, value));
    root.appendChild(h('div', { class: 'idcard' },
      h('div', { class: 'idc-pattern' }),
      h('div', { class: 'idc-top' },
        h('div', { class: 'idc-titles' }, h('div', { class: 'idc-country' }, d.country || ''), h('div', { class: 'idc-title' }, d.title || '')),
      ),
      h('div', { class: 'idc-body' },
        h('div', { class: 'idc-photo' }, E.mugshot(d.user_id, d.mugshotAt, 'idc')), // character photo
        h('div', { class: 'idc-fields' },
          row(E.t('idcard_name'), d.name || ''),
          row(E.t('idcard_id'), E.digits(d.user_id), 'mono'),
          row(E.t('idcard_job'), d.job || '—'))),
      h('div', { class: 'idc-bottom' },
        h('div', { class: 'idc-code' }, Array.from({ length: 28 }, (_, i) => h('i', { style: { width: ((i * 7 + idSeed(d.user_id)) % 3 + 1) + 'px' } }))),
        h('div', { class: 'idc-num mono' }, E.digits(String(1000000000 + (idSeed(d.user_id) * 7919) % 1000000000).slice(0, 10))))));
    show(root);
    requestAnimationFrame(() => root.firstChild.classList.add('in'));
    clearTimeout(idTimer);
    idTimer = setTimeout(() => {
      if (root.firstChild) root.firstChild.classList.remove('in');
      setTimeout(() => hide(root), 500);
    }, Math.max(3, d.duration || 10) * 1000);
  });

  /* =================================================================== Panels */
  const panelRoot = $('panel-layer');
  let panelKind = null;
  function closePanel() {
    hide(panelRoot);
    panelKind = null;
    E.popEsc('panel');
    E.post('close', { layer: 'panel' });
  }
  function sheet(title, icon, body, wide) {
    return h('div', { class: 'sheet-backdrop' },
      h('div', { class: 'sheet' + (wide ? ' wide' : '') },
        h('div', { class: 'sheet-head' },
          h('div', { class: 'sheet-title' }, title),
          h('button', { class: 'icon-btn', onclick: closePanel, title: E.t('close') }, E.icon('x', 18))),
        h('div', { class: 'sheet-body' }, body)));
  }
  const empty = (text) => h('div', { class: 'empty' }, h('div', null, text || E.t('none')));
  const kv = (label, value, cls) => h('div', { class: 'kv ' + (cls || '') }, h('span', null, label), h('b', null, value));
  const statusBadge = (status) => h('span', { class: 'badge st-' + status }, E.t('status_' + status) !== 'status_' + status ? E.t('status_' + status) : status);

  function personHeader(name, id, avatar, extra) {
    return h('div', { class: 'person' }, E.photo(avatar, 64),
      h('div', { class: 'person-info' }, h('div', { class: 'person-name' }, name || '—'),
        h('div', { class: 'person-meta' }, h('span', { class: 'chip mono' }, E.t('id_label') + ' ' + E.digits(id)), extra || null)));
  }

  function fineRow(f, opts) {
    return h('div', { class: 'row-card fine-row' + (f.status === 'paid' ? ' is-paid' : '') },
      opts && opts.check ? h('input', { type: 'checkbox', class: 'chk', checked: true, dataset: { id: f.id } }) : null,
      h('div', { class: 'grow' },
        h('div', { class: 'row-title' }, f.label, h('span', { class: 'muted' }, ' • ' + (f.category || ''))),
        h('div', { class: 'row-sub' }, E.t('fines_officer') + ': ' + (f.officer ? f.officer.name + ' | ' + E.t('id_label') + ' ' + f.officer.id : '—') + ' • ' + E.date(f.createdAt))),
      h('div', { class: 'amount' }, '$' + E.money(f.amount)),
      f.status ? h('span', { class: 'badge ' + (f.status === 'paid' ? 'ok' : 'bad') }, f.status === 'paid' ? E.t('fines_paid') : E.t('fines_unpaid')) : null);
  }

  // Fines / impounded vehicles windows: "cards" (إدارة اللوحة → الواجهة, the default) or "classic".
  const finesLook = () => ((E.appliedTheme && E.appliedTheme.finesLook) || E.cfg.finesLook || 'cards') === 'classic' ? 'classic' : 'cards';
  const impoundLook = () => ((E.appliedTheme && E.appliedTheme.impoundLook) || E.cfg.impoundLook || 'cards') === 'classic' ? 'classic' : 'cards';
  // Same window again after a payment (keeps the phone / remote / read-only state).
  const reopen = (kind, d, data) => openPanel({ kind, title: currentTitle, phone: currentPhone, data: Object.assign({ remote: d.remote, location: d.location }, data) });

  // F1: one card per fine (pay it alone), the total and "pay all" under them.
  function finesCards(d) {
    const list = d.list || [];
    const pay = async (btn, all, ids) => {
      btn.disabled = true;
      const r = await E.post('panelAction', { action: 'finesPay', ids, all, remote: d.remote === true });
      if (r && r.ok) reopen('finePay', d, r.data);
      else { btn.disabled = false; E.toast(r && r.data, 'error'); }
    };
    const body = h('div', { class: 'fc-wrap' },
      list.length ? h('div', { class: 'fc-list' }, list.map((f) => {
        const btn = d.readonly ? null : h('button', { class: 'fc-pay', onclick: () => pay(btn, false, [f.id]) }, E.t('fines_pay'));
        return h('div', { class: 'fc-card' },
          h('div', { class: 'fc-row' }, h('b', { class: 'fc-title' }, f.label), h('b', { class: 'fc-amount mono' }, '$' + E.money(f.amount))),
          h('div', { class: 'fc-row' }, h('span', { class: 'fc-sub' }, (f.category || '') + ' · ' + E.date(f.createdAt)), btn));
      })) : h('div', { class: 'fc-empty' }, E.t('fines_none')));
    if (list.length) {
      const all = d.readonly ? null : h('button', { class: 'fc-pay all', onclick: () => pay(all, true) }, E.t('fines_pay_all'));
      body.appendChild(h('div', { class: 'fc-foot' }, h('span', null, E.t('fines_total') + ' ', h('b', { class: 'mono' }, '$' + E.money(d.total))), all));
    }
    if (d.note) body.appendChild(h('div', { class: 'fc-note' }, d.note));
    return body;
  }

  // V1: one card per vehicle: model + plate, reason · place, fee + release button.
  function impoundCards(d) {
    const list = d.list || [];
    const body = h('div', { class: 'fc-wrap' },
      list.length ? h('div', { class: 'fc-list' }, list.map((r) => {
        const btn = d.readonly ? null : h('button', { class: 'fc-pay', onclick: async () => {
          btn.disabled = true;
          const res = await E.post('panelAction', { action: 'impoundPay', id: r.id, remote: d.remote === true });
          if (res && res.ok) reopen('impoundPay', d, res.data);
          else { btn.disabled = false; E.toast(res && res.data, 'error'); }
        } }, E.t('impound_release_btn'));
        return h('div', { class: 'fc-card' },
          h('div', { class: 'fc-row' }, h('b', { class: 'fc-title' }, r.model || '—'), h('span', { class: 'plate fc-plate' }, r.plate)),
          h('div', { class: 'fc-sub' }, r.reason + ' · ' + r.location),
          h('div', { class: 'fc-row' }, h('b', { class: 'fc-amount mono' }, '$' + E.money(r.fee)), btn));
      })) : h('div', { class: 'fc-empty' }, E.t('impound_none')));
    if (d.note) body.appendChild(h('div', { class: 'fc-note' }, d.note));
    return body;
  }

  const renderers = {
    absher(d) {
      const metric = (label,value,icon) => h('div',{class:'bf-metric'},h('span',{class:'bf-metric-icon'},E.icon(icon,20)),h('strong',null,value),h('small',null,label));
      const section = (title,subtitle,...children) => h('section',{class:'bf-section'},h('h2',null,title),h('p',{class:'muted'},subtitle),h('div',{class:'bf-grid'},children));
      return h('div',{class:'bf-profile'},
        section('البيانات الشخصية','المعلومات المسجلة في المنصة',
          metric('الاسم',d.name || '—','users'),metric('الرقم المدني',E.digits(d.user_id),'identity'),
          metric('رقم الهاتف','غير متوفر','phone'),metric('معرّف الحساب',E.digits(d.user_id),'identity')),
        section('الوضع النظامي','ملخص الالتزامات والحالة الحالية',
          metric('مخالفات غير مسددة',E.digits(d.finesCount || 0),'fine'),
          metric('حالة المحكومية',d.jailed ? 'محكوم' : 'لا توجد محكومية نشطة','jail'),
          metric('حالة التعقب',d.wanted ? 'مطلوب' : 'لا يوجد تعميم نشط','search'),
          metric('مركبات محجوزة',E.digits(d.vehiclesCount || 0),'car')),
        section('المحفظة','أرصدة حسابك داخل اللعبة',
          metric('في البنك',E.money(d.bank)+' ريال','cash'),metric('نقدًا',E.money(d.wallet)+' ريال','cash'),
          metric('إجمالي المخالفات',E.money(d.finesTotal)+' ريال','fine')));
    },
    ehsan(d) {
      const request = async (operation,payload,btn) => {
        if(btn) btn.disabled=true;
        const r=await E.post('panelAction',Object.assign({action:'ehsan',operation},payload));
        if(btn) btn.disabled=false;
        if(r && r.ok) openPanel({kind:'ehsan',title:'إحسان',phone:true,data:r.data});
        else E.toast(r && r.data || 'تعذر إكمال الطلب','error');
      };
      const amount=h('input',{type:'number',min:1,max:d.maxTarget,required:true,placeholder:'المبلغ المطلوب'});
      const reason=h('textarea',{maxlength:240,required:true,placeholder:'اشرح الحالة: مخالفات أو ديون داخل اللعبة',rows:3});
      const submit=h('button',{class:'bf-button',type:'submit'},'إرسال الحالة');
      const create=h('form',{class:'bf-case-form',onsubmit:ev=>{ev.preventDefault();request('create',{amount:Number(amount.value),reason:reason.value},submit);}},
        h('h3',null,'إنشاء طلب مساندة'),h('p',{class:'muted'},'الاسم: '+d.name+' • الأيدي: '+E.digits(d.user_id)+' — موثّقان من السيرفر'),
        h('label',null,'المبلغ المستهدف',amount),h('label',null,'تفاصيل الحالة',reason),
        h('p',{class:'muted'},d.approval ? 'تظهر الحالة للمتبرعين بعد اعتماد الإدارة.' : 'تظهر الحالة بعد إرسالها.'),submit);
      const states={active:'متاحة للدعم',pending:'قيد المراجعة',completed:'اكتمل الدعم',rejected:'لم تعتمد',cancelled:'ملغاة'};
      const cards=(d.list || []).map(c=>{
        const remaining=Math.max(0,c.target-c.raised);
        const card=h('article',{class:'bf-case'},h('div',{class:'bf-case-head'},h('h3',null,c.name),h('span',{class:'chip'},states[c.status] || c.status)),
          h('small',{class:'muted'},'الأيدي '+E.digits(c.user_id)+' • الحالة #'+E.digits(c.id)),h('p',null,c.reason),
          h('progress',{max:c.target,value:c.raised}),h('div',{class:'bf-case-head'},h('span',null,E.money(c.raised)+' / '+E.money(c.target)+' ريال'),h('span',null,'المتبقي '+E.money(remaining))));
        if(c.status==='active' && !c.own && remaining>0) {
          const input=h('input',{type:'number',min:d.min,max:Math.min(d.max,remaining),required:true,placeholder:'مبلغ الدعم'});
          const check=h('input',{type:'checkbox',required:true});
          const button=h('button',{type:'submit',class:'bf-button',disabled:!c.online || d.blocked},'تأكيد التبرع');
          card.appendChild(h('form',{class:'bf-donation',onsubmit:ev=>{ev.preventDefault();request('donate',{id:c.id,amount:Number(input.value)},button);}},
            h('label',null,'المبلغ بالنقد داخل اللعبة',input),h('label',{class:'bf-check'},check,'أوافق على تحويل المبلغ للمستفيد'),button));
          if(!c.online) card.appendChild(h('small',{class:'muted'},'الدعم متاح عند اتصال المستفيد.'));
        }
        if(d.admin && c.status==='pending') ['approve','reject'].forEach(decision=>{
          const button=h('button',{class:'bf-button secondary',onclick:()=>request('moderate',{id:c.id,decision},button)},decision==='approve'?'اعتماد الحالة':'رفض الحالة');card.appendChild(button);
        });
        if((c.own || d.admin) && ['pending','active'].includes(c.status)) {
          const button=h('button',{class:'bf-button secondary',onclick:()=>request('moderate',{id:c.id,decision:'cancel'},button)},'إغلاق الحالة');card.appendChild(button);
        }
        return card;
      });
      const prev=h('button',{class:'bf-button secondary',disabled:d.page<=1,onclick:()=>request('list',{page:d.page-1},prev)},'السابق');
      const next=h('button',{class:'bf-button secondary',disabled:!d.hasNext,onclick:()=>request('list',{page:d.page+1},next)},'التالي');
      const refresh=h('button',{class:'bf-button secondary',onclick:()=>request('list',{page:d.page},refresh)},'تحديث الحالات');
      return h('div',{class:'bf-ehsan'},h('div',{class:'callout'},'إحسان | مساندة المجتمع داخل اللعبة. الدعم يُحوّل نقدًا للمستفيد، ويسدد التزاماته بنفسه.'),
        d.blocked?h('div',{class:'callout bad'},'التبرعات متوقفة مؤقتًا لمراجعة عملية مالية غير مكتملة.'):null,
        create,h('div',{class:'bf-case-head'},h('h2',null,'حالات المجتمع'),refresh),h('div',{class:'bf-cases'},cards.length?cards:empty('لا توجد حالات في هذه الصفحة')),
        h('div',{class:'bf-pagination'},prev,h('span',null,'صفحة '+E.digits(d.page)),next),
        h('h3',null,'سجل دعمك — آخر 10 عمليات'),
        (d.history || []).length?h('div',{class:'stack'},d.history.map(tx=>h('div',{class:'row-card'},
          h('span',null,'عملية #'+E.digits(tx.id)+' • حالة #'+E.digits(tx.case_id)),
          h('strong',null,E.money(tx.amount)+' ريال'),
          h('small',null,({paid:'مكتملة',failed:'لم تكتمل',prepared:'قيد المراجعة',deducted:'قيد المراجعة',credited:'قيد المراجعة'})[tx.status] || tx.status)))):empty('لا توجد عمليات دعم مسجلة'));

    },
    citizen(d) {
      return h('div', { class: 'stack' },
        personHeader(d.name, d.user_id, d.avatar, h('span', { class: 'chip ' + (d.online ? 'ok' : '') }, d.online ? E.t('online') : E.t('offline'))),
        h('div', { class: 'kv-grid' },
          kv(E.t('citizen_job'), d.job || '—'),
          kv(E.t('citizen_wanted'), d.wanted && d.wanted.active ? E.t('citizen_wanted_yes') : E.t('citizen_wanted_no'), d.wanted && d.wanted.active ? 'bad' : 'ok'),
          kv(E.t('citizen_fines'), E.digits(d.fines ? d.fines.count : 0)),
          kv(E.t('citizen_fines_total'), '$' + E.money(d.fines ? d.fines.total : 0))),
        d.jailed ? h('div', { class: 'callout bad' }, E.t('citizen_jailed')) : null,
        d.wanted && d.wanted.active ? h('div', { class: 'callout bad' }, h('div', null, h('b', null, d.wanted.reason), h('div', { class: 'muted' }, (d.wanted.by || '') + ' • ' + E.date(d.wanted.createdAt)))) : null,
        // Last fines and last jail sentences, with date and time
        h('div', { class: 'section-title' }, E.t('citizen_last_fines')),
        d.fines && d.fines.list && d.fines.list.length ? h('div', { class: 'list' }, d.fines.list.map((f) => fineRow(f))) : empty(E.t('citizen_no_history')),
        h('div', { class: 'section-title' }, E.t('citizen_last_jails')),
        d.jails && d.jails.length ? h('div', { class: 'list' }, d.jails.map((j) => h('div', { class: 'row-card' },
          h('div', { class: 'grow' },
            h('div', { class: 'row-title' }, j.reason || '—'),
            h('div', { class: 'row-sub' }, E.t('jail_officer') + ': ' + (j.officer || '—') + ' • ' + E.date(j.startedAt))),
          h('div', { class: 'amount' }, E.hours(j.seconds)),
          j.current ? h('span', { class: 'badge bad' }, E.t('jail_current')) : null))) : empty(E.t('citizen_no_history')));
    },
    fines(d) {
      return h('div', { class: 'stack' },
        personHeader(d.name, d.user_id, null, h('span', { class: 'chip bad' }, E.t('fines_unpaid') + ': $' + E.money(d.unpaidTotal))),
        d.list && d.list.length ? h('div', { class: 'list' }, d.list.map((f) => fineRow(f))) : empty(E.t('fines_none')));
    },
    jail(d) {
      return h('div', { class: 'stack' },
        personHeader(d.name, d.user_id, null, h('span', { class: 'chip ' + (d.jailed ? 'bad' : 'ok') }, d.jailed ? E.t('jail_is_jailed') : E.t('jail_not_jailed'))),
        d.jailed ? h('div', { class: 'kv-grid' },
          kv(E.t('jail_remaining'), E.mmss(d.remaining), 'mono big'),
          kv(E.t('jail_name'), d.jailName || ''),
          kv(E.t('jail_reason'), d.reason || '—'),
          kv(E.t('jail_officer'), d.officer ? d.officer.name + ' | ' + E.t('id_label') + ' ' + d.officer.id : '—')) : null);
    },
    impound(d) {
      return h('div', { class: 'stack' },
        personHeader(d.name, d.user_id),
        d.list && d.list.length ? h('div', { class: 'list' }, d.list.map((r) => h('div', { class: 'row-card' },
          h('div', { class: 'plate' }, r.plate),
          h('div', { class: 'grow' },
            h('div', { class: 'row-title' }, (r.model || '—') + ' • ' + r.reason),
            h('div', { class: 'row-sub' }, r.location + ' • ' + (r.officer ? r.officer.name + ' | ' + E.t('id_label') + ' ' + r.officer.id : '') + ' • ' + E.date(r.createdAt))),
          h('div', { class: 'amount' }, '$' + E.money(r.fee)),
          h('span', { class: 'badge ' + (r.status === 'impounded' ? 'bad' : 'ok') }, r.status === 'impounded' ? E.t('impound_status_impounded') : E.t('impound_status_released'))))) : empty(E.t('impound_none')));
    },
    search(d) {
      return h('div', { class: 'stack' },
        personHeader(d.name, d.user_id, null, d.money !== null && d.money !== undefined ? h('span', { class: 'chip' }, E.t('search_money') + ': $' + E.money(d.money)) : null),
        h('div', { class: 'section-title' }, E.t('search_items')),
        d.items && d.items.length ? h('div', { class: 'item-grid' }, d.items.map((it) => h('div', { class: 'item' + (it.contraband ? ' contraband' : '') },
          h('div', { class: 'item-name' }, it.label), h('div', { class: 'item-amount mono' }, '×' + E.digits(it.amount)),
          it.contraband ? h('span', { class: 'badge bad' }, E.t('search_contraband')) : null))) : empty(E.t('search_empty')),
        d.weapons ? h('div', { class: 'section-title' }, E.t('search_weapons')) : null,
        d.weapons ? (d.weapons.length ? h('div', { class: 'item-grid' }, d.weapons.map((w) => h('div', { class: 'item' }, h('div', { class: 'item-name mono' }, w.name.replace('WEAPON_', '')), h('div', { class: 'item-amount mono' }, E.digits(w.ammo))))) : empty(E.t('search_empty'))) : null);
    },
    vehicle(d) {
      const body = h('div', { class: 'stack' },
        h('div', { class: 'vehicle-head' }, h('div', { class: 'plate big' }, d.plate), h('div', null, h('div', { class: 'row-title' }, d.model || '—'),
          h('div', { class: 'row-sub' }, E.t('vehicle_owner') + ': ' + (d.owner ? d.owner.name + ' | ' + E.t('id_label') + ' ' + d.owner.id : '—')))),
        d.items && d.items.length ? h('div', { class: 'item-grid' }, d.items.map((it) => h('div', { class: 'item' + (it.contraband ? ' contraband' : '') },
          h('div', { class: 'item-name' }, it.label), h('div', { class: 'item-amount mono' }, '×' + E.digits(it.amount)),
          it.contraband ? h('span', { class: 'badge bad' }, E.t('search_contraband')) : null))) : empty(E.t('search_empty')));
      if (d.canSeize) {
        const btn = h('button', { class: 'btn btn-danger wide', onclick: async () => {
          btn.disabled = true;
          const r = await E.post('panelAction', { action: 'vehicleSeize', token: d.token });
          if (r && r.ok) { E.toast(E.t('vehicle_seize'), 'success'); d.items = r.data.items; d.canSeize = false; openPanel({ kind: 'vehicle', title: currentTitle, data: d }); }
          else { btn.disabled = false; E.toast(r && r.data, 'error'); }
        } }, E.t('vehicle_seize'));
        body.appendChild(btn);
      }
      return body;
    },
    finePay(d) {
      if (finesLook() === 'cards') return finesCards(d);
      const list = d.list || [];
      const body = h('div', { class: 'stack' },
        h('div', { class: 'pay-summary' }, h('div', null, h('div', { class: 'muted' }, E.t('fines_total')), h('div', { class: 'amount big' }, '$' + E.money(d.total))),
          h('span', { class: 'chip' }, E.digits(d.count || 0) + ' ' + E.t('fines_unpaid'))),
        list.length ? h('div', { class: 'list' }, list.map((f) => fineRow(f, { check: !d.readonly }))) : empty(E.t('fines_none')),
        d.note ? h('div', { class: 'fc-note' }, d.note) : null);
      if (list.length && !d.readonly) {
        const pay = async (all) => {
          const ids = Array.from(body.querySelectorAll('.chk')).filter((c) => c.checked).map((c) => Number(c.dataset.id));
          const r = await E.post('panelAction', { action: 'finesPay', ids, all, remote: d.remote === true });
          if (r && r.ok) reopen('finePay', d, r.data);
          else E.toast(r && r.data, 'error');
        };
        body.appendChild(h('div', { class: 'actions' },
          h('button', { class: 'btn btn-primary', onclick: () => pay(true) }, E.t('fines_pay_all')),
          h('button', { class: 'btn', onclick: () => pay(false) }, E.t('fines_pay'))));
      }
      return body;
    },
    impoundPay(d) {
      if (impoundLook() === 'cards') return impoundCards(d);
      const list = d.list || [];
      const rows = list.length ? h('div', { class: 'list' }, list.map((r) => {
        const btn = d.readonly ? h('div', { class: 'amount' }, '$' + E.money(r.fee)) : h('button', { class: 'btn btn-primary', onclick: async () => {
          btn.disabled = true;
          const res = await E.post('panelAction', { action: 'impoundPay', id: r.id, remote: d.remote === true });
          if (res && res.ok) reopen('impoundPay', d, res.data);
          else { btn.disabled = false; E.toast(res && res.data, 'error'); }
        } }, E.t('impound_pay') + ' $' + E.money(r.fee));
        return h('div', { class: 'row-card' }, h('div', { class: 'plate' }, r.plate),
          h('div', { class: 'grow' }, h('div', { class: 'row-title' }, (r.model || '—') + ' • ' + r.reason), h('div', { class: 'row-sub' }, r.location + ' • ' + E.date(r.createdAt))), btn);
      })) : empty(E.t('impound_none'));
      return d.note ? h('div', { class: 'stack' }, rows, h('div', { class: 'fc-note' }, d.note)) : rows;
    },
  };
  const PANEL_ICONS = { citizen: 'userSearch', fines: 'fine', jail: 'jail', impound: 'impound', search: 'search', vehicle: 'car', finePay: 'cash', impoundPay: 'impound' };
  let currentTitle = '';
  let currentPhone = false;
  let absherHome = null; // the phone's home screen, for "رجوع"

  // منصة أبشر: the window drawn as a phone. The word "أبشر" is only here (the points use a sheet).
  let portalNavBusy = false;
  let portalSummary = {};
  function phone(d, body) {
    if(d.kind==='absher') { absherHome=d; portalSummary=d.data || {}; }
    else if(d.data) {
      ['wallet','bank','name','user_id'].forEach(key=>{if(d.data[key]!==undefined) portalSummary[key]=d.data[key];});
    }
    const nav=async(view,label,btn)=>{
      if(portalNavBusy) return;
      portalNavBusy=true;btn.disabled=true;
      const r=await E.post('panelAction',view==='ehsan'?{action:'ehsan',operation:'list'}:{action:'absher',view});
      portalNavBusy=false;btn.disabled=false;
      if(r && r.ok) openPanel({kind:view==='ehsan'?'ehsan':r.data.kind,title:label,phone:true,data:view==='ehsan'?r.data:r.data.data});
      else E.toast(r && r.data || 'تعذر تحميل الصفحة','error');
    };
    const item=(view,label,icon,selected)=>{
      const btn=h('button',{class:'bf-nav-item'+(selected?' active':''),onclick:()=>nav(view,label,btn)},E.icon(icon,18),label);return btn;
    };
    const active=d.kind;
    const appearance=(E.cfg.portal && E.cfg.portal.Appearance) || {};
    const palette={};
    [['Accent','--bf-accent'],['Background','--bf-bg'],['Card','--bf-card']].forEach(([key,variable])=>{
      if(/^#[0-9a-f]{6}$/i.test(appearance[key] || '')) palette[variable]=appearance[key];
    });
    palette['--bf-width']=Math.max(700,Math.min(1800,Number(appearance.Width) || 1280))+'px';
    palette['--bf-height']=Math.max(50,Math.min(95,Number(appearance.Height) || 88))+'vh';
    return h('div',{class:'sheet-backdrop bf-backdrop'},h('div',{class:'bf-portal',style:palette},
      h('aside',{class:'bf-sidebar'},h('div',{class:'bf-brand'},h('span',{class:'bf-brand-mark'},'B'),h('div',null,h('h2',null,(E.cfg.portal && E.cfg.portal.Title) || 'أبشر'),h('small',null,'منصة الخدمات المدنية'))),
        h('small',{class:'bf-nav-caption'},'حسابي'),item('profile','المعلومات الشخصية','identity',active==='absher'),item('record','ملفي النظامي','shield',active==='citizen'),
        h('small',{class:'bf-nav-caption'},'الخدمات'),
        portalSummary.fines!==false?item('finesPay','المخالفات والتسوية','fine',active==='finePay'):null,
        portalSummary.impound!==false?item('impoundPay','المركبات المحجوزة','car',active==='impoundPay'):null,
        portalSummary.ehsan!==false?item('ehsan','إحسان — مساندة المجتمع','cash',active==='ehsan'):null,
        h('div',{class:'bf-sidebar-footer'},h('strong',null,portalSummary.name || 'BoFaisaL'),h('small',null,'تطوير BoFaisaL'))),
      h('main',{class:'bf-main'},h('header',{class:'bf-topbar'},h('div',null,h('h1',null,active==='absher'?'المعلومات الشخصية':d.title),h('small',{class:'muted'},'بياناتك وخدماتك في مكان واحد')),
        h('div',{class:'bf-top-actions'},h('span',{class:'chip'},'البنك '+E.money(portalSummary.bank || 0)+' ريال'),h('span',{class:'chip'},'نقدًا '+E.money(portalSummary.wallet || 0)+' ريال'),
          h('button',{class:'icon-btn',onclick:closePanel,title:'إغلاق'},E.icon('x',18)))),h('div',{class:'bf-content'},body))));
  }
  // Vehicle search, "list" look (إدارة اللوحة → الواجهة, the default): the model and owner with
  // a big plate on top, the trunk as rows, contraband tagged, and an outlined seize button.
  function vehicleStyle() {
    const v = (E.appliedTheme && E.appliedTheme.vehicleSearch) || E.cfg.vehicleSearch || 'list';
    return v === 'classic' ? 'classic' : 'list';
  }
  function vehicleList(d) {
    const items = d.items || [];
    const contraband = items.filter((it) => it.contraband).length;
    const card = h('div', { class: 'vs-card' },
      h('div', { class: 'vs-head' },
        h('div', { class: 'vs-car' }, h('div', { class: 'vs-model' }, d.model || '—'),
          h('div', { class: 'vs-owner' }, d.owner ? d.owner.name + ' · ' + E.digits(d.owner.id) : '—')),
        h('div', { class: 'plate vs-plate' }, d.plate),
        h('button', { class: 'icon-btn vs-close', onclick: closePanel, title: E.t('close') }, E.icon('x', 16))),
      items.length
        ? h('div', { class: 'vs-rows' }, items.map((it) => h('div', { class: 'vs-row' + (it.contraband ? ' bad' : '') },
            h('span', null, it.label, it.contraband ? h('span', { class: 'vs-tag' }, E.t('search_contraband')) : null),
            h('span', { class: 'mono vs-amount' }, '×' + E.digits(it.amount)))))
        : h('div', { class: 'vs-empty' }, E.t('search_empty')));
    if (d.canSeize) {
      const btn = h('button', { class: 'vs-seize', onclick: async () => {
        btn.disabled = true;
        const r = await E.post('panelAction', { action: 'vehicleSeize', token: d.token });
        if (r && r.ok) { E.toast(E.t('vehicle_seize'), 'success'); d.items = r.data.items; d.canSeize = false; openPanel({ kind: 'vehicle', title: currentTitle, data: d }); }
        else { btn.disabled = false; E.toast(r && r.data, 'error'); }
      } }, E.t('vehicle_seize') + ' (' + E.digits(contraband) + ')');
      card.appendChild(h('div', { class: 'vs-foot' }, btn));
    }
    return h('div', { class: 'sheet-backdrop' }, card);
  }

  function openPanel(d) {
    const render = renderers[d.kind];
    if (!render) return;
    panelKind = d.kind;
    currentTitle = d.title || '';
    currentPhone = d.phone === true;
    if (currentPhone) E.clear(panelRoot).appendChild(phone(d, render(d.data || {})));
    else if (d.kind === 'vehicle' && vehicleStyle() === 'list') E.clear(panelRoot).appendChild(vehicleList(d.data || {}));
    else E.clear(panelRoot).appendChild(sheet(currentTitle, PANEL_ICONS[d.kind] || 'info', render(d.data || {}), d.kind === 'search' || d.kind === 'vehicle'));
    show(panelRoot);
    E.pushEsc('panel', closePanel);
  }
  E.on('panel:open', openPanel);
  E.on('panel:close', () => { hide(panelRoot); panelKind = null; E.popEsc('panel'); });

  /* ============================================================ Dialog popup */
  const dialogRoot = $('dialog-layer');
  let dialogId = null;
  function closeDialog(submit) {
    if (dialogId === null) return;
    const id = dialogId;
    dialogId = null;
    E.popEsc('dialog');
    if (submit) {
      const values = {};
      dialogRoot.querySelectorAll('[data-key]').forEach((el) => { values[el.dataset.key] = el.value; });
      E.post('dialogSubmit', { id, values });
    } else {
      E.post('dialogCancel', { id });
    }
    hide(dialogRoot);
  }
  E.on('dialog:open', (d) => {
    dialogId = d.id;
    const fields = (d.fields || []).map((f, i) => h('label', { class: 'field' }, h('span', null, f.label),
      f.type === 'textarea'
        ? h('textarea', { dataset: { key: f.key }, maxlength: f.max || 250, rows: 4, placeholder: f.placeholder || '' }, f.default || '')
        : h('input', { dataset: { key: f.key }, type: f.type === 'number' ? 'number' : 'text', maxlength: f.max || 64, placeholder: f.placeholder || '', value: f.default || '', autofocus: i === 0 })));
    const form = h('form', { class: 'stack', onsubmit: (ev) => { ev.preventDefault(); closeDialog(true); } }, fields,
      h('div', { class: 'actions' }, h('button', { class: 'btn btn-primary', type: 'submit' }, E.t('confirm')),
        h('button', { class: 'btn', type: 'button', onclick: () => closeDialog(false) }, E.t('cancel'))));
    E.clear(dialogRoot).appendChild(h('div', { class: 'sheet-backdrop' }, h('div', { class: 'sheet dialog' },
      h('div', { class: 'sheet-head' }, h('div', { class: 'sheet-title' }, d.title || ''),
        h('button', { class: 'icon-btn', type: 'button', onclick: () => closeDialog(false) }, E.icon('x', 18))),
      h('div', { class: 'sheet-body' }, form))));
    show(dialogRoot);
    E.pushEsc('dialog', () => closeDialog(false));
    const first = dialogRoot.querySelector('input, textarea');
    if (first) setTimeout(() => first.focus(), 30);
  });
  E.on('dialog:close', () => { dialogId = null; E.popEsc('dialog'); hide(dialogRoot); });

  /* ============================================================ Builtin menu */
  const menuRoot = $('menu-layer');
  let menu = null;
  let menuIndex = 0;
  function renderMenu() {
    const items = menu.items || [];
    E.clear(menuRoot).appendChild(h('div', { class: 'menu' },
      h('div', { class: 'menu-head' }, h('div', null, h('div', { class: 'menu-title' }, menu.title || ''), menu.subtitle ? h('div', { class: 'menu-sub' }, menu.subtitle) : null)),
      h('div', { class: 'menu-items' }, items.map((it, i) => h('button', {
        class: 'menu-item' + (i === menuIndex ? ' active' : ''),
        onmouseenter: () => { menuIndex = i; renderMenu(); },
        onclick: () => selectMenu(i),
      }, h('div', { class: 'mi-label' }, it.label), it.description ? h('div', { class: 'mi-desc' }, it.description) : null))),
      h('div', { class: 'menu-foot' }, '↑ ↓ • Enter • ' + (menu.back ? 'Backspace ' + E.t('back') : 'Esc ' + E.t('close')))));
    show(menuRoot);
  }
  function selectMenu(i) {
    if (!menu) return;
    const token = menu.token;
    menu = null;
    hide(menuRoot);
    E.popEsc('menu');
    E.post('menuSelect', { token, index: i + 1 });
  }
  function closeMenu(back) {
    if (!menu) return;
    const token = menu.token;
    menu = null;
    hide(menuRoot);
    E.popEsc('menu');
    E.post(back ? 'menuBack' : 'menuClose', { token });
  }
  E.on('menu:open', (d) => { menu = d; menuIndex = 0; renderMenu(); E.pushEsc('menu', () => closeMenu(false)); });
  E.on('menu:close', () => { menu = null; hide(menuRoot); E.popEsc('menu'); });
  E.on('key', (ev) => {
    if (!menu) return;
    const n = (menu.items || []).length;
    if (ev.key === 'ArrowDown') { menuIndex = (menuIndex + 1) % Math.max(1, n); renderMenu(); }
    else if (ev.key === 'ArrowUp') { menuIndex = (menuIndex - 1 + n) % Math.max(1, n); renderMenu(); }
    else if (ev.key === 'Enter' && n) { ev.preventDefault(); selectMenu(menuIndex); }
    else if (ev.key === 'Backspace') { ev.preventDefault(); closeMenu(menu.back); }
  });

  /* ================================================================= Spectate */
  E.on('spectate:show', (d) => {
    const root = E.clear($('spectate'));
    root.appendChild(h('div', { class: 'spec-top' }, h('span', { class: 'live-dot' }), E.t('spectate_title'), h('b', null, (d.name || '') + ' | ' + E.t('id_label') + ' ' + E.digits(d.id))));
    root.appendChild(h('button', { class: 'spec-stop hint-pill kh-' + E.keyHintLook(), onclick: () => E.post('spectateStop', {}) }, h('kbd', null, d.key || 'BACKSPACE'), h('span', null, E.t('spectate_stop'))));
    show(root);
  });
  E.on('spectate:hide', () => hide($('spectate')));

  /* ========================================================= Progress & skill */
  let progTimer = null;
  E.on('progress:start', (d) => {
    const root = E.clear($('progress'));
    const bar = h('i');
    const pct = h('span', { class: 'mono' }, '0%');
    root.appendChild(h('div', { class: 'progress-card' }, h('div', { class: 'progress-top' }, h('span', null, d.label || ''), pct), h('div', { class: 'progress-bar' }, bar)));
    show(root);
    const started = Date.now();
    const total = Math.max(1, d.duration || 10) * 1000;
    clearInterval(progTimer);
    progTimer = setInterval(() => {
      const p = Math.min(1, (Date.now() - started) / total);
      bar.style.width = (p * 100).toFixed(1) + '%';
      pct.textContent = E.digits(Math.round(p * 100)) + '%';
      if (p >= 1) clearInterval(progTimer);
    }, 100);
  });
  E.on('progress:stop', () => { clearInterval(progTimer); hide($('progress')); });

  /* ========================================================== Jail task HUD */
  // Two looks, chosen per task in إدارة اللوحة: "corners" (frame corners, lines) and "segments"
  // (a line of blocks). Progress on top, the check (press E) under it. Shown in #progress, so it
  // follows the place / size of "شريط التقدم" in the layout editor.
  const SEGS = 20;
  function taskCard(style, label) {
    const pct = h('span', { class: 'mono th-pct' }, E.digits(0) + '%');
    const hint = h('div', { class: 'th-hint' });
    const t = { style, pct, hint };
    if (style === 'segments') {
      t.segs = Array.from({ length: SEGS }, () => h('i'));
      t.sk = Array.from({ length: SEGS }, () => h('i'));
      t.skill = h('div', { class: 'th-segs th-skill idle' }, t.sk);
      t.el = h('div', { class: 'task-hud th-segments' },
        h('div', { class: 'th-top' }, h('span', null, label || ''), pct),
        h('div', { class: 'th-segs' }, t.segs), t.skill, hint);
    } else {
      t.bar = h('i');
      t.zone = h('b', { class: 'th-zone' });
      t.ptr = h('i', { class: 'th-ptr' });
      t.skill = h('div', { class: 'th-skill idle' }, t.zone, t.ptr);
      t.el = h('div', { class: 'task-hud th-corners' },
        h('i', { class: 'th-c tl' }), h('i', { class: 'th-c tr' }), h('i', { class: 'th-c bl' }), h('i', { class: 'th-c br' }),
        h('div', { class: 'th-top' }, h('span', null, label || ''), pct),
        h('div', { class: 'th-line' }, t.bar), t.skill, hint);
    }
    t.progress = (p) => {
      pct.textContent = E.digits(Math.round(p * 100)) + '%';
      if (t.segs) t.segs.forEach((s, i) => s.classList.toggle('on', i < Math.floor(p * SEGS + 1e-6)));
      else t.bar.style.width = (p * 100).toFixed(1) + '%';
    };
    return t;
  }
  E.taskCard = taskCard;

  let task = null;   // the task on screen
  let check = null;  // the running check
  let taskTimer = null;
  E.on('task:start', (d) => {
    clearInterval(taskTimer);
    task = taskCard(d.style, d.label);
    E.clear($('progress')).appendChild(task.el);
    show($('progress'));
    const started = Date.now();
    const total = Math.max(1, d.duration || 10) * 1000;
    taskTimer = setInterval(() => {
      const p = Math.min(1, (Date.now() - started) / total);
      if (task) task.progress(p);
      if (p >= 1) clearInterval(taskTimer);
    }, 100);
  });
  E.on('task:stop', () => {
    clearInterval(taskTimer);
    if (check) endCheck(false, true);
    task = null;
    hide($('progress'));
  });
  // The pointer goes back and forth on the line; E inside the coloured part = success.
  E.on('task:check', (d) => {
    if (!task) return E.post('skillcheck', { success: false });
    const zone = Math.max(0.08, Math.min(0.5, d.zone || 0.2));
    const zoneStart = 0.15 + Math.random() * (0.8 - zone);
    check = { pos: 0, dir: 1, zoneStart, zone, speed: 0.6 * (d.speed || 1), last: performance.now(), startedAt: performance.now(), done: false };
    const t = task;
    t.skill.classList.remove('idle', 'ok', 'bad');
    t.hint.textContent = E.t('task_check_' + (t.segs ? 'segments' : 'corners'));
    if (t.segs) {
      check.from = Math.round(zoneStart * SEGS);
      check.to = Math.min(SEGS, check.from + Math.max(2, Math.round(zone * SEGS)));
      t.sk.forEach((s, i) => s.className = i >= check.from && i < check.to ? 'zone' : '');
    } else {
      t.zone.style.left = zoneStart * 100 + '%';
      t.zone.style.width = zone * 100 + '%';
    }
    const c = check;
    const step = (now) => {
      if (c.done || check !== c) return;
      c.pos += ((now - c.last) / 1000) * c.speed * c.dir;
      c.last = now;
      if (c.pos >= 1) { c.pos = 1; c.dir = -1; } else if (c.pos <= 0) { c.pos = 0; c.dir = 1; }
      if (t.segs) {
        const idx = Math.min(SEGS - 1, Math.floor(c.pos * SEGS));
        t.sk.forEach((s, i) => s.classList.toggle('ptr', i === idx));
      } else t.ptr.style.left = c.pos * 100 + '%';
      if (now - c.startedAt > 6000) return endCheck(false);
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  });
  function endCheck(success, silent) {
    const c = check;
    if (!c || c.done) return;
    c.done = true;
    check = null;
    const t = task;
    if (t) {
      t.skill.classList.add(success ? 'ok' : 'bad');
      t.hint.textContent = '';
      setTimeout(() => { if (task === t && !check) t.skill.classList.remove('ok', 'bad'), t.skill.classList.add('idle'); }, 450);
    }
    if (!silent) E.post('skillcheck', { success });
  }
  E.on('key', (ev) => {
    if (!check || ev.code !== 'KeyE') return;
    const c = check;
    const inside = c.from !== undefined
      ? (() => { const idx = Math.min(SEGS - 1, Math.floor(c.pos * SEGS)); return idx >= c.from && idx < c.to; })()
      : c.pos >= c.zoneStart && c.pos <= c.zoneStart + c.zone;
    endCheck(inside);
  });

  let skill = null;
  E.on('skillcheck:start', (d) => {
    const root = E.clear($('skillcheck'));
    const zone = Math.max(0.06, Math.min(0.5, d.zone || 0.2));
    const start = 0.25 + Math.random() * (0.7 - zone);
    const R = 46, C = 2 * Math.PI * R;
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 120 120');
    const track = document.createElementNS(ns, 'circle');
    Object.entries({ cx: 60, cy: 60, r: R, class: 'sk-track' }).forEach(([k, v]) => track.setAttribute(k, v));
    const arc = document.createElementNS(ns, 'circle');
    Object.entries({ cx: 60, cy: 60, r: R, class: 'sk-zone', 'stroke-dasharray': zone * C + ' ' + C, 'stroke-dashoffset': -start * C, transform: 'rotate(-90 60 60)' }).forEach(([k, v]) => arc.setAttribute(k, v));
    const needle = document.createElementNS(ns, 'line');
    Object.entries({ x1: 60, y1: 60, x2: 60, y2: 12, class: 'sk-needle' }).forEach(([k, v]) => needle.setAttribute(k, v));
    svg.append(track, arc, needle);
    root.appendChild(h('div', { class: 'skill-card' }, svg, h('div', { class: 'sk-key' }, h('kbd', null, d.key || 'E'))));
    show(root);
    skill = { pos: 0, zoneStart: start, zone, speed: 0.55 * (d.speed || 1), last: performance.now(), done: false };
    const step = (now) => {
      if (!skill || skill.done) return;
      skill.pos = (skill.pos + ((now - skill.last) / 1000) * skill.speed) % 1;
      skill.last = now;
      needle.setAttribute('transform', 'rotate(' + skill.pos * 360 + ' 60 60)');
      if (now - skill.startedAt > 6000) return finishSkill(false);
      requestAnimationFrame(step);
    };
    skill.startedAt = performance.now();
    requestAnimationFrame(step);
  });
  function finishSkill(success) {
    if (!skill || skill.done) return;
    skill.done = true;
    $('skillcheck').classList.add(success ? 'ok' : 'bad');
    setTimeout(() => { $('skillcheck').classList.remove('ok', 'bad'); hide($('skillcheck')); }, 350);
    skill = null;
    E.post('skillcheck', { success });
  }
  E.on('key', (ev) => {
    if (!skill || ev.code !== 'KeyE') return;
    const p = skill.pos;
    finishSkill(p >= skill.zoneStart && p <= skill.zoneStart + skill.zone);
  });

  /* ============================================================ Wanted alert */
  // Two looks, chosen in إدارة اللوحة (الواجهة): "poster" (a wanted poster with the character
  // photo, the default) and "classic" (the red card).
  function wantedStyle() {
    const s = (E.appliedTheme && E.appliedTheme.wanted) || E.cfg.wantedStyle || 'poster';
    return s === 'classic' ? 'classic' : 'poster';
  }
  // d.kind = "report": the new report alert (same looks, its own title and colour).
  function wantedEl(d, style) {
    const report = d.kind === 'report';
    const q = d.quickOpen || E.cfg.wanted || {};
    const quick = q.enabled ? [h('kbd', null, q.label || 'G'), E.t(report ? 'report_quick' : 'wanted_quick', { key: q.label || 'G' })] : null;
    const bar = h('div', { class: 'wa-bar' }, h('i', { style: { animationDuration: (q.seconds || 10) + 's' } }));
    if ((style || wantedStyle()) === 'classic') {
      return h('div', { class: 'wanted-card' + (report ? ' is-report' : '') },
        h('div', { class: 'wa-head' }, h('b', null, report ? E.t('report_alert_title') + ' #' + E.digits(d.id) : E.t('wanted_title'))),
        h('div', { class: 'wa-name' }, (d.name || '') + ' | ' + E.t('id_label') + ' ' + E.digits(d.user_id)),
        h('div', { class: 'wa-reason' }, d.reason || ''),
        quick ? h('div', { class: 'wa-quick' }, quick) : null, bar);
    }
    return h('div', { class: 'wanted-poster' + (report ? ' is-report' : '') },
      h('div', { class: 'wp-title' }, report ? E.t('report_alert_title', null, 'بلاغ جديد') : E.t('wanted_poster_title', null, 'مطلوب')),
      report ? h('div', { class: 'wp-sub mono' }, '#' + E.digits(d.id)) : null,
      E.mugshot(d.user_id, d.mugshotAt, 'wp-mug'), // character photo
      h('div', { class: 'wp-name' }, (d.name || '') + ' — ' + E.digits(d.user_id)),
      d.reason ? h('div', { class: 'wp-reason' }, d.reason) : null,
      quick ? h('div', { class: 'wp-quick' }, quick) : null, bar);
  }
  E.wantedEl = wantedEl;

  let wantedTimer = null;
  E.on('wanted:alert', (d) => {
    const root = E.clear($('wanted-alert'));
    const q = d.quickOpen || E.cfg.wanted || {};
    root.appendChild(wantedEl(d));
    show(root);
    clearTimeout(wantedTimer);
    wantedTimer = setTimeout(() => hide(root), (q.seconds || 10) * 1000);
  });
  E.on('wanted:alertHide', () => hide($('wanted-alert')));

  /* ======================================================== Security alert chip */
  E.on('alert:status', (d) => {
    const root = E.clear($('alert-status'));
    if (!d.active) return hide(root);
    root.appendChild(h('div', { class: 'alert-chip' }, h('span', null, E.t('alert_zone_chip'))));
    show(root);
  });

  /* ======================================================= Skip cards (F5) */
  // The client is told how many info cards are on screen (it only reads F5 while there are).
  // "cards:skip" closes one: the oldest inquiry card first, then the ID card, then the badge.
  const visibleLayer = (id) => !$(id).classList.contains('hidden') && $(id).children.length > 0;
  function cardsCount() {
    return $('infocards').children.length + (visibleLayer('idcard-layer') ? 1 : 0) + (visibleLayer('badge-layer') ? 1 : 0);
  }
  let lastCount = -1;
  let reportTimer = null;
  function reportCards() {
    clearTimeout(reportTimer);
    reportTimer = setTimeout(() => {
      const n = cardsCount();
      if (n !== lastCount) { lastCount = n; E.post('cardsShown', { count: n }); }
    }, 50);
  }
  document.addEventListener('DOMContentLoaded', () => {
    new MutationObserver(reportCards).observe($('infocards'), { childList: true });
    ['idcard-layer', 'badge-layer'].forEach((id) => new MutationObserver(reportCards).observe($(id), { attributes: true, attributeFilter: ['class'], childList: true }));
  });
  E.on('cards:skip', () => {
    const first = $('infocards').firstElementChild;
    if (first) { first.classList.remove('in'); setTimeout(() => first.remove(), 200); return; }
    if (visibleLayer('idcard-layer')) return hide($('idcard-layer'));
    if (visibleLayer('badge-layer')) return hide($('badge-layer'));
  });
})();
