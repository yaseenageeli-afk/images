--[[
    ════════════════════════════════════════════════════════════════════════
     الإعدادات
    ════════════════════════════════════════════════════════════════════════
     كل نظام في قسم لحاله، بنفس ترتيب اللعبة تقريباً:

         1 ─ الأساسيات            (vRP، OneSync، قاعدة البيانات)
         2 ─ الخدمة والحضور        (تسجيل الدخول، الكود العسكري)
         3 ─ الإجازات
         4 ─ التأكيد واختيار اللاعب (F5 / F6، أقرب لاعب، الموانع)
         5 ─ أوامر الشات والأزرار
         6 ─ المخالفات             (والوصل ونسبة العسكري)
         7 ─ السجن                 (اللبس، الكفالة، الهروب، العداد، المهام)
         8 ─ حجز المركبات
         9 ─ خيارات الميدان
        10 ─ الهوية والهوية العسكرية
        11 ─ العتاد
        12 ─ الاستنفار الأمني
        13 ─ الحواجز والشوك
        14 ─ التعميمات وسحب العساكر
        15 ─ البلاغات والمطلوبين والاستعلام
        16 ─ الشؤون                (النطاق، الرتب، التصفير، المراقبة)
        17 ─ التوب 10 والنقاط
        18 ─ الآيباد وصور الشخصيات وإدارة اللوحة
        19 ─ الواجهة والإشعارات والأصوات
        20 ─ رسائل الشات

     باقي الملفات:
        config/config.lua        ← القوائم، الأغراض (الحواجز، العتاد، المخالفات...)، الرتب والصلاحيات
        config/coords.lua        ← الإحداثيات
        config/integrations.lua  ← الربط مع أنظمة سيرفرك
        config/notifications.lua ← كلام الإشعارات
        config/locale.lua        ← باقي النصوص
        config/server.lua        ← الويب هوكات والتوكنات (سري)

     أنواع القيم:
        true / false  ← تشغيل / إيقاف
        "نص"          ← بين علامتين تنصيص
        رقم           ← بدون تنصيص (ثواني، دقائق، متر... مكتوب جنب كل واحد)

     أرقام الأزرار (للخيارات اللي تطلب رقم زر):
        38 E · 47 G · 166 F5 · 167 F6 · 194 BACKSPACE · 177 BACKSPACE (بديل)
        القائمة الكاملة: https://docs.fivem.net/docs/game-references/controls/
]]


--[[ ═══════════════════════════════════════════════════════════════════════
     1 ─ الأساسيات
     ═══════════════════════════════════════════════════════════════════════ ]]

-- يطبع معلومات تشخيص في الكونسول (للمطور). خله false في السيرفر الرسمي.
Config.Debug = false

Config.Framework = {
    Resource = "vrp",            -- اسم مجلد vRP في السيرفر
    CallStyle = "auto",          -- طريقة استدعاء vRP: "auto" (تلقائي) | "legacy" | "modern"
    JobGroupType = "job",        -- نوع قروب الوظيفة في vRP (gtype) اللي ينعرض كوظيفة اللاعب
    ReadGroupsConfig = true,     -- يقرأ قروبات vRP عشان يتأكد إن الرتب موجودة ويخفي الرتب الوهمية
    GroupRefreshSeconds = 180,   -- كل كم ثانية يتأكد من رتب اللاعبين (لو تغيّرت من سكربت ثاني بدون إيفنت)
                                 -- يتوزع على اللاعبين واحد واحد، فما يثقل السيرفر
}

-- OneSync: "auto" يقرأ إعداد السيرفر بنفسه | true شغّال | false طافي. ينصح فيه بقوة.
Config.OneSync = "auto"

Config.Database = {
    Driver = "auto",             -- نوع قاعدة البيانات: "auto" | "oxmysql" | "mysql-async" | "ghmattimysql" | "custom"
    AutoCreateTables = true,     -- ينشئ جداول السكربت تلقائياً أول ما يشتغل
    LogsKeepDays = 30,           -- السجلات (جدول bofaisal_police_logs) تنحذف بعد كم يوم، 0 = تظل للأبد

    -- Driver = "custom": دوالك أنت (كل دالة تستلم sql و params و cb)
    -- Custom = {
    --     query   = function(sql, params, cb) cb(النتائج) end,     -- SELECT ← قائمة صفوف
    --     execute = function(sql, params, cb) cb(عدد_الصفوف) end,  -- UPDATE / DELETE
    --     insert  = function(sql, params, cb) cb(رقم_الصف) end,    -- INSERT ← insertId
    -- },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     2 ─ الخدمة والحضور
     ═══════════════════════════════════════════════════════════════════════
     العسكري يطلع من الخدمة تلقائياً إذا خرج من السيرفر.
]]

Config.Duty = {
    HeartbeatInterval = 60,      -- كل كم ثانية ينحفظ وقت الحضور
    MaxStaleSessionHours = 12,   -- أقصى مدة جلسة تنحسب إذا طاح السيرفر والعسكري مسجل دخول (بالساعات)
    MenuOnlyClockWhenOff = true, -- true = العسكري الغير مسجل دخول ما تطلع له في قائمة الشرطة إلا "تسجيل الدخول"

    -- الأشياء اللي تحتاج العسكري يكون مسجل دخول: true = لازم يسجل دخول | false = بدون
    RequireDutyFor = {
        citizenInquiry = true,  -- استعلام عن مواطن
        wanted = true,           -- تعميم بلاغ / إضافة مطلوب
        fines = true,            -- المخالفات
        jail = true,             -- السجن
        field = true,            -- خيارات الميدان
        equipment = true,        -- العتاد
        securityAlert = true,    -- الاستنفار الأمني
        impound = true,          -- حجز المركبات
        barricades = true,       -- الحواجز
        reports = true,          -- البلاغات
        inquiries = true,        -- الاستعلامات
    },
}

Config.MilitaryCode = {
    -- "manual" = كل عسكري يكتب كوده بنفسه من مكتبي (صلاحية "militaryCode")
    -- "roster" = الكود ياخذ كود العسكري في الجدول العسكري تلقائياً (A-1 ...) ويتحدث معه،
    --            ولا يتعدل من مكتبي. يتغير من إعدادات الجدول (صلاحية "rosterManage")
    Mode = "manual",
    MaxLength = 12,              -- أقصى عدد حروف للكود العسكري
    Default = "",                -- الكود الافتراضي للعسكري الجديد (فاضي = بدون)
}


--[[ ═══════════════════════════════════════════════════════════════════════
     3 ─ الإجازات
     ═══════════════════════════════════════════════════════════════════════
     كل عسكري عنده رصيد إجازة بالدقائق.
        * يضغط "أخذ إجازة" ← تنسحب رتبته ويصير عاطل، والرصيد ينقص دقيقة بدقيقة.
        * يخلص الرصيد ← ترجع رتبته تلقائياً.
        * يكسر الإجازة بدري ← ترجع رتبته والدقائق المتبقية ترجع لرصيده.
        * كل ResetEveryDays يوم يرجع رصيد كل العساكر للرصيد الافتراضي (خلّصوه أو لا).
]]

Config.Vacation = {
    InactiveGroup = "عاطل", -- قروب العاطل اللي ياخذه العسكري وقت الإجازة (لازم يكون موجود في قروبات vRP)
    DefaultBalance = 120,         -- الرصيد الافتراضي بالدقائق (للعسكري الجديد وعند كل تجديد)
    MaxBalance = 500,             -- أقصى رصيد ممكن بالدقائق (لما القادة يضيفون رصيد)
    MinBalance = 1,               -- أقل رصيد يسمح بأخذ إجازة (بالدقائق)
    ResetEveryDays = 7,           -- كل كم يوم يتجدد الرصيد للكل (0 = ما يتجدد)
    CheckInterval = 30,           -- كل كم ثانية يتأكد من انتهاء الإجازات والتجديد
    CountOffline = false,         -- false = الإجازة توقف لما يطلع من السيرفر وتكمل لما يرجع
                                  -- true  = تمشي بالوقت الحقيقي حتى وهو طالع
}


--[[ ═══════════════════════════════════════════════════════════════════════
     4 ─ التأكيد (F5 = قبول / F6 = رفض) واختيار أقرب لاعب
     ═══════════════════════════════════════════════════════════════════════ ]]

Config.Confirm = {
    AcceptKey = 166,       -- رقم زر القبول في اللعبة (166 = F5)
    RejectKey = 167,       -- رقم زر الرفض (167 = F6)
    AcceptLabel = "F5",    -- اسم زر القبول اللي يظهر على الشاشة
    RejectLabel = "F6",    -- اسم زر الرفض اللي يظهر على الشاشة
    DefaultTimeout = 30,   -- كم ثانية قبل ما ينلغي الطلب لو ما أحد رد

    -- مين يأكد كل إجراء: "target" (اللاعب المستهدف) | "self" (العسكري نفسه) | false (بدون تأكيد)
    Actions = {
        fine = "self",            -- المخالفة
        jail = "self",            -- السجن
        recall = "self",          -- سحب العساكر (كل عسكري ينسحب يأكد بنفسه دائماً)
        identity = "target",      -- عرض الهوية
        jailModify = "self",      -- تعديل مدة السجن
        jailRelease = "self",     -- فك السجن
        impound = "self",         -- حجز مركبة
        impoundRelease = "self",  -- فك حجز مركبة
        dismiss = "self",         -- فصل
        recruit = false,          -- توظيف
        resetAttendance = "self", -- تصفير تواجد
        resetFines = "self",      -- تصفير مخالفات
        resetData = "self",       -- تصفير بيانات
        vacationBalance = false,  -- إضافة رصيد إجازة
        vacationBreak = "self",   -- كسر إجازة عسكري
    },
}

-- اختيار أقرب لاعب (المخالفات، السجن، الميدان)
-- كل الخيارات اللي تنطبق على لاعب (المخالفة، السجن، الكلبشة، السحب، الإدخال والإخراج من المركبة...)
-- تنفذ على أقرب لاعب منك مباشرة، بدون قائمة تختار منها.
Config.Targeting = {
    Radius = 4.0,     -- أقصى مسافة للاعب القريب (متر)
    AllowSelf = false, -- true = تقدر تسوي كل شي على نفسك (للتجربة): المخالفة، السجن، خيارات الميدان،
                      --        البلاغ، المطلوبين، المراقبة، السحب، الكفالة، والشؤون (توظيف، ترقية، فصل، تصفير...)
                      --        حماية العساكر (Config.OfficerProtection) ما تمنعك عن نفسك
                      -- false = ما تقدر تنفذ شي على نفسك. طفّه في السيرفر الرسمي!
                      -- (ينفذ على نفسك بس إذا ما فيه أحد قريب منك)
}

-- العساكر على رأس عملهم (عندهم رتبة عسكرية) ما تنطبق عليهم هذي الأشياء.
-- العسكري اللي في إجازة يعتبر مواطن عادي وتنطبق عليه.
Config.OfficerProtection = {
    Fines   = true,  -- ما ينخالف
    Jail    = true,  -- ما ينسجن
    Reports = true,  -- ما ينبلغ عنه (إبلاغ عن مجرم / تعميم بلاغ)
    Wanted  = true,  -- ما ينضاف لقائمة المطلوبين
}


-- الموانع: برمشنات vRP، اللي عنده البرمشن في قروبه (رتبته) ما يقدر الشرطي يسجنه / يكلبشه / يسحبه /
-- يخالفه / يحجز مركبته (يطلع للشرطي "لا يمكنك سجن هذا اللاعب" وغيرها، والنص في config/notifications.lua).
-- انسخ البرمشن وحطه في القروب اللي تبيه داخل vrp/cfg/groups.lua، مثال:
--     ["vip"] = { _config = { ... }, "police.nojail", "police.nocuff", "police.nodrag" },
-- المانع يشتغل فوراً أول ما ينعطى اللاعب القروب (بدون ريستارت). فك الكلبشة وترك السحب يظلون مسموحين.
-- false = المانع طافي
Config.Immunity = {
    Jail    = "player.owner",     -- منع سجن
    Cuff    = "player.owner",     -- منع كلبشة
    Drag    = "player.owner",     -- منع سحب
    Fine    = "player.owner",     -- منع مخالفة
    Impound = "player.owner",  -- منع حجز المركبة (يشتغل حتى لو صاحب المركبة طالع من السيرفر)
}


--[[ ═══════════════════════════════════════════════════════════════════════
     5 ─ أوامر الشات والأزرار (اختصارات لقائمة الشرطة)
     ═══════════════════════════════════════════════════════════════════════
     كل أمر يفتح نفس اللي يفتحه زره في القائمة، بنفس الصلاحيات ونفس شرط الخدمة.
     enabled = تشغيل الأمر (false = مطفي)
     command = اسم الأمر في الشات بدون "/" (غيّره لو فيه سكربت ثاني يستخدم نفس الاسم)
     key     = زر اختياري يفتحه مباشرة، مثال "F7" (false = بدون زر)
               اللاعب يقدر يغيّر الزر من إعدادات اللعبة ← Key Bindings ← FiveM
     label   = الوصف اللي يطلع تحت الأمر في الشات وفي إعدادات الأزرار

     تقدر تغيّر command و key و label و enabled بدون ما يتأثر شي:
        * اكتب الاسم بدون "/" وبدون مسافات (لو كتبت "/" ينشال تلقائياً)
        * لو اسمين متكررين يشتغل الأول بس، والكونسول يكتب لك أي واحد تكرر
        * لا تغيّر الاسم اللي قبل "=" (مثل Cuff أو Jail)، هذا اللي يعرف فيه السكربت الأمر
     الأوامر المطفية (enabled = false) أسماؤها منتشرة في سكربتات ثانية، شغّلها إذا ما عندك تعارض.
     بعد أي تعديل: restart BoFaisaL_Police
     (أمر قائمة السكربت المدمجة في config/integrations.lua ← BuilderMenu.builtin، يستخدم بس لو type = "builtin")
]]

Config.Commands = {
    -- القوائم
    Police         = { enabled = false, command = "police",     key = false, label = "قائمة الشرطة" },
    Ipad           = { enabled = true,  command = "tablet",     key = false, label = "القائمة العسكرية" },
    Clock          = { enabled = false, command = "duty",       key = false, label = "تسجيل الدخول / الخروج" },
    Fines          = { enabled = true,  command = "fine",       key = false, label = "المخالفات" },
    Jail           = { enabled = true,  command = "jail",       key = false, label = "السجن" },
    Badge          = { enabled = true,  command = "badge",      key = false, label = "إظهار الهوية العسكرية" },
    Barricades     = { enabled = false, command = "barrier",    key = false, label = "الحواجز" },
    Equipment      = { enabled = false, command = "gear",       key = false, label = "أخذ العتاد" },
    SecurityAlert  = { enabled = false, command = "alert",      key = false, label = "الاستنفار الأمني" },

    -- الميدان
    Identity       = { enabled = true,  command = "requestid",  key = false, label = "طلب الهوية", everyone = true }, -- everyone = أي لاعب يقدر يطلب الهوية (مو بس العساكر)
    Search         = { enabled = true,  command = "searchbag",  key = false, label = "تفتيش الحقيبة" },
    VehicleSearch  = { enabled = true,  command = "searchcar",  key = false, label = "تفتيش السيارة" },
    Cuff           = { enabled = false, command = "cuff",       key = false, label = "كلبشة / فك الكلبشة" },
    Drag           = { enabled = false, command = "dragg",       key = false, label = "سحب" },

    -- الاستعلامات والإجراءات
    CitizenInquiry = { enabled = false, command = "citizen",    key = false, label = "استعلام عن مواطن" },
    Wanted         = { enabled = false, command = "wanted",     key = false, label = "تعميم بلاغ" },
    FineInquiry    = { enabled = false, command = "fines",      key = false, label = "استعلام عن مخالفات" },
    JailCheck      = { enabled = true,  command = "jailcheck",  key = false, label = "استعلام عن سجن لاعب" },
    JailRelease    = { enabled = true,  command = "unjail",     key = false, label = "فك سجن لاعب" },
    Impound        = { enabled = false, command = "impound",    key = false, label = "حجز مركبة" },

    -- للمواطنين
    Report         = { enabled = false, command = "report",     key = false, label = "إبلاغ عن مجرم" },
    Absher         = { enabled = true, command = "absher",     key = false, label = "منصة أبشر" },

    -- الإدارة
    StopSpectate   = { enabled = true,  command = "bofaisal_stopspectate", key = false, label = "إيقاف المراقبة (طوارئ)" },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     6 ─ المخالفات
     ═══════════════════════════════════════════════════════════════════════
     قائمة المخالفات في config/config.lua ← 2.3  ·  نقاط السداد في config/coords.lua ← 3
]]

Config.Fines = {
    PaymentMethod = "full",   -- طريقة الدفع: "wallet" (الكاش) | "bank" (البنك) | "full" (الكاش ثم البنك)
    AutoCharge = false,       -- true = يخصم المبلغ مباشرة بعد المخالفة | false = يدفعها في نقطة السداد
    ConfirmTimeout = 30,      -- ثواني للرد على المخالفة
    Cooldown = 5,             -- ثواني بين كل مخالفتين لنفس العسكري
    InquiryLimit = 7,        -- أقصى عدد مخالفات يقرأها الاستعلام
    MaxAmount = 0,            -- أقصى مبلغ للمخالفة الوحدة (0 = بدون حد)
                              -- لو مخالفة في القائمة مبلغها أكبر، تنكتب بالحد الأقصى بس

    -- الوصل
    Receipt = true,           -- وصل مخالفة ورقي يطلع للي جته المخالفة (يتسكّر بـ F5)، false = إشعار عادي بس
    ReceiptSeconds = 15,      -- كم ثانية يظل الوصل

    -- نسبة العسكري
    OfficerShare = 30,        -- نسبة العسكري من كل مخالفة يحررها (%)، 0 = بدون نسبة
    ShareOn = "issue",        -- متى ياخذ نسبته: "issue" أول ما يحرر المخالفة | "paid" لما تندفع المخالفة
                              -- (مع "paid" لازم نظام الفلوس يقدر يعطي لاعب مو متصل، أو تضيع نسبته لو طالع)
}


--[[ ═══════════════════════════════════════════════════════════════════════
     7 ─ السجن
     ═══════════════════════════════════════════════════════════════════════
     أسباب السجن في config/config.lua ← 2.4  ·  المواقع والمهام في config/coords.lua ← 1 و 2
     كل دقيقة سجن = شهر (في الشات والعداد).
]]

Config.Jail = {
    Name = "السجن المركزي",     -- اسم السجن اللي يظهر للاعب

    CountOfflineTime = false,   -- false = المدة تنقص بس وهو داخل السيرفر | true = تنقص حتى لو طالع
    MinMinutes = 1,             -- أقل مدة سجن (بالدقائق)
    MaxMinutes = 300,           -- أقصى مدة سجن (بالدقائق): لا السجن ولا التعديل ولا زيادة الهروب يتعدّاها
                                -- لو سبب سجن مدته أطول، يتسجن بالحد الأقصى بس
    ConfirmTimeout = 30,        -- ثواني للرد على السجن
    PersistInterval = 30,       -- كل كم ثانية تنحفظ المدة في قاعدة البيانات
    BlockWeapons = true,        -- السجين ما يقدر يطلّع سلاح ولا يضرب داخل السجن

    Handcuff = {
        Enabled = true,          -- يكلبش السجين
        RemoveOnRelease = true,   -- يفك الكلبشة عند الإفراج
        Enforce = true,          -- يرجع يكلبشه لو انفكت
        EnforceInterval = 15,     -- كل كم ثانية يتأكد من الكلبشة
    },

    -- لبس السجن (اللبس الأصلي ينحفظ ويرجع عند الإفراج)
    --   components = [رقم القطعة] = { رقم الموديل, رقم اللون }
    --   props      = [رقم الإكسسوار] = { رقم الموديل, رقم اللون } (-1 = يشيله)
    Clothing = {
        Enabled = true,           -- يلبّس السجين لبس السجن
        Uniform = true,           -- لبس موحد: يشيل القناع والشنطة والسلاسل والدرع والقبعة والنظارة وكل الإكسسوارات
                                  -- وما يطلع شي فوق لبس السجن (يرجع كله مع لبسه عند الإفراج)
        Male = {
            components = { [3] = { 0, 0 }, [4] = { 3, 7 }, [6] = { 12, 12 }, [8] = { 15, 0 }, [11] = { 146, 0 } },
            props = { [0] = { -1, 0 } },
        },
        Female = {
            components = { [3] = { 2, 0 }, [4] = { 3, 15 }, [6] = { 66, 5 }, [8] = { 3, 0 }, [11] = { 38, 3 } },
            props = { [0] = { -1, 0 } },
        },
    },

    -- الكفالة (من نقطة سداد المخالفات ← كفالة المساجين): أي لاعب يدفع ويطلّع السجين
    Bail = {
        Enabled = true,           -- تشغيل الكفالة
        PricePerMonth = 100000,     -- سعر كل شهر باقي من السجن (مثال: 1000000 = مليون للشهر)
        MinPrice = 0,             -- أقل سعر للكفالة
        MaxPrice = 0,             -- أعلى سعر (0 = بدون حد)
        BlockedReasons = {},      -- أسباب سجن ما لها كفالة، مثال: { "murder" } (رقم السبب id من قائمة أسباب السجن)
    },

    Escape = {
        Enabled = true,           -- يمنع الهروب ويرجّع الهارب
        AddMinutes = 1,           -- دقائق تنضاف مع كل محاولة هروب (0 = بدون)
        MaxAddedMinutes = 10,     -- أقصى زيادة بسبب الهروب لنفس المحكومية
        CheckInterval = 2,        -- كل كم ثانية يتأكد من مكان السجين
        Message = "وين رايح يا عسل؟\nإذا حاولت تهرب بتزيد المدة.", -- الرسالة اللي تطلع للهارب
    },

    Hud = {
        Enabled = true,           -- عداد المدة على الشاشة
        Style = "digital",        -- شكله: "digital" ساعة رقمية | "split" قسمين | "minimal" الوقت بس | "strip" الشكل الافتراضي
                                  -- (وتقدر تغيّره من إدارة اللوحة ← الواجهة)
    },

    -- مهام السجن لتقليل المدة (أماكنها في config/coords.lua ← 2)
    Tasks = {
        Enabled = true,           -- تشغيل المهام
        MaxReductionPercent = 50, -- أقصى نسبة تنقصها المهام من المحكومية
        MinRemaining = 60,        -- المهام ما تنزل المدة تحت كذا (ثواني)
        UiStyle = "corners",      -- شكل المهمة على الشاشة: "corners" زوايا | "segments" خط مقسّم | "classic" الشكل الافتراضي
                                  -- (وتقدر تختار لكل مهمة من إدارة اللوحة ← النقاط والأماكن)

        -- أنواع المهام: label = الاسم | scenario أو dict + anim = الحركة
        --   prop = غرض في يد السجين وقت المهمة: model = اسم الغرض | bone = العظمة (28422 = اليد اليمين)
        --          offset = { x, y, z } مكانه في اليد | rotation = { x, y, z } دورانه
        Types = {
            -- التنظيف: حركة الكنس بالمقشة (المقشة في يده)
            clean  = { label = "تنظيف", dict = "anim@amb@drug_field_workers@rake@male_a@base", anim = "base",
                       prop = { model = "prop_tool_broom", bone = 28422, offset = { -0.005, 0.0, 0.0 }, rotation = { 360.0, 360.0, 0.0 } } },
            repair = { label = "إصلاح", dict = "mini@repair", anim = "fixing_a_ped" },
            weld   = { label = "لحام",  scenario = "WORLD_HUMAN_WELDING" },
            garden = { label = "زراعة", scenario = "WORLD_HUMAN_GARDENER_PLANT" },
        },

        -- الصعوبة: checks = عدد الاختبارات | speed = سرعة المؤشر | zone = حجم المنطقة الصحيحة
        Difficulties = {
            easy   = { checks = 1, speed = 1.0,  zone = 0.24 },
            medium = { checks = 2, speed = 1.35, zone = 0.17 },
            hard   = { checks = 3, speed = 1.7,  zone = 0.12 },
        },

        -- شكل علامة المهمة على الأرض (الافتراضي، وتقدر تختار غيره لكل مهمة من إدارة اللوحة) و أيقونتها في الخريطة
        Marker = { type = 21, color = { 37, 99, 235, 170 }, scale = { 0.45, 0.45, 0.45 }, offsetZ = 0.6, bob = true, faceCamera = true, drawDistance = 20.0 },
        Blip = { enabled = true, sprite = 566, color = 38, scale = 0.6 },
    },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     8 ─ حجز المركبات
     ═══════════════════════════════════════════════════════════════════════
     أسباب الحجز في config/config.lua ← 2.5  ·  مراكز الحجز في config/coords.lua ← 4
]]

Config.Impound = {
    PickVehicle = "nearest",   -- كيف يحدد المركبة: "nearest" أقرب مركبة للعسكري (اللوحة تنقرأ منها)
                               --                    "plate" العسكري يكتب اللوحة
    PlateMaxLength = 8,        -- أقصى عدد حروف اللوحة (لـ "plate")
    VehicleRadius = 8.0,       -- أقصى مسافة بين العسكري والمركبة (متر)
    AllowReimpound = false,    -- يسمح بحجز لوحة محجوزة أصلاً
    DeleteVehicle = true,      -- يحذف المركبة من الشارع بعد الحجز
    BlockSpawn = true,         -- المركبة المحجوزة ما تطلع من أي كراج (بدون ربط مع سكربت الكراجات):
                               -- لو حاول يطلعها تنحذف فوراً ويطلع له إنها في الحجز، لين ينفك حجزها
    DefaultFee = 2500,         -- الرسوم إذا كتب العسكري سبب من عنده
    PaymentMethod = "full",    -- طريقة الدفع: "wallet" | "bank" | "full"
    AllowCustomReason = true,  -- يسمح للعسكري يكتب سبب من عنده
    NotifyOwner = true,       -- يبلغ المالك إذا كان متصل
    NotifyOnLogin = false,     -- يذكّر المالك بمركباته المحجوزة لما يدخل
    InquiryLimit = 50,         -- أقصى عدد مركبات يقرأها الاستعلام
}

-- منصة أبشر: خيار في القائمة الرئيسية لكل اللاعبين (تشغيله واسمه في config/config.lua ← Main ← Absher)
-- يفتح لوحة واسعة: المعلومات الشخصية، المخالفات، المركبات، وإحسان
Config.Absher = {
    Appearance = { Accent = "#18b981", Background = "#080f0d", Card = "#141c17", Width = 1280, Height = 88 },
    Title = "أبشر",          -- عنوان منصة الخدمات المدنية
    RemotePay = true,        -- true = يدفع مخالفاته من المنصة من أي مكان | false = المنصة تعرض فقط، والدفع من نقطة السداد
    RemoteRelease = true,    -- true = يفك حجز مركبته من المنصة من أي مكان ويطلّعها من الكراج | false = من مركز الحجز بس
}


--[[ ═══════════════════════════════════════════════════════════════════════
     9 ─ خيارات الميدان
     ═══════════════════════════════════════════════════════════════════════
     تشغيل/إيقاف وأسماء الخيارات في config/config.lua ← 1.2 ← Field
        permission     الصلاحية المطلوبة (من القسم 4 في config.lua). كل خيار له صلاحيته، و"field" في الرتبة = كلها
        confirm        false = بدون تأكيد | "target" = المستهدف يأكد | "self" = العسكري يأكد
        requireCuffed  true = لازم يكون اللاعب مكلبش
]]

Config.Field = {
    Actions = {
        cuff            = { permission = "police.em", confirm = false, requireCuffed = false,
                            officerAnimation = true,   -- حركة العسكري وهو يكلبش (false = بدون)
                            targetAnimation = true },  -- حركة المكلبش (اليدين ورا ظهره). تشتغل مع Handcuff.type = "builtin"
                                                       -- (مع "vrp" الحركة من vRP نفسه)
        seizeWeapons    = { permission = "police.em", confirm = false, requireCuffed = true, giveToOfficer = false, maxAmmo = 250 }, -- giveToOfficer = الأسلحة تروح للعسكري
        drag            = { permission = "police.em", confirm = false, requireCuffed = true },
        search          = { permission = "police.em", confirm = false, requireCuffed = true, showMoney = true, showWeapons = true }, -- يعرض الفلوس والأسلحة
        vehicleSearch   = { permission = "police.em", confirm = false, radius = 5.0, allowSeizeContraband = true }, -- radius = مسافة المركبة
        putInVehicle    = { permission = "police.em", confirm = false, requireCuffed = true, requireDrag = true, radius = 6.0 }, -- requireDrag = لازم يكون ساحبه أول
        pullOutVehicle  = { permission = "police.em", confirm = false, requireCuffed = false },
        seizeContraband = { permission = "police.em", confirm = false, requireCuffed = true, giveToOfficer = false }, -- giveToOfficer = الممنوعات تروح للعسكري
        identity        = { permission = "police.em", confirm = "target" },
    },
    Cooldown = 1,   -- ملي ثانية بين كل إجراءين لنفس العسكري
    -- giveToOfficer في "seizeWeapons": بس الأسلحة اللي في هالقائمة تروح للعسكري.
    -- أي سلاح ثاني ينسحب من اللاعب عادي بس ما ينعطى للعسكري (قائمة الأسلحة تجي من لعبة اللاعب،
    -- والغشاش يقدر يزوّرها عشان يعطي العسكري سلاح ثقيل). ضيف أي سلاح تبيه هنا.
    GiveWeapons = {
        "WEAPON_KNIFE", "WEAPON_NIGHTSTICK", "WEAPON_HAMMER", "WEAPON_BAT", "WEAPON_CROWBAR", "WEAPON_FLASHLIGHT",
        "WEAPON_MACHETE", "WEAPON_SWITCHBLADE", "WEAPON_KNUCKLE", "WEAPON_BOTTLE", "WEAPON_DAGGER", "WEAPON_HATCHET",
        "WEAPON_PISTOL", "WEAPON_PISTOL_MK2", "WEAPON_COMBATPISTOL", "WEAPON_APPISTOL", "WEAPON_STUNGUN", "WEAPON_PISTOL50",
        "WEAPON_SNSPISTOL", "WEAPON_HEAVYPISTOL", "WEAPON_VINTAGEPISTOL", "WEAPON_REVOLVER",
        "WEAPON_MICROSMG", "WEAPON_SMG", "WEAPON_ASSAULTSMG", "WEAPON_COMBATPDW", "WEAPON_MACHINEPISTOL", "WEAPON_MINISMG",
        "WEAPON_PUMPSHOTGUN", "WEAPON_SAWNOFFSHOTGUN", "WEAPON_ASSAULTSHOTGUN", "WEAPON_BULLPUPSHOTGUN",
        "WEAPON_ASSAULTRIFLE", "WEAPON_CARBINERIFLE", "WEAPON_ADVANCEDRIFLE", "WEAPON_SPECIALCARBINE", "WEAPON_BULLPUPRIFLE",
        "WEAPON_COMPACTRIFLE", "WEAPON_GUSENBERG",
    },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     10 ─ الهوية والهوية العسكرية
     ═══════════════════════════════════════════════════════════════════════ ]]

-- بطاقة الهوية (عرض الهوية من خيارات الميدان)
Config.IdCard = {
    Title = "بطاقة الهوية الوطنية",       -- عنوان البطاقة
    Country = "المملكة العربية السعودية", -- اسم الدولة فوق البطاقة
    Duration = 10,                       -- كم ثانية تظل البطاقة على الشاشة
    Animation = { dict = "mp_common", name = "givetake1_a", duration = 1500 }, -- حركة إعطاء الهوية
}

-- إظهار الهوية العسكرية: العسكري يطلّع هويته بحركة، واللي قدامه يشوف بطاقته كم ثانية.
-- الاسم والرتبة والقطاع والوزارة وصورة الشخصية من بيانات العسكري نفسه.
Config.Badge = {
    Country = "المملكة العربية السعودية", -- العنوان اللي فوق في البطاقة
    Title = "الهوية العسكرية",               -- نوع البطاقة (فوق على اليسار)
    Distance = 3.0,                       -- اللاعبين اللي قدامه بهالمسافة يشوفون البطاقة (متر)
    Seconds = 8,                          -- كم ثانية تظل البطاقة على الشاشة
    ShowSelf = false,                     -- false = تطلع بس للاعبين القريبين | true = العسكري يشوف بطاقته بعد
    RequireDuty = true,                  -- true = لازم يكون مسجل دخول عشان يطلّعها
    Cooldown = 5,                         -- ثواني بين كل مرتين

    -- الحقول اللي تطلع في البطاقة (false = تختفي)
    Fields = { number = true, name = true, rank = true, sector = true, issued = true },

    -- الحركة والبطاقة في اليد
    Animation = true,
    AnimDict = "paper_1_rcm_alt1-9", AnimName = "player_one_dual-9",
    AnimSeconds = 3,
    Prop = { model = "prop_fib_badge", bone = 28422, offset = { 0.065, 0.029, -0.035 }, rotation = { 80.0, -1.9, 75.0 } },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     11 ─ العتاد
     ═══════════════════════════════════════════════════════════════════════
     قائمة العتاد في config/config.lua ← 2.2
]]

Config.Equipment = {
    Cooldown = 120,          -- ثواني بين كل عتادين لنفس العسكري
    ReturnEnabled = true,    -- زر "تسليم العتاد"
    ReturnMode = "kit",      -- "kit" يسحب بس أسلحة العتاد | "all" يسحب كل الأسلحة
    StripOnClockOut = true,  -- تنسحب أسلحة العتاد لما يسجل خروج (أو يطلع من السيرفر وهو مسجل دخول: تنسحب لما يرجع)
    StripOnDismiss = true,   -- تنسحب أسلحة العتاد لما ينفصل (لو طالع تنسحب لما يرجع)
                             -- (الأسلحة الشخصية اللي مو من العتاد تظل معه)
}

--[[ ═══════════════════════════════════════════════════════════════════════
     12 ─ الاستنفار الأمني
     ═══════════════════════════════════════════════════════════════════════
     الاستنفار يصير دائرة حول العسكري اللي بدأه (هو في منتصفها).
     كل عسكري يقدر يسوي استنفار واحد بس. "إيقاف استنفار" يوقف استنفاره هو،
     وإذا ما عنده استنفار شغّال يوقف الاستنفار اللي هو داخل حدوده (حتى لو مو حقه).
     إذا خرج العسكري من السيرفر، استنفاره يوقف تلقائياً.
     اللي داخل الدائرة وقت بدء الاستنفار ما يتأثر، واللي يدخل بعدها يتأثر.
]]

Config.SecurityAlert = {
    Radius = 57.0,               -- نصف قطر دائرة الاستنفار (متر)
    MaxActive = 10,              -- أقصى عدد استنفارات بنفس الوقت في السيرفر

    MapZone = {
        enabled = true,          -- يرسم الدائرة في الخريطة
        color = 1,               -- لون الدائرة (1 = أحمر)
        alpha = 110,             -- شفافية الدائرة (0 - 255)
        blip = { enabled = true, sprite = 161, color = 1, scale = 1.2, label = "استنفار أمني" }, -- أيقونة الخريطة
    },

    VehicleSlowdown = { enabled = true, maxSpeed = 30.0 },  -- يحد سرعة المركبات داخل الدائرة (كم/س)
    PlayerSlowdown = { enabled = true, disableSprint = true, disableJump = true, moveRate = 0.85 }, -- يبطّئ المشي ويمنع الركض والقفز
    WeaponBan = { enabled = true, vehicle = true }, -- اللي يدخل بعد بدء الاستنفار ما يقدر يطلّع سلاح داخل الدائرة
                                                    -- vehicle = يمنع الإطلاق من السيارة بعد

    ExemptOfficers = true,        -- قوانين الاستنفار ما تنطبق على العساكر، حتى لو دخلوا من برا الدائرة
    ExemptOnlyOnDuty = true,      -- true = بس العساكر المسجلين دخول · false = كل العساكر حتى لو مو مسجلين دخول
    ExemptionEndsOnExit = true,   -- اللي كان داخل وطلع ورجع يعتبر دخول جديد (يتأثر)
    AnnounceToCitizens = true,    -- إنذار على الشاشة عند البدء والإيقاف
    AnnounceDistance = 300.0,     -- الإنذار يوصل بس للي داخل الدائرة + هالمسافة (متر)
    CheckInterval = 400,          -- كل كم ملي ثانية يتأكد اللاعب داخل أو لا
}


--[[ ═══════════════════════════════════════════════════════════════════════
     13 ─ الحواجز والشوك
     ═══════════════════════════════════════════════════════════════════════
     أنواع الحواجز في config/config.lua ← 2.1
]]

Config.BarricadeOptions = {
    MaxPerOfficer = 10,           -- أقصى عدد حواجز لكل عسكري
    MaxTotal = 80,                -- أقصى عدد حواجز في السيرفر كله
    PlaceDistance = 2.2,          -- مسافة الحاجز قدام العسكري (متر)
    MaxPlaceDistance = 6.0,       -- أقصى مسافة يسمح فيها السيرفر (حماية)
    DeleteRadius = 3.5,           -- مسافة "إزالة أقرب حاجز" (متر)
    LifetimeMinutes = 60,         -- الحاجز ينحذف بعد كم دقيقة (0 = ما ينحذف)
    DeleteOnDisconnect = true,    -- تنحذف حواجز العسكري إذا خرج من السيرفر

    -- الشوك (أي حاجز في القائمة فيه spikes = true)
    Spikes = {
        Radius = 1.8,             -- كم متر من وسط الشوك يفجّر الكفر اللي يمشي فوقه
        Deploy = true,            -- حركة انفراش الشوك على الأرض لما ينحط
        PlaceAnimation = true,    -- العسكري ينزل ويحط الشوك على الأرض
        IgnoreEmergency = false,  -- true = سيارات الطوارئ (الشرطة والإسعاف) ما تتأثر بالشوك
    },
}


--[[ ═══════════════════════════════════════════════════════════════════════
     14 ─ التعميمات وسحب العساكر
     ═══════════════════════════════════════════════════════════════════════ ]]

Config.Broadcast = {
    OfficerEnabled = true,        -- تفعيل "تعميم على العساكر"
    CitizenEnabled = true,        -- تفعيل "تعميم على المواطنين"
    -- عنوان التعميم = وزارة المرسل (وزارة الداخلية / وزارة الدفاع / أي وزارة تضيفها / رئاسة الوزراء)
    TitleByMinistry = true,
    OfficerTitle = "تعميم عسكري", -- العنوان لو TitleByMinistry = false
    CitizenTitle = "تعميم",       -- العنوان لو TitleByMinistry = false
    OfficerAudience = "all",   -- مين يشوف تعميم العساكر: "all" كل العساكر | "scope" نطاق المرسل | "onduty" المسجلين دخول
    Duration = 12,                -- كم ثانية يظل التعميم على الشاشة
    MaxLength = 300,              -- أقصى عدد حروف للتعميم
    Cooldown = 30,                -- ثواني بين كل تعميمين لنفس الشخص
    ShowSender = true,            -- يكتب اسم المرسل ورتبته تحت التعميم
    Style = {
        top = "26%",              -- مكان التعميم من فوق الشاشة
        width = "560px",          -- عرض التعميم
        animation = "slide",      -- طريقة الظهور: "slide" | "fade" | "zoom"
        officerAccent = "#18b981", -- لون خط تعميم العساكر
        citizenAccent = "#3b82f6", -- لون خط تعميم المواطنين
    },
    Sound = { enabled = true, name = "CHECKPOINT_PERFECT", set = "HUD_MINI_GAME_SOUNDSET" }, -- صوت التعميم
}

-- سحب العساكر: كل عسكري يوصله يقبل بـ F5 أو يرفض بـ F6
Config.Recall = {
    Timeout = 45,              -- ثواني للرد
    Cooldown = 5,            -- ثواني بين كل سحبين لنفس الشخص
    IncludeOffDuty = true,     -- true = يوصل حتى للي مو مسجلين دخول | false = المسجلين دخول بس
    Waypoint = "caller",       -- وين يروح اللي يقبل: "caller" مكان الطالب | "hq" المقر (config/coords.lua ← 5) | "none" ما يروح مكان
    Teleport = true,           -- true = ينتقل فوراً للمكان لما يضغط F5 | false = تنحط له نقطة في الخريطة بس
    AutoClockIn = false,       -- اللي يقبل يتسجل دخول تلقائياً
    Scope = "sector",          -- مين يوصله السحب:
                               --   "sector" = رتبة القطاع ← عساكر قطاعه | الوزير ← كل قطاعات وزارته | رئاسة الوزراء ← كل العساكر
                               --   "all"    = كل العساكر المتصلين لأي أحد
    DefaultMessage = "مطلوب حضوركم إلى موقع الاستدعاء فوراً", -- الرسالة لو ما كتب الطالب شي
}


--[[ ═══════════════════════════════════════════════════════════════════════
     15 ─ البلاغات والمطلوبين والاستعلام
     ═══════════════════════════════════════════════════════════════════════ ]]

Config.Reports = {
    Cooldown = 60,                -- ثواني بين كل بلاغين لنفس المواطن
    MaxOpenPerReporter = 1,       -- أقصى عدد بلاغات مفتوحة لنفس المواطن
    MaxReasonLength = 250,        -- أقصى عدد حروف لسبب البلاغ
    ExpireMinutes = 90,           -- البلاغ ينتهي بعد كم دقيقة من تقديمه (استُلم أو لا)
    OneAtATime = true,            -- العسكري ما يقدر يستلم أكثر من بلاغ بنفس الوقت
    NotifyOfficers = "onduty",    -- مين يوصله إشعار البلاغ الجديد: "onduty" | "all" | "none"
    NotifyReporterOnClaim = true, -- يبلغ المواطن لما عسكري يستلم بلاغه
    AllowSelfReport = false,      -- يسمح للاعب يبلغ عن نفسه
    OnlineTargetsOnly = true,    -- true = البلاغ يكون بس على لاعب متصل (اللي مو متصل ما ينقبل البلاغ عليه)
    StoreLocation = true,         -- يحفظ مكان البلاغ عشان العسكري يحط عليه نقطة
    ListLimit = 100,              -- أقصى عدد بلاغات تظهر في القائمة
    Alert = true,                 -- إنذار على الشاشة للبلاغ الجديد (نفس شكل إنذار المطلوب) لنفس اللي يوصلهم إشعار البلاغ
    QuickOpen = { enabled = true, key = 47, label = "G", seconds = 10 }, -- زر فتح صفحة البلاغات من الإنذار (47 = G) ومدة الإنذار
}

Config.Wanted = {
    MaxReasonLength = 250,     -- أقصى عدد حروف لسبب التعميم
    NotifyOfficers = "onduty", -- مين يوصله إنذار المطلوب الجديد: "onduty" | "all"
    ClearOnJail = true,        -- يشيله من المطلوبين إذا انسجن
    QuickOpen = { enabled = true, key = 47, label = "G", seconds = 10 }, -- زر فتح قائمة المطلوبين من الإنذار (47 = G) ومدة الإنذار
    ListLimit = 100,           -- أقصى عدد مطلوبين يظهرون
    AlertStyle = "poster",     -- شكل إنذار المطلوب: "poster" بوستر بصورة الشخصية | "classic" الشكل الافتراضي
                               -- (وتقدر تغيّره من إدارة اللوحة ← الواجهة)
}

-- استعلام عن مواطن
Config.CitizenInquiry = {
    History = 3,               -- كم آخر مخالفة وآخر حالة سجن تظهر
}


--[[ ═══════════════════════════════════════════════════════════════════════
     16 ─ الشؤون
     ═══════════════════════════════════════════════════════════════════════ ]]

Config.Affairs = {
    -- الصلاحيات اللي تشتغل على أي عسكري (بدون نطاق القطاع). true = بدون نطاق | false = نطاق الرتبة بس
    NoScope = {
        monitor = false,          -- مراقبة العساكر
        vacationBalance = false,  -- إضافة رصيد إجازة
        officerInquiry = false,   -- استعلام عن عسكري
        resetAttendance = false,  -- تصفير تواجد
        resetFines = false,       -- تصفير مخالفات
        resetData = false,        -- تصفير بيانات
        recall = false,           -- (ما يأثر على السحب: نطاقه من Config.Recall.Scope)
        vacationBreak = false,   -- كسر إجازة عسكري
        recruit = false,         -- توظيف (ينصح يظل بالنطاق)
        dismiss = false,         -- فصل (ينصح يظل بالنطاق)
        statistics = false,      -- توب 10
    },
    RecruitRadius = 10.0,        -- التوظيف يعرض اللاعبين القريبين منك بهالمسافة (متر)
}

-- الترقية وكسر الرتبة والفصل
Config.Hierarchy = {
    -- كيف تدير الرتبة رتب نفس مستواها (نفس القطاع / نفس الوزارة):
    --   "junior" ← بس الرتب اللي تحتها (النائب ما يقدر يفصل القائد)
    --   "all"    ← كل رتب نفس المستوى
    --   "none"   ← بس المستويات الأقل
    SameContainer = "junior",
    AllowSelfManagement = false, -- يقدر يسوي إجراءات إدارية على نفسه؟
}

-- وش ينمسح في "تصفير بيانات عسكري" (true = ينمسح)
Config.Reset = {
    Data = {
        attendance = true,         -- إجمالي الحضور
        attendanceHistory = false, -- سجل الجلسات
        fines = true,              -- عدد المخالفات اللي حررها
        jails = true,              -- عدد حالات السجن
        reports = true,            -- عدد البلاغات المنجزة
        impounds = true,           -- عدد المركبات المحجوزة
        vacationBalance = false,   -- يرجع رصيد الإجازة للافتراضي
        militaryCode = false,      -- يمسح الكود العسكري
    },
}

-- الجدول العسكري (صفحة في الآيباد): كل قطاع ينقسم لثلاث أقسام، كل قسم بحرف (تغيّر الحروف من إعدادات الجدول).
-- قسم كل رتبة: اكتب tier في الرتبة نفسها في config/config.lua ← Config.Government، مثال:
--     { group = "ps_officer", label = "ضابط أمن عام", tier = "officers" },
--     tier = "command" القيادة | "officers" الضباط | "enlisted" الأفراد
-- بدون tier: السكربت يعرفه من اسم الرتبة بالكلمات تحت (اللي ما فيها ولا كلمة = أفراد).
Config.Roster = {
    Tiers = {                -- اسم كل قسم (يطلع بعد اسم القطاع)
        command  = "القيادة",
        officers = "الضباط",
        enlisted = "الأفراد",
    },
    TierWords = {
        command  = { "قائد", "مدير", "نائب", "مستشار", "مسؤول", "مسئول" },
        officers = { "ضابط", "ملازم", "نقيب", "رائد", "مقدم", "عقيد", "عميد", "لواء", "فريق" },
    },
    -- الجدول يتحدث بنفسه مع أي تغيير من السكربت (توظيف، فصل، ترقية، إجازة...).
    -- هذا بس للعساكر الغير متصلين اللي تغيرت رتبتهم من برا السكربت (قاعدة البيانات أو سكربت ثاني):
    -- كل كم دقيقة يتأكد من رتبهم (خفيف: يقرأ القروبات بس، على دفعات). 0 = ما يتأكد (يتحدثون لما يدخلون)
    SyncOfflineMinutes = 30,
}

-- مراقبة العساكر / السجناء
Config.Spectate = {
    StopKey = 194,                  -- زر إيقاف المراقبة (194 = BACKSPACE)
    StopKeyLabel = "BACKSPACE",     -- اسم الزر اللي يظهر على الشاشة
    FollowInterval = 500,           -- كل كم ملي ثانية تتحدث الكاميرا
    -- أمر الطوارئ لإيقاف المراقبة صار في القسم 5 ← Config.Commands.StopSpectate
}


--[[ ═══════════════════════════════════════════════════════════════════════
     17 ─ التوب 10 والنقاط
     ═══════════════════════════════════════════════════════════════════════
     التوب 10 يترتب على النقاط ويعرض النقاط بس، والعسكري يشوف نقاطه ومركزه في "مكتبي".
]]

Config.Statistics = {
    Top = 10,                -- كم عسكري يظهر
    WebhookCooldown = 60,    -- ثواني بين كل إرسالين للتقرير (الويبهوك في config/server.lua)
}

--   Every  = كل كم (مخالفة / سجن / بلاغ / حجز) | EveryMinutes = كل كم دقيقة تواجد
--   Points = كم نقطة ياخذ عليها (0 = ما تنحسب)
Config.Points = {
    Fines      = { Every = 3, Points = 1 },         -- كل 3 مخالفات حررها = نقطة
    Jails      = { Every = 3, Points = 1 },         -- كل 3 سجن = نقطة
    Attendance = { EveryMinutes = 30, Points = 1 }, -- كل 30 دقيقة تواجد = نقطة
    Reports    = { Every = 2, Points = 1 },         -- البلاغات اللي أنجزها (0 = مطفي)
    Impounds   = { Every = 3, Points = 1 },         -- المركبات اللي حجزها (0 = مطفي)
}


--[[ ═══════════════════════════════════════════════════════════════════════
     18 ─ الآيباد وصور الشخصيات وإدارة اللوحة
     ═══════════════════════════════════════════════════════════════════════
     أمر وزر فتح الآيباد في القسم 5 ← Config.Commands.Ipad
]]

Config.Ipad = {
    Size = 0.75,              -- حجم الآيباد: نسبة من الشاشة (0.60 = 60%). كل ما صغر الرقم صغر
    Animation = true,         -- حركة مسك الآيباد
    Prop = "prop_cs_tablet",  -- موديل الآيباد في اليد
    AnimDict = "amb@code_human_in_bus_passenger_idles@female@tablet@base", -- الحركة
    AnimName = "base",
}

-- صورة شخصية اللاعب (تطلع في المطلوبين والبلاغات والهوية والشارة بدل صورة الديسكورد)
-- اللعبة نفسها تصوّر وجه الشخصية، وتنحفظ آخر صورة في قاعدة البيانات عشان تطلع حتى لو اللاعب طالع.
Config.Mugshot = {
    Enabled = true,        -- تشغيل صور الشخصيات
    FirstDelay = 25,       -- كم ثانية بعد دخول اللاعب قبل أول صورة (عشان تلبس الشخصية لبسها)
    RefreshMinutes = 10,   -- كل كم دقيقة يتأكد هل تغيّر لبسه أو شكله (ما يصوّر إلا إذا تغيّر)
    MaxAgeMinutes = 60,    -- يصوّر صورة جديدة بعد هالمدة حتى لو ما تغيّر شي (لو غيّر ملامح الوجه بس)
    RequestBurst = 5,      -- كم طلب صور ورا بعض يقدر يسوي اللاعب (حماية من السبام)
    RequestCooldown = 5,   -- بعدها لازم ينتظر كم ثانية
    KeepDays = 60,         -- صورة اللاعب تنحذف إذا ما دخل السيرفر من كم يوم (0 = تظل للأبد)
}

-- إدارة اللوحة: تبويب في الآيباد يتحكم في لون الواجهة والشفافية والأشكال ومواقع الإشعارات.
-- يظهر بس للي عنده البرمشن هذا في قروبه داخل vrp/cfg/groups.lua، مثال:
--     ["superadmin"] = { _config = { ... }, "police.panel", ... },
-- التغييرات تنحفظ في قاعدة البيانات وتوصل لكل اللاعبين مباشرة.
Config.PanelAdmin = {
    Enabled = true,               -- تشغيل تبويب إدارة اللوحة
    Permission = "player.owner",  -- اسم البرمشن في groups.lua
}


--[[ ═══════════════════════════════════════════════════════════════════════
     19 ─ الواجهة والإشعارات والأصوات
     ═══════════════════════════════════════════════════════════════════════
     كل "Style" هنا هو الشكل الافتراضي، وتقدر تغيّره من الآيباد ← إدارة اللوحة ← الواجهة.
]]

Config.UI = {
    -- عام
    Brand = "BoFaisaL | القيادة الأمنية",                  -- اسم فوق قائمة الآيباد (فاضي = "القائمة العسكرية")
    ServerName = "BoFaisaL RP",  -- اسم السيرفر اللي يطلع فوق في شريط الآيباد
    Accent = "#18b981",          -- اللون الأساسي (أزرق غامق)
    ArabicDigits = false,        -- true = أرقام عربية ٠١٢٣ | false = 0123
    Hints = true,                -- تلميح الأزرار وقت وضع الحواجز
    MarkerDistance = 7.0,       -- أقصى مسافة تبان منها علامات النقاط على الأرض (متر). أقل = استهلاك أقل
                                 -- (كل شكل له مسافته في config/config.lua ← 2.7، وهذا الحد الأعلى لها كلها)

    -- الإشعار (اليمين)
    NotifySeconds = 6,           -- كم ثانية يظل الإشعار
    NotifyStyle = "gradient",    -- شكله: "gradient" تدرّج لون | "ring" حلقة وقت | "classic" الشكل الافتراضي

    -- بطاقات اليسار (الاستعلام، التفتيش، الوصل...)
    InfoCardSeconds = 12,        -- كم ثانية تظل بطاقة الاستعلام
    CitizenCardSeconds = 20,     -- كم ثانية تظل بطاقة "استعلام عن مواطن" (أطول لأن فيها معلومات أكثر)
    InfoCardStyle = "file",      -- شكلها: "file" ملف شرطة | "classic" الشكل الافتراضي
    SkipKey = 166,               -- زر يسكّر بطاقات اليسار والهوية والشارة قبل وقتها (166 = F5)، false = بدون
                                 -- لو فيه نافذة تأكيد مفتوحة، الزر يكون للقبول
    CardPageSize = 8,            -- القوائم الطويلة في البطاقة (مثل الأسلحة في التفتيش) تنعرض كذا سطر بالصفحة
    CardPageKeys = { next = 175, prev = 174, nextLabel = "→", prevLabel = "←" }, -- أزرار الصفحة التالية / السابقة (175 = سهم يمين، 174 = سهم يسار)

    -- تلميح الزر (وضع الحواجز، إيقاف المراقبة): "pill" | "glass" | "bar" | "keycap"
    -- (وتقدر تغيّره من إدارة اللوحة ← الواجهة)
    KeyHintStyle = "glass",

    -- النوافذ
    ConfirmStyle = "compact",    -- نافذة التأكيد (F5 / F6): "compact" صغير بالنص | "classic" الشكل الافتراضي
    VehicleSearchStyle = "list", -- نافذة تفتيش المركبة: "list" قائمة نظيفة | "classic" الشكل الافتراضي
    FinesStyle = "cards",        -- نافذة المخالفات (نقطة السداد ومنصة أبشر): "cards" قائمة بطاقات | "classic" الشكل الافتراضي
    ImpoundStyle = "cards",      -- نافذة المركبات المحجوزة: "cards" بطاقة لكل مركبة | "classic" الشكل الافتراضي
}

-- أصوات اللعبة: { "اسم الصوت", "مجموعة الصوت" } أو false عشان تطفي صوت واحد
-- (صوت التعميم في القسم 14 ← Broadcast.Sound)
Config.Sounds = {
    Enabled = false,                                                -- false = يطفي كل الأصوات تحت
    Confirm   = { "Menu_Accept", "Phone_SoundSet_Default" },       -- وصلك طلب تأكيد (F5 / F6)
    Accept    = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },     -- قبلت الطلب
    Reject    = { "BACK", "HUD_FRONTEND_DEFAULT_SOUNDSET" },       -- رفضت الطلب
    IdCard    = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },     -- ظهرت بطاقة هوية
    Waypoint  = { "WAYPOINT_SET", "HUD_FRONTEND_DEFAULT_SOUNDSET" }, -- انحطت لك نقطة في الخريطة
    Escape    = { "CHECKPOINT_MISSED", "HUD_MINI_GAME_SOUNDSET" }, -- محاولة هروب من السجن
    Barricade = { "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET" },     -- انحط حاجز
}


--[[ ═══════════════════════════════════════════════════════════════════════
     20 ─ رسائل الشات
     ═══════════════════════════════════════════════════════════════════════
     كل إعلان = سطر أو أكثر في الشات، وكل سطر يبدأ باسم وزارة العسكري بين قوسين.
        enabled  = تشغيل الإعلان
        audience = مين يشوفه: "all" الكل | "officers" العساكر والمعنيين | "involved" المعنيين بس
        lines    = أسطر الرسالة (كل سطر رسالة لحالها في الشات)
     ألوان الشات: ^0 أبيض | ^3 أصفر | ^5 أزرق فاتح | ^1 أحمر | ^2 أخضر | ^6 بنفسجي
     المتغيرات: {officer} {officer_id} {target} {target_id} {ministry} {amount} {label} {minutes} {reason}
]]

Config.Chat = {
    Tag = "^3[{ministry}]",       -- أول كل سطر: وزارة العسكري (مثال: [وزارة الداخلية])
    DefaultTag = "الشرطة",        -- لو ما فيه عسكري (مثل انتهاء المحكومية)

    Jail = {
        enabled = true,
        audience = "all",
        lines = {
            "^5العسكري ^0{officer} ^5قام بسجن ^0{target}",
            "^3المدة : ^0{minutes} شهر ^0|| ^3السبب : ^0{reason}",
        },
    },
    Fine = {
        enabled = true,
        audience = "all",
        lines = {
            "^5العسكري ^0{officer} ^5قام بمخالفة ^0{target}",
            "^3المبلغ : ^0${amount} ^0|| ^3المخالفة : ^0{label}",
        },
    },
    JailRelease = {
        enabled = true,
        audience = "all",
        lines = {
            "^5العسكري ^0{officer} ^5قام بفك سجن ^0{target}",
        },
    },
    JailBail = {
        enabled = true,
        audience = "all",
        lines = {
            "^5تم دفع كفالة ^0{target} ^5من قبل ^0{officer}",   -- {officer} = اللي دفع الكفالة
        },
    },
    JailServed = {
        enabled = false,
        audience = "all",
        lines = {
            "^5تم الإفراج عن ^0{target} ^5بعد انتهاء محكوميته",
        },
    },
}

-- إضافات BoFaisaL: دعم مالي داخل اللعبة، دون ارتباط بخدمة إحسان الواقعية.
Config.Ehsan = {
    Enabled = true,
    Command = "ehsan",
    MaxTarget = 1000000,
    MinDonation = 1,
    MaxDonation = 100000,
    PageSize = 20,
    CreateCooldownHours = 24,
    RequireApproval = true,
    AdminPermission = "player.owner",
}
