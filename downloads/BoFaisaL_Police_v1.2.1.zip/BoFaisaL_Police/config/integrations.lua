--[[
    ════════════════════════════════════════════════════════════════════════
     الربط مع أنظمة السيرفر
    ════════════════════════════════════════════════════════════════════════
     السكربت ما يستبدل أنظمة سيرفرك. كل قسم هنا يحدد كيف السكربت يتكلم مع نظام
     موجود عندك (القائمة، الإنفنتوري، الكراج...).

     أنواع الربط اللي تتكرر:
        "vrp"           ← يستخدم دوال vRP مباشرة (الافتراضي في أغلب الأقسام)
        "builtin"       ← نظام السكربت نفسه
        "event"         ← يرسل إيفنت لنظام سيرفرك (تكتب اسم الإيفنت)
        "client_export" ← يستدعي export من سكربت ثاني عند اللاعب (تكتب resource و fn)
        "custom"        ← دالة Lua من عندك (تكتب الكود بنفسك)
        "none"          ← بدون

     format = دالة ترتب البيانات بالشكل اللي ينتظره نظام سيرفرك.
     إذا نظام مو شغّال، الكونسول يطبع "<الاسم> integration unavailable" والميزة تتعطل بهدوء.
]]

Config.Integrations = {

    -------------------------------------------------------------------------
    -- القائمة الرئيسية: "الشرطة" و "إبلاغ عن مجرم" تنضاف لقائمة vRP الموجودة
    -------------------------------------------------------------------------
    BuilderMenu = {
        type = "vrp",                  -- "vrp" = قائمة vRP | "builtin" = قائمة السكربت
        menu = "main",                 -- اسم قائمة vRP اللي تنضاف لها الخيارات
        headerColor = "rgba(24, 125, 82, 0.90)", -- لون رأس قائمة vRP
        ordering = "invisible",        -- vRP يرتب الخيارات أبجدياً:
                                       -- "invisible" يحافظ على ترتيب السكربت بدون ما يبان شي
                                       -- "numbers" يحط أرقام 1. 2. | "none" يخلي vRP يرتب
        builtin = { command = "bofaisal", key = "F7" }, -- أمر وزر قائمة السكربت (لو type = "builtin")
    },

    -------------------------------------------------------------------------
    -- النوافذ اللي تطلب كتابة (رقم الهوية، السبب...)
    -------------------------------------------------------------------------
    Popup = {
        type = "vrp",                  -- "vrp" = نافذة vRP (حقل حقل) | "builtin" = نافذة السكربت | "custom"
        timeout = 120,                 -- كم ثانية قبل ما تنلغي النافذة
        -- custom: لازم ترجع { [field.key] = "القيمة" } أو nil لو ألغى
        custom = function(source, title, fields) return nil end,
    },

    -------------------------------------------------------------------------
    -- إنفنتوري اللاعب (التفتيش، الممنوعات، أغراض العتاد)
    -------------------------------------------------------------------------
    Inventory = {
        type = "vrp",                  -- "vrp" | "custom"
        custom = {
            getItems = function(user_id, source) return {} end,       -- ترجع { { item = "id", label = "الاسم", amount = 1 } }
            getAmount = function(user_id, item) return 0 end,         -- كم عنده من غرض
            remove = function(user_id, item, amount) return false end, -- يسحب غرض
            give = function(user_id, item, amount) return false end,   -- يعطي غرض
        },
    },

    -------------------------------------------------------------------------
    -- الأسلحة (الاستيلاء على الأسلحة، العتاد)
    -------------------------------------------------------------------------
    Weapons = {
        type = "vrp",                  -- "vrp" | "builtin" (من اللعبة مباشرة) | "custom"
        custom = {
            get = function(source) return {} end,   -- ترجع { WEAPON_PISTOL = { ammo = 50 } }
            clear = function(source) end,           -- يسحب كل الأسلحة
            give = function(source, weapons) end,   -- يعطي أسلحة
        },
    },

    -------------------------------------------------------------------------
    -- صندوق المركبة (تفتيش مركبة)
    -------------------------------------------------------------------------
    VehicleInventory = {
        type = "vrp_chest",                 -- "vrp_chest" = صناديق vRP | "custom"
        key = "chest:u{owner}veh_{model}",  -- مفتاح صندوق المركبة في vRP
        custom = {
            getItems = function(vehicle) return {} end,               -- vehicle = { plate, owner, model }
            remove = function(vehicle, item, amount) return false end,
        },
    },

    -------------------------------------------------------------------------
    -- الكراج: معرفة مالك المركبة من اللوحة (السكربت ما يستبدل كراجك)
    -------------------------------------------------------------------------
    -- في vRP كل مركبات اللاعب لها نفس اللوحة (رقمه). السكربت يعرف المالك من اللوحة،
    -- ويعرف أي مركبة بالضبط من موديلها (المركبة اللي جنب العسكري).
    VehicleGarage = {
        type = "sql",                  -- "sql" = استعلام قاعدة بيانات | "export" | "custom"
        platePrefix = "P ",            -- حروف تنشال من بداية اللوحة قبل البحث
        plateIsUserId = true,          -- true = لو اللوحة رقم ولاعب بهالرقم موجود، هو المالك (لو ما لقاها الاستعلام تحت)
        sql = {
            -- لازم يرجع user_id (و model اختياري) للوحة
            ownerByPlate = "SELECT user_id FROM vrp_user_identities WHERE registration = ?",
            -- (اختياري) مركبات المالك عشان يعرف اسم الموديل
            ownerVehicles = "SELECT vehicle AS model FROM vrp_user_vehicles WHERE user_id = ?",
            -- للكراجات اللي تحفظ لوحة لكل مركبة:
            -- ownerByPlate = "SELECT user_id, vehicle AS model FROM vrp_user_vehicles WHERE vehicle_plate = ?",
        },
        export = { resource = "", fn = "" },     -- "export": exports[resource]:fn(plate) ← { owner = user_id, model = "adder" }
        custom = function(plate) return nil end, -- "custom": ترجع { owner = user_id, model = "adder" } أو nil
    },

    -------------------------------------------------------------------------
    -- حالة الحجز داخل كراجك
    -------------------------------------------------------------------------
    VehicleImpound = {
        type = "bofaisal",                -- "bofaisal" = الكراج يسأل السكربت (exports) | "sql" | "custom"
        -- "sql": أوامر تنفذ عند الحجز والفك. المتغيرات: @owner @model @plate @id
        sql = {
            onImpound = "UPDATE vrp_user_vehicles SET impounded = 1 WHERE user_id = @owner AND vehicle = @model",
            onRelease = "UPDATE vrp_user_vehicles SET impounded = 0 WHERE user_id = @owner AND vehicle = @model",
        },
        custom = {
            onImpound = function(record) end, -- عند الحجز
            onRelease = function(record) end, -- عند الفك
        },
    },

    -------------------------------------------------------------------------
    -- حفظ واسترجاع اللبس (لبس السجن)
    -------------------------------------------------------------------------
    Clothing = {
        type = "vrp",                  -- "vrp" | "builtin" (من اللعبة مباشرة) | "custom"
        custom = {
            get = function(source) return nil end,    -- يرجع اللبس الحالي
            set = function(source, clothing) end,     -- يلبّس لبس محفوظ
        },
    },

    -------------------------------------------------------------------------
    -- الكلبشة
    -------------------------------------------------------------------------
    Handcuff = {
        type = "vrp",                  -- "vrp" | "builtin" | "custom"
        custom = {
            isCuffed = function(source) return false end, -- هل اللاعب مكلبش
            setCuffed = function(source, state) end,      -- يكلبش / يفك
        },
    },

    -------------------------------------------------------------------------
    -- السحب
    -------------------------------------------------------------------------
    Drag = {
        type = "builtin",              -- "builtin" = سحب السكربت | "event" = إيفنت سيرفرك | "custom"
        event = "myserver:drag",       -- "event": اسم إيفنت السحب حق سيرفرك
        eventSide = "client",          -- "client" = يرسله للاعب | "server" = إيفنت سيرفر
        receiver = "target",           -- مين يستلم الإيفنت: "target" المسحوب | "officer" العسكري
        args = function(officerSource, targetSource) return { officerSource } end, -- البيانات المرسلة
        custom = function(officerSource, targetSource) end,
    },

    -------------------------------------------------------------------------
    -- إدخال وإخراج من المركبة
    -------------------------------------------------------------------------
    Seats = {
        type = "builtin",              -- "builtin" = السكربت يقعّده على كرسي فاضي (ينصح فيه) | "vrp" | "custom"
        custom = {
            putIn = function(targetSource, officerSource) end,   -- إدخال
            pullOut = function(targetSource, officerSource) end, -- إخراج
        },
    },

    -------------------------------------------------------------------------
    -- الفلوس (المخالفات، رسوم الحجز)
    -------------------------------------------------------------------------
    Money = {
        type = "vrp",                  -- "vrp" | "custom"
        custom = {
            pay = function(user_id, amount, method) return false end, -- يخصم. method: "wallet" | "bank" | "full"
            give = function(user_id, amount) end,                     -- يعطي
        },
    },

    -------------------------------------------------------------------------
    -- رسائل الشات
    -------------------------------------------------------------------------
    Chat = {
        type = "chat",                 -- "chat" = سكربت الشات الأساسي | "custom"
        custom = function(targets, title, message, color) end, -- targets = قائمة اللاعبين
    },

    -------------------------------------------------------------------------
    -- وظيفة اللاعب (استعلام عن مواطن، المطلوبين، الهوية)
    -------------------------------------------------------------------------
    Job = {
        type = "vrp",                  -- "vrp" = قروب نوعه job | "custom"
        unemployed = "بدون وظيفة",      -- النص لو ما عنده وظيفة
        custom = function(user_id, source) return nil end,
    },

    -------------------------------------------------------------------------
    -- صورة البروفايل (الآيباد، البلاغات، المطلوبين، الهوية)
    --   "discord" ← صورة الديسكورد المربوط. يحتاج توكن بوت ديسكورد في config/server.lua
    --               (DiscordBotToken). بدون توكن أو بدون ديسكورد ← يظهر أول حرف من الاسم.
    --   "steam"   ← صورة ستيم (يحتاج SteamApiKey في config/server.lua)
    --   "url"     ← رابط من عندك. المتغيرات: {user_id} {discord} {steam} {license}
    --   "custom"  ← دالتك ترجع رابط الصورة
    --   "none"    ← بدون صور
    -------------------------------------------------------------------------
    ProfileImage = {
        type = "discord",
        url = "https://example.com/avatars/{user_id}.png",
        cacheMinutes = 60,             -- كم دقيقة تنحفظ الصورة قبل ما تتحدث
        custom = function(user_id, source) return nil end,
    },
}
